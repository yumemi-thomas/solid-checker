# rc.17 sweep corpus: freeze and restore

The solid-checker rc.17 sweep corpus is 23 shallow git clones (13 GB with `node_modules`) with local edits
on top: Solid packages pinned to exact rc.17 versions, `@solidjs/signals` 2.0.0-rc.17 overrides, viviana's
`allowUnusedPatches: true`, and the lockfiles those installs produced. This directory is everything needed to
rebuild it with the same resolved dependency versions, without the original machine.

```
restore.mjs        clone each app at its pinned commit, lay the frozen files over it, frozen install, verify
fingerprint.mjs    deterministic fingerprint of every installed package under an apps dir
freeze.mjs         (maintainers) re-create apps/ from a live corpus
tools.json         package managers and exact install commands (also used by restore.mjs)
rc17-manifest.json repository, commit, installDir, packageManager per app (copy of solid-checker's manifest)
fingerprint.json   fingerprint of the original corpus
apps/<app>/        meta.json (provenance + sha256 of each frozen file), files/ (the modified and untracked
                   files, same relative paths: package.json edits, pnpm-workspace.yaml, every lockfile),
                   changes.patch (git diff against the pinned commit, for review only)
```

## Prerequisites

- node 24.22.1 (what the corpus was built and tested with; another node draws a warning, and has not been tested).
  `npx` comes with node.
- git (built with 2.54.0; only `git fetch --depth 1 <url> <sha>` is needed).
- Network access to github.com (clones; one lockfile also points at codeload.github.com) and
  registry.npmjs.org. No registry mirror or auth is assumed.
- Nothing else on PATH: **bun, pnpm, yarn and npm are not needed** and corepack is not used. Every tool runs as
  `npx -y <package>@<exact version>` (npm 11.19.1, bun 1.4.0, `@yarnpkg/cli-dist` 4.18.0, pnpm 10.15.0 / 10.32.1 /
  10.33.2 / 11.22.0 / 11.25.0 / 12.3.4, chosen per app), so the new machine gets the same versions whatever it has
  installed. They are recorded in `tools.json`.
- About 13 GB free for the apps plus the package-manager caches (about 7 GB with a cold cache).

## Restore

```sh
node restore.mjs --apps-root ../solid-checker-rc17-corpus/apps
```

Options (every location is an argument; the default `--apps-root` is relative to the current directory):

| option | meaning |
| --- | --- |
| `--apps-root <dir>` | where to restore; must not already hold the apps (default `../solid-checker-rc17-corpus/apps`) |
| `--only a,b` | restore only these apps |
| `--jobs N` | parallel installs (default 4); yarn apps always run alone, after the others |
| `--cache-root <dir>` | keep the npm, bun and pnpm-store caches under this directory instead of the user's own (use it for a cold-cache run, or to keep the caches out of `$HOME`) |
| `--writable` | skip the final read-only step |
| `--clone-to <dir>` | after restoring, make a writable copy (see below) |
| `--verify-only` | no clone, no install: fingerprint an existing tree and diff it (still makes it read-only unless `--writable`) |
| `--clone-only --clone-to <dir>` | just copy an existing restored tree (see below) |

Per app it:

1. `git init`, `git fetch --depth 1 <repository> <commit>`, checks out that commit, and checks `HEAD`.
2. Copies `apps/<app>/files/*` over the clone and checks each file against its recorded sha256.
3. Installs in `installDir` with the original package manager and version, frozen, lifecycle scripts off:

   | manager | command | extra env |
   | --- | --- | --- |
   | npm | `npm ci --ignore-scripts --no-audit --no-fund` | `CI=1` |
   | pnpm | `pnpm install --frozen-lockfile --ignore-scripts` | `CI=1` |
   | bun | `bun install --frozen-lockfile --ignore-scripts --minimum-release-age=0` | `CI=1` |
   | yarn | `yarn install --immutable --mode=skip-build` | `CI=1 YARN_NPM_MINIMAL_AGE_GATE=0 YARN_NODE_LINKER=node-modules YARN_ENABLE_IMMUTABLE_INSTALLS=1 YARN_ENABLE_GLOBAL_CACHE=0` |

   (The original build used the same commands without the frozen flags. `--frozen-lockfile`, `--immutable` and
   `npm ci` fail rather than rewrite a lockfile.) A failed install is retried up to 8 times; installs resume from
   what the previous attempt fetched.
4. **Fails loudly if the install changed anything**: after the install `git status` must list exactly the frozen
   files and every one must still have its recorded sha256.
5. Fingerprints the result and diffs it against `fingerprint.json`.

Exit status is 1 if any app failed or differs. `restore-logs/<app>.log` (one per app) and `restore-report.json`
are written next to the apps dir.

### Read-only result, and writable copies

The corpus is shared between worktrees and agents and must not drift, so after every selected app verified OK
`restore.mjs` makes the apps tree read-only (`chmod -R a-w <apps-root>`). Pass `--writable` to skip that. The
tree is left writable if any app failed.

- The checker only reads the corpus: a full 34-project sweep runs on the read-only tree with no errors.
- `git status` and other index-refreshing git commands in a read-only app may complain; use a copy for those.
- To delete a read-only tree: `chmod -R u+w <apps-root> && rm -rf <apps-root>`.

For anything that must modify files (installs, experiments), use a copy-on-write clone instead of the shared tree:

```sh
node restore.mjs --clone-only --apps-root <restored apps> --clone-to <writable apps>
# what it runs:
#   macOS:  cp -cR <restored apps> <writable apps> && chmod -R u+w <writable apps>      (APFS clonefile)
#   Linux:  cp -a --reflink=auto <restored apps> <writable apps> && chmod -R u+w <writable apps>
```

On APFS (and Linux filesystems with reflinks: btrfs, xfs) the file data is shared, so the copy costs almost no
extra disk; it still creates every directory entry, so allow time proportional to the number of files (see
Timing). Without reflink support the copy is a full 13 GB copy. `--clone-to <dir>` on a normal restore does the same
after the read-only step.

## Expected output

One line per app (`OK` = identical, `OK-noted` = identical except the noted, informational differences
below), a summary, and the read-only line:

```
OK               ai-memory-ui             npm             8s
OK-noted         compass-ui               bun@1.4.0      11s (noted: original-only store entries=32 hoist links=2)
...
OK               jandibat-web             yarn@4.18.0   165s

11 OK, 12 OK with noted differences, 0 failed, in 5m3s
report: .../restore-report.json   logs: .../restore-logs
read-only: chmod -R a-w .../apps   (use --clone-to for a writable copy-on-write copy)
```

Anything else (`FAIL`, `DIFF`, a `MISSING`/`EXTRA`/`STORE-EXTRA`/`KEY` line) is a real difference.

## What "matches" means

`fingerprint.mjs` records, per app, every package under every `node_modules` (workspace projects included):
`path`, `name@version` and a hash of its `package.json`; symlinks as `path -> target`; and for solid-js,
@solidjs/signals, @solidjs/web, @solidjs/compiler, @solidjs/h, @solidjs/universal, @solidjs/diagnostics,
@solidjs/router, @solidjs/vite-plugin, vite-plugin-solid, babel-preset-solid, babel-plugin-jsx-dom-expressions
and dom-expressions: version plus sha256 of `package.json` and of the main dist entry.
`node fingerprint.mjs --apps-root <dir> --out <file>` prints it for any tree (npm, bun hoisted and isolated, yarn
node-modules, pnpm layouts; PnP files are hashed if present).

Compared strictly, in both directions: every package outside a pnpm/bun store (all npm and yarn packages, the
app's own links into the store, workspace links) and the Solid toolchain packages.
Compared one way, informational (reported as `noted`, not failures): entries **only the original corpus has**
inside a pnpm/bun store, hoisting links, and platform-specific packages.

- **original-only store entries.** The original corpus was built by repeated incremental installs
  (`install --no-frozen-lockfile`, then pins, then more installs), which left stale store directories behind
  (e.g. `@solidjs/signals@2.0.0-rc.18` next to the live rc.17, old `@kobalte/core` alphas, `*_tmp_*` leftovers)
  and kept optional packages a fresh frozen install skips. Nothing links to them, and no frozen install can
  recreate them. A restore never has an entry the original lacks (that is a failure).
- **hoist links** (`node_modules/.pnpm/node_modules/*`, `.bun/node_modules/*`): which version of a name pnpm/bun
  hoists for phantom dependencies depends on install order.
- **platform-only**: packages declaring `os`/`cpu`/`libc` (esbuild, rollup, swc, lightningcss, oxc natives ...), their
  links, store directories reachable only through such packages, and store directories reached only through
  `optionalDependencies` (the wasm32 chain behind `@solidjs/compiler`). These legitimately differ by OS and CPU.
  On the machine that built the corpus they differ only in leftovers and peer variants of that wasm32 chain.

`restore-report.json` has the full lists.

## Timing (Apple silicon, macOS, 23 apps)

| run | wall time |
| --- | --- |
| first full restore, cold caches, 4 parallel (other jobs were running at the same time) | 28 min |
| full restore, warm caches, 4 parallel, yarn alone at the end | 5 min restore (yarn 2.5 min of it), 7 min total with tool warm-up |
| `--verify-only` | 20 s |

`cp -cR` of the restored tree: see the figure in the maintainers' report; it scales with file count, not bytes.

## Known caveats

- **Registry availability.** The frozen lockfiles pin exact versions and integrity hashes; a version unpublished or a
  repository history rewritten since 2026-10-25 makes that app fail (loudly). github.com must still serve the pinned
  commits.
- **Platform-specific packages** differ across OS/arch by design (above). On another OS expect `OK-noted` with
  platform-only differences; nothing else may differ.
- **yarn (jandibat-web) and EPERM.** On macOS yarn 4.18.0 sometimes fails to rename a freshly written cache zip
  (`EPERM: operation not permitted, rename ...zip.tmp`); under parallel load the retries did not converge, run alone
  it succeeds (usually on the first or second attempt). `restore.mjs` therefore runs yarn apps alone, after the pool,
  with retries. If you restore only that app, run it on its own.
- **Package-manager versions.** pnpm 10.x may switch to the version in a project's `packageManager` field; that is
  the original behaviour and part of the freeze. Running the tools through `npx -y` needs the npm registry too.
- **Engines.** oscartbeaumont-website declares `node >=25`; pnpm only warns (it did in the original build too).
- **`fingerprint.json` is the original corpus.** It is not the canonical frozen-install result; that is why the
  original-only entries above are noted rather than failures. Two restores of the same freeze are expected to
  produce identical trees.
- **Provenance of the lockfiles.** They are the files the original installs produced; this freeze does not
  re-resolve anything, so no newer Solid prerelease can enter.

## Re-freezing (maintainers)

```sh
node freeze.mjs --apps-root <live corpus apps> --manifest <rc17-manifest.json> --out <this directory>
```

Copies each app's modified and untracked files (never `node_modules` or `.yarn`), writes `changes.patch` and
`meta.json`, and refuses a corpus whose clones are not at the manifest commits. Refresh `fingerprint.json` with
`fingerprint.mjs` afterwards.
