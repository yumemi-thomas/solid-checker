#!/usr/bin/env node
// Freeze the local edits of the rc.17 sweep corpus: for every app, the files that differ from a
// clean clone at the pinned commit (modified + untracked, never node_modules / .yarn), plus a
// review patch and a meta.json with the provenance from the manifest.
//
//   node freeze.mjs [--apps-root <corpus/apps>] [--manifest <rc17-manifest.json>] [--out <dir>]
//   (defaults: ../solid-checker-rc17-corpus/apps, ./rc17-manifest.json next to this script, this script's directory)
//
// Read-only on the corpus (git status / git diff / copy).
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { copyFileSync, mkdirSync, readFileSync, rmSync, writeFileSync, existsSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, all) => (a.startsWith("--") ? [...acc, [a.slice(2), all[i + 1]]] : acc), []));
const appsRoot = resolve(args["apps-root"] ?? "../solid-checker-rc17-corpus/apps");
const manifestPath = resolve(args.manifest ?? join(here, "rc17-manifest.json"));
const out = resolve(args.out ?? here);
const manifest = JSON.parse(readFileSync(manifestPath, "utf8"));

const git = (cwd, ...a) => execFileSync("git", a, { cwd, maxBuffer: 1 << 28 });
const sha256 = (buf) => createHash("sha256").update(buf).digest("hex");

writeFileSync(join(out, "rc17-manifest.json"), readFileSync(manifestPath));
let total = 0;
for (const [app, info] of Object.entries(manifest.apps)) {
  const dir = join(appsRoot, app);
  const head = git(dir, "rev-parse", "HEAD").toString().trim();
  if (head !== info.commit) throw new Error(`${app}: HEAD ${head} is not the manifest commit ${info.commit}`);
  // -z porcelain: "XY path\0" (renames "XY new\0old\0"); untracked files listed individually.
  const entries = git(dir, "status", "--porcelain=v1", "-z", "--untracked-files=all").toString().split("\0").filter(Boolean);
  const files = [];
  const deleted = [];
  for (let i = 0; i < entries.length; i++) {
    const code = entries[i].slice(0, 2);
    const path = entries[i].slice(3);
    if (code[0] === "R" || code[1] === "R") throw new Error(`${app}: rename at ${path} is not handled`);
    if (code.includes("D")) deleted.push(path);
    else files.push(path);
  }
  const dest = join(out, "apps", app);
  rmSync(dest, { recursive: true, force: true });
  mkdirSync(dest, { recursive: true });
  const filesDir = join(dest, "files");
  const record = [];
  for (const rel of files.sort()) {
    if (/(^|\/)(node_modules|\.yarn)\//.test(rel)) throw new Error(`${app}: ${rel} must not be frozen`);
    const target = join(filesDir, rel);
    mkdirSync(dirname(target), { recursive: true });
    copyFileSync(join(dir, rel), target);
    record.push({ path: rel, sha256: sha256(readFileSync(join(dir, rel))), untracked: git(dir, "ls-files", "--", rel).length === 0 });
  }
  // changes.patch: tracked changes, then each untracked file as an addition (review only; restore copies the files).
  let patch = git(dir, "diff", "--no-color").toString();
  for (const f of record.filter((r) => r.untracked)) {
    try { execFileSync("git", ["diff", "--no-index", "--no-color", "--", "/dev/null", f.path], { cwd: dir, maxBuffer: 1 << 28 }); }
    catch (e) { if (e.status !== 1) throw e; patch += e.stdout.toString(); }
  }
  writeFileSync(join(dest, "changes.patch"), patch);
  writeFileSync(join(dest, "meta.json"), JSON.stringify({ app, repository: info.repository, commit: info.commit, installDir: info.installDir, packageManager: info.packageManager, files: record, deleted }, null, 2) + "\n");
  total += record.length;
  console.log(`${app}: ${record.length} files (${record.filter((r) => r.untracked).length} untracked), ${deleted.length} deleted`);
}
console.log(`frozen ${total} files for ${Object.keys(manifest.apps).length} apps into ${out}/apps`);
