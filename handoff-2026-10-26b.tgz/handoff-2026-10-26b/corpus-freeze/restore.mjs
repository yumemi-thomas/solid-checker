#!/usr/bin/env node
// Rebuild the rc.17 sweep corpus: clone each app at its pinned commit, lay the frozen edits
// over it, install with the original package manager in frozen mode, fingerprint, diff.
//
//   node restore.mjs [--apps-root <dir, default ../solid-checker-rc17-corpus/apps>] [--only a,b] [--jobs 4] [--cache-root <dir>]
//                    [--writable] [--clone-to <dir>]
//   node restore.mjs --verify-only --apps-root <existing apps>   (no clone/install: fingerprint + diff an existing tree)
//   node restore.mjs --clone-only --apps-root <existing apps> --clone-to <dir>
//
// --writable   leave the restored tree writable (default: `chmod -R a-w` once every selected app verified OK)
// --clone-to   after restoring (or with --clone-only, on its own) make a writable copy-on-write copy
//              (macOS `cp -cR`, Linux `cp -a --reflink=auto`, then `chmod -R u+w`)
// --cache-root put the npm, bun and pnpm-store caches under <dir> (default: the user's own caches)
import { spawn, execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { copyFileSync, createWriteStream, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { compareApp, fingerprint } from "./fingerprint.mjs";

const here = dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const flag = (name) => argv.includes(`--${name}`);
const opt = (name, fallback = undefined) => { const i = argv.indexOf(`--${name}`); return i === -1 ? fallback : argv[i + 1]; };
// Every location is an argument; the default apps root is relative to the current directory.
const appsRoot = resolve(opt("apps-root", "../solid-checker-rc17-corpus/apps"));
const freezeDir = resolve(opt("freeze-dir", here));
const only = opt("only") ? opt("only").split(",") : null;
const jobs = Number(opt("jobs", 4));
const cacheRoot = opt("cache-root") ? resolve(opt("cache-root")) : null;
const cloneTo = opt("clone-to") ? resolve(opt("clone-to")) : null;
const sha256 = (buf) => createHash("sha256").update(buf).digest("hex");

function makeClone(from, to, apps = null) {
  if (existsSync(to) && readdirSync(to).length) throw new Error(`--clone-to ${to} exists and is not empty`);
  mkdirSync(to, { recursive: true });
  const cp = process.platform === "darwin" ? ["-cR"] : ["-a", "--reflink=auto"];
  // `--only` copies just those apps; the per-file cost of a clone makes the full tree take a long time.
  for (const entry of apps ?? readdirSync(from)) {
    console.log(`clone: cp ${cp.join(" ")} ${join(from, entry)} ${to}/`);
    execFileSync("cp", [...cp, join(from, entry), to + "/"], { stdio: "inherit" });
  }
  execFileSync("chmod", ["-R", "u+w", to], { stdio: "inherit" });
  console.log(`clone: ${to} is writable (copy-on-write where the filesystem supports it)`);
}
if (flag("clone-only")) {
  if (!cloneTo) { console.error("--clone-only needs --clone-to"); process.exit(2); }
  makeClone(appsRoot, cloneTo, only);
  process.exit(0);
}

const tools = JSON.parse(readFileSync(join(freezeDir, "tools.json"), "utf8"));
const wantFingerprint = JSON.parse(readFileSync(join(freezeDir, "fingerprint.json"), "utf8"));
const manifest = JSON.parse(readFileSync(join(freezeDir, "rc17-manifest.json"), "utf8"));
const metas = readdirSync(join(freezeDir, "apps")).sort().map((app) => JSON.parse(readFileSync(join(freezeDir, "apps", app, "meta.json"), "utf8")));
for (const m of metas) if (manifest.apps[m.app]?.commit !== m.commit) throw new Error(`${m.app}: frozen commit differs from the manifest`);
const selected = metas.filter((m) => !only || only.includes(m.app));
if (only) for (const name of only) if (!metas.some((m) => m.app === name)) throw new Error(`unknown app ${name}`);
if (process.version.slice(1) !== tools.node) console.warn(`warning: node ${process.version} (the corpus was built with ${tools.node}); npm lockfile handling is pinned via npx npm@${tools.npm.version}`);

const logsDir = join(dirname(appsRoot), "restore-logs");
mkdirSync(logsDir, { recursive: true });
mkdirSync(appsRoot, { recursive: true });

const env = { ...process.env, ...tools.env.all };
if (cacheRoot) {
  Object.assign(env, { npm_config_cache: join(cacheRoot, "npm"), BUN_INSTALL_CACHE_DIR: join(cacheRoot, "bun"), npm_config_store_dir: join(cacheRoot, "pnpm-store") });
  mkdirSync(cacheRoot, { recursive: true });
}

function run(cmd, args, cwd, log, extraEnv = {}) {
  return new Promise((res, rej) => {
    log.write(`\n$ ${cmd} ${args.join(" ")}  (cwd ${cwd})\n`);
    const p = spawn(cmd, args, { cwd, env: { ...env, ...extraEnv }, stdio: ["ignore", "pipe", "pipe"] });
    let tail = "";
    const keep = (d) => { const s = d.toString(); log.write(s); tail = (tail + s).slice(-3000); };
    p.stdout.on("data", keep); p.stderr.on("data", keep);
    p.on("error", rej);
    p.on("close", (code) => (code === 0 ? res(tail) : rej(new Error(`${cmd} ${args.slice(0, 3).join(" ")} exited ${code}\n${tail}`))));
  });
}

function installSpec(pm) {
  const [tool, version] = pm.split("@");
  if (tool === "npm") return { spec: `npm@${tools.npm.version}`, args: tools.install.npm, env: {} };
  if (tool === "pnpm") return { spec: `pnpm@${version}`, args: tools.install.pnpm, env: {} };
  if (tool === "bun") { if (version !== tools.bun.version) throw new Error(`bun@${version} is not the pinned ${tools.bun.version}`); return { spec: `bun@${version}`, args: tools.install.bun, env: {} }; }
  if (tool === "yarn") { if (version !== tools.yarn.version) throw new Error(`yarn@${version} is not the pinned ${tools.yarn.version}`); return { spec: `${tools.yarn.package}@${version}`, args: tools.install.yarn, env: tools.env.yarn }; }
  throw new Error(`unknown package manager ${pm}`);
}

function gitChanged(dir) {
  const out = execFileSync("git", ["status", "--porcelain=v1", "-z", "--untracked-files=all"], { cwd: dir, maxBuffer: 1 << 28 }).toString().split("\0").filter(Boolean);
  return out.map((e) => ({ code: e.slice(0, 2), path: e.slice(3) })).sort((a, b) => (a.path < b.path ? -1 : 1));
}

// A frozen install must leave every frozen file untouched and create no other tracked/untracked file;
// the installed packages must then match the recorded fingerprint.
function verifyTree(meta, dir, result) {
  const want = [...meta.files.map((f) => f.path), ...meta.deleted].sort();
  const got = gitChanged(dir).map((c) => c.path).sort();
  if (JSON.stringify(want) !== JSON.stringify(got)) throw new Error(`working tree differs from the frozen edits: missing ${JSON.stringify(want.filter((p) => !got.includes(p)))}, unexpected ${JSON.stringify(got.filter((p) => !want.includes(p)))}`);
  for (const f of meta.files) if (sha256(readFileSync(join(dir, f.path))) !== f.sha256) throw new Error(`${f.path} differs from the frozen file`);
  const diff = compareApp(wantFingerprint[meta.app], fingerprint(appsRoot, [meta.app])[meta.app]);
  result.diff = diff;
  result.status = diff.exact ? "OK" : diff.ok ? "OK-noted" : "DIFF";
}

function summarize(r) {
  if (r.status === "FAIL") return r.error.split("\n")[0];
  const d = r.diff;
  const fail = [["missing", d.missing], ["extra", d.extra], ["storeExtra", d.storeExtra], ["key", d.key], ["pnp", d.pnp]].filter(([, v]) => v.length).map(([k, v]) => `${k}=${v.length}`);
  const info = [["original-only store entries", d.leftover], ["hoist links", d.hoist], ["platform-only", d.platformOnly]].filter(([, v]) => v.length).map(([k, v]) => `${k}=${v.length}`);
  return [fail.length ? `DIFFERENT ${fail.join(" ")}` : "", info.length ? `(noted: ${info.join(" ")})` : ""].filter(Boolean).join(" ");
}

async function restoreApp(meta) {
  const dir = join(appsRoot, meta.app);
  const log = createWriteStream(join(logsDir, `${meta.app}.log`), { flags: "w" });
  const started = Date.now();
  const result = { app: meta.app, packageManager: meta.packageManager };
  try {
    if (existsSync(dir) && readdirSync(dir).length) throw new Error(`${dir} already exists and is not empty (restore into a fresh directory)`);
    mkdirSync(dir, { recursive: true });
    await run("git", ["init", "-q"], dir, log);
    await run("git", ["fetch", "--depth", "1", "-q", meta.repository, meta.commit], dir, log).catch(() => run("git", ["fetch", "--depth", "1", "-q", meta.repository, meta.commit], dir, log));
    await run("git", ["checkout", "-q", "FETCH_HEAD"], dir, log);
    const head = execFileSync("git", ["rev-parse", "HEAD"], { cwd: dir }).toString().trim();
    if (head !== meta.commit) throw new Error(`cloned ${head}, wanted ${meta.commit}`);
    for (const f of meta.files) {
      const target = join(dir, f.path);
      mkdirSync(dirname(target), { recursive: true });
      copyFileSync(join(freezeDir, "apps", meta.app, "files", f.path), target);
      if (sha256(readFileSync(target)) !== f.sha256) throw new Error(`frozen file ${f.path} does not match its recorded sha256`);
    }
    for (const f of meta.deleted) rmSync(join(dir, f), { force: true });
    const { spec, args, env: toolEnv } = installSpec(meta.packageManager);
    const installDir = join(dir, meta.installDir);
    // Retry: a frozen install is idempotent and resumes from what the previous attempt fetched.
    // (yarn on macOS intermittently fails a cache-file rename with EPERM; a re-run converges.)
    for (let attempt = 1; ; attempt++) {
      try { await run("npx", ["-y", spec, ...args], installDir, log, toolEnv); break; }
      catch (e) { if (attempt >= 8) throw e; log.write(`\ninstall attempt ${attempt} failed, retrying\n`); result.retries = attempt; }
    }

    verifyTree(meta, dir, result);
  } catch (e) {
    result.status = "FAIL";
    result.error = String(e.message).slice(-1500);
  }
  result.seconds = Math.round((Date.now() - started) / 1000);
  log.write(`\n=> ${result.status} in ${result.seconds}s\n`);
  log.end();
  console.log(`${result.status.padEnd(16)} ${meta.app.padEnd(24)} ${meta.packageManager.padEnd(12)} ${String(result.seconds).padStart(4)}s ${summarize(result)}`);
  return result;
}

const verifyOnly = flag("verify-only");
// Warm each distinct tool once, serially: concurrent first-time `npx -y` runs race on a cold cache.
const warmLog = createWriteStream(join(logsDir, "_tools.log"), { flags: "w" });
if (!verifyOnly) for (const spec of [...new Set(selected.map((m) => installSpec(m.packageManager).spec))]) await run("npx", ["-y", spec, "--version"], dirname(appsRoot), warmLog);
warmLog.end();

const started = Date.now();
// yarn runs alone after the parallel pool: under load its cache-file renames fail with EPERM on macOS
// (retries do not converge); run alone it restores in one or two attempts.
const queue = selected.filter((m) => !m.packageManager.startsWith("yarn"));
const yarnApps = selected.filter((m) => m.packageManager.startsWith("yarn"));
const results = [];
if (verifyOnly) {
  for (const meta of selected) {
    const result = { app: meta.app, packageManager: meta.packageManager, seconds: 0 };
    try { verifyTree(meta, join(appsRoot, meta.app), result); } catch (e) { result.status = "FAIL"; result.error = String(e.message).slice(-1500); }
    console.log(`${result.status.padEnd(16)} ${meta.app.padEnd(24)} ${summarize(result)}`);
    results.push(result);
  }
} else {
  await Promise.all(Array.from({ length: Math.max(1, jobs) }, async () => { while (queue.length) results.push(await restoreApp(queue.shift())); }));
  for (const meta of yarnApps) results.push(await restoreApp(meta));
}
results.sort((a, b) => (a.app < b.app ? -1 : 1));
const seconds = Math.round((Date.now() - started) / 1000);

const bad = results.filter((r) => r.status === "FAIL" || r.status === "DIFF");
const platform = results.filter((r) => r.status === "OK-noted");
console.log(`\n${results.length - bad.length - platform.length} OK, ${platform.length} OK with noted differences, ${bad.length} failed, in ${Math.floor(seconds / 60)}m${seconds % 60}s`);
for (const r of results.filter((x) => x.diff && (x.status === "DIFF" || x.diff.platformOnly.length || x.diff.leftover.length || x.diff.hoist.length))) {
  console.log(`\n${r.app}:`);
  const show = (label, list, n = 6) => { for (const p of list.slice(0, n)) console.log(`  ${label.padEnd(10)} ${typeof p === "string" ? p : JSON.stringify(p)}`); if (list.length > n) console.log(`  ${label.padEnd(10)} ... ${list.length - n} more (restore-report.json)`); };
  show("MISSING", r.diff.missing); show("EXTRA", r.diff.extra); show("STORE-EXTRA", r.diff.storeExtra); show("KEY", r.diff.key);
  show("leftover", r.diff.leftover, 3); show("hoist", r.diff.hoist, 2); show("platform", r.diff.platformOnly, 3);
}
const report = join(dirname(appsRoot), "restore-report.json");
writeFileSync(report, JSON.stringify({ seconds, results: results.map(({ diff, ...r }) => ({ ...r, differences: diff ?? null })) }, null, 1));
console.log(`report: ${report}   logs: ${logsDir}`);

if (bad.length) { console.error(`\nNOT making the tree read-only: ${bad.length} app(s) failed (${bad.map((r) => r.app).join(", ")})`); process.exit(1); }
if (flag("writable")) console.log("--writable: tree left writable");
else {
  // Shared corpora must not drift: nothing may write inside a verified tree. (`rm -rf` it later with `chmod -R u+w` first.)
  execFileSync("chmod", ["-R", "a-w", appsRoot], { stdio: "inherit" });
  console.log(`read-only: chmod -R a-w ${appsRoot}   (use --clone-to for a writable copy-on-write copy)`);
}
if (cloneTo) makeClone(appsRoot, cloneTo, only);
