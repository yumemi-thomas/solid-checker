#!/usr/bin/env node
// Deterministic fingerprint of every package installed under a corpus apps dir.
//
//   node fingerprint.mjs [--apps-root <dir, default ../solid-checker-rc17-corpus/apps>] [--only a,b] [--out file.json]
//
// Per app: every `node_modules` directory at any depth in the app (workspace projects included),
// walked the way package managers lay them out: npm/bun(hoisted)/yarn(node-modules) nest
// `node_modules` inside packages; pnpm and bun's isolated linker keep the real packages in
// `node_modules/.pnpm|.bun/<id>/node_modules/<name>` and symlink everything else.
//
// An entry is `<path relative to the app>\t<name>@<version>\t<sha256 of its package.json, 16 hex>`,
// or `<path>\t-> <symlink target>` (an absolute target is rewritten relative to the apps root).
// Entries fall into four lists:
//   packages  everything outside a pnpm/bun store: nested node_modules packages, workspace links, the
//             app's direct links into the store. Compared strictly, both directions.
//   store     real packages and links inside a store (`.pnpm/<id>/node_modules/...`). A fresh frozen
//             install may lack entries an older incremental install left behind, never the reverse
//             (see compareApp).
//   hoist     the store's private hoisting links (`.pnpm/node_modules/*`): which version of a name gets
//             hoisted depends on install order, so they are informational.
//   platform  packages whose package.json declares `os`, `cpu` or `libc` (esbuild/rollup/swc natives ...)
//             and links to them: informational, they legitimately differ by OS/arch.
// `key` holds the Solid toolchain packages (KEY_PACKAGES) with their version and the sha256 of their
// package.json and of their main dist entry.
import { createHash } from "node:crypto";
import { existsSync, lstatSync, readFileSync, readdirSync, readlinkSync, realpathSync, statSync, writeFileSync } from "node:fs";
import { isAbsolute, join, relative, resolve, sep } from "node:path";
import { pathToFileURL } from "node:url";

export const KEY_PACKAGES = new Set([
  "solid-js", "@solidjs/signals", "@solidjs/web", "@solidjs/compiler", "@solidjs/h", "@solidjs/universal", "@solidjs/diagnostics",
  "babel-preset-solid", "babel-plugin-jsx-dom-expressions", "dom-expressions", "@solidjs/vite-plugin", "vite-plugin-solid", "@solidjs/router",
]);
const IN_STORE = /(^|\/)node_modules\/\.(pnpm|bun)\//;

const sha256 = (buf) => createHash("sha256").update(buf).digest("hex");
const readJson = (file) => { try { return JSON.parse(readFileSync(file, "utf8")); } catch { return null; } };
const posix = (p) => p.split(sep).join("/");

function exportsEntry(exp) {
  if (typeof exp === "string") return exp;
  if (!exp || typeof exp !== "object") return null;
  const root = "." in exp ? exp["."] : exp;
  if (typeof root === "string") return root;
  if (!root || typeof root !== "object") return null;
  for (const cond of ["node", "import", "module", "default", "browser", "require"]) {
    const hit = exportsEntry(root[cond]);
    if (hit) return hit;
  }
  return null;
}
function mainEntry(pkgDir, pj) {
  const candidates = [exportsEntry(pj.exports), pj.module, pj.main, "index.js"].filter((c) => typeof c === "string");
  for (const c of candidates) {
    const file = join(pkgDir, c);
    if (existsSync(file) && statSync(file).isFile()) return { path: posix(c.replace(/^\.\//, "")), sha256: sha256(readFileSync(file)) };
  }
  return null;
}

function fingerprintApp(appDir, appsRoot) {
  const records = [];
  const key = {};
  const appReal = realpathSync(appDir);
  const rel = (p) => posix(relative(appDir, p));
  const STORE_ID = /^((?:.*\/)?node_modules\/\.(?:pnpm|bun)\/[^/]+)\/node_modules\//;
  const idOf = (relPath) => STORE_ID.exec(relPath)?.[1] ?? null;

  // `hoistDir` is true inside the store's own `node_modules` (the hoisting directory).
  function addPackage(pkgPath, hoistDir) {
    const st = lstatSync(pkgPath);
    const where = rel(pkgPath);
    const rec = { hoist: hoistDir, store: IN_STORE.test(where), owner: hoistDir ? null : idOf(where), target: null, platform: false, line: null };
    if (st.isSymbolicLink()) {
      let target = readlinkSync(pkgPath);
      if (isAbsolute(target)) target = posix(relative(appsRoot, target));
      let real = null;
      try { real = realpathSync(pkgPath); } catch { /* dangling */ }
      const pj = real ? readJson(join(real, "package.json")) : null;
      rec.platform = !!(pj && (pj.os || pj.cpu || pj.libc));
      rec.target = real ? idOf(posix(relative(appReal, real)) + "/node_modules/") : null;
      rec.line = `${where}\t-> ${target}`;
      rec.linkName = /node_modules\/((?:@[^/]+\/)?[^/]+)$/.exec(where)?.[1] ?? null;
      records.push(rec);
      return;
    }
    if (!st.isDirectory()) return;
    const pj = readJson(join(pkgPath, "package.json"));
    const pjHash = pj ? sha256(readFileSync(join(pkgPath, "package.json"))).slice(0, 16) : "-";
    rec.line = `${where}\t${pj ? `${pj.name}@${pj.version}` : "(no package.json)"}\t${pjHash}`;
    rec.platform = !!(pj && (pj.os || pj.cpu || pj.libc));
    rec.optional = pj ? Object.keys(pj.optionalDependencies ?? {}) : [];
    records.push(rec);
    if (pj && KEY_PACKAGES.has(pj.name)) key[where] = { name: pj.name, version: pj.version, packageJson: sha256(readFileSync(join(pkgPath, "package.json"))), main: mainEntry(pkgPath, pj) };
    if (existsSync(join(pkgPath, "node_modules"))) walkModules(join(pkgPath, "node_modules"), false);
  }

  function walkModules(nm, hoistDir) {
    for (const name of readdirSync(nm).sort()) {
      if (name === ".pnpm" || name === ".bun") {
        const dir = join(nm, name);
        for (const id of readdirSync(dir).sort()) {
          if (id.startsWith(".")) continue;
          // `<store>/node_modules` is the hoisting directory (symlinks only); the others hold one real package each.
          if (id === "node_modules") walkModules(join(dir, id), true);
          else if (existsSync(join(dir, id, "node_modules"))) walkModules(join(dir, id, "node_modules"), false);
        }
        continue;
      }
      if (name.startsWith(".")) continue;
      const path = join(nm, name);
      if (name.startsWith("@") && lstatSync(path).isDirectory()) {
        for (const sub of readdirSync(path).sort()) addPackage(join(path, sub), hoistDir);
      } else addPackage(path, hoistDir);
    }
  }

  function findModules(dir) {
    for (const e of readdirSync(dir, { withFileTypes: true }).sort((a, b) => (a.name < b.name ? -1 : 1))) {
      if (!e.isDirectory() || e.name === ".git") continue;
      const p = join(dir, e.name);
      if (e.name === "node_modules") walkModules(p, false);
      else findModules(p);
    }
  }
  findModules(appDir);

  // Store directories that exist only for platform-specific packages are platform entries too: the wasm32 chain
  // behind @solidjs/compiler (its optionalDependencies compiler-wasm32-wasi, then @emnapi/*, @napi-rs/wasm-runtime,
  // @tybys/wasm-util ...) is linked in different peer variants depending on install history. A store directory is
  // platform-exclusive when it holds a package with os/cpu/libc, is an optionalDependency of the package that
  // links it, or only receives links from platform-exclusive directories (never from an app link or an ordinary
  // package).
  const optionalOf = new Map();
  for (const r of records) if (r.owner && r.optional) optionalOf.set(r.owner, new Set(r.optional));
  const incoming = new Map();
  const platformIds = new Set();
  for (const r of records) {
    if (r.owner && !r.hoist && r.platform && !r.line.includes("\t->")) platformIds.add(r.owner);
    if (!r.target || r.hoist) continue;
    if (r.owner && r.linkName && optionalOf.get(r.owner)?.has(r.linkName)) { platformIds.add(r.target); r.platform = true; continue; }
    (incoming.get(r.target) ?? incoming.set(r.target, []).get(r.target)).push(r.owner);
  }
  for (let grew = true; grew;) {
    grew = false;
    for (const [id, owners] of incoming) if (!platformIds.has(id) && owners.every((o) => o && platformIds.has(o))) { platformIds.add(id); grew = true; }
  }
  const packages = [], store = [], hoist = [], platform = [];
  for (const r of records) (r.platform || (r.owner && platformIds.has(r.owner)) ? platform : r.hoist ? hoist : r.store ? store : packages).push(r.line);
  const pnp = [];
  for (const f of [".pnp.cjs", ".pnp.js", ".pnp.loader.mjs"]) if (existsSync(join(appDir, f))) pnp.push(`${f}\t${sha256(readFileSync(join(appDir, f)))}`);
  for (const list of [packages, store, hoist, platform]) list.sort();
  return { counts: { packages: packages.length, store: store.length, hoist: hoist.length, platform: platform.length }, key, packages, store, hoist, platform, pnp };
}

export function fingerprint(appsRoot, only = null) {
  const root = resolve(appsRoot);
  const apps = readdirSync(root, { withFileTypes: true }).filter((e) => e.isDirectory() && (!only || only.includes(e.name))).map((e) => e.name).sort();
  return Object.fromEntries(apps.map((app) => [app, fingerprintApp(join(root, app), root)]));
}

const minus = (a, b) => { const s = new Set(b); return a.filter((x) => !s.has(x)); };

// Compare an installed app (`got`) with the recorded fingerprint (`want`).
//   fail:  packages outside a store differ either way; a store entry exists in `got` but not in `want`; a Solid
//          toolchain package differs, or exists in `got` only.
//   info:  `leftover`  store entries only `want` has (an incremental install leaves stale store dirs, and keeps
//                      optional packages a fresh frozen install skips)
//          `hoist`     hoisting-link differences, `platformOnly` os/cpu-specific packages.
export function compareApp(want, got) {
  const d = {
    missing: minus(want.packages, got.packages), extra: minus(got.packages, want.packages),
    storeExtra: minus(got.store, want.store), leftover: minus(want.store, got.store),
    hoist: [...minus(want.hoist, got.hoist).map((x) => `- ${x}`), ...minus(got.hoist, want.hoist).map((x) => `+ ${x}`)],
    platformOnly: [...minus(want.platform, got.platform).map((x) => `- ${x}`), ...minus(got.platform, want.platform).map((x) => `+ ${x}`)],
    key: [], pnp: [],
  };
  for (const k of new Set([...Object.keys(want.key), ...Object.keys(got.key)])) {
    if (JSON.stringify(want.key[k]) === JSON.stringify(got.key[k])) continue;
    if (want.key[k] && !got.key[k] && IN_STORE.test(k)) continue; // a leftover store dir, counted in `leftover`
    d.key.push({ path: k, want: want.key[k] ?? null, got: got.key[k] ?? null });
  }
  if (JSON.stringify(want.pnp) !== JSON.stringify(got.pnp)) d.pnp.push(`${want.pnp} != ${got.pnp}`);
  d.ok = !d.missing.length && !d.extra.length && !d.storeExtra.length && !d.key.length && !d.pnp.length;
  d.exact = d.ok && !d.leftover.length && !d.hoist.length && !d.platformOnly.length;
  return d;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const args = Object.fromEntries(process.argv.slice(2).reduce((acc, a, i, all) => (a.startsWith("--") ? [...acc, [a.slice(2), all[i + 1]]] : acc), []));
  const result = fingerprint(args["apps-root"] ?? "../solid-checker-rc17-corpus/apps", args.only ? args.only.split(",") : null);
  const text = JSON.stringify(result, null, 1) + "\n";
  if (args.out) writeFileSync(args.out, text);
  else process.stdout.write(text);
  for (const [app, fp] of Object.entries(result)) console.error(`${app}: ${Object.entries(fp.counts).map(([k, v]) => `${v} ${k}`).join(", ")}`);
}
