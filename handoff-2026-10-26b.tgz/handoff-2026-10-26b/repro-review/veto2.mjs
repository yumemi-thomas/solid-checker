import {readFileSync} from "node:fs";
import {relative} from "node:path";
const S="/Users/thomas.guehenneux/EDF/tmp/sc-sweep/";
const nov=JSON.parse(readFileSync(S+"rc17-sweep-head-noveto.json","utf8"));
const cls=JSON.parse(readFileSync("classified.json","utf8"));
const cases=JSON.parse(readFileSync("/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker/fixtures/uncertifiable-repro/cases.json","utf8")).cases;
const caseFor=(c)=>{let b=null,l=-1;for(const e of cases)for(const p of e.causes)if((c===p||c.startsWith(p+"/"))&&p.length>l){b=e;l=p.length;}return b;};
const projs=new Set(nov.results.map(r=>r.app+"|"+r.project));
const vetoAll=cls.filter(e=>/dispatch-veto/.test(e.cause));
console.log("all dispatch-veto attributed:",vetoAll.length,"in noveto projects:",vetoAll.filter(e=>projs.has(e.app+"|"+e.project)).length);
// per case: weight attributed, how many gone in noveto
const k=(a,p,r,pa,l)=>[a,p,r,pa,l].join("|");
const nc=new Map();
for(const row of nov.results) for(const f of row.findings){ if(f.kind!=="uncertifiable")continue; const kk=k(row.app,row.project,f.id,relative(row.root,f.primaryLocation.path),f.primaryLocation.line); nc.set(kk,(nc.get(kk)||0)+1);}
const perCase={};
for(const e of cls){ if(!projs.has(e.app+"|"+e.project)) continue; const c=caseFor(e.cause); const id=c?c.id:"(none)"; const kk=k(e.app,e.project,e.rule,e.path,e.line); const n=nc.get(kk)||0; const st=n>0?"stay":"gone"; if(n>0)nc.set(kk,n-1); const s=perCase[id]??={stay:0,gone:0}; s[st]++; }
const rows=Object.entries(perCase).filter(([,s])=>s.gone>0).sort((a,b)=>b[1].gone-a[1].gone);
for(const [id,s] of rows) console.log(id.padEnd(40),"gone",s.gone,"stay",s.stay);
