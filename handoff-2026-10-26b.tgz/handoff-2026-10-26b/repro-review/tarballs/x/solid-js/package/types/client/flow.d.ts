import type { Accessor, RevealOrder } from "@solidjs/signals";
export type { RevealOrder };
import type { Element as SolidElement } from "../types.js";
type NonZeroParams<T extends (...args: any[]) => any> = Parameters<T>["length"] extends 0 ? never : T;
type ErrorAccessor = Accessor<unknown>;
type ConditionalRenderCallback<T> = (item: Accessor<NonNullable<T>>) => SolidElement;
type KeyedConditionalRenderCallback<T> = (item: NonNullable<T>) => SolidElement;
type ConditionalRenderChildren<T, F extends ConditionalRenderCallback<T> = ConditionalRenderCallback<T>> = SolidElement | NonZeroParams<F>;
type KeyedConditionalRenderChildren<T, F extends KeyedConditionalRenderCallback<T> = KeyedConditionalRenderCallback<T>> = SolidElement | NonZeroParams<F>;
/**
 * Creates a list of elements from a list.
 *
 * Receives a map function as its child and returns a JSX element for each
 * list item; if the list is empty, an optional `fallback` is rendered instead.
 *
 * The child callback shape follows the keying mode:
 * - default / `keyed={true}` receives `(item, index)` where `item` is the raw
 *   row value and `index` is an accessor.
 * - `keyed={false}` receives `(item, index)` where `item` is an accessor and
 *   `index` is a stable number.
 * - `keyed={(item) => key}` receives accessors for both arguments.
 *
 * @example
 * ```tsx
 * <For each={items} fallback={<div>No items</div>}>
 *   {(item, index) => <div data-index={index()}>{item.label}</div>}
 * </For>
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/for
 */
export declare function For<T extends readonly any[], U extends SolidElement>(props: {
    each: T | undefined | null | false;
    fallback?: SolidElement;
    keyed?: true;
    children: (item: T[number], index: Accessor<number>) => U;
}): SolidElement;
export declare function For<T extends readonly any[], U extends SolidElement>(props: {
    each: T | undefined | null | false;
    fallback?: SolidElement;
    keyed: false;
    children: (item: Accessor<T[number]>, index: number) => U;
}): SolidElement;
export declare function For<T extends readonly any[], U extends SolidElement>(props: {
    each: T | undefined | null | false;
    fallback?: SolidElement;
    keyed: (item: T[number]) => any;
    children: (item: Accessor<T[number]>, index: Accessor<number>) => U;
}): SolidElement;
/**
 * Creates a list of elements from a count.
 *
 * Receives a map function as its child that takes the index and returns a JSX
 * element; if the count is zero, an optional `fallback` is rendered instead.
 *
 * @example
 * ```tsx
 * <Repeat count={items.length} fallback={<div>No items</div>}>
 *   {(index) => <div data-index={index}>{items[index]}</div>}
 * </Repeat>
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/repeat
 */
export declare function Repeat<T extends SolidElement>(props: {
    count: number;
    from?: number | undefined;
    fallback?: SolidElement;
    children: ((index: number) => T) | T;
}): SolidElement;
/**
 * Conditionally renders its children when `when` is truthy, otherwise renders
 * the optional `fallback`.
 *
 * The function-child form receives a narrowed value. Without `keyed`
 * (default), it receives an accessor and the child is preserved across truthy
 * values; with `keyed`, it receives the raw value and remounts whenever the
 * value's identity changes.
 *
 * @example
 * ```tsx
 * <Show when={user()} fallback={<SignIn />}>
 *   {u => <Greeting name={u().name} />}
 * </Show>
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/show
 */
export declare function Show<T>(props: {
    when: T | undefined | null | false;
    keyed: true;
    fallback?: SolidElement;
    children: SolidElement;
}): SolidElement;
export declare function Show<T, F extends KeyedConditionalRenderCallback<T>>(props: {
    when: T | undefined | null | false;
    keyed: true;
    fallback?: SolidElement;
    children: NonZeroParams<F>;
}): SolidElement;
export declare function Show<T>(props: {
    when: T | undefined | null | false;
    keyed?: false;
    fallback?: SolidElement;
    children: SolidElement;
}): SolidElement;
export declare function Show<T, F extends ConditionalRenderCallback<T>>(props: {
    when: T | undefined | null | false;
    keyed?: false;
    fallback?: SolidElement;
    children: NonZeroParams<F>;
}): SolidElement;
/**
 * Switches between content based on mutually exclusive conditions. Renders
 * the first `<Match>` whose `when` is truthy; falls back to `fallback` when
 * none match.
 *
 * @example
 * ```tsx
 * <Switch fallback={<FourOhFour />}>
 *   <Match when={state.route === 'home'}>
 *     <Home />
 *   </Match>
 *   <Match when={state.route === 'settings'}>
 *     <Settings />
 *   </Match>
 * </Switch>
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/switch-and-match
 */
export declare function Switch(props: {
    fallback?: SolidElement;
    children: SolidElement;
}): SolidElement;
export type MatchProps<T, F extends ConditionalRenderCallback<T> = ConditionalRenderCallback<T>> = {
    when: T | undefined | null | false;
    keyed?: false;
    children: ConditionalRenderChildren<T, F>;
};
export type KeyedMatchProps<T, F extends KeyedConditionalRenderCallback<T> = KeyedConditionalRenderCallback<T>> = {
    when: T | undefined | null | false;
    keyed: true;
    children: KeyedConditionalRenderChildren<T, F>;
};
export type AnyMatchProps<T> = MatchProps<T> | KeyedMatchProps<T> | {
    when: T | undefined | null | false;
    keyed?: boolean;
    children: SolidElement;
};
/**
 * A branch inside a `<Switch>`. The first `<Match>` whose `when` is truthy
 * wins; remaining matches are skipped.
 *
 * Like `<Show>`, `<Match>` supports a function child. Non-keyed children
 * receive an accessor for the narrowed value; keyed children receive the raw
 * narrowed value.
 *
 * @example
 * ```tsx
 * <Switch fallback={<NotFound />}>
 *   <Match when={user()}>
 *     {u => <Profile name={u().name} />}
 *   </Match>
 *   <Match when={loading()}>
 *     <Spinner />
 *   </Match>
 * </Switch>
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/switch-and-match
 */
export declare function Match<T>(props: {
    when: T | undefined | null | false;
    keyed: true;
    children: SolidElement;
}): SolidElement;
export declare function Match<T, F extends KeyedConditionalRenderCallback<T>>(props: KeyedMatchProps<T, F>): SolidElement;
export declare function Match<T>(props: {
    when: T | undefined | null | false;
    keyed?: false;
    children: SolidElement;
}): SolidElement;
export declare function Match<T, F extends ConditionalRenderCallback<T>>(props: MatchProps<T, F>): SolidElement;
export declare function Match<T>(props: AnyMatchProps<T>): SolidElement;
/**
 * Catches uncaught errors inside its subtree and renders fallback content
 * instead. The `fallback` prop can be a JSX element, or a callback that
 * receives the error and a `reset()` function for retry affordances.
 *
 * Errors thrown from the fallback itself can be caught by a parent
 * `<Errored>`.
 *
 * @example
 * ```tsx
 * <Errored fallback={(err, reset) => (
 *   <div onClick={reset}>Error: {err().toString()}</div>
 * )}>
 *   <MyComp />
 * </Errored>
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/errored
 */
export declare function Errored(props: {
    fallback: SolidElement | ((err: ErrorAccessor, reset: () => void) => SolidElement);
    children: SolidElement;
}): SolidElement;
/**
 * Renders a `fallback` while pending async reads inside the subtree settle.
 *
 * Any computation (`createMemo`, `createSignal(fn)`, `createStore(fn)`,
 * `lazy(...)`, etc.) that throws because data isn't ready is caught by the
 * nearest enclosing `<Loading>`. The boundary swaps to its `fallback` until
 * every pending read has resolved, then renders the children.
 *
 * Once content has rendered, a refetch keeps it visible: the boundary reads
 * the pending value like any other reader and holds the write that made it
 * pending until the data lands (`isPending()` flips meanwhile).
 *
 * The optional `on` prop is a dependency list. The expression is tracked and
 * its value is irrelevant — what matters is what it reads. Whenever anything
 * it reads changes (a plain write, an optimistic write, a source going
 * pending or landing), the boundary stops waiting on its current content and
 * shows `fallback` again if something under it is still pending, until the
 * new content is ready; if nothing is pending, nothing happens. The fallback
 * lands with the same frame as the change that caused it: immediately when
 * nothing else holds that frame; together with the rest of the new page
 * during a held navigation (a write inside an `action`, or one whose data
 * other readers are still waiting on) — never a spinner beside a page the
 * change has not reached yet. If the same data is also read outside the
 * boundary, the frame waits on it and the fallback can never be seen; DEV
 * warns `LOADING_ON_OUTSIDE_HOLD`, and the fix is structural — move the
 * outside read under the boundary so one hold owns the data. A frame held
 * past the content's landing by something else (the write's action, other
 * pending data) shows no fallback either; that is a race, a legitimate
 * outcome, and not reported — show the wait with `isPending()` instead.
 * A display-ahead read in `on` (`latest()`) shows the fallback now, beside
 * the held frame; that is a capability, not the recommended shape. The
 * children are not re-created; they stay alive behind the fallback.
 *
 * Scope `<Loading>` around the data-dependent slot, not the surrounding
 * shell. Wrapping layout chrome (header, nav, footer) in the same boundary
 * as the data means revalidation replaces the entire screen with the
 * fallback; rendering chrome outside the boundary keeps it stable while
 * only the affordance flips.
 *
 * @example
 * ```tsx
 * const Profile = lazy(() => import("./Profile"));
 *
 * <Loading fallback={<Spinner />}>
 *   <Profile />
 * </Loading>
 * ```
 *
 * @example
 * ```tsx
 * // Depend on the route: a navigation shows the skeleton with the new route
 * // while the page loads; a refetch of the same route keeps the page visible.
 * <Loading fallback={<Skeleton />} on={route()}>
 *   <Page />
 * </Loading>
 *
 * // Several dependencies: a change to any of them shows the fallback.
 * <Loading fallback={<Skeleton />} on={[query(), page()]}>
 *   <Results />
 * </Loading>
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/loading
 */
export declare function Loading(props: {
    fallback?: SolidElement;
    on?: any;
    children: SolidElement;
}): SolidElement;
export type RevealProps = {
    order?: RevealOrder;
    collapsed?: boolean;
    children: SolidElement;
};
/**
 * Coordinates the reveal timing of sibling `<Loading>` boundaries.
 *
 * The `order` prop picks the reveal policy:
 * - `"sequential"` (default) — boundaries reveal in registration order; later boundaries
 *   stay on their fallback until earlier ones resolve.
 * - `"together"` — every direct slot stays on its fallback until the whole group is
 *   "minimally ready" (every direct slot has its own first visible content available),
 *   then the group releases in one cohesive reveal.
 * - `"natural"` — each boundary reveals as its own data resolves. At the top level
 *   this is equivalent to omitting `<Reveal>`; the mode exists for nesting, where
 *   the group registers as a single composite slot in an enclosing `<Reveal>`.
 *
 * The `collapsed` prop is only consulted when `order="sequential"` (the default);
 * it is ignored under `"together"` and `"natural"`. When set, tail boundaries past
 * the frontier suppress their own fallback output.
 *
 * Nested `<Reveal>` groups compose: the inner group is one slot in the outer order
 * and is held on its fallbacks until the outer releases the slot. Once released, the
 * inner group runs its own `order` locally over whatever is still pending. There is
 * no escape hatch — nesting under an outer group means participating in its ordering.
 * See `documentation/solid-2.0/03-control-flow.md` for the full nesting matrix and the
 * "minimally ready" definition per order.
 *
 * @example
 * ```tsx
 * // Default order is "sequential"; the inner group composes as one slot
 * // and runs its own "natural" order locally once the outer releases it.
 * <Reveal>
 *   <Loading fallback={<Skeleton />}><ProfileHeader /></Loading>
 *   <Reveal order="natural">
 *     <Loading fallback={<Skeleton />}><PostA /></Loading>
 *     <Loading fallback={<Skeleton />}><PostB /></Loading>
 *   </Reveal>
 *   <Loading fallback={<Skeleton />}><Comments /></Loading>
 * </Reveal>
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/reveal
 */
export declare function Reveal(props: RevealProps): SolidElement;
