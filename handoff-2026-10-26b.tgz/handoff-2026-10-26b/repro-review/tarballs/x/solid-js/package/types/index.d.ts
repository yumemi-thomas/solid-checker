export { $PROXY, $TRACK, action, affects, createOwner, createReaction, createTrackedEffect, deep, flatten, flush, getNextChildId, getObserver, getOwner, isDisposed, isEqual, isPending, isWrappable, mapArray, merge, isStatic, omit, onCleanup, onSettled, latest, reconcile, refresh, repeat, resetErrorHalt, resolve, until, NotReadyError, TimeoutError, runWithOwner, enableExternalSource, enforceLoadingBoundary, snapshot, untrack, configureClientErrors } from "@solidjs/signals";
export type { ClientErrorContext, ClientErrorHook, ClientErrorsConfig, Accessor, ComputeFunction, EffectBundle, EffectFunction, EffectOptions, ExternalSource, ExternalSourceConfig, ExternalSourceFactory, Merge, MemoOptions, NoInfer, NotWrappable, Omit, Owner, ProjectionOptions, Refreshable, Signal, SignalOptions, SourceAccessor, Setter, Store, Truthy, UntilOptions, StoreReturn, ProjectionStoreReturn, StoreOptions, SolidStore, StoreNode, StoreSetter, StorePathRange, ArrayFilterFn, CustomPartial, Part, PathSetter } from "@solidjs/signals";
export { children, createContext, useContext } from "./client/core.js";
export type { ChildrenReturn, Context, ContextProviderComponent, ResolvedChildren, ResolvedElement } from "./client/core.js";
export * from "./client/component.js";
export { dynamicComponent, type DynamicOptions } from "./client/dynamic.js";
export * from "./client/flow.js";
export type { ArrayElement, Element } from "./types.js";
export { enableHydration, createRoot, createMemo, createDeferred, createSignal, createStore, createProjection, createOptimistic, createOptimisticStore, createRenderEffect, createEffect, NoHydration, Hydration, isHydrating, isHydratable, onHydrationEnd } from "./client/hydration.js";
/** Where a server failure was met, as the server error hook hears it (see `@solidjs/web`'s `ServerErrorContext`). */
export interface ServerErrorSite {
    kind: "render" | "server-function" | "request";
    handling: "fallback" | "client" | "failed" | "serialize" | "thrown" | "channel";
    boundary?: string;
    /** Where the error was thrown — labels root-first up the owner chain it escaped. */
    ownerPath?: string[];
    /** Where it was met — the labels up the chain of the boundary named by `boundary`. */
    boundaryPath?: string[];
    functionId?: string;
    direct?: boolean;
    /** The request event, when the caller has it in hand; else read from the request scope. */
    event?: unknown;
}
export type ServerErrorHook = (error: unknown, context: ServerErrorSite) => unknown | void;
import { type Dev, type Observe } from "@solidjs/signals";
export declare const OBSERVE: Observe | undefined;
export declare const DEV: Dev | undefined;
export type { Dev, Observe, ServerObserve, Records, RecordTypes, HostRecordTypes, RecordType, RecordEvent, RecordLive, RecordListener, RecordSubscribeOptions, AttributionSlot, InteractionRef, NavigationRef, Diagnostics, DiagnosticCapture, DiagnosticCode, DiagnosticEvent, DiagnosticKind, DiagnosticListener, DiagnosticSeverity, DiagnosticSubject } from "@solidjs/signals";
export type { BoundaryEvent, BoundaryLive, BoundaryListener, ServerTrace } from "./server/observe.js";
export type { RecoveryEvent, RecoveryLive, RecoveryListener } from "./recovery.js";
export type { ChangeOrigin } from "@solidjs/signals/attribution";
declare global {
    var Solid$$: boolean;
}
