import { createRenderEffect as coreRenderEffect, createEffect as coreEffect, type ComputeFunction, type MemoOptions, type NoInfer, type ProjectionOptions, type Refreshable, type Signal, type SignalOptions, type SourceAccessor, type Store, type StoreOptions, type StoreSetter, createRoot as coreRoot } from "@solidjs/signals";
import type { Element as SolidElement } from "../types.js";
type HydrationSsrFields = {
    /**
     * Defer the SSR stream flush until this primitive's first value is
     * resolved. Lets late-resolving sources hold the document open
     * rather than forcing the surrounding `<Loading>` boundary to render
     * its fallback into the HTML. Server-only; ignored on the client.
     */
    deferStream?: boolean;
    /**
     * Hydration policy. Decides what initial value the client uses and
     * whether the compute re-runs.
     *
     * - `"server"` *(default)*: client uses the serialized server value
     *   as initial state. Compute does **not** re-run for the initial
     *   value — the serialized result is authoritative. Choose this when
     *   the compute is deterministic from server-available inputs.
     * - `"hybrid"`: client uses the serialized server value first; then,
     *   for a compute that returns an **async iterable**, the client
     *   continues the stream from it (the server consumed exactly one
     *   yield; the client's first yield duplicates it and is discarded,
     *   later yields update the node). For a sync or promise-shaped
     *   compute, `"hybrid"` is identical to `"server"`: the serialized
     *   value is adopted and the compute does not re-run until a
     *   dependency changes or `refresh()`. Choose this for streaming
     *   sources the client should keep consuming after hydration.
     * - `"client"`: skip the server value entirely. Compute is deferred
     *   until hydration completes, then runs as if first-mounted.
     *   Choose this for client-only state where serialization is
     *   meaningless. Two forms decide what the pre-compute window
     *   renders: **bare** (structural) — the source suspends on the
     *   server as a final hole and the nearest `<Loading>` boundary
     *   renders its fallback, handing the position to the client; or a
     *   **declared commit #0** (value) — `loadingValue` on signal-family
     *   sources (`loadingValue: undefined` is a valid declaration),
     *   `seedLoadingValue: true` on store-family sources — which renders
     *   provisional data with no boundary involvement.
     */
    ssrSource?: "server" | "hybrid" | "client";
};
declare module "@solidjs/signals" {
    interface MemoOptions<T> extends HydrationSsrFields {
    }
    interface SignalOptions<T> extends HydrationSsrFields {
    }
    interface EffectOptions extends HydrationSsrFields {
    }
    interface ProjectionOptions extends HydrationSsrFields {
    }
}
/**
 * Options for `createProjection`, `createStore(fn, ...)`, and
 * `createOptimisticStore(fn, ...)`.
 *
 * `ssrSource` controls what initial value the client uses and whether
 * the projection's compute re-runs:
 *
 * - `"server"` *(default)*: client uses the serialized server value
 *   as initial state.
 * - `"hybrid"`: serialized value first; for an async-iterable derive
 *   the client then continues the stream from it. For a sync or
 *   promise-shaped derive, identical to `"server"`.
 * - `"client"`: skip serialization; compute runs only after hydration
 *   completes. Bare = suspends on the server (nearest `<Loading>`
 *   renders its fallback and hands the position to the client);
 *   `seedLoadingValue: true` = the seed is the declared commit #0 and
 *   renders instead.
 *
 * See {@link HydrationSsrFields} for the fuller explanation.
 */
type HydrationMemoOptions<T> = MemoOptions<T>;
type HydrationSignalOptions<T> = SignalOptions<T> & MemoOptions<T>;
type HydrationProjectionOptions = ProjectionOptions;
export type HydrationContext = {};
/**
 * Whether the code running now is claiming server-rendered DOM: the root
 * pass of `hydrate()`, or code under a streamed `<Loading>` boundary while
 * that boundary resumes. `false` on the server, in client-only renders,
 * after hydration, and in a render a resume window triggers outside the
 * resuming boundary (that render builds fresh DOM).
 *
 * Not reactive: read it where a component or primitive is created. While it
 * is `true`, render what the server rendered, and switch to the client-only
 * value from `onSettled`.
 *
 * @example
 * ```ts
 * const [width, setWidth] = createSignal(isHydrating() ? 0 : el.offsetWidth);
 * onSettled(() => setWidth(el.offsetWidth));
 * ```
 */
export declare function isHydrating(): boolean;
/**
 * Whether the calling owner sits where hydration applies — not under
 * `<NoHydration>`, or back under a nested `<Hydration>` — so a value keyed
 * to this position reaches a hydrating client. On the server it also
 * requires the owner to belong to a render in progress. `false` with no
 * owner (a promise continuation, an IO callback): read it where the owner
 * is known. On the client, `<Hydration>` is a passthrough, so inside a
 * `<NoHydration>` zone (which renders only outside hydration) this stays
 * `false` even under a nested `<Hydration>`.
 *
 * Solid decides this itself for its own values. A library writing keyed
 * values with `getHydrationWriter()` reads it to make the same decision.
 */
export declare function isHydratable(): boolean;
/**
 * Runs `callback` once, when the hydration phase ends: the root pass of
 * `hydrate()` is over and every streamed `<Loading>` boundary (and every
 * hold an integration registers, such as server-component content waiting
 * for its data) has resumed or been cancelled. When no hydration is in
 * progress — before `hydrate()` starts, after the phase has ended, in a
 * client-only render, on the server — it runs in the next microtask.
 *
 * Intended for test tooling and markers, such as an attribute an end-to-end
 * test waits for. Do not branch what the app renders on it: read
 * `isHydrating()` where a value must match the server, and switch to the
 * client-only value from `onSettled`.
 *
 * - **Register it after calling `hydrate()`.** Registered before hydration
 *   starts, the callback runs in the next microtask and does not wait for
 *   hydration work started afterward. The same holds when `hydrate()` parks
 *   because the entry ran while the parser was still inside the server
 *   shell (an `async` entry script): hydration starts at the shell-end
 *   marker, after `hydrate()` has returned.
 * - **It does not say hydration succeeded.** When a document root's module
 *   preload fails, hydration is abandoned with the server markup left in
 *   place and not interactive, and the callback still runs. A non-document
 *   root whose preload fails runs it before falling back to a client render.
 * - **It is not page-wide completion with several hydration roots.** A root
 *   whose render waits on its module preload is not counted, so another
 *   root finishing can end the phase before that root has claimed anything.
 *
 * @example
 * ```ts
 * hydrate(() => <App />, document);
 * onHydrationEnd(() => {
 *   document.documentElement.dataset.hydrated = "";
 * });
 * ```
 * @experimental
 */
export declare function onHydrationEnd(callback: () => void): void;
export declare let _lazyHydrationLookup: (<T>(comp: (() => T | undefined) | undefined, moduleUrl?: string, exportName?: string) => (() => T) | undefined) | undefined;
export declare function enableHydration(): void;
/**
 * Creates a readonly derived reactive memoized signal.
 *
 * `compute(prev)` runs reactively — every reactive read inside it is
 * tracked, and the returned value becomes the memo's current value.
 * The memo is cached: it only recomputes when one of its tracked
 * sources changes.
 *
 * ```ts
 * const value = createMemo<T>(compute, options?: MemoOptions<T>);
 * ```
 *
 * @example
 * ```ts
 * const [first, setFirst] = createSignal("Ada");
 * const [last, setLast] = createSignal("Lovelace");
 *
 * const fullName = createMemo(() => `${first()} ${last()}`);
 *
 * fullName(); // "Ada Lovelace"
 * ```
 *
 * @example
 * ```ts
 * // Async memo — reads suspend inside <Loading>
 * const user = createMemo(async () => {
 *   const res = await fetch(`/users/${id()}`);
 *   return res.json();
 * });
 * ```
 *
 * **Hydration:** `MemoOptions` accepts an `ssrSource` field
 * (`"server"` | `"hybrid"` | `"client"`) that controls what initial
 * value the client uses and whether `compute` re-runs. See
 * {@link HydrationSsrFields}. `transparent: true` opts a memo out of
 * hydration (it consumes no id slot and computes live); a memo created
 * with no owner, or under a root without an `id`, has no id to consume
 * and takes that path on its own.
 *
 * @param compute receives the previous value, returns the new value
 * @param options `MemoOptions` — `id`, `name`, `equals`, `unobserved`,
 *   `lazy`, `transparent`, `ssrSource`
 *
 * @description https://v2.solidjs.com/reference/solid-js/reactivity/create-memo
 */
export declare const createMemo: {
    <T>(compute: ComputeFunction<NoInfer<T>, T>, options: HydrationMemoOptions<T> & {
        loadingValue: T;
    }): SourceAccessor<T>;
    <T>(compute: ComputeFunction<undefined | NoInfer<T>, T>, options?: HydrationMemoOptions<T>): SourceAccessor<T>;
};
/**
 * Creates a simple reactive state with a getter and setter.
 *
 * - **Plain form** — `createSignal(value, options?: SignalOptions<T>)`:
 *   stores a value; the setter writes a new value or applies an
 *   updater `(prev) => next`.
 * - **Function form (writable memo)** —
 *   `createSignal(fn, options?: SignalOptions<T> & MemoOptions<T>)`:
 *   the value is computed by `fn` like a memo, but the setter can
 *   locally override it (useful for optimistic edits over a derived
 *   default).
 *
 * ```ts
 * // Plain
 * const [count, setCount] = createSignal(0);
 *
 * count();              // 0
 * setCount(1);          // explicit value
 * setCount(c => c + 1); // updater
 *
 * // Writable memo: derives from `fn()` and can be written like a signal.
 * // A write lands at once and never re-runs `fn` on its own; when `userId`
 * // changes, in the same update or later, `fn` re-runs and receives the
 * // written value as `prev`. While a transaction holds a re-derived value, a
 * // write from outside it does not replace that derivation — it becomes its
 * // `prev`.
 * const [user, setUser] = createSignal(() => fetchUser(userId()));
 * setUser({ ...user(), name: "Alice" });
 * ```
 *
 * **Hydration:** in the function form, `SignalOptions & MemoOptions`
 * accepts an `ssrSource` field (`"server"` | `"hybrid"` | `"client"`)
 * that controls what initial value the client uses and whether `fn`
 * re-runs. See {@link HydrationSsrFields}. `transparent: true` and the
 * ownerless / id-less cases behave as for `createMemo`.
 *
 * @returns `[state: Accessor<T>, setState: Setter<T>]`
 *
 * @description https://v2.solidjs.com/reference/solid-js/reactivity/create-signal
 */
export declare const createSignal: {
    <T>(): Signal<T | undefined>;
    <T>(value: Exclude<T, Function>, options?: SignalOptions<T>): Signal<T>;
    <T>(fn: ComputeFunction<NoInfer<T>, T>, options: HydrationSignalOptions<T> & {
        loadingValue: T;
    }): Signal<T>;
    <T>(fn: ComputeFunction<undefined | NoInfer<T>, T>, options?: HydrationSignalOptions<T>): Signal<T>;
};
/**
 * Creates an optimistic signal — a `Signal<T>` whose writes are
 * tentative inside an `action` transition: they show up immediately,
 * then auto-revert (or reconcile to the action's resolved value) once
 * the transition settles.
 *
 * Use this for single-value optimistic state. For collection-shaped
 * state, prefer `createOptimisticStore`.
 *
 * - **Plain form** — `createOptimistic(value, options?: SignalOptions<T>)`.
 * - **Function form** — `createOptimistic(fn, options?: SignalOptions<T> & MemoOptions<T>)`:
 *   the authoritative value is recomputed by `fn`; the optimistic
 *   overlay reverts after each transition.
 *
 * @example
 * ```ts
 * const [name, setName] = createOptimistic("Ada");
 *
 * const rename = action(function* (next: string) {
 *   setName(next);                 // optimistic
 *   yield api.rename(next);        // commits or reverts on settle
 * });
 * ```
 *
 * **Hydration:** in the function form, accepts an `ssrSource` field
 * (`"server"` | `"hybrid"` | `"client"`). See {@link HydrationSsrFields}.
 *
 * @returns `[state: Accessor<T>, setState: Setter<T>]`
 *
 * @description https://v2.solidjs.com/reference/solid-js/reactivity/create-optimistic
 */
export declare const createOptimistic: {
    <T>(): Signal<T | undefined>;
    <T>(value: Exclude<T, Function>, options?: SignalOptions<T>): Signal<T>;
    <T>(fn: ComputeFunction<NoInfer<T>, T>, options: HydrationSignalOptions<T> & {
        loadingValue: T;
    }): Signal<T>;
    <T>(fn: ComputeFunction<undefined | NoInfer<T>, T>, options?: HydrationSignalOptions<T>): Signal<T>;
};
/**
 * Creates an async memo that may lag, but never leads: after its first
 * answer, a refetch holds nothing — readers keep the previous answer until
 * the new one lands, and `isPending` reports the refetch. See
 * `createDeferred` in `@solidjs/signals`. Hydrates like `createMemo`: the
 * server's answer is its first.
 */
export declare const createDeferred: {
    <T>(compute: ComputeFunction<NoInfer<T>, T>, options: HydrationMemoOptions<T> & {
        loadingValue: T;
    }): SourceAccessor<T>;
    <T>(compute: ComputeFunction<undefined | NoInfer<T>, T>, options?: HydrationMemoOptions<T>): SourceAccessor<T>;
};
/**
 * Creates a derived (projected) store — `createMemo` for stores. The
 * derive function receives a mutable draft and either mutates it in
 * place (canonical) or returns a new value. Either way the result is
 * reconciled against the previous draft by `options.key` (default
 * `"id"`), so surviving items keep their proxy identity — only
 * added/removed items are created/disposed.
 *
 * Returns the projected store directly (no setter — reads only).
 *
 * Reach for this when you want the structural-sharing / per-property
 * tracking of a store on top of a derived computation. For simple
 * read-only derivations, `createMemo` is lighter.
 *
 * @example
 * ```ts
 * // Mutation form — update individual fields on the draft.
 * const summary = createProjection<{ total: number; active: number }>(
 *   draft => {
 *     draft.total = users().length;
 *     draft.active = users().filter(u => u.active).length;
 *   },
 *   { total: 0, active: 0 }
 * );
 *
 * // Return form — produce a derived collection. Reconciled by `id`
 * // so each surviving user keeps the same store identity.
 * const activeUsers = createProjection<User[]>(
 *   () => allUsers().filter(u => u.active),
 *   []
 * );
 * ```
 *
 * **Hydration:** `ProjectionOptions` accepts an `ssrSource` field
 * (`"server"` | `"hybrid"` | `"client"`) for the same client-vs-server
 * tradeoffs as the other primitives. See {@link HydrationSsrFields}.
 */
export declare const createProjection: {
    <T extends object = {}>(fn: (() => T | Promise<T> | AsyncIterable<T>) & NoArray<T>, seed?: null, options?: Omit<HydrationProjectionOptions, "seedLoadingValue">): Refreshable<Store<T>>;
    <T extends object = {}>(fn: (draft: T) => void | T | Promise<void | T> | AsyncIterable<void | T>, seed: NoFn<T> | Store<NoFn<T>>, options?: HydrationProjectionOptions): Refreshable<Store<T>>;
};
type NoFn<T> = T extends Function ? never : T;
type NoArray<T> = Extract<T, readonly unknown[]> extends never ? unknown : never;
/**
 * Creates a deeply-reactive store backed by a Proxy. Reads track each
 * property accessed; only the parts that change trigger updates.
 *
 * Store properties hold **plain values**, not accessors. The proxy
 * already tracks reads per-property — wrapping a value in
 * `() => state.foo` produces a getter that *won't* track when called,
 * which looks like a reactivity bug but is just a category error. If
 * you have a signal-shaped piece of state, make it a property of the
 * store (`{ foo: 1 }`) rather than nesting an accessor inside
 * (`{ foo: () => signal() }`).
 *
 * The setter takes a **draft-mutating** function — mutate the draft
 * in place (canonical). The callback may also return a new value:
 * arrays are replaced by index (length adjusted), objects are
 * shallow-diffed at the top level (keys present in the returned value
 * are written, missing keys deleted). Use the return form for shapes
 * where mutation is awkward — most commonly removing items via
 * `filter`. The setter does **not** do keyed reconciliation; for
 * that, use the derived/projection form (or `createProjection`).
 *
 * - **Plain form** — `createStore(initialValue, options?)`: wraps a value in a
 *   reactive proxy.
 * - **Derived form** — `createStore(fn, seed, options?)`: a
 *   *projection store* whose contents are computed by `fn(draft)`.
 *   `fn` may be sync, async, or an `AsyncIterable`; the projection's
 *   result reconciles against the existing store by `options.key`
 *   (default `"id"`) for stable identity.
 *
 * @example
 * ```ts
 * const [state, setState] = createStore({
 *   user: { name: "Ada", age: 36 },
 *   todos: [] as { id: string; text: string; done: boolean }[]
 * });
 *
 * // Canonical: mutate the draft in place.
 * setState(s => { s.user.age = 37; });
 * setState(s => { s.todos.push({ id: "1", text: "x", done: false }); });
 *
 * // Return form: reach for it when mutation is awkward.
 * setState(s => s.todos.filter(t => !t.done));               // remove items
 * setState(s => ({ ...s, user: { name: "Grace", age: 85 } })); // shallow replace
 * ```
 *
 * @example
 * ```ts
 * // Derived store — auto-fetches & reconciles by `id`.
 * const [users] = createStore(
 *   async () => fetch("/users").then(r => r.json()),
 *   [] as User[]
 * );
 * ```
 *
 * **Hydration:** the derived form accepts `ProjectionOptions`, including
 * an `ssrSource` field
 * (`"server"` | `"hybrid"` | `"client"`). See {@link HydrationSsrFields}.
 *
 * @returns `[store: Store<T>, setStore: StoreSetter<T>]`
 */
export declare const createStore: {
    <T extends object = {}>(initialValue: NoFn<T> | Store<NoFn<T>>, options?: StoreOptions): [get: Store<T>, set: StoreSetter<T>];
    <T extends object = {}>(fn: (() => T | Promise<T> | AsyncIterable<T>) & NoArray<T>, seed?: null, options?: Omit<HydrationProjectionOptions, "seedLoadingValue">): [get: Refreshable<Store<T>>, set: StoreSetter<T>];
    <T extends object = {}>(fn: (draft: T) => void | T | Promise<void | T> | AsyncIterable<void | T>, seed: NoFn<T> | Store<NoFn<T>>, options?: HydrationProjectionOptions): [get: Refreshable<Store<T>>, set: StoreSetter<T>];
};
/**
 * The store equivalent of `createOptimistic`. Writes inside an
 * `action` transition are tentative — they show up immediately but
 * auto-revert (or reconcile to the action's resolved value) once the
 * transition finishes.
 *
 * Use this for optimistic UI on collection-shaped data. For
 * single-value optimistic state, prefer `createOptimistic`.
 *
 * - **Plain form** — `createOptimisticStore(initialValue, options?)`.
 * - **Derived form** — `createOptimisticStore(fn, seed, options?)`:
 *   a projection store whose authoritative value is recomputed by
 *   `fn` and whose optimistic overlay reverts after each transition.
 *
 * In the derived form, `options.key` defaults to `"id"`; specify it only when your data
 * uses a different identity field (e.g. `{ key: "uuid" }` or
 * `{ key: t => t.slug }`). Restating the default just adds noise.
 *
 * @example
 * ```ts
 * const [todos, setTodos] = createOptimisticStore<Todo[]>([]);
 *
 * // Mutation: optimistic add, then in-place reconcile to the saved row.
 * const addTodo = action(function* (text: string) {
 *   const tempId = crypto.randomUUID();
 *   setTodos(t => { t.push({ id: tempId, text, pending: true }); });
 *   const saved = yield api.createTodo(text);
 *   setTodos(t => {
 *     const i = t.findIndex(x => x.id === tempId);
 *     if (i >= 0) t[i] = saved;
 *   });
 * });
 *
 * // Return form: filter is the natural shape for removal.
 * const removeTodo = action(function* (id: string) {
 *   setTodos(t => t.filter(x => x.id !== id));
 *   yield api.removeTodo(id);
 * });
 * ```
 *
 * **Hydration:** the derived form accepts `ProjectionOptions`, including
 * an `ssrSource` field
 * (`"server"` | `"hybrid"` | `"client"`). See {@link HydrationSsrFields}.
 *
 * @returns `[store: Store<T>, setStore: StoreSetter<T>]`
 */
export declare const createOptimisticStore: {
    <T extends object = {}>(initialValue: NoFn<T> | Store<NoFn<T>>, options?: StoreOptions): [get: Store<T>, set: StoreSetter<T>];
    <T extends object = {}>(fn: (() => T | Promise<T> | AsyncIterable<T>) & NoArray<T>, seed?: null, options?: Omit<HydrationProjectionOptions, "seedLoadingValue">): [get: Refreshable<Store<T>>, set: StoreSetter<T>];
    <T extends object = {}>(fn: (draft: T) => void | T | Promise<void | T> | AsyncIterable<void | T>, seed: NoFn<T> | Store<NoFn<T>>, options?: HydrationProjectionOptions): [get: Refreshable<Store<T>>, set: StoreSetter<T>];
};
/**
 * Creates a reactive root — an owner scope with its own `dispose()`. A root
 * created inside an existing owner is owned by it and is disposed when the
 * parent is disposed; call `dispose()` to tear it down earlier. To create a
 * root that outlives its creator, detach explicitly:
 * `runWithOwner(null, () => createRoot(...))`. Pass `id` to seed hydration
 * ids for the tree it owns.
 *
 * ```ts
 * const dispose = createRoot(dispose => {
 *   // ...
 *   return dispose;
 * });
 *
 * // Detached from the current owner (lives until `detached()` is called):
 * const detached = runWithOwner(null, () => createRoot(d => d));
 * ```
 *
 * **Hydration:** a root created during hydration marks itself as the
 * snapshot scope, so writes landing during the hydration pass are held
 * until the pass completes (the mark used to depend on which primitive
 * ran first under it).
 *
 * @description https://v2.solidjs.com/reference/solid-js/advanced/owner-introspection/create-root
 */
export declare const createRoot: typeof coreRoot;
/**
 * Creates a reactive computation that runs during the render phase as
 * DOM elements are created and updated but not necessarily connected.
 *
 * Same compute/effect split as `createEffect` (`compute(prev)` tracks,
 * `effect(next, prev?)` runs imperatively), but scheduled inside the
 * render queue rather than after it. Reach for this only when
 * authoring renderer plumbing — app code should use `createEffect`.
 *
 * ```ts
 * createRenderEffect<T>(compute, effectFn, options?: EffectOptions);
 * ```
 *
 * **Hydration:** `EffectOptions` accepts an `ssrSource` field
 * (`"server"` | `"hybrid"` | `"client"`). See {@link HydrationSsrFields}.
 * `transparent: true` makes the effect invisible to hydration entirely —
 * it consumes no hydration id slot and its compute runs live rather than
 * adopting the serialized server value — for client-only effects the
 * server never created. An effect created with no owner, or under a
 * root without an `id`, has no id slot to consume and takes that path on
 * its own.
 *
 * @example
 * ```ts
 * // Custom directive: bind an element's textContent to a reactive source
 * // synchronously during render. App code should use `createEffect` for
 * // post-render side effects.
 * function bindText(el: HTMLElement, source: () => string) {
 *   createRenderEffect(
 *     () => source(),
 *     value => { el.textContent = value; }
 *   );
 * }
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/advanced/specialized-reactivity/create-render-effect
 */
export declare const createRenderEffect: typeof coreRenderEffect;
/**
 * Creates a reactive effect with **separate compute and effect phases**.
 *
 * - `compute(prev)` runs reactively — *put all reactive reads here*.
 *   The returned value is passed to `effect` and is also the new
 *   "previous" value for the next run.
 * - `effect(next, prev?)` runs imperatively (untracked) after the
 *   queue flushes. *Put DOM writes / fetch / logging / subscriptions
 *   here.* It may return a cleanup function which runs before the
 *   next effect or on disposal.
 *
 * Reactive reads inside `effect` will *not* re-trigger this effect —
 * that's intentional. If you need a single-phase tracked effect, use
 * `createTrackedEffect` (with the tradeoffs noted there).
 *
 * Pass an `EffectBundle` (`{ effect, error }`) instead of a plain
 * function to intercept errors thrown from the compute or effect
 * phases.
 *
 * ```ts
 * createEffect<T>(compute, effectFn | { effect, error }, options?: EffectOptions);
 * ```
 *
 * @example
 * ```ts
 * const [count, setCount] = createSignal(0);
 *
 * createEffect(
 *   () => count(),                  // compute: tracks `count`
 *   value => console.log(value)     // effect: side effect
 * );
 *
 * setCount(1); // logs 1 after the next flush
 * ```
 *
 * @example
 * ```ts
 * createEffect(
 *   () => userId(),
 *   id => {
 *     const ctrl = new AbortController();
 *     fetch(`/users/${id}`, { signal: ctrl.signal });
 *     return () => ctrl.abort(); // cleanup before next run / disposal
 *   }
 * );
 * ```
 *
 * **Hydration:** `EffectOptions` accepts an `ssrSource` field
 * (`"server"` | `"hybrid"` | `"client"`). See {@link HydrationSsrFields}.
 * `transparent: true` makes the effect invisible to hydration entirely —
 * it consumes no hydration id slot and its compute runs live rather than
 * adopting the serialized server value — for client-only effects the
 * server never created. An effect created with no owner, or under a
 * root without an `id`, has no id slot to consume and takes that path on
 * its own.
 *
 * @description https://v2.solidjs.com/reference/solid-js/reactivity/create-effect
 */
export declare const createEffect: typeof coreEffect;
/**
 * Disables hydration for its children on the client.
 * During hydration, skips the subtree entirely (returns undefined so DOM is left untouched).
 * After hydration, renders children fresh.
 *
 * @example
 * ```tsx
 * // Mount a client-only widget that the server didn't render. The subtree
 * // is left empty during hydration, then renders fresh once hydration ends.
 * <NoHydration>
 *   <ClientOnlyMap />
 * </NoHydration>
 * ```
 */
export declare function NoHydration(props: {
    children: SolidElement;
}): SolidElement;
/**
 * Re-enables hydration within a `<NoHydration>` zone (passthrough on the
 * client). Use it to opt a subtree back into hydration when the surrounding
 * region was opted out.
 *
 * @example
 * ```tsx
 * // Inside a `<NoHydration>` region, re-enable hydration for one inner
 * // subtree that does need to match a server-rendered fragment.
 * <NoHydration>
 *   <ClientOnlyShell>
 *     <Hydration>
 *       <ServerHydratedWidget />
 *     </Hydration>
 *   </ClientOnlyShell>
 * </NoHydration>
 * ```
 */
export declare function Hydration(props: {
    id?: string;
    children: SolidElement;
}): SolidElement;
export {};
