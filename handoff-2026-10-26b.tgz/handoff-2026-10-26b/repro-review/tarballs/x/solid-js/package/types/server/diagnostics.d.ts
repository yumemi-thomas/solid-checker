import { type DiagnosticEvent, type DiagnosticSubject } from "@solidjs/signals";
export declare const IS_DEV: string | boolean;
export declare const IS_OBSERVE: string | boolean;
export type Finding = Omit<DiagnosticEvent, "sequence">;
/**
 * Dev: stamps `flight` with when its work started (the core's
 * `OBSERVE.attribution.markFlight`, which the client engine reads too). The
 * `<Loading>` waterfall check reads the stamps back with `flightOrigin` to
 * tell a wait on work that was already running from one that could only
 * start after the previous wait landed (#4105). Call sites gate on `IS_DEV`.
 */
export declare function markFlight(flight: object, startedAt?: number): void;
/** Dev: the stamp `markFlight` left on `flight`, if any. */
export declare function flightOrigin(flight: object): number | undefined;
/**
 * Records a finding on `OBSERVE.diagnostics` — observe and dev tiers — and,
 * in dev, reports it on the console through the core's one face (message,
 * `in <App> › <Page>`, the once-per-code footer). `subject` locates it; the
 * current owner by default, which is what the check sites want (they fire
 * inside the scope that misbehaved). Server owners are signals-shaped
 * enough for the core's `ownerPath` and exclusion walks (`_parent` +
 * `_name`, the two fields signals' property mangling reserves as
 * cross-package), so component labels (see `createComponent`) come through
 * unchanged in every tier. No-op in prod.
 *
 * Advisory (`info`) findings are structured-channel only, as in the core:
 * a fact worth recording that has not earned the console.
 */
export declare function emitFinding(finding: Finding, subject?: DiagnosticSubject | null): void;
/**
 * The structured record alone, for a site that THROWS its message: the
 * thrown error is the console face, and the core lands the once-per-code
 * footer beneath it (see `emitDiagnostic`). Reporting as well would print
 * the finding twice.
 */
export declare function recordFinding(finding: Finding, subject?: DiagnosticSubject | null): void;
/**
 * A dev CHECK: `emitFinding` behind the dev gate, so the site reads as one
 * call and folds out of the observe and prod artifacts entirely (message
 * strings included). Returns nothing; sites that must also throw or
 * fall back keep doing so after the call.
 */
export declare function devCheck(finding: Finding, subject?: DiagnosticSubject | null): void;
/** `Name: message` for an Error, `String(value)` otherwise — the text a finding's message carries. */
export declare function errorText(error: unknown): string;
