/** Dev-only; the callers gate on their build's dev literal, where `DEV` is defined. */
export declare function installConsoleFooter(): void;
