import type { Accessor, RevealOrder } from "./signals.js";
import type { Element as SolidElement } from "../types.js";
export type { RevealOrder };
type NonZeroParams<T extends (...args: any[]) => any> = Parameters<T>["length"] extends 0 ? never : T;
type ConditionalRenderCallback<T> = (item: Accessor<NonNullable<T>>) => SolidElement;
type KeyedConditionalRenderCallback<T> = (item: NonNullable<T>) => SolidElement;
type ConditionalRenderChildren<T, F extends ConditionalRenderCallback<T> = ConditionalRenderCallback<T>> = SolidElement | NonZeroParams<F>;
type KeyedConditionalRenderChildren<T, F extends KeyedConditionalRenderCallback<T> = KeyedConditionalRenderCallback<T>> = SolidElement | NonZeroParams<F>;
/**
 * Creates a list of elements from a list
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/for
 */
export declare function For<T extends readonly any[], U extends SolidElement>(props: {
    each: T | undefined | null | false;
    fallback?: SolidElement;
    keyed?: true;
    children: (item: T[number], index: Accessor<number>) => U;
}): SolidElement;
export declare function For<T extends readonly any[], U extends SolidElement>(props: {
    each: T | undefined | null | false;
    fallback?: SolidElement;
    keyed: false;
    children: (item: Accessor<T[number]>, index: number) => U;
}): SolidElement;
export declare function For<T extends readonly any[], U extends SolidElement>(props: {
    each: T | undefined | null | false;
    fallback?: SolidElement;
    keyed: (item: T[number]) => any;
    children: (item: Accessor<T[number]>, index: Accessor<number>) => U;
}): SolidElement;
/**
 * Creates a list elements from a count
 *
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/repeat
 */
export declare function Repeat<T extends SolidElement>(props: {
    count: number;
    from?: number | undefined;
    fallback?: SolidElement;
    children: ((index: number) => T) | T;
}): SolidElement;
/**
 * Conditionally render its children or an optional fallback component
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/show
 */
export declare function Show<T>(props: {
    when: T | undefined | null | false;
    keyed: true;
    fallback?: SolidElement;
    children: SolidElement;
}): SolidElement;
export declare function Show<T, F extends KeyedConditionalRenderCallback<T>>(props: {
    when: T | undefined | null | false;
    keyed: true;
    fallback?: SolidElement;
    children: NonZeroParams<F>;
}): SolidElement;
export declare function Show<T>(props: {
    when: T | undefined | null | false;
    keyed?: false;
    fallback?: SolidElement;
    children: SolidElement;
}): SolidElement;
export declare function Show<T, F extends ConditionalRenderCallback<T>>(props: {
    when: T | undefined | null | false;
    keyed?: false;
    fallback?: SolidElement;
    children: NonZeroParams<F>;
}): SolidElement;
/**
 * Switches between content based on mutually exclusive conditions
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/switch-and-match
 */
export declare function Switch(props: {
    fallback?: SolidElement;
    children: SolidElement;
}): SolidElement;
export type MatchProps<T, F extends ConditionalRenderCallback<T> = ConditionalRenderCallback<T>> = {
    when: T | undefined | null | false;
    keyed?: false;
    children: ConditionalRenderChildren<T, F>;
};
export type KeyedMatchProps<T, F extends KeyedConditionalRenderCallback<T> = KeyedConditionalRenderCallback<T>> = {
    when: T | undefined | null | false;
    keyed: true;
    children: KeyedConditionalRenderChildren<T, F>;
};
export type AnyMatchProps<T> = MatchProps<T> | KeyedMatchProps<T> | {
    when: T | undefined | null | false;
    keyed?: boolean;
    children: SolidElement;
};
/**
 * Selects a content based on condition when inside a `<Switch>` control flow
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/switch-and-match
 */
export declare function Match<T>(props: {
    when: T | undefined | null | false;
    keyed: true;
    children: SolidElement;
}): SolidElement;
export declare function Match<T, F extends KeyedConditionalRenderCallback<T>>(props: KeyedMatchProps<T, F>): SolidElement;
export declare function Match<T>(props: {
    when: T | undefined | null | false;
    keyed?: false;
    children: SolidElement;
}): SolidElement;
export declare function Match<T, F extends ConditionalRenderCallback<T>>(props: MatchProps<T, F>): SolidElement;
export declare function Match<T>(props: AnyMatchProps<T>): SolidElement;
/**
 * Catches uncaught errors inside components and renders a fallback content
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/errored
 */
export declare function Errored(props: {
    fallback: SolidElement | ((err: () => any, reset: () => void) => SolidElement);
    children: SolidElement;
}): SolidElement;
/**
 * Tracks all resources inside a component and renders a fallback until they are all resolved
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/loading
 */
export declare function Loading(props: {
    fallback?: SolidElement;
    on?: any;
    children: SolidElement;
}): SolidElement;
export type RevealProps = {
    order?: RevealOrder;
    collapsed?: boolean;
    children: SolidElement;
};
/**
 * Coordinates the reveal timing of sibling `<Loading>` boundaries during SSR.
 *
 * The `order` prop picks the reveal policy:
 * - `"sequential"` (default) — boundaries reveal in streamed order; out-of-order
 *   resolutions have their fragment HTML streamed into templates as data arrives,
 *   but the swap from fallback to content waits until the frontier reaches them.
 * - `"together"` — every direct slot holds its fallback until the whole group is
 *   "minimally ready" (every direct slot has its own first visible content
 *   available), then the whole group releases in a single activation.
 * - `"natural"` — each boundary's swap is triggered as its own data resolves. At
 *   the top level this is equivalent to omitting `<Reveal>`; the mode exists for
 *   nesting, where the group registers as a single composite slot in an enclosing
 *   `<Reveal>`.
 *
 * The `collapsed` prop is only consulted when `order="sequential"` (the default);
 * it is ignored under `"together"` and `"natural"`.
 *
 * Nesting: a nested `<Reveal>` is held on its fallbacks until its parent releases
 * the slot it occupies. HTML for resolved fragments still streams through normally;
 * only the `revealFragments` swap calls are deferred. Once released, the inner
 * group runs its own `order` locally over whatever is still pending. There is no
 * escape hatch.
 *
 * Engine support:
 * - `renderToString` fully supports `order="sequential"` (without `collapsed`) and
 *   `order="natural"` because neither requires streamed activation.
 * - `order="together"` and `collapsed` rely on streamed activation and require
 *   `renderToStream`. Using them inside a nested `<Reveal>` under
 *   `renderToString` logs a warning.
 *
 * See `documentation/solid-2.0/03-control-flow.md` for the full outer/inner
 * nesting matrix and the "minimally ready" definition per order.
 *
 * @description https://v2.solidjs.com/reference/solid-js/components-jsx/reveal
 */
export declare function Reveal(props: RevealProps): SolidElement;
