import type { Context } from "./signals.js";
import type { Observe } from "@solidjs/signals";
export type SSRTemplateObject = {
    t: string[];
    h: Function[];
    p: Promise<any>[];
} | {
    t: string;
    h?: undefined;
    p?: undefined;
};
/** Inline style content, e.g. dev CSS collected from a bundler's module graph. */
export type InlineStyleAsset = {
    id: string;
    content: string;
    attrs?: Record<string, string>;
};
export type ResolvedAssets = {
    js: string[];
    css: (string | InlineStyleAsset)[];
    /** Renderer-defined preload descriptors; lazy() only reads `as` for NoHydration filtering. */
    preloads?: unknown[];
};
export type HydrationContext = {
    id: string;
    count: number;
    /**
     * Serialize a value for client hydration.
     * In renderToStream (async: true), accepts promises and async iterables.
     * In renderToString (async: false), only synchronous values are allowed —
     * passing async values will throw.
     */
    serialize: (id: string, v: any, deferStream?: boolean) => void;
    resolve(value: any): SSRTemplateObject;
    ssr(template: string[], ...values: any[]): SSRTemplateObject;
    escape(value: any): string;
    replace: (id: string, replacement: () => any) => void;
    block: (p: Promise<any>) => void;
    /**
     * Register a deferred fragment; the resolver settles it: `v` its markup,
     * `err` the failure it settled with, `escaped` that the failure escaped a
     * server component (no server `<Errored>` rendered an outcome for it) —
     * the renderer surfaces it as the frame's own error, the outward face;
     * `escaped.frame` names the component's frame where the channel needs it
     * (the document face's `sc:live` op).
     */
    registerFragment: (v: string, options?: {
        revealGroup?: string;
    }) => (v?: string, err?: any, escaped?: {
        frame?: string;
    }) => boolean;
    revealFragments?: (groupOrKeys: string | string[]) => void;
    revealFallbacks?: (groupOrKeys: string | string[]) => void;
    /** Register a client-side asset discovered during SSR (e.g. from lazy()). */
    registerAsset?: {
        (type: "module" | "style", url: string): void;
        (type: "inline-style", style: InlineStyleAsset): void;
        (type: "preload", preload: unknown): void;
    };
    /** Register a moduleUrl-to-entryUrl mapping for the current boundary. */
    registerModule?: (moduleUrl: string, entryUrl: string) => void;
    /**
     * Resolve a module's client assets from the asset manifest. Set by
     * the @solidjs/web server renderer. Resolver manifests (dev servers answering from a live
     * module graph) may return a promise and may resolve css entries to
     * inline-style descriptors instead of URLs.
     */
    resolveAssets?: (moduleUrl: string) => ResolvedAssets | null | Promise<ResolvedAssets | null>;
    /**
     * Synchronous resolution fast path. Set by @solidjs/web for object
     * manifests (sync by nature) and for resolver manifests providing
     * `resolveSync`; used by sync consumers like lazy's moduleUrl getter.
     */
    resolveAssetsSync?: (moduleUrl: string) => ResolvedAssets | null | undefined;
    /** Retrieve the moduleUrl-to-entryUrl map for a boundary. */
    getBoundaryModules?: (id: string) => Record<string, string> | null;
    /** True only in renderToStream — enables async data serialization and streaming. */
    async?: boolean;
    /**
     * Frame renders only (DR-2 case 1, set by the frame sink): signal that an
     * async value settled without a serialization flush the sink could see —
     * the binding ledger schedules an equality-gated sweep of watched slot
     * args. No-op semantics elsewhere; absent outside frame renders.
     */
    commit?: () => void;
    /**
     * Frame renders only (set alongside `commit`): the sink's commit epoch.
     * Sync-valued memos cache per epoch — cached within one sweep, recomputed
     * when pulled after a later commit — so watched-arg sweeps read current
     * derivations. Absent outside frame renders (memos then cache for the
     * render, the document-SSR contract).
     */
    commitEpoch?: () => number;
    /**
     * Take a response-window hold; returns the release. Live work with a
     * knowable end that isn't a fragment or a serialized promise — a
     * server-consumed async iterable feeding live bindings (a bounded async
     * trace) — keeps the response open until it completes. Set by
     * @solidjs/web's render core; holds gate only the end of the response.
     */
    hold?: () => () => void;
    /**
     * Document renders only (set alongside `commit` by @solidjs/web's
     * document live-hole arming): told when the render serves something a
     * later commit in this response will replace — a server-owned async
     * iterable classified to pump, a loading value or seed served ahead of
     * its landing. Called before that value can be read, so a hole minted
     * while it has never been called read only final values, and ships
     * unmarked.
     */
    unsettled?: () => void;
};
export declare const NoHydrateContext: Context<boolean>;
type SharedConfig = {
    context?: HydrationContext;
    getNextContextId(): string | undefined;
};
export declare const sharedConfig: SharedConfig;
export declare function callerRenderContext(): HydrationContext | undefined;
/**
 * Gives the core's `OBSERVE.attribution.withOrigin` its one server meaning.
 * The server reimplements reactivity and installs no attribution engine, so
 * the core's `withOrigin` is `fn()` here; a router calls it the same way on
 * both sides, and the initial-route declaration it makes while building its
 * context under a render is the fact the server has nowhere else to learn
 * — the route a request resolved to, for the request's `"render"` record
 * (`RenderEvent.route`). Filed through the render context's `_declareRoute`
 * seam, which @solidjs/web installs while a `"render"` listener exists; a
 * non-initial ref (nothing writes a location on the server) and a call
 * outside a render are `fn()` as before. A host that bundles the runtime
 * twice (two copies of this entry over one core) wraps twice, each copy
 * reading its own `sharedConfig` — only the copy running the render has a
 * context, so the declaration lands once, on that render. Called from the
 * server entry under `_SOLID_OBSERVE_`.
 */
export declare function installServerWithOrigin(observe: Observe): void;
export {};
