import type { Accessor, Component, DynamicOptions, RevealOrder, ServerErrorHook, ServerErrorSite } from "solid-js";
import type { HydrationContext } from "./server/shared.js";
export { mergeSources, mergeView, omitView, viewOf, OmitView, MergeView, sourceKeys, sourceHas, sourceGet, sourceOwners, hasStaticKeys, resolvedTable, SOURCE_PLAIN, SOURCE_OMIT, SOURCE_PROXY, SOURCE_MEMO, SOURCE_MERGE, type SourceKind } from "@solidjs/signals";
/**
 * Server: a thrown `NotReadyError` becomes the promise to wait on (or, with
 * `probe`, is reported without rethrowing); anything else is rethrown or
 * routed to the owner's error handling. Client: no-op.
 */
export declare const ssrHandleError: (err: any, probe?: boolean) => Promise<any> | undefined;
/** Server: wrap `fn` to run under the current request's owner/scope. Client: identity. */
export declare const ssrScope: <T>(fn: () => T) => () => unknown;
/** Server: run `fn` inside the current server-component scope (`live` marks a live component's document render). Client: calls `fn`. */
export declare const runInServerComponentScope: <T>(fn: () => T, options?: {
    live?: boolean;
}) => T;
/** Server: whether a server-component scope is active. Client: `false`. */
export declare const inServerComponentScope: () => boolean;
/** Server: whether a LIVE server component's document render scope is active. Client: `false`. */
export declare const inLiveServerComponentScope: () => boolean;
/**
 * Server: the value the client may see in place of a render failure about to
 * be serialized or rendered for it — the value itself in the dev build or
 * when branded with `markSafeError`, else one generic `Error` per original
 * (recorded once as `SERVER_ERROR_SANITIZED`, `data.source: "ssr"`). `subject` locates the finding;
 * `null` from a serialization funnel. With a `site`, the hook hears of it
 * first (`hook` and `scope` as `reportServerError` takes them). Client: identity.
 */
export declare const ssrSanitizeError: (value: unknown, subject?: object | null, site?: ServerErrorSite, hook?: ServerErrorHook, scope?: object) => unknown;
/**
 * Server: tells the server error hook about a failure — once per error
 * object per kind per request (per render outside one), at first sight — with where
 * it was met; `{ mapped: true, value }` when the hook gave a wire value (now
 * or earlier), `{ mapped: false }` otherwise. `hook` is the hook of the render or request the failure
 * belongs to (a render's `onError`, the server-function handler's) — the
 * caller's to name, never read off the global SSR context — ahead of the
 * ambient registration; `undefined` leaves the ambient one alone. `scope`
 * is the render's ledger scope (its context's `_errorScope`) when the caller
 * has it; else the request in scope is. Client: `{ mapped: false }`.
 */
export declare const reportServerError: (value: unknown, site: ServerErrorSite, subject?: object | null, hook?: ServerErrorHook, scope?: object) => {
    mapped: boolean;
    value?: unknown;
};
export type { ServerErrorSite, ServerErrorHook } from "solid-js";
/** Server: a monotonic stamp for owner creation order. Client: `0`. */
export declare const creationStamp: () => number;
/**
 * Client: set (or clear, `null`) a callback run before every signal or store
 * write lands — the server-components client's deferred hydration mounts
 * what it left unmounted. Server: no-op.
 */
export declare const setWriteHook: (hook: ((node?: object) => void) | null) => void;
/** Dependency edges. Client: name plain signals (`<owner id>~<n>`) from now on. Server: no-op. */
export declare const setSignalIdentities: (on: boolean) => void;
/**
 * Dependency edges. Server: a render that names and tracks plain signals
 * starts; call the returned function when it ends. Client: no-op.
 */
export declare const beginEdgesRender: () => () => void;
/** Dependency edges, dev only. Client: watch every node read. Server: no-op. */
export declare const setReadWatch: (watch: ((node: object) => void) | null) => void;
/** Dependency edges. Client: a plain signal's identity, if it was named. Server: `undefined`. */
export declare const signalName: (node: object | undefined) => string | undefined;
/**
 * Dependency edges. Client: the name a store proxy's writes go by (its
 * root's, when the root was named and can be placed). Server: `undefined`.
 */
export declare const storeName: (proxy: object | undefined) => string | undefined;
/**
 * Dependency edges. Server: run a slot fill, returning the plain-signal
 * identities it read (through memos too) and whether it ran a computation
 * whose reads the server cannot see. Client: runs it.
 */
export declare const trackFillReads: <T>(fn: () => T) => {
    result: T;
    reads: Set<string> | null;
    untracked: boolean;
};
/** Server: the live projection trace behind a value, if any. Client: `undefined`. */
export declare const getProjectionTrace: (value: unknown) => {
    subscribe(): AsyncIterable<any>;
    array: boolean;
} | undefined;
/**
 * Server: a seat on the shared multicast of an async iterable — every reader
 * under a render (the serializer, memos) sees the whole sequence. Client:
 * the source itself.
 */
export declare const shareAsyncIterable: <T>(source: AsyncIterable<T>) => AsyncIterable<T>;
/** The primitive behind `<Errored>`: `fn()`, or `fallback(error, reset)` once something under it throws. */
export declare const createErrorBoundary: <T, U>(fn: () => T, fallback: (error: Accessor<unknown>, reset: () => void) => U) => Accessor<T | U>;
/** The primitive behind `<Loading>`: `fallback()` while async reads under `fn` are pending, else `fn()`. */
export declare const createLoadingBoundary: <T, U>(fn: () => T, fallback: () => U, options?: {
    on?: () => any;
}) => Accessor<T | U>;
/** The primitive behind `<Reveal>`: coordinates when the loading boundaries under `fn` reveal. */
export declare const createRevealOrder: <T>(fn: () => T, options?: {
    order?: () => RevealOrder;
    collapsed?: () => boolean;
}) => T;
/**
 * The core behind `dynamicComponent` and `@solidjs/web`'s `dynamic`. `tagArm`
 * is the renderer's string-tag path (`staticElement` on the client,
 * `ssrElement` on the server); omit it and a string resolution renders
 * nothing. Not application API.
 */
export declare const dynamicCore: (source: () => any, options?: DynamicOptions, tagArm?: (tag: string, props: any) => any) => Component<any>;
/**
 * The shape `sharedConfig` has on either entry. The two objects share the
 * name, not the members: the client's carries hydration state, populated by
 * `enableHydration()` and the DOM runtime's `hydrate()`; the server's carries
 * the render's `context` and the id allocator. Every member is therefore
 * optional — a member is present only on the tier (and, for some, only in
 * the phase) that sets it.
 */
interface SharedConfig {
    /**
     * Both: the next hydration key under the current owner, `undefined` under
     * `NoHydration`. Server: always present. Client: assigned by
     * `enableHydration()`, read only behind a `hydrating` check.
     */
    getNextContextId?: () => string | undefined;
    /**
     * Both, dev builds only: the id `getNextContextId()` would hand out next,
     * read without consuming it (`undefined` outside an id-carrying tree).
     * Callers gate on `_SOLID_DEV_`.
     */
    devPeekNextContextId?: () => string | undefined;
    /** Server: the hydration context of the render in progress, absent outside one. */
    context?: HydrationContext;
    /** Client: whether a hydration pass is claiming server-rendered DOM right now. */
    hydrating?: boolean;
    /** Client: whether hydration has completed. */
    done?: boolean;
    resources?: {
        [key: string]: any;
    };
    /** Client: reads a serialized value by id from the hydration payload. */
    load?: (id: string) => Promise<any> | any;
    /** Client: whether the hydration payload carries `id`. */
    has?: (id: string) => boolean;
    /** Client: collects the server-rendered nodes under the hydration root `key` into `registry`. */
    gather?: (key: string) => void;
    /** Client: the server-rendered nodes of the active root, by hydration key. */
    registry?: Map<string, object>;
    /**
     * Client: the registry/gather pair each streamed boundary registered
     * under, keyed by boundary id, so a late resume claims against its own root.
     */
    boundaryScopes?: Map<string, {
        registry?: Map<string, object>;
        gather?: (key: string) => void;
    }>;
    captureBoundaryScope?: (id: string) => void;
    cleanupFragment?: (id: string) => void;
    loadModuleAssets?: (mapping: Record<string, string>) => Promise<void> | undefined;
    completed?: WeakSet<object> | null;
    events?: any[] | null;
    verifyHydration?: () => void;
    /** Client: whether a hydration pass is still claiming — absent means "not hydrating". */
    isHydrationInProgress?: () => boolean;
    /** Client: runs `callback` once all hydration completes — absent means it already has. */
    onHydrationEnd?: (callback: () => void) => void;
    /** Client: whether a render under the current owner is part of the claim in progress — absent means "claiming". */
    isClaiming?: () => boolean;
}
/**
 * The hydration/SSR coordination object the core shares with its renderers
 * — the client entry's or the server entry's, whichever the app runs.
 */
export declare const sharedConfig: SharedConfig;
/**
 * Client: installs the server-component half of hydration on `sharedConfig`
 * and the page's `_$HY` — `holdBoundary` (a client hold on adopted markup
 * counted as a pending boundary, frames-rulings 3.1), `hydrateWindow` (the
 * claim window an adopted occurrence re-enters hydration through), fragment
 * ownership by rendering (the `_$HY.fa` term of the reveal policy) and the
 * ledger's published answer `_$HY.fr` ({ pending, subscribe }). For the
 * integration that owns server-rendered markup wholesale (`@solidjs/web/frames`'
 * `installServerComponents`), which calls it where it installs its reveal
 * hook; idempotent, before or after `hydrate()`. A page without server
 * components never calls it and carries none of it. Server: no-op.
 */
export declare const enableServerComponentHydration: () => void;
/**
 * Dev builds: the brand the component wrapper sets on every component it
 * runs (`Comp[$DEVCOMP] === true`), read by the refresh runtime and
 * devtools. Other builds: a symbol nothing sets.
 */
export declare const $DEVCOMP: symbol;
