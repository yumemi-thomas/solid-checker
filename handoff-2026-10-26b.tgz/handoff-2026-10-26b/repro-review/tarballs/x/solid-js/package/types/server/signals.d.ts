import { $REFRESH } from "@solidjs/signals";
export { $REFRESH };
export { NotReadyError, NoOwnerError, ContextNotFoundError, TimeoutError, isEqual, isWrappable, SUPPORTS_PROXY, enableExternalSource, enforceLoadingBoundary } from "@solidjs/signals";
export { flatten } from "@solidjs/signals";
export { snapshot, omit, storePath, isStatic, $PROXY, $TRACK } from "@solidjs/signals";
import type { Accessor as SignalAccessor, ProjectionOptions, Refreshable, StoreOptions } from "@solidjs/signals";
export type SourceAccessor<T> = Refreshable<SignalAccessor<T>>;
export type { Accessor, ComputeFunction, EffectFunction, EffectBundle, EffectOptions, ExternalSource, ExternalSourceConfig, ExternalSourceFactory, MemoOptions, NoInfer, SignalOptions, Setter, Signal, Owner, Refreshable, Maybe, Store, StoreSetter, StoreNode, NotWrappable, SolidStore, Merge, Omit, Context, ContextRecord, IQueue, StorePathRange, ArrayFilterFn, CustomPartial, Part, PathSetter } from "@solidjs/signals";
import type { Accessor, ComputeFunction, EffectFunction, EffectBundle, EffectOptions, MemoOptions, SignalOptions, Signal, Merge, Owner, Store, StoreSetter, Context, UntilOptions } from "@solidjs/signals";
import { sharedConfig, NoHydrateContext } from "./shared.js";
type Disposable = () => void;
interface SSROwner {
    /**
     * The hydration id, or — while `_scopeSlot >= 0` — the PREFIX of a
     * pending one (see `ssrScope`). Read it for id derivation only through
     * `materializeId` / `ownerId`, never directly.
     */
    id?: string;
    _transparent: boolean;
    _disposal: Disposable | Disposable[] | null;
    _parent: SSROwner | null;
    _context: Record<symbol | string, unknown>;
    _childCount: number;
    _firstChild: SSROwner | null;
    _nextSibling: SSROwner | null;
    _disposed: boolean;
    /**
     * A reserved-but-unformatted hole slot (`ssrScope`), or -1. While a hole
     * scope is swapped onto this owner, its id is the pair (`id` = the
     * enclosing owner's id, `_scopeSlot` = the slot the hole reserved) and
     * the string `formatChildId(id, _scopeSlot)` is only built on demand —
     * a text hole never asks for one. Owned by the swap: set and restored
     * around every evaluation; -1 in every literal and on pool reuse.
     */
    _scopeSlot: number;
    /**
     * Observe/dev tiers only: the label the core's `ownerPath` walk reads
     * (`<Name>` on a component's owner — see `createComponentOwner`), the
     * same field and the same walk as client owners, so a server finding
     * locates itself as `<App> › <Page>` without the core learning this
     * shape. Prod owners never carry the slot (a second literal, like the
     * signals node shapes), so the 10-field layout above is untouched there.
     */
    _name?: string;
    /**
     * Observe/dev tiers only: the component's JSX site (`file:line:col`) the
     * compiler emitted beside its name — the core's `emitDiagnostic` walks
     * `_parent` for the first one, so a server finding carries `loc` the way
     * a client one does. A slot beside `_name`, for the same hidden-class
     * reason.
     */
    _loc?: string;
}
/**
 * The owner's id for a reader that is NEVER a pending hole scope — its own
 * freshly created owner (boundaries, rows, Reveal, an async node's
 * serialization key). The direct field read is the prod build; the dev
 * build asserts the premise, so a future reader that lands on a swapped
 * owner fails loudly instead of deriving from the bare prefix. Readers that
 * CAN see a pending owner use `materializeId`.
 */
export declare function ownerId(owner: Owner | SSROwner): string | undefined;
export declare function getNextChildId(owner: Owner): string;
export declare function peekNextChildId(owner: Owner): string;
/**
 * Dev only — installed as `sharedConfig.devPeekNextContextId`, never
 * exported from the entry (the prod and observe artifacts carry none of it).
 * The id the NEXT child of the current owner would take, read with no side
 * effect: a pending hole slot (`ssrScope`) is folded into the prefix
 * arithmetically — the same string `materializeId` would build — without
 * materializing it onto the owner. `undefined` outside an id-carrying tree.
 * `@solidjs/web` snapshots it around an unscoped hole's evaluation: a hole
 * that moved it took ids from the enclosing counter, which the client
 * allocates at a different time (`UNSCOPED_HOLE_ALLOCATED_IDS`).
 */
export declare function devPeekNextChildId(): string | undefined;
/** The reactive-scope creation stamp (see `ownerCreations`). */
export declare function creationStamp(): number;
export declare function createOwner(options?: {
    id?: string;
    transparent?: boolean;
}): Owner;
/**
 * Observe/dev tiers: the transparent, labelled owner a component body runs
 * under, so the owner tree reads as the component tree — the server twin of
 * the client's `observedComponent` root. Transparent, so it consumes no
 * hydration id (ids keep walking up to the enclosing id-bearing owner).
 * NOT counted in `creationStamp()`: the live-hole engine reads that stamp
 * to tell render-once work from re-runnable holes, and a label must not
 * change that verdict between tiers — a component that latches in the
 * observe tier and binds live in prod would be a tier-dependent render.
 * Never called from the prod build.
 */
export declare function createComponentOwner(name: string, loc?: string): Owner;
export declare function runWithOwner<T>(owner: Owner | null, fn: () => T): T;
export declare function getOwner(): Owner | null;
export declare function isDisposed(owner: Owner): boolean;
/**
 * Server mirror of `onCleanup`. Cleanups run in unwind order: an owner's
 * children are disposed before its own cleanups, and within one owner later
 * registrations run before earlier ones (see `disposeOwner`).
 */
export declare function onCleanup(fn: Disposable): Disposable;
export declare function createContext<T>(defaultValue?: T, description?: string): Context<T>;
export declare function getContext<T>(context: Context<T>, owner?: Owner | null): T;
export declare function setContext<T>(context: Context<T>, value?: T, owner?: Owner | null): void;
export declare function createRoot<T>(init: ((dispose: () => void) => T) | (() => T), options?: {
    id?: string;
    transparent?: boolean;
}): T;
/**
 * Id scope for a dynamic child hole ("hole owner"). One id slot is reserved
 * from the enclosing owner at registration time — in source order — so
 * sibling ids can't shift when the hole's evaluation is deferred by async
 * and retried later. Every evaluation attempt runs with the reserved id and
 * a zeroed child counter, making retries deterministic. Mirrors the client,
 * where the outer insert effect for the same hole is non-transparent (its
 * own id scope).
 *
 * Emitted by the ssr generate as `_$scope(...)` around deferred child holes
 * that can allocate hydration ids. Hot per-row path (one per qualifying
 * hole), so no owner object is allocated — like mapArray's row-owner
 * elision, the scope is virtual: the parent owner's `id`/`_childCount` are
 * swapped around the evaluation. Content created during the evaluation
 * attaches to the parent owner, which matches the pre-scope disposal
 * semantics (boundary retries dispose it via the boundary owner).
 *
 * The swapped owner is the nearest ID-BEARING one, not necessarily the
 * current one: content created inside the hole reads its ids through
 * `nextChildIdFor`, which walks up past transparent owners, so a swap on a
 * transparent owner (the server-component scope owner; in observe/dev, the
 * labelled `<Name>` owner every component body runs under) would be
 * invisible to it and the hole's content would take fresh ids from the
 * enclosing counter — a different id than the client, which scopes the
 * hole by its own insert effect regardless of what sits between.
 *
 * The reservation is a counter increment; the scope's id STRING is not
 * built here. Most scoped holes are text (`{row.label}` — since #3599 every
 * hole that is not provably primitive is scoped) and nothing inside them
 * ever asks for a child id, so formatting `prefix + slot` up front was the
 * dominant per-hole cost. Instead the swap installs the pair
 * (`id = prefix`, `_scopeSlot = slot`) and `materializeId` folds it into the
 * string on the first derivation — the same string the eager form built.
 * `prefix` is the enclosing owner's id at reservation time, materialized
 * once if that owner is itself a pending scope (a hole inside a hole).
 */
export declare function ssrScope<T>(fn: () => T): () => unknown;
interface ServerComputation<T = any> {
    owner: Owner;
    value: T;
    compute: ComputeFunction<any, T>;
    error: unknown;
    errored: boolean;
    computed: boolean;
    disposed: boolean;
    sync?: boolean;
    epoch?: number;
    moving?: boolean;
    onDisposed?: Array<() => void>;
}
type SsrSourceMode = "server" | "hybrid" | "client";
interface ServerProjectionOptions extends ProjectionOptions {
    deferStream?: boolean;
    ssrSource?: SsrSourceMode;
}
type ServerMemoOptions<T> = MemoOptions<T> & {};
type ServerSignalOptions<T> = SignalOptions<T>;
type NoFn<T> = T extends Function ? never : T;
type NoArray<T> = Extract<T, readonly unknown[]> extends never ? unknown : never;
export declare function getObserver(): ServerComputation<any> | null;
export declare function createSignal<T>(): Signal<T | undefined>;
export declare function createSignal<T>(value: Exclude<T, Function>, options?: SignalOptions<T>): Signal<T>;
export declare function createSignal<T>(fn: ComputeFunction<NoInfer<T>, T>, options: ServerSignalOptions<T> & {
    loadingValue: T;
}): Signal<T>;
export declare function createSignal<T>(fn: ComputeFunction<undefined | NoInfer<T>, T>, options?: ServerSignalOptions<T>): Signal<T>;
export declare function createMemo<T>(compute: ComputeFunction<NoInfer<T>, T>, options: ServerMemoOptions<T> & {
    loadingValue: T;
}): SourceAccessor<T>;
export declare function createMemo<T>(compute: ComputeFunction<undefined | NoInfer<T>, T>, options?: ServerMemoOptions<T>): SourceAccessor<T>;
export type PatchOp = [path: PropertyKey[]] | [path: PropertyKey[], value: any] | [path: PropertyKey[], value: any, insert: 1];
export declare function createDeepProxy<T extends object>(target: T, patches: PatchOp[], basePath?: PropertyKey[], shallow?: boolean): T;
export declare function createEffect<const T>(compute: ComputeFunction<undefined | NoInfer<T>, T>, effect: EffectFunction<NoInfer<T>, T> | EffectBundle<NoInfer<T>, T>, options?: EffectOptions): void;
export declare function createRenderEffect<const T>(compute: ComputeFunction<undefined | NoInfer<T>, T>, effectFn: EffectFunction<NoInfer<T>, T>, options?: EffectOptions): void;
/**
 * @deprecated Do not use in new code: `createEffect(compute, effect)` for
 * reactive side effects, `onSettled` for one-time post-render DOM work.
 * Retained only to ease 1.x migration — see the JSDoc in `@solidjs/signals`.
 */
export declare function createTrackedEffect(compute: () => void | (() => void), options?: {
    name?: string;
}): void;
export declare function createReaction(effectFn: EffectFunction<undefined> | EffectBundle<undefined>, options?: EffectOptions): (tracking: () => void) => void;
export declare function createOptimistic<T>(): Signal<T | undefined>;
export declare function createOptimistic<T>(value: Exclude<T, Function>, options?: SignalOptions<T>): Signal<T>;
export declare function createOptimistic<T>(fn: ComputeFunction<NoInfer<T>, T>, options: ServerSignalOptions<T> & {
    loadingValue: T;
}): Signal<T>;
export declare function createOptimistic<T>(fn: ComputeFunction<undefined | NoInfer<T>, T>, options?: ServerSignalOptions<T>): Signal<T>;
export declare function createStore<T extends object = {}>(initialValue: NoFn<T> | Store<NoFn<T>>, options?: StoreOptions): [get: Store<T>, set: StoreSetter<T>];
export declare function createStore<T extends object = {}>(fn: (() => T | Promise<T> | AsyncIterable<T>) & NoArray<T>, seed?: null, options?: Omit<ServerProjectionOptions, "seedLoadingValue">): [get: Refreshable<Store<T>>, set: StoreSetter<T>];
export declare function createStore<T extends object = {}>(fn: (draft: T) => void | T | Promise<void | T> | AsyncIterable<void | T>, seed: NoFn<T> | Store<NoFn<T>>, options?: ServerProjectionOptions): [get: Refreshable<Store<T>>, set: StoreSetter<T>];
export declare function createOptimisticStore<T extends object = {}>(initialValue: NoFn<T> | Store<NoFn<T>>, options?: StoreOptions): [get: Store<T>, set: StoreSetter<T>];
export declare function createOptimisticStore<T extends object = {}>(fn: (() => T | Promise<T> | AsyncIterable<T>) & NoArray<T>, seed?: null, options?: Omit<ServerProjectionOptions, "seedLoadingValue">): [get: Refreshable<Store<T>>, set: StoreSetter<T>];
export declare function createOptimisticStore<T extends object = {}>(fn: (draft: T) => void | T | Promise<void | T> | AsyncIterable<void | T>, seed: NoFn<T> | Store<NoFn<T>>, options?: ServerProjectionOptions): [get: Refreshable<Store<T>>, set: StoreSetter<T>];
export interface ProjectionTrace {
    /** An independent consumer: snapshot at subscribe, then every batch after. */
    subscribe(): AsyncIterable<any>;
    /** Whether the projection's root is an array — the consumer's seed shape. */
    array: boolean;
}
export declare function createProjection<T extends object = {}>(fn: (() => T | Promise<T> | AsyncIterable<T>) & NoArray<T>, seed?: null, options?: Omit<ServerProjectionOptions, "seedLoadingValue">): Refreshable<Store<T>>;
export declare function createProjection<T extends object = {}>(fn: (draft: T) => void | T | Promise<void | T> | AsyncIterable<void | T>, seed: NoFn<T> | Store<NoFn<T>>, options?: ServerProjectionOptions): Refreshable<Store<T>>;
export declare function reconcile<T extends U, U extends object>(value: T): (state: U) => T;
export declare function deep<T extends object>(store: Store<T>): Store<T>;
export declare function merge<T extends unknown[]>(...sources: T): Merge<T>;
export declare function mapArray<T, U>(list: Accessor<readonly T[] | undefined | null | false>, mapFn: (v: T, i: Accessor<number>) => U, options?: {
    keyed?: true;
    fallback?: Accessor<any>;
}): () => U[];
export declare function mapArray<T, U>(list: Accessor<readonly T[] | undefined | null | false>, mapFn: (v: Accessor<T>, i: number) => U, options: {
    keyed: false;
    fallback?: Accessor<any>;
}): () => U[];
export declare function mapArray<T, U>(list: Accessor<readonly T[] | undefined | null | false>, mapFn: (v: Accessor<T>, i: Accessor<number>) => U, options: {
    keyed: (item: T) => any;
    fallback?: Accessor<any>;
}): () => U[];
export declare function repeat<T>(count: Accessor<number>, mapFn: (i: number) => T, options?: {
    fallback?: Accessor<any>;
    from?: Accessor<number | undefined>;
}): () => T[];
/**
 * The error handler a boundary installs for its subtree. Called with the
 * error alone it routes it (an `<Errored>` renders its fallback and throws;
 * a `<Loading>` channels it). Called with `outcome: true` it is asked for
 * the SERVER's rendered outcome for a post-flush failure inside a server
 * component (frames-rulings 3.3 — the position shows what the server
 * rendered, never a blank): the nearest server `<Errored>` answers with
 * its fallback as markup; a `<Loading>` passes the question up; a handler
 * that belongs to no server `<Errored>` answers `undefined` — the error
 * escapes the component.
 */
export type BoundaryErrorHandler = (err: any, outcome?: true) => string | undefined | void;
declare const ErrorContext: Context<BoundaryErrorHandler | null>;
export { ErrorContext };
export type ServerRevealGroup = {
    id: string;
    /**
     * Register a child fragment (Loading) or composite child (inner Reveal).
     * Returns `collapseFallback` (hide fallback visually, used for collapsed-sequential
     * tail) and `held` (stash `revealFragments` swaps until the parent releases us).
     * `held` only applies when the caller is a nested Reveal — Loadings ignore it.
     *
     * `onReveal` (a Loading's, observe tier): called when the group issues the
     * swap for `key` — its `revealFragments` — so the boundary record can say
     * how long the finished content was held. Synchronous from `onResolved`
     * when the order lets the child reveal live; later otherwise.
     */
    register(key: string, options?: {
        onActivate?: () => void;
        onReveal?: () => void;
    }): {
        collapseFallback: boolean;
        held: boolean;
    };
    /** Called by a child when its subtree is fully resolved, which also implies minimal readiness. */
    onResolved(key: string): void;
    /**
     * Called by a nested Reveal when it becomes "minimally resolved" under its own
     * order (together: fully resolved; sequential: first registered fragment resolved;
     * natural: any fragment resolved). Loadings don't fire this — their `onResolved`
     * implies minimal readiness at the same time.
     */
    onMinimallyResolved?(key: string): void;
};
export declare const RevealGroupContext: Context<ServerRevealGroup | null>;
export declare function runWithBoundaryErrorContext<T>(owner: Owner, render: () => T, onError: (err: any, parentHandler: BoundaryErrorHandler | null, outcome?: true) => string | undefined | void, context?: NonNullable<typeof sharedConfig.context>, boundaryId?: string): T;
export { NoHydrateContext };
/** Where a failure was met, as the hook hears it (the `event` is added at the call). */
export interface ServerErrorSite {
    kind: "render" | "server-function" | "request";
    handling: "fallback" | "client" | "failed" | "serialize" | "thrown" | "channel";
    boundary?: string;
    /**
     * Where the error was THROWN: component labels root-first up the owner
     * chain it escaped (the observe and dev builds label owners). The
     * boundary's chain when the thrower is unknown.
     */
    ownerPath?: string[];
    /** Where it was MET: the labels up the chain of the boundary named by `boundary`. */
    boundaryPath?: string[];
    functionId?: string;
    direct?: boolean;
    /** The request event, when the caller has it in hand; else read from the request scope. */
    event?: unknown;
}
export type ServerErrorHook = (error: unknown, context: ServerErrorSite) => unknown | void;
export declare function createErrorBoundary<T, U>(fn: () => T, fallback: (error: Accessor<unknown>, reset: () => void) => U): Accessor<T | U>;
export declare function createLoadingBoundary<T, U>(fn: () => T, fallback: () => U, options?: {
    on?: () => any;
}): Accessor<T | U>;
export type RevealOrder = "sequential" | "together" | "natural";
export declare function createRevealOrder<T>(fn: () => T, _options?: {
    order?: () => RevealOrder;
    collapsed?: () => boolean;
}): T;
export declare function untrack<T>(fn: () => T): T;
export declare function flush(): void;
export declare function resetErrorHalt(): void;
export interface ClientErrorContext {
    ownerPath?: string[];
}
export type ClientErrorHook = (error: unknown, context: ClientErrorContext) => void;
export interface ClientErrorsConfig {
    onError?: ClientErrorHook;
}
export declare function configureClientErrors(_config: ClientErrorsConfig): void;
export declare function resolve<T>(fn: () => T): Promise<T>;
export declare function until<T>(fn: () => T, options?: UntilOptions): Promise<T>;
export declare function isPending(fn: () => any): boolean;
export declare function latest<T>(fn: () => T): T;
export declare function refresh<T>(target: Refreshable<T>): Promise<T extends (...args: any) => infer V ? V : T>;
/** On the server everything is a first load and the server always waits:
 * `createDeferred` is `createMemo` (D-40). */
export declare const createDeferred: typeof createMemo;
export declare function affects(_target: unknown, _key?: PropertyKey): void;
export declare function action<T extends (...args: any[]) => any>(fn: T): T;
export declare function onSettled(callback: () => void | (() => void)): void;
type NoInfer<T extends any> = [T][T extends any ? 0 : never];
export declare function storeIsShallow(_proxy: any): boolean;
export declare function storeHasFamily(_proxy: any): boolean;
export declare function storeHasOptimisticFamily(_proxy: any): boolean;
