import type { Accessor } from "./signals.js";
import type { Element as SolidElement } from "../types.js";
export { sharedConfig, NoHydrateContext } from "./shared.js";
export type { HydrationContext, SSRTemplateObject } from "./shared.js";
/**
 * Handles errors during SSR rendering.
 * Returns the promise source for NotReadyError (for async handling),
 * or delegates to the ErrorContext handler.
 *
 * `probe: true` is the side-effect-free identification mode: it answers the
 * pending source for NotReady and `undefined` for anything else, never
 * routing or rethrowing. Used where the caller only wants to know whether a
 * throw was a pending read (e.g. the head registry's shell-hold path) while
 * keeping real errors on their existing handling path.
 */
export declare function ssrHandleError(err: any, probe?: boolean): Promise<any> | undefined;
export declare function createLoadingBoundary<T, U>(fn: () => T, fallback: () => U, options?: {
    on?: () => any;
}): Accessor<T | U>;
export { ssrScope } from "./signals.js";
/**
 * Disables hydration for its children during SSR.
 * Elements inside will not receive hydration keys (`_hk`) and signals will not be serialized.
 * Use `Hydration` to re-enable hydration within a `NoHydration` zone.
 */
export declare function NoHydration(props: {
    children: SolidElement;
}): SolidElement;
/** Server: always `false` — nothing is claimed here. See the client entry. */
export declare function isHydrating(): boolean;
/**
 * Server: runs `callback` in the next microtask — nothing hydrates here. See
 * the client entry.
 *
 * @experimental
 */
export declare function onHydrationEnd(callback: () => void): void;
/**
 * Server: whether the caller's owner belongs to a render in progress and is
 * not under `<NoHydration>` (or is back under a nested `<Hydration>`). See
 * the client entry.
 */
export declare function isHydratable(): boolean;
/**
 * Re-enables hydration within a `NoHydration` zone, establishing a new ID namespace.
 * Pass an `id` prop matching the client's `hydrate({ renderId })` to align hydration keys.
 * Has no effect when not inside a `NoHydration` zone (passthrough).
 */
export declare function Hydration(props: {
    id?: string;
    children: SolidElement;
}): SolidElement;
