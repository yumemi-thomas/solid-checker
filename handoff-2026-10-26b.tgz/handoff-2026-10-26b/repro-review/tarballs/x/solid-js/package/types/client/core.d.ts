import type { Accessor, EffectOptions } from "@solidjs/signals";
import type { ArrayElement, Element as SolidElement } from "../types.js";
import { FlowComponent } from "./component.js";
export declare const IS_DEV: string | boolean;
export declare const IS_OBSERVE: string | boolean;
/**
 * Observe: stamps `flight` with when its work started — `from`'s start, or
 * now — so a reader that meets it later isn't read as a waterfall link (see
 * `OBSERVE.attribution.markFlight`). Call sites gate on `IS_OBSERVE`.
 */
export declare function markFlight(flight: object, from?: object): void;
export type NoInfer<T extends any> = [T][T extends any ? 0 : never];
export type ContextProviderComponent<T> = FlowComponent<{
    value: T;
}>;
export interface Context<T> extends ContextProviderComponent<T> {
    id: symbol;
    defaultValue: T | undefined;
}
/**
 * Creates a Context for sharing state with descendants of a Provider in the
 * component tree.
 *
 * The returned `Context` is itself a provider component — pass it a `value`
 * prop to scope a value to its children. Read it inside descendants with
 * `useContext`.
 *
 * Two forms:
 *
 * - **`createContext<T>()`** (default-less, the canonical form). Reading via
 *   `useContext` outside an enclosing Provider throws `ContextNotFoundError`.
 *   Use this for everything that carries reactive state — signals, stores,
 *   `[state, actions]` tuples, services. The Provider is mandatory by
 *   construction; the throw makes a missing Provider a loud bug instead of a
 *   silent no-op. The annotation `<T>` is required because there is no value
 *   to infer from.
 * - **`createContext<T>(defaultValue)`** (default form). Reserved for the
 *   narrow case of contexts whose value is a primitive with a meaningful
 *   static fallback (theme, locale, frozen config). Outside any Provider,
 *   `useContext` returns `defaultValue`.
 *
 * `undefined` means "not provided": `createContext(undefined)` is still the
 * default-less form, and a Provider passing `value={undefined}` counts as no
 * Provider. For an optional context use `null` as the empty value:
 * `createContext<T | null>(null)`.
 *
 * Context is for state that belongs to a subtree, which includes app-wide
 * state in an app that renders on the server: a value created inside a
 * component is created once per request, and the Provider owns and disposes
 * it. Module scope is shared by every request in the same process, so reserve
 * it for constants.
 *
 * @param defaultValue optional default; only meaningful for primitive
 *   fallbacks. Omit for any context carrying reactive state.
 * @param options `{ name }` for debugging in development
 * @returns a context object that doubles as its own provider component
 *
 * @example
 * ```tsx
 * // Reactive payload — default-less, throws if no Provider.
 * type TodosCtx = readonly [Store<Todo[]>, TodoActions];
 * const TodosContext = createContext<TodosCtx>();
 *
 * function App() {
 *   return (
 *     <TodosContext value={createTodos()}>
 *       <TodoList />
 *     </TodosContext>
 *   );
 * }
 *
 * function TodoList() {
 *   const [todos, { addTodo }] = useContext(TodosContext); // typed as TodosCtx
 *   // ...
 *   return null;
 * }
 * ```
 *
 * @example
 * ```tsx
 * // Primitive default — falls back to "light" outside a Provider.
 * const ThemeContext = createContext<"light" | "dark">("light");
 *
 * function Button() {
 *   const theme = useContext(ThemeContext); // "light" | "dark"
 *   return <button class={theme}>Click</button>;
 * }
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/components-context/create-context
 */
export declare function createContext<T>(defaultValue?: T, options?: EffectOptions): Context<T>;
/**
 * Reads the current value of a context.
 *
 * - For `createContext<T>()` (default-less): returns the value from the
 *   nearest enclosing Provider, or throws `ContextNotFoundError` if none is
 *   mounted. Return type is `T` (no narrowing required).
 * - For `createContext<T>(defaultValue)`: returns the value from the nearest
 *   enclosing Provider, or `defaultValue` if none is mounted.
 *
 * In Solid, `useContext` is the canonical way to read context. There is no
 * need for a wrapper hook that throws on missing Provider — the default-less
 * form already does that, and its return type is `T`.
 *
 * @param context a context returned from `createContext`
 * @returns the value provided by the nearest enclosing Provider, or the
 *   default if one was supplied to `createContext`
 * @throws `ContextNotFoundError` if no Provider is mounted and the context
 *   was created without a default
 *
 * @example
 * ```tsx
 * const TodosContext = createContext<TodosCtx>();
 *
 * function TodoList() {
 *   const [todos, { addTodo }] = useContext(TodosContext); // throws if no Provider
 *   // ...
 *   return null;
 * }
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/components-context/use-context
 */
export declare function useContext<T>(context: Context<T>): T;
export type ResolvedElement = Exclude<SolidElement, ArrayElement>;
export type ResolvedChildren = ResolvedElement | ResolvedElement[];
export type ChildrenReturn = Accessor<ResolvedChildren> & {
    toArray: () => ResolvedElement[];
};
/**
 * Resolves a `children` accessor and exposes the result as an accessor with
 * a `.toArray()` helper. Use this when a component needs to inspect or
 * iterate over its children rather than just render them through.
 *
 * @param fn an accessor for the children
 * @returns an accessor of the resolved children, with `.toArray()` for iteration
 *
 * @example
 * ```tsx
 * function List(props: { children: Element }) {
 *   const items = children(() => props.children);
 *   return <ul>{items.toArray().map(item => <li>{item}</li>)}</ul>;
 * }
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-js/components-context/children
 */
export declare function children(fn: Accessor<SolidElement>): ChildrenReturn;
/**
 * Observe/dev component wrapper: runs the component inside a transparent
 * root that carries its label, so the owner tree reads as the component
 * tree. Observe tier: the root and its `_name` — what `ownerPath` and
 * attribution need (`["<App>", "<TodoRow>", "effect"]`). Dev tier adds the
 * non-function check, the devtools `_component` record and `$DEVCOMP` brand,
 * and the strict-read label. The prod build never calls this.
 *
 * `name` is the source tag the compiler emitted under `sourceNames.components`; it
 * wins over `Comp.name`, which a minifier rewrites and a `lazy()` or HMR
 * wrapper hides.
 */
/**
 * A `console.createTask` task (Chrome's async stack tagging API; no lib
 * typing yet): `run(fn)` executes `fn` with the task's creation stack as
 * the async parent of whatever `fn` reports.
 */
export interface ConsoleTask {
    run<T>(fn: () => T): T;
}
/**
 * The dev-tier record a component root carries as `_component` — what
 * devtools read off the owner tree.
 */
export interface ComponentRecord<P = unknown> {
    fn: (props: P) => unknown;
    props: P;
    /** The source tag when the compiler emitted one, else `fn.name`. */
    name: string | undefined;
    /**
     * The JSX site as a console task — when the console supports it and an
     * attribution engine was installed when the component rendered (see
     * `createConsoleTask` and the note at its use).
     */
    task: ConsoleTask | undefined;
}
export declare function observedComponent<P, V>(Comp: (props: P) => V, props: P, name?: string, loc?: string): V;
