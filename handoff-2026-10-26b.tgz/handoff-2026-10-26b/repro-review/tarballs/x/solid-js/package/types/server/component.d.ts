import type { Element as SolidElement } from "../types.js";
export declare function enableHydration(): void;
/**
 * A general `Component` has no implicit `children` prop. If desired, specify
 * one explicitly, e.g. `Component<{ name: string; children: Element }>`.
 */
export type Component<P extends Record<string, any> = {}> = (props: P) => SolidElement;
/**
 * Extend props to forbid the `children` prop.
 */
export type VoidProps<P extends Record<string, any> = {}> = P & {
    children?: never;
};
/**
 * `VoidComponent` forbids the `children` prop.
 */
export type VoidComponent<P extends Record<string, any> = {}> = Component<VoidProps<P>>;
/**
 * Extend props to allow optional Solid children.
 */
export type ParentProps<P extends Record<string, any> = {}> = P & {
    children?: SolidElement;
};
/**
 * `ParentComponent` allows an optional `children` prop with the usual type in JSX.
 */
export type ParentComponent<P extends Record<string, any> = {}> = Component<ParentProps<P>>;
/**
 * Extend props to require a `children` prop with the specified type.
 */
export type FlowProps<P extends Record<string, any> = {}, C = SolidElement> = P & {
    children: C;
};
/**
 * `FlowComponent` requires a `children` prop with the specified type.
 */
export type FlowComponent<P extends Record<string, any> = {}, C = SolidElement> = Component<FlowProps<P, C>>;
export type ValidComponent = Component<any>;
/**
 * Takes the props of the passed component and returns its type
 */
export type ComponentProps<T extends ValidComponent> = T extends Component<infer P> ? P : never;
/**
 * Type of `props.ref`, for use in `Component` or `props` typing.
 */
export type Ref<T> = T | ((val: T) => void);
/**
 * Creates a component. On the server this is a plain call (no untrack
 * needed); the observe and dev tiers run it under a labelled owner so the
 * owner tree reads as the component tree — see `observedComponent`.
 */
export declare function createComponent<T extends Record<string, any>>(Comp: Component<T>, props: T, _name?: string, _loc?: string): SolidElement;
/**
 * Lazy load a function component asynchronously.
 * On server, returns a createMemo that throws NotReadyError until the module resolves,
 * allowing resolveSSRNode to capture it as a fine-grained hole. The memo naturally
 * scopes the owner so hydration IDs align with the client's createMemo in lazy().
 * The component is the resolved module's default export, or the export named
 * by the `{ export }` option (a call-site literal, so the client half can
 * resolve the same export synchronously during hydration).
 *
 * The bundler plugin injects `moduleUrl` (the module specifier, third
 * argument) so the server can look up client chunk URLs from the asset
 * manifest. When no callsite `moduleUrl` exists (e.g. `lazy` over an
 * `import.meta.glob` entry), asset resolution defers until the import
 * resolves and reads the module's bundler-injected `$$moduleUrl` export
 * instead.
 *
 * The returned component's `moduleUrl` property resolves through the asset
 * manifest of the render it is read in (the caller's, through its owner):
 * there it returns the client-loadable entry URL for the module (e.g.
 * `/assets/About-abc123.js`), suitable for stamping into markup (island
 * containers and similar). Read where no render can be attributed — outside
 * one, or after an `await` without the owner — it returns the raw module
 * specifier. Reading it in a render also registers a modulepreload hint for
 * the module's chunks — accessing the resolved client URL on the server is
 * treated as a declaration that the client will fetch it. `preload()` hints
 * into the caller's render the same way, and into none without one.
 */
export declare function lazy<M extends Record<string, any>, K extends keyof M & string>(fn: () => Promise<M>, options: {
    export: K;
}, moduleUrl?: string): M[K] & {
    preload: () => Promise<M>;
    moduleUrl?: string;
};
export declare function lazy<T extends Component<any>>(fn: () => Promise<{
    default: T;
}>, options?: {
    export?: string;
}, moduleUrl?: string): T & {
    preload: () => Promise<{
        default: T;
    }>;
    moduleUrl?: string;
};
/**
 * Cached dynamic import the server can preload before hydration. Unlike
 * `lazy()`, the value is the module namespace, and the hydration key is the
 * module id (`moduleUrl` / `$$moduleUrl`), not a hydration id.
 *
 * `.peek()` during a render resolves assets, files `registerModule(moduleUrl,
 * entry)` on the caller's boundary, and holds the shell with `ctx.block`
 * while the module (or its assets) is in flight — then throws `NotReadyError`
 * so the render retries and reads the module synchronously. `.preload()` only
 * hints assets; it does not register. A missing id warns in dev and `.peek()`
 * still returns the module. Outside a render, `.peek()` is a sync read.
 */
export declare function lazyModule<T extends Record<string, any>>(fn: () => Promise<T>, moduleUrl?: string): (() => Promise<T>) & {
    preload: () => Promise<T>;
    peek: () => T | undefined;
    moduleUrl?: string;
};
export declare function createUniqueId(): string;
