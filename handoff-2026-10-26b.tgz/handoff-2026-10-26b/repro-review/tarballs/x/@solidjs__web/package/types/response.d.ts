/**
 * Envelope pairing HTTP metadata with a value. Produced by `respond()` and
 * by server-function `transformResult` implementations (e.g. single-flight
 * payloads); the HTTP handler forwards `response`'s headers and
 * (non-redirect) status and encodes `value` as the body through the codec,
 * while client-only integrations read `value` directly — no reparse.
 *
 * The envelope IS a `Response` — the given response's body, status and
 * headers — so a consumer that knows nothing of Solid (a filesystem
 * router's API dispatch, any fetch-style handler) answers with it as-is.
 * `response` is the envelope itself, or `undefined` when constructed
 * without one.
 */
export interface ResponseEnvelope<T = unknown> extends Response {
    response: Response | undefined;
    value: T;
}
export declare const ResponseEnvelope: {
    new <T>(response: Response | undefined, value: T): ResponseEnvelope<T>;
};
/** Whether `value` is a `ResponseEnvelope` (robust across module copies). */
export declare function isResponseEnvelope(value: unknown): value is ResponseEnvelope;
export declare const HREF: unique symbol;
export interface Href {
    /**
     * The brand doubles as a channel: when the slot holds a string it is the
     * value's *logical* path — the routable pathname before an integration's
     * display rendering (eg. a hash router's `#` prefix). `redirect()` prefers
     * it over coercion so Location headers carry routable paths; `toString()`
     * remains the display href for the DOM. `true` brands a value whose
     * string form is already logical.
     */
    [HREF]: true | string;
    toString(): string;
}
/** Whether `value` is an `Href`-branded URL-bearing value. */
export declare function isHref(value: unknown): value is Href;
export declare const SAFE_ERROR: unique symbol;
/**
 * Marks `error` as safe to serialize to the client verbatim, opting it out
 * of production error sanitization (see `handleServerFunctionRequest`). Use
 * for errors whose message/properties are intentional client-facing content.
 * Returns the same value for convenient `throw markSafeError(new Error(...))`.
 */
export declare function markSafeError<E>(error: E): E;
/** Whether `value` is branded safe to serialize (robust across module copies). */
export declare function isSafeError(value: unknown): value is Error;
/**
 * Response header naming the cache keys a mutation invalidated, comma
 * separated. Set by the helpers below and read by the client transport and
 * by integrations; core never inspects the keys, so how they are matched
 * (prefixes, exact names, namespaces) is the integration's business.
 */
export declare const REVALIDATE_HEADER = "X-Revalidate";
/**
 * The reserved `revalidate` key meaning every entry, in every cache: the
 * host-independent spelling of "all" (as `Clear-Site-Data: "*"` spells it),
 * for authors who mean it rather than a host's default. Stands alone —
 * naming it beside other keys is refused, since "everything and also
 * these" is a mistake, not a scope.
 */
export declare const REVALIDATE_ALL = "*";
/** `ResponseInit` accepted by the response helpers, plus `revalidate`. */
export interface ResponseHelperInit extends ResponseInit {
    /**
     * The cache keys the mutation invalidated, sent as the `X-Revalidate`
     * header for the client's integrations to apply. Three declarations, three
     * scopes: omitted sends no header — the host's default (Solid Router
     * revalidates everything after any mutation, form action or direct call;
     * a router without that convention reloads only what it owns); an empty
     * list (or `""`) sends an empty header — nothing, explicitly; `REVALIDATE_ALL` (`"*"`) — every entry,
     * whatever the host's default. How named keys are matched (prefixes,
     * namespaces) is each integration's business.
     */
    revalidate?: string | string[];
}
/** @internal */
export declare const RESPONSE_HEADER_VALUE_LIMIT = 4096;
/**
 * Response redirecting to `url` (default 302). `revalidate` names the
 * cache keys the mutation invalidated.
 *
 * Typed so it never shows up in the type of the function returning it: a
 * redirect is control flow for the integration to act on, not a value.
 * `T` defaults to `never`, which vanishes from the inferred return type's
 * union; where the context expects a type (an annotated return, a
 * `Response`-typed request handler) `T` takes it. A literal `never` return
 * would also mark code after a bare call unreachable; a type parameter
 * does not. At runtime it is a real `Response`.
 */
export declare function redirect<T = never>(url: string | Href, init?: number | ResponseHelperInit): T;
/**
 * Empty response requesting revalidation of the named cache keys (all of
 * them when omitted).
 *
 * Typed as `redirect` is, for the same reason: it never shows up in the
 * type of the function returning it. At runtime it is a real `Response`.
 */
export declare function reload<T = never>(init?: ResponseHelperInit): T;
/**
 * Statuses HTTP forbids a body on — the `Response` constructor enforces it
 * by throwing on ANY body, `JSON.stringify(undefined)`'s `"undefined"`
 * included. Shared with the server-function encoder, which answers void
 * results on these statuses with a real null-body response and reports
 * value-carrying ones as authoring errors (#3095).
 * @internal
 */
export declare const NULL_BODY_STATUSES: ReadonlySet<number>;
/**
 * A value paired with response metadata (status, headers, `revalidate`) —
 * for the things a naked return can't express. Progressive enhancement
 * stays invisible: the carried response holds a plain JSON body so
 * consumers without the client runtime (no-JS form posts, direct HTTP)
 * get real JSON, while integrations read `value` — no reparse. The body is
 * encoded when read, so `value` may be anything a plain return may.
 *
 * Typed as `value`'s type: every caller of the function returning it —
 * over HTTP or in-process — receives the value, never the envelope. At
 * runtime it is a `ResponseEnvelope`, a real `Response` that integrations
 * recognize with `isResponseEnvelope()`.
 */
export declare function respond<T>(value: T, init?: ResponseHelperInit): T;
