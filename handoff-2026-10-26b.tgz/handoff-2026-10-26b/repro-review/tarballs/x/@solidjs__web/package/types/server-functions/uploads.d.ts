export declare const UPLOAD_ARGS_PART = "args";
export declare const UPLOAD_FILE_PART = "file";
/**
 * True for a file or a blob. One from another frame is an instance of that
 * frame's `Blob`, so its shape tells instead.
 */
declare function isBlob(value: any): boolean;
/**
 * The client half. Each file or blob in the arguments serializes as its
 * index in `files`. A file that appears twice is pushed once, so it arrives
 * as one value.
 */
export declare function createUploadSerializer(files: any): {
    tag: string;
    test: typeof isBlob;
    parse: {
        sync: (value: any, ctx: any) => {
            i: any;
        };
        async: (value: any, ctx: any) => Promise<{
            i: any;
        }>;
        stream: (value: any, ctx: any) => {
            i: any;
        };
    };
    serialize: (node: any, ctx: any) => any;
    deserialize: () => never;
};
/**
 * The server half, made for one request. Each index turns back into its
 * part of `form`. A bad index or a missing part fails the decode.
 */
export declare function createUploadDeserializer(form: any): {
    tag: string;
    test: () => boolean;
    parse: {
        sync: () => never;
        async: () => never;
        stream: () => never;
    };
    serialize: () => never;
    deserialize: (node: any, ctx: any) => any;
};
/**
 * The request body for a call with files. `FormData` only takes blobs of its
 * own frame, so a blob from another frame is copied first.
 */
export declare function createUploadBody(serialized: any, files: any): Promise<FormData>;
export {};
