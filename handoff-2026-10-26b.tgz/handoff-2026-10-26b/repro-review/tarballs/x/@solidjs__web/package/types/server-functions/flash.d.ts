export declare function setFlashSecret(secret: any): void;
/**
 * The outcome of a call made without the client runtime, as it rides the
 * flash cookie: what was submitted, where, and what came back. `result` and
 * `error` are mutually exclusive — a thrown outcome fills `error`, a
 * returned one fills `result` — mirroring the split a scripted call sees.
 */
export interface FlashSubmission {
    /** The arguments the call was made with (files are dropped). */
    input: any[];
    /**
     * The call's url: the UNBOUND function base — the server function
     * request's pathname (`<endpoint>/<id>`), without the `?args=` query a
     * `.with()`-bound form's action carries (or any other query decoration).
     * Matches what the scripted road records as a submission's url, so
     * integrations can match flash and scripted submissions with the same
     * `s.url === fn.base` test; bound arguments arrive in `input` instead,
     * prepended exactly like a scripted call's.
     */
    url: string;
    /** The returned value, when the call returned. */
    result?: any;
    /** The thrown value, when the call threw. */
    error?: any;
    /**
     * Set when the outcome was too large for the cookie's 4 KB ceiling and
     * was degraded to fit (#3137): the input echo is dropped, and `result` /
     * `error` may carry a bounded prefix — or the bare outcome flag `true` —
     * rather than the full value. The submission still says what happened
     * and where; integrations should render it as "succeeded (result too
     * large to display)" rather than replaying the value.
     */
    truncated?: boolean;
}
export declare function encodeFlashCookie(url: string, result: any, input: any[], thrown?: boolean): Promise<string | null>;
export declare function decodeFlashCookie(cookieHeader: string | null): Promise<FlashSubmission | undefined>;
