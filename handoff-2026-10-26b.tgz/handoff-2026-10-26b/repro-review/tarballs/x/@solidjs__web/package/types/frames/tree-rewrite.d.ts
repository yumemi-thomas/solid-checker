/**
 * Copy-on-write rewrite of a value tree, for the serialization-border walks
 * (`toBorderForm` — every document-face serialization and every slot-arg
 * record — and the slot-arg stand-in scrub). `visit(value, path)` is asked
 * at every OBJECT node first (primitives pass through unasked: no visitor
 * replaces one, and leaves are most of a payload) and answers with the
 * node's replacement, or `DESCEND` to walk the node's leaves — which
 * happens for a plain array or plain object only; anything else (a class
 * instance, a `Map`, a proxy) is the app's and passes through untouched.
 *
 * Author values are never mutated. The walk is plain recursion, copy-on-
 * write: an untouched subtree passes by reference, a changed one is copied
 * along the path to the root. That is the whole cost for acyclic data of
 * ordinary depth (measured below what `next`'s direct recursion paid, the
 * primitive short-circuit buying more than the visitor call costs).
 *
 * A back-reference to an ancestor has no copy-on-write answer (the copy's
 * back-reference would point at the original, unrewritten), and tracking
 * ancestors at every node would tax every walk. So ancestors are tracked
 * only from a depth ordinary payloads never reach (`TRACK`): a cycle is
 * caught within one cycle-length past it, the pass aborts and the tree is
 * rewritten again as a memoized clone — one copy per container, a back-
 * reference resolving to the ancestor's copy. Only cyclic (or unusually
 * deep) values pay. Replacements are recorded as they are produced (a trace
 * envelope, a multicast seat, a scrubbed stand-in): a node seen again on
 * the first pass — a cycle revisits its nodes on every level down to the
 * catch — and every node of the clone pass answer from the record, so a
 * visitor's side effects run once per node whichever way the walk went.
 * Walks that replace nothing never pay the lookup. A value reachable at two
 * paths is one node: its replacement is shared (one seat for one iterable —
 * the identity the input had, which the serializer writes once and the
 * client materializes once), and a shared subtree with nothing to replace
 * is visited at each occurrence on the first pass and once on the clone
 * pass. `path` is built (`.key`, `[i]`) only when `withPath`.
 */
export declare const DESCEND: unique symbol;
type Visit = (value: object, path: string | undefined) => any;
export declare function rewriteTree(value: any, visit: Visit, withPath: boolean): any;
export {};
