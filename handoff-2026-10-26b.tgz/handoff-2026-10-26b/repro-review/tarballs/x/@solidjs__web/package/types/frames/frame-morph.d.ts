/**
 * Morph a frame's content toward a new root: `ranges` is the frame-wide
 * displaced-range index (the eager client's `#applyRoot` builds it), and
 * subtrees the reconcile inserted whole are grafted afterwards.
 * @internal
 */
export declare function morph(parent: any, fragment: any, claim: any, ranges: any): void;
/** Land each displaced range a morph pass left in `ranges` where its
 *  occurrence now is under `roots` (see `flushGrafts`). @internal */
export declare function graft(roots: any, ranges: any): void;
/**
 * Reconcile the children of `parent` toward the children of `source`, reusing
 * existing DOM in place. `source` is a freshly parsed, disposable node whose
 * children are moved into `parent` only when they are genuinely new.
 *
 * When `boundStart`/`boundEnd` are given, only the nodes in `(boundStart,
 * boundEnd)` are reconciled and new nodes are inserted before `boundEnd` —
 * this is how a range-boundary frame reconciles between its markers without
 * touching the client content around them.
 *
 * `ranges` (threaded through the whole recursion from the frame's root apply)
 * indexes the frame content's slot ranges by occurrence id as they stood
 * BEFORE this morph. Occurrence ids are unique within a frame's content, so
 * a range the new content places under a different parent (keyed list churn)
 * is still THAT occurrence — the index is what lets the morph relocate it,
 * live interior intact, where sibling-scoped matching sees only a new id.
 */
export declare function reconcileChildren(parent: any, source: any, boundStart?: any, boundEnd?: any, claim?: any, ranges?: any, grafts?: any): void;
