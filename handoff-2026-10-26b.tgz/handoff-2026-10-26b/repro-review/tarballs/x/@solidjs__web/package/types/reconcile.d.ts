export default function reconcileArrays(parentNode: Node, a: Node[], b: Node[], marker?: Node | null): void;
