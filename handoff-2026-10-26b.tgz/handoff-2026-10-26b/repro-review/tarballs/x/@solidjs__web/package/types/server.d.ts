import { getOwner, createComponent, untrack, merge as mergeProps } from "solid-js";
import { ssrScope as scope } from "solid-js/internal";
import type { Owner } from "solid-js";
import type { ServerErrorSite } from "solid-js/internal";
import { effect, memo } from "./render.js";
import { type TraceContext } from "./trace.js";
export { parseCookieHeader, serializeCookie } from "./cookies.js";
export { clearFlashCookie, hasFlashCookie } from "./cookies.js";
export { getServerFunctionMetadata, getServerFunctionRPC, isServerFunction } from "./server-functions/registry.js";
import { JSX } from "./jsx.js";
import { SerializerPlugin } from "./serializer-decode.js";
type PreloadLinkAttributes = {
    type?: string;
    crossorigin?: JSX.HTMLCrossorigin;
    integrity?: string;
    referrerpolicy?: JSX.HTMLReferrerPolicy;
    fetchpriority?: JSX.HTMLFetchPriority;
    media?: string;
};
/**
 * An explicit `<link rel="preload">` emitted by the SSR asset pipeline.
 *
 * `as` is the HTML Standard's set of preload destinations exactly — anything
 * else translates to null and the browser does nothing with the link.
 *
 * `imagesrcset` candidates must already be resolved by the integration: they
 * are carried verbatim (a relative candidate resolves against the DOCUMENT
 * URL, not the manifest base). Pair it with `imagesizes` whenever a candidate
 * uses a width descriptor, which the spec requires — without it the source
 * size falls back to `100vw` and the preload can miss the image the `<img>`
 * selects. Omitting `href` is the spec's own recommendation for the source-set
 * form: it would only serve browsers without `imagesrcset` support, and there
 * it would likely preload the wrong candidate.
 */
export type PreloadLink = PreloadLinkAttributes & ({
    href: string;
    as: Exclude<JSX.HTMLPreloadAs, "image">;
    imagesrcset?: never;
    imagesizes?: never;
} | {
    href: string;
    as: "image";
    imagesrcset?: string;
    imagesizes?: string;
} | {
    href?: never;
    as: "image";
    imagesrcset: string;
    imagesizes?: string;
});
/**
 * Static asset graph consumed by the SSR pipeline. This is Solid's own
 * contract — a parsed Vite client manifest satisfies it structurally
 * (unknown fields pass through untyped), but any bundler integration can
 * produce it. Only these fields are ever read: `preloads` is Solid's
 * extension slot for explicit typed links the integration selects.
 */
export type AssetManifest = Record<string, {
    file: string;
    css?: string[];
    isEntry?: boolean;
    imports?: string[];
    preloads?: PreloadLink[];
}> & {
    _base?: string;
};
/** Inline style content, e.g. dev CSS collected from a bundler's module graph. */
export type InlineStyleAsset = {
    id: string;
    content: string;
    attrs?: Record<string, string>;
};
export type ResolvedAssets = {
    js: string[];
    css: (string | InlineStyleAsset)[];
    preloads?: PreloadLink[];
};
/**
 * Resolver form of the manifest option — the primitive a dev server
 * implements against its live module graph (a static manifest object is
 * normalized into a sync resolver internally). `resolve` may return a
 * promise (async resolvers require streaming rendering); CSS entries may be
 * URL strings (emitted as load-gated `<link>` tags) or inline-style
 * descriptors (emitted as `<style>` tags), and `preloads` carries explicit
 * preload links selected by the integration. A bare `resolve`-shaped
 * function is accepted as shorthand for `{ resolve }`.
 */
export type AssetResolver = {
    resolve(key: string): ResolvedAssets | null | undefined | Promise<ResolvedAssets | null | undefined>;
    /**
     * Synchronous fast path answering with whatever is knowable without async
     * work (typically js URLs, omitting css). Sync consumers — e.g. a lazy
     * component's `moduleUrl` getter used by islands — use this when `resolve`
     * would return a promise, so adapters should provide it whenever possible.
     */
    resolveSync?(key: string): ResolvedAssets | null | undefined;
};
/** Bare-function shorthand for `AssetResolver` (no sync fast path). */
export type AssetResolverFn = (key: string) => ResolvedAssets | null | undefined | Promise<ResolvedAssets | null | undefined>;
/**
 * CSP nonce for the tags a server render emits. A string applies to both
 * nonce-aware destinations. A `{ script, style }` pair routes each tag to
 * the directive governing its fetch (`script-src-elem` / `style-src-elem`,
 * falling back to `script-src` / `style-src` then `default-src`). Both
 * keys are required; `false` leaves that destination un-nonced. Worker
 * destinations take the script nonce, which only applies when their own
 * fallback reaches `script-src`. A nonce on a `useHead` tag's own props
 * always wins.
 *
 * Surfaces that emit one script (`HydrationScript`,
 * `generateHydrationScript`, `createSSRResponse`) take either shape and use
 * its script half.
 */
export type CSPNonce = string | {
    script: string | false;
    style: string | false;
};
/**
 * A head tag descriptor. Props values may be getters (evaluated lazily on
 * the server — at the owning flush boundary — and reactively on the client);
 * `children` is the text body (title text, inline style/script content).
 * `key` overrides the built-in dedupe identity (`title` is a hard singleton
 * that `key` cannot fork).
 *
 * Getters must be plain reads: they evaluate at flush time here (under no
 * component owner) and inside registry-owned computations on the client, so
 * a getter that allocates a reactive owner (`createMemo`, a `children()`
 * helper) consumes a hydration id slot on one side only and desyncs every
 * id allocated after the `useHead` call. Create such helpers eagerly at
 * component position and read them from the getter. See
 * docs/head-management-rfc.md.
 */
export type HeadTag = {
    tag: "title" | "meta" | "link" | "style" | "script" | "base";
    props: Record<string, any>;
    key?: string | (() => string);
};
/**
 * The mutable response head an integration's handler exposes on the request
 * event as `event.response`: status/statusText/headers it will apply when
 * sending the response. A scaffold, not a `Response` — application code
 * (e.g. JSX response components) writes to it during render, and the
 * handler reads it when the head goes out. Core does not declare the
 * `response` property on `RequestEvent` itself: integrations that provide
 * one declare it through module augmentation (as `@solidjs/router` does),
 * and this type names the shape they agree on. Core's server-function
 * handler folds it onto the outgoing response when present — its
 * `Set-Cookie` values (cookies appended during the call via
 * `serializeCookie`) append cookie-by-cookie, other headers fill gaps —
 * and reads it when folding single-flight cookies, but never requires it.
 */
export interface ResponseStub {
    status?: number;
    statusText?: string;
    headers: Headers;
    /**
     * Set once the response head has been derived/sent from this stub —
     * status and headers can no longer change. Flip it through
     * `commitResponseStub`, which also instruments the stub's `headers` so
     * a post-commit write fails loudly (dev build throws, production
     * reports + no-ops) instead of silently missing the wire. `status`/
     * `statusText` stay plain fields: consumers that write response
     * metadata during render (e.g. JSX response components) must still
     * treat later status writes and cleanup-time retractions as no-ops.
     */
    committed?: boolean;
}
/**
 * The type of `RequestEvent.locals` — a module-augmentable interface so
 * applications can type the state their middleware hangs on the event.
 * Augment it through the package that re-exports the event (interface
 * identity flows through the re-export chain):
 *
 * ```ts
 * declare module "@solidjs/web" {
 *   interface RequestEventLocals {
 *     user: User;
 *   }
 * }
 * ```
 *
 * The index signature keeps un-augmented usage permissive — `locals` is a
 * free-form bag by default — so augmentation adds precision for the keys
 * it names without gating existing code. The flip side: unaugmented keys
 * read as `any` rather than erroring, a deliberate trade (a strict-only
 * `locals` would break every untyped write that works today).
 */
export interface RequestEventLocals {
    [key: string | number | symbol]: any;
}
/**
 * The per-request context available on the server: the incoming `Request`
 * and a `locals` bag integrations and middleware can hang state on (typed
 * through the augmentable `RequestEventLocals`). Frameworks typically
 * extend this shape with richer fields (e.g. a `response` head — see
 * `ResponseStub`).
 */
export interface RequestEvent {
    request: Request;
    locals: RequestEventLocals;
}
export type { CookieOptions } from "./cookies.js";
export type { ServerFunction, ServerFunctionMetadata, ServerFunctionRPC } from "./server-functions/shared.js";
export interface SSRResponseOptions {
    /** Base head; the stub's status/headers win over it. */
    responseInit?: ResponseInit;
    /** Nonce carried by the post-flush `<script>` redirect fallback (its script half). */
    nonce?: CSPNonce;
    /** Rewrites each outgoing HTML chunk (entry script injection, ...). */
    transformChunk?: (chunk: string) => string;
}
/**
 * Fetch-style middleware: return a `Response` to answer the request, or
 * call `next()` (optionally with a substitute `Request`) to advance the
 * chain and observe/replace the eventual response.
 */
export type FetchMiddleware = (request: Request, next: (request?: Request) => Promise<Response>) => Response | Promise<Response>;
export { createComponent, effect, memo, untrack, mergeProps, scope, getOwner };
export { DOMWithState, ChildProperties, DOMElements, SVGElements, MathMLElements, VoidElements, RawTextElements, Namespaces, DelegatedEvents } from "./constants.js";
export declare function useHead(tag: HeadTag | HeadTag[] | (() => HeadTag | HeadTag[])): void;
export declare function renderToString<T>(fn: () => T, options?: {
    nonce?: CSPNonce;
    renderId?: string;
    noScripts?: boolean;
    plugins?: SerializerPlugin[];
    manifest?: AssetManifest | AssetResolver | AssetResolverFn;
    /**
     * This render's server error hook, ahead of `configureServerErrors`'
     * (see `ServerErrorHook`): every failure the render handles — an
     * `<Errored>` fallback (`handling: "fallback"`), a hydration value that
     * would not serialize (`"serialize"`) — and the throw that fails it
     * (`"failed"`, heard before it is rethrown to the caller), once per
     * error, with where it was met. A one-argument listener still works; it
     * hears them all.
     */
    onError?: ServerErrorHook;
    /**
     * Embedded-render contract for hosts that own the document. When the
     * render output contains no `</head>`, everything head-bound (resolved
     * `useHead` winners, eager resources, tracked asset links, inline
     * styles) is delivered here as one HTML string — prelude (charset/base)
     * first — for the host to splice into its own `<head>` template, instead
     * of being dropped. Called synchronously before `renderToString`
     * returns; not called when the output has a `</head>` (splicing is
     * automatic then).
     */
    onHead?: (head: string) => void;
}): string;
export declare function renderToStream<T>(fn: () => T, options?: {
    nonce?: CSPNonce;
    renderId?: string;
    noScripts?: boolean;
    plugins?: SerializerPlugin[];
    manifest?: AssetManifest | AssetResolver | AssetResolverFn;
    onCompleteShell?: (info: {
        write: (v: string) => void;
    }) => void;
    onCompleteAll?: (info: {
        write: (v: string) => void;
    }) => void;
    /**
     * This render's server error hook, ahead of `configureServerErrors`'
     * (see `ServerErrorHook`): every failure the render handles — an
     * `<Errored>` fallback (`handling: "fallback"`), a rejected fragment
     * (`"client"`), a hydration value that would not serialize
     * (`"serialize"`) — and the one that fails the request (`"failed"`),
     * once per error per kind per request (per render outside one), with
     * where it was met. A one-argument listener still
     * works; it hears them all — filter on `context.handling` for the
     * request-failing ones alone. Without a hook (here or ambient) a
     * failure that fails the request goes to `console.error`.
     */
    onError?: ServerErrorHook;
    /**
     * Embedded-render contract for hosts that own the document. When the
     * shell contains no `</head>`, everything head-bound at first flush
     * (resolved `useHead` winners, eager resources, tracked asset links,
     * inline styles) is delivered here as one HTML string — prelude first —
     * before the shell chunk is emitted, so the host can write its own
     * `<head>` ahead of piping the stream. Post-shell head updates flow
     * through the stream itself and apply in the browser. Not called when
     * the shell has a `</head>` (splicing is automatic then).
     */
    onHead?: (head: string) => void;
    /**
     * The request's lifecycle. Aborting tears the render down exactly as a
     * client disconnect does (`SSR_STREAM_ABANDONED`, `data.reason:
     * "signal"`): in-flight reactive work is disposed, every async source
     * still being pulled is returned, and nothing more reaches the sink. For
     * the host whose transport cannot report a dead consumer through the
     * sink or the readable view — a frame stream whose emission never
     * touches the document writable, a platform whose response body is
     * consumed by a proxy — this is the one teardown handle; pass
     * `request.signal`. Idempotent with the sink and consumer paths: whichever
     * fires first tears down, the rest are no-ops.
     */
    signal?: AbortSignal;
}): {
    /**
     * Awaiting the stream resolves with the complete HTML once every boundary
     * settles — the fully-settled-string form of the render (`const html =
     * await renderToStream(...)`). Render errors route through `onError` and
     * the promise resolves with whatever HTML the render produced; it never
     * rejects.
     *
     * Completion is this path's head-freeze point: the request event's
     * `response` head (the request scope the render was started in) is
     * committed right before the render's final dispose, so
     * `httpStatus`/`httpHeader` declarations still live at completion survive
     * into `createSSRResponse(html, event)` — which sees the already-committed
     * stub and passes it through. The piped forms freeze at shell flush
     * instead.
     */
    then<TResult1 = string, TResult2 = never>(onfulfilled?: ((html: string) => TResult1 | PromiseLike<TResult1>) | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | null): Promise<TResult1 | TResult2>;
    pipe: (writable: {
        write: (v: string) => void;
        end: () => void;
    }) => void;
    pipeTo: (writable: WritableStream) => Promise<void>;
    /**
     * Lazy `ReadableStream<Uint8Array>` view of the render — hand it straight
     * to `new Response(stream.readable)`. First access starts the render
     * piping through an internal `TransformStream` (chunks are UTF-8 encoded
     * bytes, the same as `pipeTo` writes) and the stream is cached, so
     * repeated access returns the same instance. Like `pipe`/`pipeTo`, this
     * consumes the render: use exactly one of the three — mixing distinct
     * consumers (`readable` after `pipe`/`pipeTo`, or vice versa) throws an
     * error naming the conflict.
     */
    readonly readable: ReadableStream<Uint8Array>;
};
export declare function HydrationScript(props: {
    nonce?: CSPNonce;
    eventNames?: string[];
}): JSX.Element;
export declare function ssrGroup<T extends () => any[]>(fn: T, n: number): T;
/**
 * The live-hole engine for one frame response. Constructed by the frame
 * renderer (frame-sink) and published on the render context; `ssr()` and
 * `resolveSSRNode` route content holes through `content()` while it is
 * present. Bindings live in the sink's DR-2 ledger — same commit-driven
 * sweeps, same equality gating, same end-of-response latch as watched slot
 * args.
 *
 * Every state transition is commit-driven: the engine never chains its own
 * promises, so it cannot amplify commits or starve the event loop — a
 * pending re-evaluation simply waits for the next commit (async settles
 * commit through the render core, and the response's end-latch sweep is
 * always the last one).
 */
export declare function createLiveHoles(sink: any, scoped: any, settled: any, errorScope: any): {
    suppressed: number;
    sweeping: boolean;
    parent: any;
    gateHit: boolean;
    sweptOwners: boolean;
    scope: any;
    visit: any;
    dry: boolean;
    /**
     * The id of a positional slot call: at render time (and on a retry,
     * which renders) the render-positional id the proxy minted, `given`,
     * kept for the call's position; on a sweep, the id that position had —
     * or, for a position no render reached, `prop#~<scope>.<n>` (the `~`
     * keeps it apart from render ids and `$key` ids, whose alphabet has
     * none). Outside every hole, `given` as it is.
     */
    slotId(prop: any, given: any): any;
    /** A slot occurrence reached by the evaluation in progress; `forget` runs
     *  once a re-evaluation of its hole no longer reaches it. */
    seen(id: any, forget: any): void;
    /**
     * Enter a nested hole's scope on the path that resolves it unminted (a
     * sweep's interior, a suppressed window): the same scope a first render
     * gives it inside `content()`. Returns the scope to restore, or
     * undefined when none was entered.
     */
    nest(hole: any): any;
    /**
     * Intercept a thunk content hole: resolve it, and — when the evaluation
     * proves re-runnable — mint an id, wrap the output in its marker pair,
     * and open the ledger binding. Returns a string (sync resolve), a
     * marker-wrapped `{ t, h, p }` template (NotReady escalation — markers
     * ride the template so the retry's splice lands inside them), an
     * UNMARKED string/template (latched: slot positions, impure
     * evaluations), or null when interception is off for this evaluation.
     */
    content(hole: any): any;
    /** The shared id counter — `ssr()` mints an attr address at injection
     *  time, before its capture completes. */
    mint(): number;
    /** Whether interception may arm at the current evaluation point —
     *  `ssr()` asks before opening an attr capture (the `data-lha`
     *  injection must not touch out-of-scope bytes, nor address an element
     *  nothing can change; content holes are gated inside `content()`
     *  itself). */
    active(): boolean;
    /**
     * Register an element's attr-hole capture (built by `ssr()`'s in-tag
     * scan): the tag's attribute area as alternating static strings and
     * re-runnable parts (`{ f }` thunks, `{ g, i }` group positions). Sweeps
     * rebuild the text, equality-gate against the baseline, and ship
     * changes as an element-keyed `attr` chunk. Names that vanish between
     * rebuilds ride an explicit `removed` list where the server holds the
     * previous text; the client also matches the element to the whole
     * text (the morph's rule), so a resume's re-emission — previous text
     * known only as a digest, no list — removes them too.
     */
    attr(cap: any): void;
};
export declare function ssr(template: string[] | string, ...nodes: any[]): {
    t: string;
};
export declare function ssrClassName(value: string | {
    [k: string]: boolean;
} | Array<any>): string;
export declare function ssrStyle(value: string | {
    [k: string]: string;
}): string;
export declare function ssrStyleProperty(name: string, value: any): string;
export declare function ssrStyleProperties(...entries: any[]): string;
export declare function ssrElement(name: string, props: any | any[] | (() => any | any[]), children: any, needsId: boolean, skip?: (key: string) => boolean, attrs?: string | (() => string)): {
    t: string;
};
export declare function ssrElementAttribute(key: string, value: any): string;
export declare function ssrAttribute(key: string, value: any): string;
export declare function ssrHydrationKey(): string;
/**
 * A render's link handler (`setLinkClaim`): given an anchor's link-relevant
 * attributes — `href`, and `target` / `rel` / `download` / `link` /
 * `aria-current` when present, raw values as written — returns the extra
 * attribute markup for the anchor, each attribute with its leading space
 * (`" data-active"`, `' data-active aria-current="page"'`), or `""`.
 * Synchronous and pure; the markup is the handler's own and is written
 * verbatim.
 * @internal
 */
export type LinkClaimHandler = (attrs: Readonly<Record<string, unknown>>) => string;
/**
 * Compiler-emitted hole after a candidate anchor's attributes in SSR output:
 * the render's link handler's markup for the anchor (`setLinkClaim`), or
 * `""` when the render has no handler. An author-written `aria-current`
 * wins — the handler is not consulted for that anchor. Not for hand-written
 * code.
 * @internal
 */
export declare function ssrLinkClaim(attrs: Readonly<Record<string, unknown>>): string;
export declare function ssrSelectValues(): void;
export declare function resolveSSRSelectValues(html: any): any;
export declare function escape(s: any, attr?: boolean): any;
export declare function getHydrationKey(): string | undefined;
export declare function applyRef(r: ((element: any) => void) | ((element: any) => void)[], element: any): void;
export declare function generateHydrationScript(options?: {
    nonce?: CSPNonce;
    eventNames?: string[];
}): string;
export declare function resolveSSRNode(node: any, result?: any, top?: boolean, nested?: boolean): any;
export declare const RequestContext: unique symbol; /**
 * Where a server-side failure was met, as the server error hook hears it.
 *
 * `kind: "render"` — `fallback`: an `<Errored>` rendered its fallback;
 * `client`: a `<Loading>` fragment rejected and the client re-renders the
 * subtree; `failed`: nothing contained it and the request fails — including
 * a synchronous throw out of `renderToString` or `renderToStream`'s first
 * pass, reported before it reaches the caller;
 * `serialize`: a hydration value would not serialize and the render went on
 * without it (a render that passed `onError`). `kind: "server-function"` — `thrown`:
 * the body threw; `channel`: a rejection or throw escaping through the
 * result graph (a promise, an iterable, a stream) with the head already
 * committed. `kind: "request"` (always `failed`): a failure that fails the
 * request outside any render or server function the runtime reports — a
 * middleware throw the framework's request handler catches (see
 * `reportRequestFailure`). `boundary` is the hydration id the boundary records and
 * findings use; `ownerPath` is where the error was THROWN — the component
 * labels root-first up the owner chain it escaped, when the compiler emitted
 * them — and `boundaryPath` where it was MET, the same labels up the
 * boundary's chain (what broke, and what the user saw); `functionId`/`direct`
 * name the server function and whether it was an in-process call during
 * SSR; `event` the request, when the failure happened inside one.
 */
export interface ServerErrorContext extends Omit<ServerErrorSite, "event"> {
    event?: RequestEvent;
}
/**
 * The server error hook (see `configureServerErrors`): every failure the
 * server runtime handles or fails on, once per error object per `kind` per
 * request (per render when no request is in scope — never once per
 * process: an error object one request met and another meets again is
 * heard by both), with where it was met. A direct server-function call that
 * throws during SSR and the `<Errored>` that contains it are heard as both:
 * `server-function` (the call failed), then `render` (the render fell back),
 * so `kind: "render"` alone answers whether a render failed. Return the value the client should receive in
 * place of the error — rendered into the fallback, serialized for
 * hydration, sent as the RPC error — or nothing for the default policy (a
 * generic `Error` outside the dev build, the error itself in it;
 * `markSafeError` still passes through).
 * A returned value is taken as intended client-facing content and is not
 * sanitized again. Ignored for `handling: "failed"`, which has no wire, and
 * once an earlier kind's sight gave one: every road carries the first.
 *
 * One road a mapping does not reach: a rejected async source's serialized
 * rejection is encoded the moment the source rejects, ahead of the boundary
 * that meets the failure, and carries the default policy's value there. The
 * hydrating client renders from the boundary's record, which carries the
 * mapping; no tick is added to the error path to make the two agree.
 */
export type ServerErrorHook = (error: unknown, context: ServerErrorContext) => unknown | void;
export interface ServerErrorsConfig {
    /** The hook, or `undefined` to clear it. */
    onError?: ServerErrorHook;
}
/**
 * Registers the ambient server error hook — the one call a server
 * `init()` makes to see every failure the runtime handles in production:
 * an `<Errored>` fallback rendered, a `<Loading>` fragment rejected, a
 * server-function throw (HTTP dispatch or an in-process call during SSR),
 * the failure that fails a request. Called once per error object per kind
 * per request (per render outside one), at first sight, wherever the runtime
 * met it; its return, when given, is the wire value (see
 * `ServerErrorHook`). A per-request hook — `renderToStream`'s
 * `onError`, the server-function handler's — overrides it for that
 * request. Registered on `globalThis` under a registered symbol, so a
 * bundled server build and an instrumented `--import`ed module share it.
 *
 * ```ts
 * configureServerErrors({
 *   onError: (error, { kind, handling, boundary, functionId }) => {
 *     Sentry.captureException(error, {
 *       mechanism: { type: `solid.${kind}.${handling}`, handled: handling !== "failed" }
 *     });
 *   }
 * });
 * ```
 */
export declare function configureServerErrors(config: ServerErrorsConfig): void;
/**
 * Reports a failure that fails a request outside any render or server
 * function the runtime reports, such as a throw a framework's request
 * handler catches from its middleware. The ambient server error hook hears
 * it as `{ kind: "request", handling: "failed", event }`, once per error
 * object per request, and its return is ignored, as for every `handling:
 * "failed"`. A render failure is the render's: a synchronous throw out of
 * `renderToString` or `renderToStream` was already heard as `kind:
 * "render"` before the caller caught it, so reporting it here adds nothing.
 * With no hook registered the failure goes to `console.error`, as a render
 * that fails before its shell does. There is no per-request hook at this
 * layer.
 */
export declare function reportRequestFailure(error: unknown, event: RequestEvent): void;
/**
 * The current request event, when called on the server inside a request
 * scope (established by `provideRequestEvent` from `@solidjs/web/storage`
 * or by the framework). Undefined on the client and outside a request.
 * Read it above `await` boundaries in partially-polyfilled environments.
 */
export declare function getRequestEvent(): RequestEvent | undefined;
/** A render's keyed server-to-client value channel (`getHydrationWriter`). */
export interface HydrationWriter {
    /**
     * Whether the render takes promises and async iterables (`renderToStream`).
     * `renderToString` takes synchronous values only; `write` throws on an
     * async one.
     */
    readonly async: boolean;
    /**
     * Serializes `value` for the client under `key`, readable there with
     * `takeHydrationValue(key)`. Returns `false` without writing when `key` was
     * already written by this render (the first write wins) or the render no
     * longer takes values (a finished `renderToString`, a completed stream).
     * `deferStream` holds the shell until a promise settles. Prefix keys with
     * the library's own namespace (`"sq:"`); Solid's own entries are keyed by
     * hydration id.
     */
    write(key: string, value: unknown, options?: {
        deferStream?: boolean;
    }): boolean;
}
/** A keyed value taken from the hydration registry (`takeHydrationValue`). */
export type HydrationValue<T = unknown> = {
    status: "resolved";
    value: T;
} | {
    status: "rejected";
    error: unknown;
} | {
    status: "pending";
    promise: Promise<T>;
};
/**
 * The keyed server-to-client value channel of the render the caller belongs
 * to — found through the caller's owner, else (no owner) through the request
 * scope when exactly one render is open for that request. `undefined`
 * outside any render and on the client. Never another request's render.
 *
 * Capture it where the render is known (component setup) to write from IO
 * later. A write is not gated on `<NoHydration>`: read `isHydratable()` where
 * the value is produced to decide. Read the value on the client with
 * `takeHydrationValue(key)`.
 *
 * @example
 * ```ts
 * const writer = getHydrationWriter();
 * if (writer && isHydratable()) writer.write("sq:" + hash, data);
 * ```
 */
export declare function getHydrationWriter(): HydrationWriter | undefined;
/**
 * Sets the link handler of the render the caller belongs to — found through
 * the caller's owner (component setup), else through the request scope when
 * exactly one render is open for it — so every candidate anchor rendered
 * from here on carries the handler's markup (`aria-current="page"`,
 * `data-active`) in the server HTML. Returns `false` outside any render.
 *
 * Scoped to the render: concurrent renders never share a handler, and it is
 * gone with the render. Set once per render, typically from a router's
 * server render with its request's location; `undefined` clears it. Anchors
 * serialized BEFORE the call (a document shell above the router) are not
 * marked. Server components inline in the document render under the page's
 * handler; a server component's own frame stream has none unless its render
 * sets one.
 *
 * The first call with a handler writes the `links` hydration record once for
 * the response (`hasServerLinkState()` on the client), the signal that the
 * anchors' link state is the server's and can be trusted at hydration.
 *
 * @example
 * ```ts
 * // in <Router>'s server render
 * setLinkClaim(attrs => matchLink(attrs, location) ? ' data-active aria-current="page"' : "");
 * ```
 * @internal
 */
export declare function setLinkClaim(handler: LinkClaimHandler | undefined): boolean;
/**
 * Server: `false`. The client reads the `links` hydration record a render
 * with a link handler wrote (`setLinkClaim`); see the client entry.
 * @internal
 */
export declare function hasServerLinkState(): boolean;
/** Server stub — the registry is the client's. See the client entry. */
export declare function takeHydrationValue<T = unknown>(_key: string): HydrationValue<T> | undefined;
/**
 * The trace the current request belongs to — continued from the incoming
 * W3C `traceparent` when there was one, originated by the runtime
 * otherwise; in observe/dev builds, merged with the installed provider's
 * answer (`OBSERVE.server.trace`). Same object for every read within the
 * request, direct server-function calls included. For a render outside a
 * request scope, the render's own trace, read within it (under its owner).
 * `undefined` outside both, and on the client. Forward it downstream from a
 * server function with `getTraceContext()?.entries.traceparent`.
 */
export declare function getTraceContext(): TraceContext | undefined;
/** A fresh, uncommitted response head. */
export declare function createResponseStub(): ResponseStub;
export declare function createRequestEvent<T extends object = {}>(request: Request, init?: T): RequestEvent & {
    response: ResponseStub;
} & T;
export declare function commitResponseStub(stub: ResponseStub, options?: {
    allowLateLocation?: boolean;
    event?: RequestEvent;
}): ResponseStub;
export declare function getExpectedRedirectStatus(response: ResponseStub): number;
export declare function commitEventResponse(response: Response, event?: RequestEvent): Response;
export declare function createSSRResponse(result: string, event: RequestEvent | undefined, options?: SSRResponseOptions): Response;
export declare function createSSRResponse(result: {
    pipe(writable: {
        write: (v: string) => void;
        end: () => void;
    }): void;
}, event: RequestEvent | undefined, options?: SSRResponseOptions): Promise<Response>;
export declare function composeMiddleware(middlewares: FetchMiddleware[]): (request: Request, next: (request?: Request) => Response | Promise<Response>) => Promise<Response>;
/**
 * Options for `registerElementClaim` (see the client entry); inert on the server.
 * @internal
 */
export type ElementClaimOptions = {
    /**
     * Attribute names whose compiler-owned writes re-claim an already claimed
     * element, as plain names (`href` covers `prop:href` and `xlink:href`).
     * Defaults to `["href", "action"]`.
     */
    attributes?: readonly string[];
}; /**
 * Server no-op: element claims are a client-only concern, but consumers may
 * register isomorphically. Returns a no-op unregister function.
 */
export declare function registerElementClaim(handler: (element: Element) => void, options?: ElementClaimOptions): () => void;
export declare function claimElement<T extends Element>(node: T, owner?: Owner | null): T;
export declare function claimElementTree<T extends Node>(root: T): T;
/** Server: `fn()`. No event is dispatched during SSR, so there is no interaction to join. */
export declare function dispatchAsInteraction<T>(_e: Event, fn: () => T): T;
export { notSup as style, notSup as insert, notSup as spread, notSup as delegateEvents, notSup as registerDelegatedRoot, notSup as unregisterDelegatedRoot, notSup as registerDelegatedContainer, notSup as unregisterDelegatedContainer, notSup as getDelegatedRoot, notSup as dynamicProperty, notSup as setAttribute, notSup as setAttributeNS, notSup as addEvent, notSup as render, notSup as template, notSup as setProperty, notSup as setStatefulProperty, notSup as className, notSup as assign, notSup as hydrate, notSup as getNextElement, notSup as getNextMatch, notSup as getNextMarker, notSup as runHydrationEvents, notSup as ref, notSup as setStyleProperty, notSup as readShallow, notSup as acquireAsset };
declare function notSup(): void;
