/** Install the traces tier into the frames client (called by `prepareTier`). */
export declare function install(): void;
