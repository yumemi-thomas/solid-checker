/**
 * `@solidjs/web/frames/assets` — the frames client's ASSETS tier (frames
 * savings pass §3 row C5): what a segment's `seg:<k>:assets` record does to
 * the document head, loaded on demand through the tier mechanism
 * (`prepareTier("assets")`, frame-client.ts).
 *
 * What rides in this chunk, and so leaves the eager frames client: the
 * import-free mirror of the client asset registry's head conventions
 * (`ensureStylesheet` / `ensurePreload` / `ensureModulePreload` /
 * `applyInlineStyles`, `findHeadElement`'s attribute-compared lookup and
 * head.ts's `qualifierValue`), the per-frame flush a pending stylesheet
 * wakes, and the assets pass over a record (modules, typed preloads, inline
 * styles). The eager client keeps the record itself (the wire's
 * `seg:<k>:assets` record, the host's `seg::assets` accumulate), the pass's walk over
 * the store, and the reveal's READINESS TERM: a segment whose assets record
 * carries stylesheets or inline styles while this tier is not resident is
 * not ready — the server's `<Loading>` fallback stays on screen; the reveal
 * happens at max(tier load, stylesheet load) (frames savings pass §1,
 * "assets": no FOUC, no blank). Once the tier is resident only stylesheets
 * gate: inline styles apply at the record's arrival (the walk runs ahead of
 * the segments in the same flush), modules and preloads likewise, and a
 * segment with none of these never waits on the tier.
 *
 * The module's exports ARE its dispatch: `prepareTier` stamps the load with
 * the module once it has resolved (`tierLoads.assets.r`), and the eager
 * client calls `gate` from `#segmentReady` and `apply` from `#flush`'s
 * assets walk off that stamp. No `install()`: the tier registers nothing
 * and imports nothing of the client — it needs no shared instance, only
 * the frame handed to `gate` (its `apply` is the flush a settled sheet
 * triggers).
 *
 * The server announces this tier wherever it emits an assets chunk
 * (`sink.needs("assets")` — the shell's pre-flush assets, a style-gated
 * fragment's, a late module / preload; frame-sink.ts): `X-Frame-Tiers` /
 * `chunk.tiers` on a stream, `_$HY.r["sc:tiers"]` + a `modulepreload` on a
 * document — so the load is a warm start; an un-announced record starts it
 * from the readiness check or the walk and the segment waits (the same DOM,
 * later).
 * @experimental
 */
import type { Frame } from "./frame-client.js";
/** A stylesheet entry as the sink writes it: a url, or `{ href, attrs }`. */
export type StylesheetEntry = string | {
    href: string;
    attrs?: Record<string, string>;
};
/** A typed preload entry (`<link rel="preload">`): request-qualifying attributes, optional href. */
export interface PreloadEntry {
    href?: string;
    attrs: Record<string, string>;
}
/** An inline style entry (`<style data-asset>`). */
export interface InlineStyleEntry {
    id: string;
    content?: string;
    attrs?: Record<string, string>;
}
/** The head-affecting members of a `seg:<k>:assets` record. */
export interface AssetsRecord {
    modules?: string[];
    styles?: StylesheetEntry[];
    inlineStyles?: InlineStyleEntry[];
    preloads?: PreloadEntry[];
}
/**
 * The stylesheet gate for one segment (`#segmentReady`'s style term, once
 * the tier is resident): ensure every named sheet is in the head — pending
 * links are inserted now, even while another prerequisite is missing, so
 * the load overlaps the rest of the stream — and report whether all have
 * settled. `frame` is re-flushed when a pending one settles.
 */
export declare function gate(entries: StylesheetEntry[], frame: Frame): boolean;
/**
 * The assets pass for one record (`#flush`'s walk, once per record identity
 * per mount): module preloads, typed preloads, inline styles. Stylesheets
 * are the gate's (`gate`) — never applied here.
 */
export declare function apply(record: AssetsRecord): void;
