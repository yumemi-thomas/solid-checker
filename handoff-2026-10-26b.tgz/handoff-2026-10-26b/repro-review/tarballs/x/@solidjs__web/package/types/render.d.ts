export declare let spreadName: string | undefined;
export declare let spreadLoc: string | undefined;
export declare function setSpreadName(name: string | undefined, loc?: string): void;
/** Dev: remember the element the running binding effect writes (first one wins). */
export declare function tagElement(node: Node): void;
export declare function effect<T>(fn: (prev?: T) => T, effectFn: (value: T, prev?: T) => void | (() => void), options?: {
    scope?: boolean;
    name?: string;
    loc?: string;
}): void;
export declare function memo<T>(fn: () => T): () => T;
