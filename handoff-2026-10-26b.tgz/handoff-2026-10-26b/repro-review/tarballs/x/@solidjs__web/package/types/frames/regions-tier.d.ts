/**
 * The `{$frame}` arm of a frame's arg resolution: for each region arg of
 * the record (`regions`: arg name -> wire id), the region ELEMENT the
 * wrapper places goes into `props` — cached per occurrence, so a re-call
 * re-places the SAME element (no marker range to walk, no fragment refill)
 * and the bound frame's parent follows live. `start` is given on the
 * adopt-time mount (the frame's `claiming`): the interior's region elements
 * are discovered first, so the record's addresses resolve to them.
 */
export declare function resolve(frame: any, occurrence: string, regions: Record<string, string>, props: Record<string, unknown>, start?: unknown): void;
/**
 * Bind a frame over each of the occurrence's region elements that has none
 * yet — those `resolve` minted during the invoke or, on the adopt path,
 * discovered in the interior before the fill ran (the fill owns its range
 * through the framework's insert; the frame never reads its output back).
 * Bind eagerly — the region ELEMENT always exists (unlike a marker range,
 * which needs placement to count).
 * This is what makes an OCCLUDED region work: its element is created when
 * args resolve but the wrapper doesn't place it until (e.g.) expand, so it
 * must bind and fill (from buffered/streamed chunks) off-DOM, then reveal
 * in place when the wrapper finally inserts the single node. Host
 * buffering flushes any queued childId chunks. The region inherits this
 * frame's slot resolution (`parent`), so client slots revealed in its
 * streamed content are filled by the same callbacks the client threaded
 * down — no global registry.
 */
export declare function bind(frame: any, occurrence: string): void;
/**
 * A fill read a region element: the reader's owner places it, as reading
 * `props.children` places client children. The region's nested fills mount
 * under it — those waiting for a placement, and those the last placement's
 * disposal took down with it.
 */
export declare function place(el: Element): void;
/**
 * Invoke a fill (`mount`, the binding's) for an occurrence: one in a region
 * mounts under the owner that placed the region — so it reads the context
 * the enclosing fill provides there — and lives as long as that placement.
 * While the region is unplaced (occluded, or its placement disposed) it
 * waits; the next placement mounts it afresh over what the range holds.
 */
export declare function nest(mount: (props: any, ctx: any) => void, props: any, ctx: any): void;
/**
 * Dispose the frames bound over an occurrence's regions and forget them;
 * without an occurrence, every region of the frame (the frame is being
 * disposed).
 */
export declare function unmount(frame: any, occurrence?: string): void;
/**
 * For the staged preview (`Frame.preview`): whether the record adds a
 * region to the occurrence or renames one of its regions — its chunks ride
 * the new name, so the rename must land with them at the commit, not in
 * the preview. Read off the host's note of the record's `{$frame}` args.
 */
export declare function changed(frame: any, occurrence: string, record: {
    regions?: Record<string, string>;
}): boolean;
/** The frames bound over the frame's regions (the staged preview recurses
 *  into them). */
export declare function frames(frame: any): any[];
