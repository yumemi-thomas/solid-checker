import type { RequestEvent, RequestEventLocals, ResponseStub } from "./client.js";
import type { JSX } from "./jsx.js";
import type { ServerErrorSite } from "solid-js";
/**
 * Where a server-side failure was met, as the server error hook hears it —
 * the client's view of the server entry's type (see `configureServerErrors`
 * there). `kind: "render"`: `fallback`/`client`/`failed`; `kind:
 * "server-function"`: `thrown`/`channel`; `kind: "request"`: `failed`.
 */
export interface ServerErrorContext extends Omit<ServerErrorSite, "event"> {
    event?: RequestEvent;
}
/** The server error hook (see the server entry's `configureServerErrors`). Its return is the wire value; nothing for the default. */
export type ServerErrorHook = (error: unknown, context: ServerErrorContext) => unknown | void;
export interface ServerErrorsConfig {
    onError?: ServerErrorHook;
}
/**
 * Registers the ambient server error hook. Server-only; on the client this
 * is a no-op so isomorphic setup code can call it unguarded.
 */
export declare function configureServerErrors(_config: ServerErrorsConfig): void;
/**
 * Reports a failure that fails a request outside any render (see the
 * server entry's `reportRequestFailure`). Server-only; on the client this is
 * a no-op.
 */
export declare function reportRequestFailure(_error: unknown, _event: RequestEvent): void;
type PreloadLinkAttributes = {
    type?: string;
    crossorigin?: JSX.HTMLCrossorigin;
    integrity?: string;
    referrerpolicy?: JSX.HTMLReferrerPolicy;
    fetchpriority?: JSX.HTMLFetchPriority;
    media?: string;
};
/**
 * An explicit `<link rel="preload">` emitted by the SSR asset pipeline.
 *
 * `as` is the HTML Standard's set of preload destinations exactly — anything
 * else translates to null and the browser does nothing with the link.
 *
 * `imagesrcset` candidates must already be resolved by the integration: they
 * are carried verbatim (a relative candidate resolves against the DOCUMENT
 * URL, not the manifest base). Pair it with `imagesizes` whenever a candidate
 * uses a width descriptor, which the spec requires — without it the source
 * size falls back to `100vw` and the preload can miss the image the `<img>`
 * selects. Omitting `href` is the spec's own recommendation for the source-set
 * form: it would only serve browsers without `imagesrcset` support, and there
 * it would likely preload the wrong candidate.
 */
export type PreloadLink = PreloadLinkAttributes & ({
    href: string;
    as: Exclude<JSX.HTMLPreloadAs, "image">;
    imagesrcset?: never;
    imagesizes?: never;
} | {
    href: string;
    as: "image";
    imagesrcset?: string;
    imagesizes?: string;
} | {
    href?: never;
    as: "image";
    imagesrcset: string;
    imagesizes?: string;
});
/**
 * Static asset graph consumed by the SSR pipeline. This is Solid's own
 * contract — a parsed Vite client manifest satisfies it structurally
 * (unknown fields pass through untyped), but any bundler integration can
 * produce it. Only these fields are ever read: `preloads` is Solid's
 * extension slot for explicit typed links the integration selects.
 */
export type AssetManifest = Record<string, {
    file: string;
    css?: string[];
    isEntry?: boolean;
    imports?: string[];
    preloads?: PreloadLink[];
}> & {
    _base?: string;
};
/** Inline style content, e.g. dev CSS collected from a bundler's module graph. */
export type InlineStyleAsset = {
    id: string;
    content: string;
    attrs?: Record<string, string>;
};
export type ResolvedAssets = {
    js: string[];
    css: (string | InlineStyleAsset)[];
    preloads?: PreloadLink[];
};
/**
 * Resolver form of the manifest option — the primitive a dev server
 * implements against its live module graph (a static manifest object is
 * normalized into a sync resolver internally). `resolve` may return a
 * promise (async resolvers require streaming rendering); CSS entries may be
 * URL strings (emitted as load-gated `<link>` tags) or inline-style
 * descriptors (emitted as `<style>` tags), and `preloads` carries explicit
 * preload links selected by the integration. A bare `resolve`-shaped
 * function is accepted as shorthand for `{ resolve }`.
 */
export type AssetResolver = {
    resolve(key: string): ResolvedAssets | null | undefined | Promise<ResolvedAssets | null | undefined>;
    /**
     * Synchronous fast path answering with whatever is knowable without async
     * work (typically js URLs, omitting css). Sync consumers — e.g. a lazy
     * component's `moduleUrl` getter used by islands — use this when `resolve`
     * would return a promise, so adapters should provide it whenever possible.
     */
    resolveSync?(key: string): ResolvedAssets | null | undefined;
};
/** Bare-function shorthand for `AssetResolver` (no sync fast path). */
export type AssetResolverFn = (key: string) => ResolvedAssets | null | undefined | Promise<ResolvedAssets | null | undefined>;
/**
 * CSP nonce for the tags a server render emits. A string applies to both
 * nonce-aware destinations; a `{ script, style }` pair routes each tag to
 * its destination's nonce, with `false` leaving that destination un-nonced.
 */
export type CSPNonce = string | {
    script: string | false;
    style: string | false;
};
/**
 * Renders a component tree synchronously to an HTML string. Async reads inside
 * `<Loading>` boundaries emit their `fallback` content; for full-graph
 * resolution await `renderToStream` instead.
 *
 * Pair the returned HTML with `hydrate()` on the client.
 *
 * @example
 * ```tsx
 * import { renderToString } from "@solidjs/web";
 *
 * const html = renderToString(() => <App />);
 * res.send(`<!doctype html><html><body><div id="root">${html}</div></body></html>`);
 * ```
 */
export declare function renderToString<T>(fn: () => T, options?: {
    nonce?: CSPNonce;
    renderId?: string;
    noScripts?: boolean;
    plugins?: any[];
    manifest?: AssetManifest | AssetResolver | AssetResolverFn;
    /** This render's server error hook, ahead of `configureServerErrors`' (see the server entry). */
    onError?: ServerErrorHook;
    /**
     * Embedded-render contract for hosts that own the document. When the
     * render output contains no `</head>`, everything head-bound (resolved
     * `useHead` winners, eager resources, tracked asset links, inline
     * styles) is delivered here as one HTML string — prelude (charset/base)
     * first — for the host to splice into its own `<head>` template, instead
     * of being dropped. Called synchronously before `renderToString`
     * returns; not called when the output has a `</head>` (splicing is
     * automatic then).
     */
    onHead?: (head: string) => void;
}): string;
/**
 * Streams an HTML response, flushing the synchronous shell first and then
 * progressively emitting async-resolved fragments as their `<Loading>`
 * boundaries settle. Good for time-to-first-byte sensitive pages.
 *
 * Returns an object with `pipe`/`pipeTo` for piping to a Node `Writable` or
 * a Web `WritableStream`, a lazy `readable` byte-stream view for
 * `new Response(stream.readable)`, plus a thenable for awaiting full
 * completion — `await renderToStream(...)` resolves with the settled HTML
 * (the fully-resolved-string form of the render). `pipe`, `pipeTo`, and
 * `readable` each consume the render — use exactly one of the three.
 *
 * @example
 * ```tsx
 * import { renderToStream } from "@solidjs/web";
 *
 * // Node:
 * renderToStream(() => <App />).pipe(res);
 *
 * // Web (Workers / Deno):
 * return new Response(renderToStream(() => <App />).readable);
 *
 * // Fully settled string:
 * const html = await renderToStream(() => <App />);
 * ```
 */
export declare function renderToStream<T>(fn: () => T, options?: {
    nonce?: CSPNonce;
    renderId?: string;
    noScripts?: boolean;
    plugins?: any[];
    manifest?: AssetManifest | AssetResolver | AssetResolverFn;
    onCompleteShell?: (info: {
        write: (v: string) => void;
    }) => void;
    onCompleteAll?: (info: {
        write: (v: string) => void;
    }) => void;
    /** This render's server error hook, ahead of `configureServerErrors`' (see the server entry). */
    onError?: ServerErrorHook;
    /**
     * Embedded-render contract for hosts that own the document. When the
     * shell contains no `</head>`, everything head-bound at first flush
     * (resolved `useHead` winners, eager resources, tracked asset links,
     * inline styles) is delivered here as one HTML string — prelude first —
     * before the shell chunk is emitted, so the host can write its own
     * `<head>` ahead of piping the stream. Post-shell head updates flow
     * through the stream itself and apply in the browser. Not called when
     * the shell has a `</head>` (splicing is automatic then).
     */
    onHead?: (head: string) => void;
    /**
     * The request's lifecycle. Aborting tears the render down exactly as a
     * client disconnect does (`SSR_STREAM_ABANDONED`, `data.reason:
     * "signal"`); the one teardown handle for a host whose transport cannot
     * report a dead consumer through the sink or the readable view — pass
     * `request.signal`.
     */
    signal?: AbortSignal;
}): {
    /**
     * Awaiting the stream resolves with the complete HTML once every boundary
     * settles — the fully-settled-string form of the render. Render errors
     * route through `onError` and the promise resolves with whatever HTML the
     * render produced; it never rejects.
     */
    then<TResult1 = string, TResult2 = never>(onfulfilled?: ((html: string) => TResult1 | PromiseLike<TResult1>) | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | null): Promise<TResult1 | TResult2>;
    pipe: (writable: {
        write: (v: string) => void;
        end: () => void;
    }) => void;
    pipeTo: (writable: WritableStream) => Promise<void>;
    readonly readable: ReadableStream<Uint8Array>;
};
/**
 * Fetch-style middleware: receives the `Request` and a `next` continuation
 * (pass a `Request` to substitute it downstream) and returns the `Response`.
 * Composed with `composeMiddleware`; runs inside the request-event scope, so
 * `getRequestEvent()` works exactly as in application code.
 */
export type FetchMiddleware = (request: Request, next: (request?: Request) => Promise<Response>) => Response | Promise<Response>;
/**
 * Creates a fresh, uncommitted {@link ResponseStub}. Server-only.
 */
export declare function createResponseStub(): ResponseStub;
/**
 * Builds the canonical request event — a web-standard `Request`, a `locals`
 * bag, and a stub-backed `response` head — for `provideRequestEvent`.
 * Server-only: on the client the request event belongs to the server that
 * rendered the page.
 */
export declare function createRequestEvent<T extends object = {}>(request: Request, init?: T): {
    request: Request;
    locals: RequestEventLocals;
    response: ResponseStub;
} & T;
/**
 * The HTTP status a redirect should use: the stub's own status when it is a
 * redirect status (301/302/303/307/308), 302 otherwise. Server-only.
 */
export declare function getExpectedRedirectStatus(response: ResponseStub): number;
/**
 * Derives the outgoing `Response` for an SSR render result, running the
 * response-head lifecycle against `event.response`: the stub commits at
 * shell flush, a pre-flush `Location` becomes a real redirect
 * (`getExpectedRedirectStatus`), and a post-flush one appends the
 * nonce-aware `<script>window.location=...</script>` fallback. String
 * results return a `Response` synchronously (an awaited `renderToStream`
 * result arrives already committed — its head froze at completion); stream
 * results resolve at shell flush. Server-only.
 */
export declare function createSSRResponse(result: string, event: RequestEvent | undefined, options?: {
    responseInit?: ResponseInit;
    nonce?: CSPNonce;
    transformChunk?: (chunk: string) => string;
}): Response;
export declare function createSSRResponse(result: {
    pipe(writable: {
        write: (v: string) => void;
        end: () => void;
    }): void;
}, event: RequestEvent | undefined, options?: {
    responseInit?: ResponseInit;
    nonce?: CSPNonce;
    transformChunk?: (chunk: string) => string;
}): Promise<Response>;
/**
 * Handler-lifecycle plumbing — the exit for a `Response` that did not go
 * through `createSSRResponse` (a middleware early return, an API result):
 * folds the request event's response stub onto it (cookies append
 * entry-by-entry, other headers gap-fill, status never) and commits the
 * stub. Already-committed stubs pass the response through untouched, so
 * handlers apply it unconditionally after their middleware chain unwinds.
 * `event` defaults to the ambient `getRequestEvent()`. Application
 * middleware never calls this. Server-only.
 */
export declare function commitEventResponse(response: Response, event?: RequestEvent): Response;
/**
 * Composes fetch-style middleware — `(request, next) => Response` — into a
 * single function of the same shape. Nothing reaches the wire until the
 * outermost middleware returns, so headers on the returned `Response` stay
 * mutable through the whole unwind, streamed bodies included. Server-only.
 */
export declare function composeMiddleware(middlewares: FetchMiddleware[]): (request: Request, next: (request?: Request) => Response | Promise<Response>) => Promise<Response>;
/**
 * Compiler primitive — emitted by Solid's JSX compiler for tagged-template
 * SSR output. Not meant for hand-written code.
 * @internal
 */
export declare function ssr(template: string[] | string, ...nodes: any[]): {
    t: string;
};
/**
 * Compiler primitive — emitted by Solid's JSX compiler for SSR element
 * output. Not meant for hand-written code.
 * @internal
 */
export declare function ssrElement(name: string, props: any | any[] | (() => any | any[]), children: any, needsId: boolean, skip?: (key: string) => boolean, attrs?: string | (() => string)): {
    t: string;
};
/**
 * Compiler primitive — serializes one attribute of a spread element as
 * `ssrElement` would, for a dynamic attribute after the element's last
 * spread. Not meant for hand-written code.
 * @internal
 */
export declare function ssrElementAttribute(key: string, value: any): string;
/**
 * Compiler primitive — the hole after a candidate anchor's attributes in SSR
 * output, the render's link handler's markup (see the server entry's
 * `setLinkClaim`). Not meant for hand-written code.
 * @internal
 */
export declare function ssrLinkClaim(attrs: Readonly<Record<string, unknown>>): string;
/**
 * Compiler primitive — serializes a class value (string, object map, or
 * array) for SSR output. Not meant for hand-written code.
 * @internal
 */
export declare function ssrClassName(value: string | {
    [k: string]: boolean;
} | Array<any>): string;
/**
 * Compiler primitive — serializes a style value for SSR output. Not meant
 * for hand-written code.
 * @internal
 */
export declare function ssrStyle(value: string | {
    [k: string]: string;
}): string;
/**
 * Compiler primitive — serializes one style property for SSR output. Not
 * meant for hand-written code.
 * @internal
 */
export declare function ssrStyleProperty(name: string, value: any): string;
/**
 * Compiler primitive — serializes a style object's `name, value` pairs for
 * SSR output. Not meant for hand-written code.
 * @internal
 */
export declare function ssrStyleProperties(...entries: any[]): string;
/**
 * Compiler primitive — serializes an attribute for SSR output. Not meant
 * for hand-written code.
 * @internal
 */
export declare function ssrAttribute(key: string, value: any): string;
/**
 * Compiler primitive — wraps a template-group closure for SSR output. Not
 * meant for hand-written code.
 * @internal
 */
export declare function ssrGroup<T extends () => any[]>(fn: T, n: number): T;
/**
 * Compiler primitive — generates the hydration-key attribute for SSR
 * output. Not meant for hand-written code.
 * @internal
 */
export declare function ssrHydrationKey(): string;
/**
 * Compiler primitive — collapses an SSR-shaped node into its HTML string.
 * Not meant for hand-written code.
 * @internal
 */
export declare function resolveSSRNode(node: any, result?: any, top?: boolean, nested?: boolean): any;
/**
 * Escapes a string for safe inclusion in HTML output. Used by the SSR
 * runtime; not generally part of user code.
 * @internal
 */
export declare function escape(s: any, attr?: boolean): any;
export {};
