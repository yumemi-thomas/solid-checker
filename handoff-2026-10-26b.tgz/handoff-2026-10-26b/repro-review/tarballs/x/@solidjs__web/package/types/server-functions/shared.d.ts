export { LIVE_LOCAL, LIVE_RESUME_FROM, LIVE_SOURCE, SERVER_FUNCTION_INVOKE, SERVER_FUNCTION_METADATA, getServerFunctionMetadata, getServerFunctionRPC, invoke, isServerFunction, provideServerFunctionRPC, withMeta } from "./registry.js";
export { FLASH_COOKIE, clearFlashCookie, hasFlashCookie, matchFlashCookie } from "../cookies.js";
import { JSONCodecOptions } from "../serializer-decode.js";
/**
 * The standardized body of a single-flight response (a response tagged with
 * `SINGLE_FLIGHT_HEADER`): the function's return `value` plus the
 * integration-produced `data` payload, folded into one round trip by the
 * HTTP handler. Integrations decoding passthrough responses themselves (no
 * registered consumer) see this shape from `decodeResponse`. The top level
 * is reserved for the protocol — integration payload lives entirely under
 * `data`, the envelope keyed by source id (the unnamed registration's
 * slice rides under the reserved id "true"); each slice can be any
 * codec-serializable value.
 */
export interface SingleFlightPayload<T = unknown, D = unknown> {
    /** The server function's return (or thrown) value. */
    value: T;
    /** The integration-produced data payload, keyed by source id. */
    data: D;
}
/**
 * Envelope context delivered alongside single-flight data: the transport
 * response, whose headers carry the integration metadata (the redirect
 * carrier for redirect-with-data, `X-Revalidate` keys) and status. The
 * body is already consumed — read `data` and `value` from the delivery,
 * not from here.
 */
export interface FlightDataContext {
    /** The HTTP response the data arrived on (metadata only). */
    response: Response;
}
/**
 * Consumer receiving single-flight data on the client: `data` is the
 * integration-produced payload (opaque to the protocol), `context` carries
 * the envelope metadata. `data` is `undefined` when the response carried
 * integration metadata (a redirect, revalidation keys) but the server
 * folded no slice for this source — the consumer still runs, to apply the
 * metadata. Async consumers are awaited before the function value is
 * returned to the caller, so caches are seeded first.
 */
export type FlightDataConsumer<D = unknown> = (data: D | undefined, context: FlightDataContext) => void | Promise<void>;
/**
 * The public contract of a server function reference — what a `"use
 * server"` import is at runtime on either side: an async callable plus its
 * build-stable identity.
 */
export interface ServerFunction<A extends readonly any[] = any[], T = any> {
    (...args: A): Promise<T>;
    /** The build-stable function id (stable across the client and server builds). */
    readonly id: string;
    /**
     * The plain-HTTP address of this function — what a `<form action>` posts
     * to without the runtime (the integration behind `action={fn}` reads it).
     * Not where the reference's own call goes: that is `serverFunctionUrl(fn,
     * ...args)`, for a `GET()` reference — the url to preload or fetch.
     */
    readonly url: string;
}
/**
 * Per-call, invocation-scoped options for `invoke` — things that vary
 * between calls of the SAME function and cannot be declared (`GET`,
 * `withMeta`) or configured (`prepareRequest`). On the server the call is
 * in-process: `signal` still rejects the caller, the transport hints are
 * no-ops (they describe a wire that does not exist).
 */
export interface InvokeOptions {
    /**
     * The call's lifecycle. Aborting rejects the call with the signal's
     * reason and cancels the request (firing `request.signal` server-side);
     * a live source's iteration ends across reconnects. When provided, the
     * signal owns the wire — timeouts compose through it
     * (`AbortSignal.timeout`, `AbortSignal.any`).
     */
    signal?: AbortSignal;
    /**
     * Lets the request outlive the page — fire-and-forget calls during
     * unload (`pagehide`). Maps to fetch's `keepalive`, body-size caps
     * included.
     */
    keepalive?: boolean;
    /** Fetch priority hint — speculative prefetch vs. interaction fetch. */
    priority?: "high" | "low" | "auto";
}
/**
 * A reference's invocation channel, carried under `SERVER_FUNCTION_INVOKE`:
 * applies one call with per-call options. Declaration wrappers (`GET`,
 * `live`) forward it mechanically — they keep the call mapping 1:1. A
 * wrapper that shares calls (a deduping cache, a multicast channel) opts
 * in deliberately, deciding first what a caller's abort means for shared
 * work — or declines, leaving `invoke` to answer with a directed error.
 * Options arrive already validated — `invoke` admits only
 * invocation-scoped keys.
 */
export type ServerFunctionInvoker<A extends readonly any[] = any[], R = any> = (args: A, options?: InvokeOptions) => R;
/**
 * Declaration-static metadata attached to a server function reference
 * through declaration wrappers (`GET`, `withMeta`). Read it with
 * `getServerFunctionMetadata`; routers and integrations detect capability
 * from here instead of property sniffing, and `prepareRequest` receives it
 * as `context.meta`. Write through `withMeta` — later writes shallow-merge
 * over earlier ones.
 */
export interface ServerFunctionMetadata {
    /** The declared HTTP method. Undeclared references call over POST. */
    readonly method?: "GET" | "POST";
    /**
     * A human-readable label for the function, seeded by development builds
     * from the compiled function's source name (dev tooling — inspectors,
     * logs). Dev-only: production builds emit no name. Not unique and not an
     * identity key — use `id` for identity. Seeded as a default: an explicit
     * `withMeta` write wins.
     */
    readonly name?: string;
    /**
     * This function's own send, client side: the transport calls it instead
     * of the configured `fetch` for every request the function makes, with
     * the configured send (the app's `fetch`, or the global) as `next`. For
     * an integration that answers a declared function's calls itself — a
     * prerendered build's static artifacts, a cache — while the app's
     * transport `fetch` stays the app's: pass on what you don't answer
     * through `next`. The contract is `fetch`'s (see
     * `ServerFunctionsClientConfig.fetch`); hydration adopts a
     * server-rendered read only if the send reaches the global `fetch` in the
     * same tick.
     *
     * ```ts
     * withMeta(getPosts, {
     *   fetch: (address, init, next) => cached(address) ?? next(address, init)
     * });
     * ```
     */
    readonly fetch?: (address: string, init: RequestInit, next: (address: string, init: RequestInit) => Response | Promise<Response>) => Response | Promise<Response>;
    /** User-declared transport metadata attached with `withMeta`. */
    readonly [key: string]: unknown;
}
/**
 * The transport surface integrations consume through the late-bound RPC
 * seam (server-functions/registry.js) — filled by the transport halves when
 * the first server function reference is created (code that only exists in
 * a bundle when a `"use server"` function was actually compiled in), read
 * by routers so they never import the transport/codec statically.
 */
export interface ServerFunctionRPC {
    /**
     * The build's `GET` declaration wrapper (client fetch transport or
     * server in-process dispatch — see the respective entries).
     */
    GET<A extends readonly any[], R>(fn: (...args: A) => R): ServerFunction<A, Awaited<R>>;
    /**
     * `decodeResponse` bound to the configured codec: decodes a server
     * function response body the transport handed over whole (redirects,
     * revalidation). Resolves undefined for empty bodies and bodies without
     * a recognized encoding (e.g. a raw user Response).
     */
    decodeResponse<T = unknown>(response: Response): Promise<T | undefined>;
}
/**
 * Transport wire detail; not meant for hand-written code.
 * @internal
 */
export type BodyFormatValue = (typeof BodyFormat)[keyof typeof BodyFormat];
export declare function configureServerFunctionsCodec(codec: JSONCodecOptions | undefined): void;
export declare function getServerFunctionsCodec(): JSONCodecOptions | undefined;
/**
 * Validates a flight data source id (both registration halves share the
 * rule): ids travel the `SINGLE_FLIGHT_HEADER` as a comma-separated list,
 * so they cannot be empty or contain commas, and "true" is reserved for
 * the unnamed registration.
 *
 * Transport building block; not meant for hand-written code.
 * @internal
 */
export declare function assertFlightSource(source: string): void;
export declare function subscribeFlightData<D = unknown>(consumer: FlightDataConsumer<D>): () => void;
export declare function subscribeFlightData<D = unknown>(source: string, consumer: FlightDataConsumer<D>): () => void;
export declare function getFlightDataConsumer(source?: string): FlightDataConsumer | undefined;
export declare function getFlightDataSourceIds(): string[];
/**
 * Whether a mutation response carries integration metadata — the redirect
 * carrier or `X-Revalidate` keys. Metadata is envelope-level (it describes
 * what the mutation did to every cache on the page), so a response carrying
 * it is delivered to every registered flight consumer, folded or not.
 *
 * Transport building block; not meant for hand-written code.
 * @internal
 */
export declare function hasFlightMetadata(response: Response): boolean;
/**
 * Delivers a decoded single-flight envelope's `data` to the registered
 * consumers — THE delivery path, shared by every transport that can carry
 * the envelope (the plain server-function client and the frames client's
 * flight application), so a mutation reads identically whichever body
 * shape it arrived in.
 *
 * `data` is the keyed envelope, `{ [source]: slice }` (the unnamed
 * registration's slice under the reserved id "true"); `response` is the
 * envelope context, whose `SINGLE_FLIGHT_HEADER` names the folded sources.
 * Each registered consumer receives its own slice, in registration order,
 * awaited sequentially so caches are seeded before the caller sees the
 * value. Pending entries in the slices (values the collector folded while
 * still in flight, streamed after the response head) are settled before
 * any consumer runs. A consumer whose source was not folded is skipped —
 * unless the response carries integration metadata, in which case it runs
 * with `data` `undefined` to apply the metadata. Consumers are looked up
 * per delivery: an awaited consumer may unsubscribe another (a provider
 * tearing down under a navigation).
 *
 * Transport building block; not meant for hand-written code.
 * @internal
 */
export declare function deliverFlightData(response: Response, data: unknown): Promise<void>;
export declare function frameAddress(id: string, args?: readonly unknown[]): string;
export declare function serverFunctionAddress(endpoint: string, id: string): string;
export declare function serverFunctionDataAddress(endpoint: string, id: string): string;
export declare function serverFunctionLiveAddress(endpoint: string, id: string): string;
export declare function parseServerFunctionAddress(pathname: string, endpoint: string): {
    id: string;
    data: boolean;
    live: boolean;
} | null;
/**
 * The longest url a `GET()` call goes out as. Longer, the call dispatches
 * over POST instead — a cache miss rather than a 414 from whichever proxy in
 * the chain draws the line first — so no url describes it (`serverFunctionUrl`
 * refuses to render one).
 * @internal
 */
export declare const MAX_GET_URL_LENGTH = 2000;
/**
 * Body of both entries' `serverFunctionActionUrl`: the plain-HTTP address of
 * a function, `<endpoint>/<id>[?args=...]`.
 * @internal
 */
export declare function serverFunctionActionUrlFor(endpoint: string, target: ServerFunction | string, boundArgs: readonly unknown[]): string;
/**
 * Body of both entries' `serverFunctionUrl`: the url a `GET()` reference's
 * own call requests — `<endpoint>/data/<id>[?args=...]`, or for a live
 * reference `<endpoint>/live/<id>[?args=...]` — built the way the transport
 * builds it (JSON arguments in `args`; see `GET`'s client half) so a fetch
 * of it is the call. For a live reference that call is a standing event
 * stream: the url is for fetching by hand (`curl -N`), not for a preload
 * or prefetch, which would open a stream nothing reads. Refuses — rather
 * than answering with an address nothing would request — when the
 * reference is not a declared read (the default transport POSTs, and a
 * POST is not described by its url), when the arguments need the codec
 * (the transport encodes those asynchronously, and a url rendered as a
 * value cannot wait), and when the url would be long enough for the call
 * to fall back to POST.
 * @internal
 */
export declare function serverFunctionUrlFor(endpoint: string, fn: ServerFunction, args: readonly unknown[]): string;
/**
 * Response header marking a thrown server-function error. The value is the
 * error's message (the structured error itself travels in the body); `"true"`
 * for thrown control-flow responses and non-Error values.
 */
export declare const ERROR_HEADER = "X-Server-Function-Error";
export declare function encodeErrorHeaderValue(value: string): string;
export declare function decodeErrorHeaderValue(value: string): string;
/** Header carrying the body format tag (a `BodyFormat` value). */
export declare const BODY_FORMAT_HEADER = "X-Server-Function-Format";
/**
 * The position a `live` loop reconnects from, on the request to a live
 * address — the header `EventSource` sends for the same purpose, so a cursor
 * source written against either reader reads one name. Its value is the
 * `id:` of the last event the loop received: a cursor the source named, or
 * the runtime's digest of a value-shaped yield (see `positionDigest`), which
 * lets the server skip re-sending a first emission the client already
 * holds. Rides only on the live address, which is `no-store` and never
 * preloaded — a position must never become an argument, where it would
 * change a read's url identity.
 * @internal
 */
export declare const LAST_EVENT_ID_HEADER = "Last-Event-ID";
/**
 * Per-iteration slot the `live` loop threads through its invoke options
 * (never a public option; process-local symbol): the reader records each
 * event's `id:` in `position`, the next connect sends it back as
 * `Last-Event-ID`, and the loop asks the reference for the LIVE address
 * when this is present. `open` builds the event-stream reader — installed
 * by `live()` itself, so a client that never imports `live` carries no
 * event-stream parser (the `provideRPC` pattern). `connection` is the slot
 * for the connection being made: the decoder sets `connection.ended`, a
 * promise for the body's end carrying how many deferreds were still open
 * (the lifetime signal — death or completion), the error the body ended
 * with, and the sweep the loop may run over the open ones.
 * @internal
 */
export declare const LIVE_WIRE: unique symbol;
/**
 * Header labelling the unknown-id 404: the address was well-formed but its
 * id is not registered in the deployment that answered (#3110). This is the
 * ordinary shape of version skew — a tab holding the previous build's ids
 * across a deploy — and the label is what lets an integration recover
 * (e.g. reload the document) instead of surfacing a generic failed call.
 * Nothing distinguishes it otherwise: a CDN 404 and a skew 404 look alike.
 */
export declare const UNKNOWN_HEADER = "X-Server-Function-Unknown";
/**
 * Header carrying a redirect to scripted callers. fetch FOLLOWS redirect
 * statuses before the transport can read them, so a scripted answer masks
 * the 3xx to 200 and this header carries what the mask erases: the author's
 * status and the target RESOLVED against the request url — exactly the
 * meaning HTTP assigns the `Location` a form post would have received.
 * Value: `<status> <absolute-url>`, decode with `decodeRedirectHeaderValue`.
 *
 * Carrying the resolved absolute form is the point (#3102, #3107): the
 * reader never guesses navigation strategy from how the author spelled the
 * target — `redirect("/")` and `redirect(new URL("/", url).href)` arrive
 * identical by construction, and same-origin vs cross-origin is a real URL
 * comparison, not a `startsWith("http")` coin toss. `Location` itself never
 * rides a masked answer: on a 200 it has no HTTP meaning, and it collided
 * with authored Locations on statuses that forward (a 201's created-at is
 * data, not navigation).
 */
export declare const REDIRECT_HEADER = "X-Server-Function-Redirect";
/**
 * Decodes a `REDIRECT_HEADER` value into the author's status and the
 * resolved absolute target. Integration plumbing for readers of the header
 * (routers); the wire format is the runtime's own, not a contract to parse
 * by hand.
 *
 * The documented output — a resolved ABSOLUTE http(s) target and a redirect
 * status — is enforced, not assumed (#3175): the absoluteness used to be a
 * property of the server having resolved it, and a hostile or buggy peer
 * could ride a `javascript:` target straight into the `location.href =
 * decoded.url` an integration reasonably writes. A value that does not
 * parse as an absolute http(s) url, or whose status is not one the runtime
 * masks, decodes to `undefined` — the same answer a missing header gives.
 */
export declare function decodeRedirectHeaderValue(value: string | null | undefined): {
    status: number;
    url: string;
} | undefined;
/**
 * Header driving the single-flight protocol on both legs: on the request it
 * opts the call into flight-data collection (the integration sends it on
 * calls whose response should fold in data), on the response it marks a
 * body carrying the standardized `{ value, data }` payload. How the data
 * is produced (and what it means) is entirely the integration's business —
 * core only owns the wire shape and the delivery.
 */
export declare const SINGLE_FLIGHT_HEADER = "X-Single-Flight";
/** FormData key used when a lone File is sent as the argument. */
export declare const FILE_FORM_KEY = "__server_function_file__";
export declare const BodyFormat: {
    Serialized: string;
    String: string;
    FormData: string;
    URLSearchParams: string;
    Blob: string;
    File: string;
    ArrayBuffer: string;
    Uint8Array: string;
    /**
     * Plain `JSON.stringify` — the fast path for JSON-safe payloads on both
     * legs: argument lists on the request, results (single-flight envelopes
     * included) on the response.
     */
    Json: string;
    /**
     * No body at all — a function that returned nothing. It marks the response
     * as one the runtime encoded, which separates a void result with a status
     * on it from a refusal answered by something else. Decoding falls through
     * to `undefined`, which is what a peer predating the tag reads too.
     */
    Void: string;
};
export declare function isJSONSafe(value: unknown): boolean;
export declare function getHeadersAndBody(body: unknown): {
    headers?: Record<string, string>;
    body: BodyInit;
} | undefined;
export declare function extractBody(source: Request | Response, codecOptions?: JSONCodecOptions, wire?: unknown): Promise<unknown>;
export declare function createChunk(data: string): Uint8Array;
export declare class ChunkReader {
    constructor(stream: any);
    /** Reads once into the buffer; answers whether the reader was cancelled. */
    readChunk(): Promise<any>;
    next(): Promise<{
        done: boolean;
        value: any;
    }>;
    drain(interpret: any): Promise<void>;
    /** End the read: the body is cancelled through the lock this reader
     *  holds, and a pending `next()` resolves done, even partway through a
     *  frame. */
    cancel(reason: any): any;
}
/**
 * Frame one payload as a server-sent event — the framing a live address
 * answers in. The same codec payloads `createChunk` frames ride one per
 * event so buffering middleboxes, trained on `text/event-stream`, pass them
 * through unbuffered; `id` (when given) rides as the event's `id:` field,
 * which is what a reconnecting loop echoes back as `Last-Event-ID`.
 *
 * Payloads are `JSON.stringify` output and so carry no raw CR/LF, but the
 * split is done regardless: a payload IS one `data:` line per line, and
 * the reader joins them back with `\n`, so the framing is correct for any
 * string rather than for the strings it happens to see.
 *
 * Transport wire detail; not meant for hand-written code.
 * @internal
 */
export declare function createEventChunk(data: string, id?: string): Uint8Array;
/**
 * The heartbeat a live response writes while idle: an event-stream comment,
 * invisible to the reader, that keeps proxies with idle timeouts from
 * closing a connection that is merely waiting.
 * @internal
 */
export declare const EVENT_STREAM_HEARTBEAT: Uint8Array<ArrayBuffer>;
/**
 * Whether a Request/Response body is framed as an event stream (by content
 * type — the framing a live address answers in).
 * @internal
 */
export declare function isEventStream(source: Request | Response): boolean;
/**
 * The reader for what `createEventChunk` writes — `ChunkReader`'s
 * counterpart for the event-stream framing, same `next()`/`drain()` shape
 * so `deserializeStream` runs unchanged over either. Only `data:` and `id:`
 * are read; `event:`, `retry:` and unknown fields are ignored (the
 * transport carries one kind of event and owns its own backoff), comments
 * are heartbeats. An event dispatches on its blank line; an event the body
 * ends inside is discarded, as the spec says, and the drain's end-of-body
 * sweep fails whatever it left open.
 *
 * Each dispatched event's `id:` is recorded on `wire.position` — the value
 * the loop sends as `Last-Event-ID` on its next connect.
 *
 * Transport wire detail; not meant for hand-written code.
 * @internal
 */
export declare class EventStreamReader {
    constructor(stream: any, wire: any);
    read(): Promise<void>;
    takeLine(): any;
    next(): Promise<{
        done: boolean;
        value: any;
    }>;
    drain(interpret: any): Promise<void>;
    /** End the read (see `ChunkReader.cancel`). */
    cancel(reason: any): any;
}
/**
 * The runtime's position for a value-shaped yield: a digest of the value's
 * JSON form, carried as the event's `id:` and echoed back on reconnect so
 * the server can skip re-sending a first emission the client already holds
 * (the data-tier analog of a frame's hole digest). Over `JSON.stringify` of
 * the VALUE, not over the codec record that carries it — a record's
 * reference ids depend on what the stream sent before it, so the same value
 * encodes differently on a fresh connection. `undefined` for a yield that
 * is not JSON-safe: such a yield carries no id and is never skipped.
 *
 * FNV-1a in two 32-bit lanes (a second seed, not a 64-bit arithmetic that
 * JavaScript lacks) → 16 hex characters. Not a security boundary: an equal
 * digest only elides a re-send the client would have discarded as equal.
 * @internal
 */
export declare function positionDigest(value: unknown): string | undefined;
/**
 * The digest behind `positionDigest`, over a string as-is: the frame tier's
 * hole/fragment digest (RFC 11 §9.5, Hole hashes) — minted by the server
 * over the html it emits, stored by the client per hole, echoed back on a
 * resume as the have-list. Same lanes, same width, same non-goal (a
 * collision elides a re-send, nothing more).
 * @internal
 */
export declare function textDigest(text: string): string;
/**
 * Encodes a terminal error-trailer frame payload. The value is expected to
 * be already sanitized by the caller; only `name` and `message` travel.
 * Transport wire detail; not meant for hand-written code.
 * @internal
 */
export declare function encodeErrorTrailer(error: unknown): string;
export declare function serializeStream(value: unknown, codecOptions?: JSONCodecOptions): ReadableStream<Uint8Array>;
export declare function serializeString(value: unknown, codecOptions?: JSONCodecOptions): Promise<string>;
export declare function deserializeStream<T = unknown>(source: Request | Response, codecOptions?: JSONCodecOptions, wire?: unknown): Promise<T>;
export declare function deserializeString<T = unknown>(text: string, codecOptions?: JSONCodecOptions): Promise<T>;
export declare function decodeResponse<T = unknown>(response: Response, codecOptions?: JSONCodecOptions): Promise<T | undefined>;
export declare function decodeResponsePayload<T = unknown, D = unknown>(response: Response, codecOptions?: JSONCodecOptions): Promise<{
    value: T | undefined;
    flightData?: D;
}>;
