/** A container's border serialization: one subscribe() per consumer. */
export interface ContainerTrace {
    subscribe(): AsyncIterable<any>;
    /** Whether the container's root is an array — the consumer's seed shape. */
    array: boolean;
}
/** The eval-face wire literal a trace decodes to before materialization. */
export interface ContainerTraceMarker {
    $tr: AsyncIterable<any>;
    $ta?: number;
}
export declare function setContainerTraceResolver(fn: (value: unknown) => ContainerTrace | undefined): void;
export declare function setAsyncIterableSharer(fn: (source: AsyncIterable<any>) => AsyncIterable<any>): void;
export declare function setContainerTraceMaterializer(fn: (marker: ContainerTraceMarker, claiming?: boolean) => unknown): void;
/**
 * Serializer half: install the async-iterable → raw-seroval-stream mint
 * (serializer-decode.js, which already carries seroval — this module must
 * stay seroval-free because it also rides the EAGER frames-client graph,
 * and seroval ships without `sideEffects: false`).
 *
 * Why a raw stream and not the iterable itself: seroval decodes an async
 * iterable as a generator WRAPPER over its internal stream, so every
 * buffered value is microtasks away — but hydration's claim walk is
 * SYNCHRONOUS. A trace whose snapshot the document already delivered must
 * read as ready DURING the walk (every other async source has a sync
 * hydration answer: promise stamps, serialized records), or the consuming
 * boundary renders a phantom fallback over settled markup (the chat
 * welcome/status meter miss). A raw stream decodes as the stream object
 * itself, whose `.on()` replays the buffer synchronously at subscribe.
 */
export declare function setContainerTraceStreamMint(fn: any): void; /** Whether a value is a traced container (server side; WeakMap probe, trap-safe). */
export declare function isContainerTraced(value: unknown): boolean;
export declare function toBorderForm(value: unknown, envelopeContainers: boolean): unknown;
export declare function isMaterializedContainer(value: unknown): boolean;
export declare function isContainerTraceMarker(value: unknown): value is ContainerTraceMarker;
export declare function reviveContainerTraces(value: unknown, claiming?: boolean): unknown;
declare function parseTrace(value: any, ctx: any): {
    a: number;
    i: any;
};
/**
 * Seroval plugin carrying reactive containers across the slot border as
 * traces. Part of the codec's DEFAULT plugin set (serializer-decode.js), so
 * every face — the hydration serializer, the frames codec, flight
 * payloads, the client data tables — carries it with nothing to wire, and
 * its weight lives in the (lazy) codec graph, never the eager client.
 *
 * @type {import("seroval").Plugin<object, { a: number, i: any }>}
 */
export declare const ContainerTracePlugin: {
    tag: string;
    test(value: any): boolean;
    parse: {
        sync(): never;
        async(value: any, ctx: any): Promise<{
            a: number;
            i: any;
        }>;
        stream: typeof parseTrace;
    };
    serialize(node: any, ctx: any): string;
    deserialize(node: any, ctx: any): any;
};
export {};
