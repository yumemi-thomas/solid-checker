import type { ServerFunction, ServerFunctionMetadata } from "./shared.js";
export { ChunkReader, ERROR_HEADER, EVENT_STREAM_HEARTBEAT, EventStreamReader, FLASH_COOKIE, LAST_EVENT_ID_HEADER, LIVE_WIRE, REDIRECT_HEADER, SERVER_FUNCTION_INVOKE, SINGLE_FLIGHT_HEADER, UNKNOWN_HEADER, clearFlashCookie, createChunk, createEventChunk, decodeErrorHeaderValue, decodeRedirectHeaderValue, decodeResponse, decodeResponsePayload, deliverFlightData, deserializeStream, encodeErrorHeaderValue, frameAddress, getFlightDataConsumer, getFlightDataSourceIds, getServerFunctionMetadata, getServerFunctionsCodec, hasFlashCookie, hasFlightMetadata, invoke, isEventStream, isServerFunction, positionDigest, serializeString, subscribeFlightData, withMeta } from "./shared.js";
export { REVALIDATE_HEADER } from "../response.js";
import { JSONCodecOptions } from "../serializer-decode.js";
export type { FlightDataConsumer, FlightDataContext, InvokeOptions, ServerFunction, ServerFunctionInvoker, ServerFunctionMetadata, SingleFlightPayload } from "./shared.js";
/** The context `prepareRequest` receives alongside the outgoing RequestInit. */
export interface PrepareRequestContext {
    /** The build-stable id of the function being called. */
    id: string;
    /**
     * The reference's declaration metadata (e.g. `method: "GET"` for
     * `GET(fn)` references). Plain references carry an empty object.
     */
    meta: ServerFunctionMetadata | undefined;
}
/**
 * Client-side session-dynamic transport hook: runs before every
 * server-function fetch. Return (or mutate and return) the RequestInit the
 * transport will use — the hook sees the final init, transport headers
 * included. The motivating case is dynamic credentials that rotate during
 * a session and apply uniformly to every call (OAuth bearer tokens); it is
 * the client-side symmetric of the server handler hooks. Single hook, not
 * a chain — compose by wrapping functions in userland.
 */
export type PrepareRequestHook = (init: RequestInit, context: PrepareRequestContext) => RequestInit | Promise<RequestInit>;
/** How the transport sends a request: `fetch`'s shape, as the runtime calls it. */
export type ServerFunctionsSend = (address: string, init: RequestInit) => Response | Promise<Response>;
/** Options for `configureServerFunctionsClient`. */
export interface ServerFunctionsClientConfig {
    /**
     * Mount path the server's HTTP handler answers on. Must match the server
     * configuration — the id travels as the segment after it, and SSR'd
     * reference `url`s (e.g. form actions) and client fetches both derive
     * from it. Prefix it when the app serves from a base path
     * (e.g. `` `${BASE_URL}_server` ``).
     *
     * An absolute URL (`"https://api.example.com/_server"`) targets a handler
     * on another origin — for a client-only build served from elsewhere: a
     * static site, a browser extension, a WebView (`capacitor://localhost`)
     * whose local server owns every path on its own hostname. The call is
     * then cross-origin, and the server admits it only when its
     * `configureServerFunctionsServer({ csrf: { origin } })` allowlist names
     * the page's origin; it answers with the CORS headers the browser needs
     * (`Access-Control-Allow-Origin`, the preflight, the protocol's headers
     * exposed). Authenticate such a client with a bearer token through
     * `prepareRequest` rather than cookies; cookies travel cross-site only
     * with a `credentials: "include"` init, `SameSite=None; Secure` on the
     * cookie, and `csrf.allowCredentials` on the server.
     * @default "/_server"
     */
    endpoint?: string;
    /**
     * Codec options (extra plugins etc.) for encoding arguments and decoding
     * results — must match the server's. Stored in the shared layer, so
     * `decodeResponse` sees them too. Arguments never carry `Response` or
     * `Request` values, whatever plugins are configured: the server refuses
     * them, and the rich-args encoder rejects the call before sending.
     */
    codec?: JSONCodecOptions;
    /**
     * Sends every server-function request — retries, telemetry, a test
     * double, or an app's own route. Called as `(address, init)`, the
     * address relative to the document as the global one receives it, so
     * `parseServerFunctionActionUrl` reads the id back out for telemetry (a
     * trailing third argument is the transport's own; ignore it). `null`
     * restores the global.
     *
     * ```ts
     * configureServerFunctionsClient({
     *   fetch: (address, init) => fetch(rewrite(address), init)
     * });
     * ```
     *
     * Forward `init` — the call's `signal` rides on it, and dropping it voids
     * both the caller's abort and the teardown a live source's `break`
     * performs. Keep the call on the configured `endpoint`'s origin: a send
     * to any other is stamped `Sec-Fetch-Site: cross-site`, and the handler
     * admits it only when its `csrf.origin` allowlist names the page's
     * origin (see `endpoint`). Hand back what the peer answered, unread.
     *
     * A retrying wrapper may re-send a request that got NO response; it must
     * never replay one whose response ended. A response that dies mid-body may
     * have executed (mutations are not idempotent), and reconnecting a live
     * source is the runtime's job — a replay would race it.
     *
     * The wrapper replaces delivery for the requests the runtime chooses to
     * send; the call-to-request mapping itself is not contractual.
     */
    fetch?: ServerFunctionsSend | null;
    /**
     * Runs before every server-function fetch. Return (or mutate and return)
     * the RequestInit the transport will use; `context.meta` is the
     * reference's declaration metadata (e.g. method). For session-dynamic
     * cross-cutting concerns — bearer tokens, tracing headers:
     *
     * ```ts
     * configureServerFunctionsClient({
     *   prepareRequest(init) {
     *     return {
     *       ...init,
     *       headers: { ...init.headers, Authorization: `Bearer ${session.token()}` }
     *     };
     *   }
     * });
     * ```
     *
     * Return synchronously when you can: hydration adopts a server-rendered
     * read only if its request is sent in the same tick, so an async hook
     * makes every hydrated read fetch again from the browser.
     */
    prepareRequest?: PrepareRequestHook;
    /**
     * Response-side integration seam — the client mirror of the handler's
     * `transformResult`. `handle(response, ctx)` sees every response before
     * the transport decodes it; returning anything but undefined resolves the
     * call with that value. `capture(info)` runs synchronously at the call
     * site (before any await) and its return arrives as `ctx.context`, so
     * ambient per-call state (e.g. a reactive owner) survives to response
     * time. See `createServerComponentHandler` in frame-transport for the
     * canonical implementation.
     */
    responseHandler?: {
        capture?(info: {
            id: string;
            meta: unknown;
        }): unknown;
        /**
         * `ctx.retry` makes the same call again — the reference, arguments,
         * declared shape and per-call options as dispatched (a `GET`-declared
         * read stays a GET; a caller-supplied `signal` still owns the wire) —
         * for a handler re-asking on its own account (a frames boundary's
         * `reset`, frames-rulings 3.3). Observe tier only: `ctx.startedAt` is
         * when the request was sent (`performance.now()`), so a handler can
         * stamp what it hands out with the request's start
         * (`OBSERVE.attribution.markFlight`).
         */
        handle(response: Response, ctx: {
            id: string;
            meta: unknown;
            args: unknown[];
            context: unknown;
            retry(): Promise<unknown>;
            startedAt?: number;
        }): unknown;
        /**
         * Answer a call before any request is made (t = 0 local answers — see
         * `createServerComponentHandler`). `info.retry` is the call as it would
         * go to the wire, for a handler that answers now and re-asks later.
         */
        intercept?(info: {
            id: string;
            meta: unknown;
            args: unknown[];
            retry(): Promise<unknown>;
        }): unknown;
        /**
         * What a `live` (re)connect of the call resumes from, when the handler
         * shows it: `position` becomes the request's `Last-Event-ID`, `headers`
         * ride beside it (a frames handler's have-list). Asked per connect;
         * `undefined` when the handler holds nothing for the call.
         */
        resume?(info: {
            id: string;
            meta: unknown;
            args: unknown[];
        }): {
            position?: string;
            headers?: Record<string, string>;
        } | undefined;
        /**
         * A `live()` call was made — fired at the call, before its first fetch,
         * so a handler that serves live calls through code it loads on demand
         * (the frames client's live wire tier) can start the load against the
         * request's own latency. Per call, not per connect.
         */
        onLive?(): void;
    };
    /**
     * Encoder for argument lists JSON can't carry faithfully. JSON-safe args
     * always go as plain JSON (no codec in the bundle); anything else throws
     * unless this is set. Installed by `enableRichArguments()` from the
     * rich-args entry — set directly only for custom wire encodings. A
     * `FormData` answer is sent as an upload: the codec output in its `args`
     * field and each file in a `file<index>` part.
     */
    serializeArgs?(args: unknown[]): string | FormData | Promise<string | FormData>;
}
/** Wire-state transitions a live call's iterable can report. */
export type LiveSourceStatus = "connected" | "reconnecting" | "closed";
/**
 * A live call's answer: the source's iterable, plus an optional `onstatus`
 * side channel for the wire facts the reconnect loop erases from the value
 * stream — `"connected"` on each successful (re)connect, `"reconnecting"`
 * (with the error) on each transient post-connect death, `"closed"` when
 * the source completes or the consumer ends it — with the error when the
 * end was a definite rejection (4xx) failing fast instead of retrying.
 */
export type LiveSource<R> = R & {
    onstatus?: (state: LiveSourceStatus, error?: unknown) => void;
};
/**
 * Identity of the currently executing server function call — see the
 * server entry. Named here so isomorphic code can import the type from
 * either entry.
 */
export interface ServerFunctionInvocation {
    id: string;
}
/**
 * The url a `GET()` reference's own call requests — the address to preload
 * (`<link rel="preload" as="fetch">`), prefetch, warm in a service worker, or
 * fetch by hand — built the way the transport builds it, so a fetch of it IS
 * the call and matches the reference's later call in every cache that keys
 * on the url. Arguments ride the query as they do on the wire (`?args=`,
 * JSON), and must be JSON-safe here: the codec's encoding is asynchronous,
 * and a url rendered as a value cannot wait for it. Resolved against the
 * configured endpoint. The answer at this url is the transport's (codec
 * shape) — read one by hand with `decodeResponse`.
 *
 * Defined for declared reads only. A reference on the default transport
 * POSTs, and a POST is not described by its url; this throws with a pointer
 * (declare `GET(fn)`, or start the call with `invoke(fn, { priority: "low"
 * }, ...args)`). Also throws when the url would be long enough for the call
 * to fall back to POST — a url you hold is always one the transport would
 * request.
 *
 * ```tsx
 * const getUser = GET(async (id: string) => { "use server"; ... });
 * <link rel="preload" as="fetch" crossorigin href={serverFunctionUrl(getUser, id)} />
 * ```
 *
 * A `live(fn)` reference's call connects at the live address, so that
 * is the url returned for one (`<endpoint>/live/<id>[?args=...]`): a
 * standing event stream of the answer — fetch it by hand (`curl -N`) to
 * watch it; do not preload or prefetch it, which would open a stream
 * nothing reads. Warm a live address by calling the reference (readers of
 * one call share one connection).
 *
 * The form-post address is a different url — `fn.url`, or
 * `serverFunctionActionUrl` for one with bound arguments. The server entry
 * exports the same function so isomorphic imports resolve.
 */
export declare function serverFunctionUrl<A extends readonly unknown[]>(fn: ServerFunction<A, any>, ...args: A): string;
export declare function serverFunctionActionUrl(fn: ServerFunction | string, ...boundArgs: readonly unknown[]): string;
export declare function parseServerFunctionActionUrl(url: string): string | null;
export declare function configureServerFunctionsClient(config?: ServerFunctionsClientConfig): void;
export declare function createServerReference(id: string, name?: string, base?: string): ServerFunction;
export declare function GET<A extends readonly any[], R>(fn: (...args: A) => R): ServerFunction<A, Awaited<R>>;
export interface LiveServerFunction<A extends readonly any[] = any[], R = any> {
    (...args: A): LiveSource<R>;
    /** The build-stable function id (stable across the client and server builds). */
    readonly id: string;
    /** URL invoking this function directly over HTTP. */
    readonly url: string;
}
/**
 * Declares a live server function whose answer is the same for every
 * viewer: on the client exactly `live(fn)` — the sharing is the server's.
 * @experimental
 */
export declare function broadcast<A extends readonly any[], R>(fn: (...args: A) => R): LiveServerFunction<A, Awaited<R>>;
/**
 * Declares a value-shaped live source: a server function returning an async
 * iterable whose yields are successive VALUES of one logical query, with the
 * contract that the source re-yields current state on every invocation.
 * Calls to the returned reference produce an iterable that survives the
 * connection — post-connect deaths re-invoke with exponential backoff
 * (reset per healthy value, woken early by connectivity returning),
 * first-connect failures reject like a normal call, and `break` aborts the
 * in-flight request. Live calls are reads and never opt into single-flight
 * enveloping. Wire state, if wanted, rides the returned iterable's
 * `onstatus` hook. Implies `GET` (a live source is a read); an explicit
 * `live(GET(fn))` is equivalent.
 */
export declare function live<A extends readonly any[], R>(fn: (...args: A) => R): LiveServerFunction<A, Awaited<R>>;
export declare function registerServerReference(): never;
export declare function getServerFunctionInvocation(): ServerFunctionInvocation | undefined;
