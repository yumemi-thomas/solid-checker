import { type Component, type DynamicOptions } from "solid-js";
import type { JSX } from "./jsx.js";
export * from "./server.js";
export * from "./response.js";
export type { CallEvent, CallListener, CallLive, CallRequestEvent, CallRequestListener, FrameAppliedEvent, FrameEvent, FrameListener, FrameLive, FrameProducedEvent, InvocationEvent, InvocationListener, InvocationLive, RenderEvent, RenderListener, RenderLive, RenderRoute } from "./observe.js";
export type { TraceContext, TraceProvider } from "./trace.js";
export type { JSX } from "./jsx.js";
export { For, Show, Loading, Reveal, Switch, Match, Repeat, Errored, NoHydration, Hydration } from "solid-js";
/**
 * Build-time constant indicating whether code is running on the server. This
 * is the server entry; the value is `true`. The client entry of `@solidjs/web`
 * sets it to `false`. See the client-entry JSDoc for the canonical guard
 * pattern.
 */
export declare const isServer: boolean;
/**
 * Build-time constant indicating whether code is running in a dev build.
 * Set by `_SOLID_DEV_` substitution per artifact, exactly like the client
 * entry: `dist/server.dev.*` (the `development` export condition) → `true`,
 * `dist/server.*` → `false`. The server runtime's own `_SOLID_DEV_` gates are
 * replaced by the same pass, so this flag and the bundle's internal behavior
 * cannot disagree.
 */
export declare const isDev: boolean;
export type IntrinsicElement = Extract<keyof JSX.IntrinsicElements, string>;
export type ValidComponent = IntrinsicElement | Component<any> | (string & {});
export type ComponentProps<T extends ValidComponent> = T extends Component<infer P> ? P : T extends keyof JSX.IntrinsicElements ? JSX.IntrinsicElements[T] : Record<string, unknown>;
export type { DynamicOptions } from "solid-js";
export { dynamicComponent } from "solid-js";
export declare function dynamic<T extends ValidComponent>(source: () => T | Promise<T> | null | undefined | false, options?: DynamicOptions): Component<ComponentProps<T>>;
/** @deprecated Props of the deprecated `<Dynamic>`; see `dynamic()`. */
export type DynamicProps<T extends ValidComponent, P = ComponentProps<T>> = {
    [K in keyof P]: P[K];
} & {
    component: T | null | undefined | false;
};
/**
 * @deprecated Use `dynamic()`. `<Dynamic>` is the same primitive, but its
 * shape puts the tag in the same bag as the element's props: every instance
 * merges `component` in at the call site, `omit()`s it back out here, and
 * builds a fresh `dynamic()` factory (with its memo) because there is nowhere
 * to hoist one. `dynamic()` has none of that and is one line longer:
 *
 * ```tsx
 * // before
 * <Dynamic component={multiline() ? RichTextEditor : "input"} value={value()} />
 *
 * // after — hoist per component instance (or per module for a constant)
 * const Field = dynamic(() => multiline() ? RichTextEditor : "input");
 * <Field value={value()} />
 * ```
 *
 * Remains available in 2.0 (deprecated, no runtime warning); prefer `dynamic()`
 * in new code.
 */
export declare function Dynamic<T extends ValidComponent>(props: DynamicProps<T>): JSX.Element;
/**
 * Portals are client-only islands: the server renders nothing for them —
 * `props.children` is never evaluated, no async is started, and nothing is
 * serialized. The client renders the content fresh once hydration settles.
 * Throwing here instead (as earlier betas did) is strictly worse: an ancestor
 * `Errored` catches it and bakes the error fallback into the streamed HTML
 * for a tree that renders fine client-side (#2876).
 *
 * The one thing both sides must still agree on is the parent's child-id
 * counter: the client Portal scopes its internals under one owner (one slot),
 * so consume the matching slot here or every hydration id after the portal
 * drifts.
 */
export declare function Portal(props: {
    mount?: Element;
    children: JSX.Element;
}): JSX.Element;
/**
 * Server half of `clientOnly`: the wrapped component never renders on the
 * server — the import is never even started — only `props.fallback` is
 * SSR'd. The client build swaps the real component in after load + mount.
 * See the client entry's JSDoc for the full contract.
 *
 * `moduleUrl` is injected by the bundler's module-URL pass (the same one
 * that annotates `lazy()`, padding the options slot when a call site omits
 * it); when present and an asset manifest is set, the render emits early
 * preload hints for the module — see `registerClientOnlyPreload` for why
 * they stay out of the hydration asset map. Without it (untransformed code)
 * or without a manifest, behavior is unchanged.
 */
export declare function clientOnly<M extends Record<string, any>, K extends keyof M & string>(fn: () => Promise<M>, options: {
    lazy?: boolean;
    export: K;
}, moduleUrl?: string): Component<ComponentProps<M[K]> & {
    fallback?: JSX.Element;
}>;
export declare function clientOnly<T extends Component<any>>(fn: () => Promise<{
    default: T;
}>, options?: {
    lazy?: boolean;
    export?: string;
}, moduleUrl?: string): Component<ComponentProps<T> & {
    fallback?: JSX.Element;
}>;
/**
 * Declares the HTTP response status (and optional status text) for the
 * lifetime of the current reactive scope during SSR, writing to the request
 * event's `response` head (core's `ResponseStub`, exposed by the
 * integration).
 *
 * Naming note — this is a scope-tied *declaration*, not a mutation: "while
 * this reactive scope is live, the response has this status." Solid reserves
 * `set*` verbs for event-time mutation; `httpStatus` is called bare in a
 * component or reactive-scope body (like `createSignal`/`onCleanup`) and
 * un-declares on scope disposal.
 *
 * Retraction semantics: disposal retracts only this scope's declaration —
 * the response falls back to the latest still-live declaration, or to the
 * base status the integration had set before the first declaration. A
 * boundary that errored, declared a status, and then recovered retracts its
 * write without stomping a status a surviving part of the tree legitimately
 * set (e.g. a 404 page whose inner boundary recovers stays a 404), and
 * sibling scopes may dispose in any order (#2984). Both the write and the
 * cleanup are no-ops once the response head is `committed` (head
 * derived/sent — status can no longer change). The head commits when it
 * freezes: at shell flush for a piped `renderToStream` (`createSSRResponse`
 * commits on the first write), and at completion for an awaited one or for
 * `renderToString` (the render commits right before its final dispose, so
 * the declarations still live at that point are the ones the consumer
 * derives the head from; `createSSRResponse` then passes the committed stub
 * through). On the client this is a no-op.
 */
export declare function httpStatus(code: number, text?: string): void;
/**
 * Declares an HTTP response header (or with `append`, appends to one) for
 * the lifetime of the current reactive scope during SSR, writing to the
 * request event's `response` head (core's `ResponseStub`, exposed by the
 * integration).
 *
 * Naming note — this is a scope-tied *declaration*, not a mutation: "while
 * this reactive scope is live, the response has this header." Solid reserves
 * `set*` verbs for event-time mutation; `httpHeader` is called bare in a
 * component or reactive-scope body (like `createSignal`/`onCleanup`) and
 * un-declares on scope disposal.
 *
 * Retraction semantics: disposal retracts only this scope's declaration —
 * the header is recomputed by replaying the still-live declarations, in
 * their original write order, over the base value the integration had set
 * before the first declaration (deleted when there is neither). Sibling
 * scopes may therefore dispose in any order without disturbing each
 * other's contributions (#2984). For `set-cookie` — the one header whose
 * multiple values must survive as separate entries — the base is captured
 * and replayed entry-exact (`getSetCookie()` + re-append; `get()`/`set()`
 * would comma-join the entries and then collapse them into one corrupt
 * header). Both the write and the cleanup are no-ops once the response head
 * is `committed` (head derived/sent — headers can no longer change); the
 * head commits when it freezes — shell flush for a piped `renderToStream`,
 * completion (right before the final dispose) for an awaited one and for
 * `renderToString` — see `httpStatus`. On the client this is a no-op.
 */
export declare function httpHeader(name: string, value: string, options?: {
    append?: boolean;
}): void;
