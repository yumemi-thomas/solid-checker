import type { FrameMessage } from "./frame-client.js";
/**
 * Addresses a frame stream: the boundary id and this response's version.
 * @experimental
 */
export interface FrameAddress {
    id: string;
    version: number;
}
/**
 * Options shared by the frame producers.
 * @experimental
 */
export interface FrameStreamOptions {
    /** Boundary address; defaults to `{ id: "", version: 1 }`. */
    frame?: {
        id?: string;
        version?: number;
    };
    /**
     * The request's abort: tears the render down as a client disconnect would
     * (see `renderToStream`'s `signal`). `serverComponentResponse` and
     * `frameFlightResponse` chain it with their own body's `cancel`.
     */
    signal?: AbortSignal;
    /**
     * The call arrived at the live address — a `live` loop is reading
     * (`getServerFunctionInvocation().live`). `serverComponentResponse` then
     * frames the chunks as server-sent events, as the codec stream is framed
     * there (`text/event-stream`, `no-store`, the idle heartbeat, the dev
     * chaos knob), so the loop reads the frame stream through the reader it
     * already has and a proxy holds the connection open as it would any
     * event stream. The chunk protocol is unchanged; only the framing is.
     */
    live?: boolean;
    /**
     * The plain response's streaming bound, in later yields (frames savings
     * pass §6 decision 4). A plain (non-`live`) server component whose
     * content reads a standing source — a generator, a projection — keeps
     * its response open and ships each later commit as holes; with no
     * declaration of liveness anywhere, that response ends here: after this
     * many emitting sweeps past the first flush the producer emits
     * `:complete` with `:bound: "yields"` and closes. `live()` is the
     * declared way past the bound; a `live` response is never bounded.
     * Default 64. `0` / `Infinity` disables the count bound.
     */
    maxYields?: number;
    /**
     * The plain response's streaming bound, in wall-clock milliseconds after
     * the first flush (the same decision): `:complete` with `:bound:
     * "time"`, then the body closes. The request's `signal` aborting after
     * the first flush ends a plain response the same way — a platform's
     * deadline is a time bound the client can tell from a death. Default
     * 30 000. `0` / `Infinity` disables the timer (the `signal` still ends
     * it).
     */
    maxDurationMs?: number;
    /**
     * A RESUME (RFC 11 §9.5): the have-list the reconnecting client sent —
     * the digests it holds for this address, keyed as the chunks carry them
     * (`""` the root skeleton, `lh:N` / `lha:N` holes, `pl-N` revealed
     * fragments; see `FRAME_HAVE_HEADER`). With it the render is
     * conditional: the root html is skipped when its skeleton digest matches,
     * and a hole or fragment is emitted only once it has settled and its
     * digest differs — so a no-op reconnect transfers nothing and a fallback
     * is never emitted over content. Absent, the render is the progressive
     * stream it always was. `frameTransformResult` reads it off the request.
     */
    resume?: {
        have: Record<string, string>;
    };
    /** Remaining `renderToStream` options (plugins, onError, manifest, ...). */
    [key: string]: unknown;
}
/**
 * A produced frame stream: pipe its wire messages, or await the collected
 * array.
 * @experimental
 */
export interface FrameStream extends PromiseLike<FrameMessage[]> {
    pipe(writable: {
        write(message: FrameMessage): void;
        end?(): void;
    }): void;
}
export { SERVER_COMPONENT, SERVER_COMPONENT_SOURCE, SERVER_COMPONENT_ADDRESS, ServerComponentPlugin } from "./frame-transport.js";
/**
 * Statement form of the registry bootstrap, for a document shell that wants
 * to install `_$SC` ahead of every data script (e.g. a plugin injecting it
 * into `<head>`). No longer required — serialized references self-bootstrap
 * — but kept for integrations still emitting it; the idempotent form makes
 * the double-definition harmless. Never splice it before the authored
 * `<head>` elements: a head-open script claims as the first walked child at
 * hydration and drifts every positional claim after it.
 */
export declare const SERVER_COMPONENT_BOOTSTRAP: string; /**
 * The emission surface `renderToStream` routes through when producing a
 * frame stream instead of a document (see the `sink` render option). Each
 * method writes records; `write` is the envelope boundary.
 * @internal Compiler/renderer wiring — use `renderToFrameStream` or
 * `renderServerComponent` instead.
 * @experimental
 */
export declare function createFrameSink(write: (message: FrameMessage) => void, frame: FrameAddress, have?: Record<string, string>, hooks?: {
    live?: boolean;
    onYield?: () => void;
}): Record<string, (...args: any[]) => void>;
/**
 * The root's SKELETON: its html with every live-hole range and slot range
 * emptied (markers kept). What remains is the structure hole emissions
 * address into — static markup, marker ids and their nesting, placeholder
 * ids and fallbacks. Equal skeletons mean equal hole/fragment keys, which
 * is what makes emitting into the client's existing DOM sound; a differing
 * one re-ships the root whole (structure changed — a hole count that moved
 * with data, a static branch that flipped).
 */
export declare function frameSkeleton(html: any): any;
export declare function renderToFrameStream(code: () => unknown, options?: FrameStreamOptions): FrameStream;
export declare function renderServerComponent(component: (props: Record<string, any>) => unknown, options?: FrameStreamOptions): FrameStream;
/**
 * Document-mode slot props — the t = 0 counterpart of
 * `createSlotProps`: the server component renders INLINE in the
 * document and the client's real props render server-side inside its
 * positions (the one hydration-time exception), wrapped in the same marker
 * dialect the chunk producer emits so the adopting client binds slots and
 * regions onto the server-rendered ranges.
 * @experimental
 */
export declare function createDocumentSlotProps(clientProps: Record<string, unknown>, frameId: string): Record<string, unknown>;
export declare function frameTransformDirectResult<T>(value: T, options: {
    id: string;
    args?: unknown[];
    /**
     * The client chunk URL of each frames-client tier, by tier name (the
     * integration's, from its manifest — the server does not know the
     * client's chunks). Given, the document emits a `modulepreload` for a
     * tier when a server component first mints its feature, beside the
     * `sc:tiers` record it writes either way; absent, the record alone
     * announces the name and the client's `installServerComponents` starts
     * the import from it. Document-wide: the first call's map is the
     * render's.
     */
    tierUrls?: Record<string, string>;
}): T;
export declare function createSlotProps(sink: ReturnType<typeof createFrameSink>, frame: FrameAddress): Record<string, any>;
export declare function serverComponentResponse(component: (props: Record<string, any>) => unknown, options?: FrameStreamOptions, init?: {
    headers?: HeadersInit;
    status?: number;
}): Response;
export declare function frameTransformResult(event: unknown, result: unknown): unknown;
export declare function frameTransformFlightResult(event: unknown, outcome: {
    value: unknown;
    data: unknown;
}, context?: unknown): Promise<Response | undefined>;
/**
 * A framed response carrying several frames and a single-flight outcome:
 * each frame's chunks in order (the host routes and buffers by id), then the
 * `{ value, data }` envelope as `outcome` chunks.
 *
 * Those chunks carry the codec's own nodes, one per chunk, so async values
 * inside flight data settle progressively exactly as they do in a plain
 * single-flight body — the consumer replays them into the same decoder.
 *
 * `signal` is the request's abort (`frameTransformFlightResult` passes it):
 * with the body's own `cancel`, either tears the frame in progress down and
 * ends the response.
 */
export declare function frameFlightResponse({ primary, regions, outcome, codec, signal }: {
    primary: any;
    regions?: any[];
    outcome: any;
    codec: any;
    signal: any;
}, init?: {}): Response;
