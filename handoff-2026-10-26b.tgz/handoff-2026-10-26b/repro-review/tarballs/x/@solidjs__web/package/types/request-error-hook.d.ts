import type { ServerErrorHook } from "solid-js";
/** Files a render's `onError` as the hook of the request it serves. */
export declare function setRequestErrorHook(event: object, hook: ServerErrorHook | undefined): void;
/** The hook of the render serving `event`'s request, if one was given. */
export declare function requestErrorHook(event: object | undefined): ServerErrorHook | undefined;
