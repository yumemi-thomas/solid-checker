import { FrameHost } from "./frame-client.js";
import { JSONCodecOptions } from "./serializer-decode.js";
/**
 * Options for `applyFrameResponse`.
 * @experimental
 */
export interface ApplyFrameResponseOptions {
    /**
     * Remap the producer's root frame id onto a local one — the id your
     * insertable/frame registered under — so navigations to the same boundary
     * reuse the same frame regardless of what the server called it. Boundary
     * identity belongs to the client.
     */
    as?: string;
    /**
     * Restamp every chunk of the response with this version (one response IS
     * one version). Versions belong to the client too: the producer cannot
     * know how many streams a boundary has consumed, so pass the Nth-response
     * counter to make policy A's stale-guard real across navigations. A
     * single-flight response addresses several boundaries, each with its own
     * history — pass a function and it is called once per frame in the
     * response.
     */
    version?: number | ((frameId: string) => number);
    /**
     * Receives the payload text of each `outcome` chunk — the response-scoped
     * single-flight envelope, the caller's result rather than anything the
     * host renders.
     */
    onOutcome?(payload: string): void;
}
/**
 * The value under `COMPONENT_BINDING` on a transport-resolved binding.
 * @experimental
 */
export interface ComponentBinding<C = unknown> {
    /** The per-function mount component (the equals-gate identity). */
    component: C;
    /** The call's intrinsic (function, arguments) address — its store's key. */
    address: string;
}
/**
 * Options for `createServerComponentHandler`.
 * @experimental
 */
export interface ServerComponentHandlerOptions<C = unknown> {
    host: FrameHost;
    /**
     * Builds the framework's mount component for a server FUNCTION. Invoked
     * once per function and cached — this is the equals-gate identity every
     * call of the function resolves through. The component is CALLED (by the
     * binding wrapper or a gated reader), receiving its current address as a
     * second argument (`() => string`); it should (re-)bind its frame's pull
     * to that address's store. Multi-mount fans out per site.
     */
    component(fnId: string): C;
    /**
     * Answer a call before any request is made (t = 0 local answers — a
     * boundary the document already carries). Returning `undefined` is a
     * miss; any other value is a hit, SYNCHRONOUS, resolving the call with
     * its binding — a hydrating consumer never observes a pending beat. A
     * PROMISE is a deferred hit (a boundary the document is still
     * delivering): the call resolves with its binding when it settles truthy,
     * and is a miss after all — the caller fetches — when it settles falsy.
     */
    intercept?(info: {
        id: string;
        meta: unknown;
        args: unknown[];
    }): unknown | PromiseLike<unknown>;
}
/**
 * Header tagging a Response as a frame stream; its value is the producing
 * frame's id. Frame-owned contract (hence the namespace) — deliberately not
 * a `BodyFormat` entry, since the body is frame chunks, not a serialized
 * value.
 */
export declare const FRAME_STREAM_HEADER = "X-Frame-Stream";
/**
 * The tiers a frame stream needs (frames savings pass §2, the
 * server-announced tier mechanism): the names, comma-separated, of the
 * frames-client tiers the render had minted when the response head left
 * — `bind,regions,assets,trace,wire` — so the client starts their loads
 * before it reads the body. Omitted when nothing was minted. A tier first
 * needed after the head rides in-band instead: `tiers` on the next chunk
 * (`FrameMessage.tiers`). Additive wire: an old client ignores both; a new
 * client without them falls back to detection at the readiness check and
 * holds (frames-rulings 3.1) — the same DOM, later.
 * @experimental
 */
export declare const FRAME_TIERS_HEADER = "X-Frame-Tiers";
/**
 * The resume request's have-list (RFC 11 §9.5, Resume request): the
 * digests the client holds for the address it is reconnecting — the root
 * skeleton under `""`, then one entry per live hole (`lh:N`), attr hole
 * (`lha:N`) and revealed fragment (`pl-N`). Its PRESENCE makes the render a
 * conditional one: the server emits a hole or fragment only when it has
 * settled and its digest differs, and never a root or a fallback over
 * content the list names. Rides only to the live address (a `no-store`
 * response nothing keys on) — never as an argument. Decision (f): this
 * name; a list whose encoding would exceed `FRAME_HAVE_BUDGET` bytes is
 * omitted and the client accepts a full snapshot.
 * @experimental
 */
export declare const FRAME_HAVE_HEADER = "X-Frame-Have";
/** The have-list's size ceiling in encoded bytes (see FRAME_HAVE_HEADER). */
export declare const FRAME_HAVE_BUDGET = 4096;
/**
 * Decodes a have-list header value; `undefined` for an absent/empty one.
 * Tolerant of malformed entries (skipped) — a wrong entry costs one
 * unneeded emission, never a wrong skip.
 * @internal
 */
export declare function decodeHaveList(text: string | null | undefined): Record<string, string> | undefined;
export declare function isFrameStreamResponse(response: Response): boolean;
export declare const applyFrameResponse: (response: Response, host: FrameHost, options?: ApplyFrameResponseOptions) => Promise<string>;
/**
 * Reads a frame-stream Response to completion, applying every chunk to
 * `host`. The client owns boundary identity: pass `options.as` to remap the
 * producer's root frame id onto a local one (the id your insertable/frame
 * registered under), so navigations to the same boundary reuse the same
 * frame regardless of what the server called it. Resolves with the id the
 * chunks were applied under once the stream ends.
 *
 * The client owns versions too: the producer can't know how many streams a
 * boundary has consumed, so `options.version` restamps the response's
 * chunks, making policy A's stale-guard real across navigations. A number
 * versions the whole response — one response IS one version — which holds
 * while a response addresses one boundary. A single-flight response
 * addresses several (each invalidated region is its own boundary, with its
 * own history), so `version` may instead be a function called once per
 * frame in the response.
 *
 * `options.onOutcome` receives the payload text of each `outcome` chunk —
 * the response-scoped single-flight envelope, which is the caller's result
 * rather than anything the host renders.
 */
/**
 * Whether a message ends its frame's response: a batch writing `:complete`
 * (the server declared the frame done) or `:error` (the failing kind of it).
 * @internal (the live wire tier's too)
 */
export declare const ends: (msg: any) => boolean;
/** Brands an inline-rendered server component with its function id. */
export declare const SERVER_COMPONENT: unique symbol;
/** The unwrapped server component behind an inline-render wrap. */
export declare const SERVER_COMPONENT_SOURCE: unique symbol;
/** The call's wire address (`frameAddress`), for regions to be emitted under. */
export declare const SERVER_COMPONENT_ADDRESS: unique symbol;
/**
 * The binding brand on values the transport resolves: `{ component, address }`
 * (see `createServerComponentHandler`). The identity split (DR-1,
 * docs/server-components-principles.md): `component` is the MOUNT identity —
 * one per server function, stable across every call — while `address` names
 * the call's content store. An equals-gated reader (a framework's `dynamic`)
 * compares `component` across resolutions: same function means "same
 * instance, new binding" — it keeps its mounted instance and delivers the
 * new address into it (the instance's frame re-binds its pull to that
 * address's resident store) — and a different function swaps normally.
 * `Symbol.for`, so consumers honor it without importing this module.
 */
export declare const COMPONENT_BINDING: unique symbol;
/**
 * The address a content token belongs to; a plain address passes through.
 * @internal
 */
export declare function contentAddress(token: string): string;
/**
 * The live handler's staged content (see `createServerComponentHandler`),
 * by token; a plain address, or a token already committed or superseded,
 * is a no-op. Mounts call both halves from the render effect that follows
 * their address accessor: `preview` from its compute half — under the
 * transaction that delivered the token, so the slot args it pushes into the
 * live fills (see `FrameHost.preview`) are staged with it and a fill's
 * derivation over an arg re-derives in that pass, never one flush behind
 * the intent it held (principles §9.2.2) — and `commit` from its effect
 * half, landing the buffered response as the store's writes in the commit.
 * Installed by the handler (one active handler at a time, as for
 * `resolveServerComponent` below).
 * @internal
 */
export declare const stagedContent: {
    preview(token: string): void;
    commit(token: string): void;
};
/**
 * The call recorded for an address — `{ id, meta, args, retry }`, `retry`
 * the thunk that makes the same call again — or `undefined` for an address
 * no response or document answer named.
 * @internal
 */
export declare function callFor(address: string): {
    id: string;
    meta: unknown;
    args: unknown[];
    retry(): Promise<unknown>;
} | undefined;
export declare function setServerComponentBootstrap(resolve: (ctx: unknown) => string): void;
/**
 * Seroval plugin for a server component crossing a serialization boundary.
 * A branded component (see `frameTransformDirectResult`) serializes as a
 * REFERENCE — its markup never rides as data.
 *
 * Two distinct consumers share the one tag:
 *
 * - `serialize` (eval-style, the document hydration serializer): emits
 *   `self._$SC.r("<function id>", "<address>")`. The document shell's inline
 *   bootstrap memoizes a stable placeholder per FUNCTION — a delegating
 *   shell whose every mount binds to its own SSR'd element during adoption
 *   — and resolves the addressed reference to the call's BINDING over it
 *   (`COMPONENT_BINDING`, the same shape `bindingFor` below mints), so a
 *   reader that adopted the reference during hydration (an async
 *   `dynamic()` instance's record) holds the same identity a later answer
 *   for the call resolves to.
 * - `deserialize` (the JSON codec): the codec only ever carries a component
 *   inside a single-flight envelope, so this is a FLIGHT reference. It must
 *   resolve to the exact object the reading call site already holds — an
 *   integration seeding its cache with anything else fails the consumer's
 *   equals-gate and remounts the boundary — so it resolves through the live
 *   transport registry by the call's address.
 */
declare function parseServerComponent(value: any, ctx: any): {
    id: any;
    address: any;
};
/** @type {import("seroval").Plugin<Function, { id: any, address: any }>} */
export declare const ServerComponentPlugin: {
    tag: string;
    test(value: any): boolean;
    parse: {
        sync: typeof parseServerComponent;
        async(value: any, ctx: any): Promise<{
            id: any;
            address: any;
        }>;
        stream: typeof parseServerComponent;
    };
    serialize(node: any, ctx: any): string;
    deserialize(node: any, ctx: any): any;
}; /**
 * The codec options for a single-flight envelope: `codec` plus
 * `ServerComponentPlugin` (deduped by tag). Injected by the protocol on both
 * legs; exported for integrations composing their own flight carriers.
 * @experimental
 */
export declare function flightCodec(codec?: JSONCodecOptions): JSONCodecOptions;
export declare function createServerComponentHandler<C>(options: ServerComponentHandlerOptions<C>): {
    /**
     * `retry` (the server-function client's thunk for the call it is
     * answering or dispatched, declared shape included) is recorded behind
     * the call's address for the re-ask (`callFor`, frames-rulings 3.3).
     */
    intercept?(info: {
        id: string;
        meta: unknown;
        args: unknown[];
        retry?(): Promise<unknown>;
    }): unknown;
    handle(response: Response, ctx: {
        id: string;
        meta: unknown;
        args: unknown[];
        context: unknown;
        retry?(): Promise<unknown>;
        /** Observe tier: when the request went out (`performance.now()`). */
        startedAt?: number;
    }): unknown;
    /**
     * A `live()` call was made (before its first fetch): starts the live wire
     * tier's load (`prepareTier("wire")`), so the import races only the
     * request — preload-at-call.
     */
    onLive(): void;
    /**
     * What a `live` (re)connect of the call resumes from (RFC 11 §9.5,
     * Resume request): the address's version ordinal as the position
     * (`Last-Event-ID`) and, when a mount shows the address with a ledger,
     * its have-list under `FRAME_HAVE_HEADER` — omitted over budget, so the
     * render is a full snapshot then. `undefined` when nothing here has
     * shown the call — or while the live wire tier, which keeps the ledger
     * and answers this, is not resident yet (a first connect over content a
     * plain call applied: a full snapshot, the degraded case accepted).
     */
    resume(info: {
        id: string;
        meta: unknown;
        args: unknown[];
    }): {
        position: string;
        headers?: Record<string, string>;
    } | undefined;
    /**
     * Declares that the document is showing a call: hydration-data references
     * carry their call's address (`_$SC.r(id, address)`) but never travel
     * through the transport, so the integration forwards those records here.
     * Mints the call's binding, so a post-load refetch resolves a value
     * whose component matches what the document mounted.
     */
    showing(address: string, functionId: string): void;
};
export {};
