import { type BoundaryEvent } from "solid-js";
import type { InvocationEvent, RenderEvent } from "./observe.js";
/**
 * The trace the current request belongs to — continued from the incoming
 * W3C `traceparent` when there was one, originated by the runtime
 * otherwise. Read with `getTraceContext()`.
 */
export interface TraceContext {
    /** 32 lowercase hex — the whole trace. */
    traceId: string;
    /** 16 lowercase hex — this request's span: runtime-generated unless a provider supplied it. */
    spanId: string;
    /** The incoming parent span, when the request continued a trace. */
    parentId?: string;
    /** The incoming `traceparent` sampled flag (bit 0); `undefined` when the runtime originated. */
    sampled?: boolean;
    /** The incoming `tracestate` header, verbatim. */
    state?: string;
    /** The incoming `baggage` header, verbatim. */
    baggage?: string;
    /**
     * Named entries handed to the browser on the first response — emitted
     * both as `Server-Timing` entries (`<name>;desc="<value>"`) and, for HTML
     * documents, as `<meta name="<name>" content="<value>">` in the shell.
     * The runtime fills `traceparent`; a provider adds its vendor pair
     * (`sentry-trace`, `baggage`). Also what application code forwards
     * downstream: `fetch(url, { headers: { traceparent: entries.traceparent } })`.
     */
    entries: Record<string, string>;
}
/**
 * An observer's answer for the trace a request belongs to, merged over the
 * runtime's default derivation: fields it returns replace the derived
 * ones (`traceId`/`spanId` from an APM's active span), its `entries` merge
 * by name over the runtime's. Called once per request (or per render, for
 * a render outside a request scope — `request` is then `undefined`), at
 * shell flush or the first `getTraceContext()`, whichever comes first.
 * Return `undefined` to leave the derivation alone.
 */
export type TraceProvider = (request: Request | undefined) => Partial<TraceContext> | undefined;
declare module "solid-js" {
    interface ServerTrace {
        /** Installs `provider`, replacing any current one. Returns the uninstall. */
        provide(provider: TraceProvider): () => void;
    }
}
/**
 * The request's server work as recorded — the `"invocation"` and
 * `"boundary"` records made while it was served, in completion order —
 * from which the `Server-Timing` metrics are projected at head commit
 * (`appendTraceServerTiming`): `solid-invocation;dur=<durationMs>;desc="<id>"`
 * for an execution, `solid-boundary;dur=<durationMs>;desc="<owner path>"` for
 * a `<Loading>` boundary the shell waited on (the `"render"` record on the
 * same `TraceRecord` gives `solid-shell;dur=<shellMs>`). One gate for record
 * and metric alike: a record is built in dev builds always, and in observe
 * builds while a listener is on its type (`OBSERVE.records.observed`), so
 * the header is a projection of what was recorded, never a second clock —
 * an app with no observer sees no wire change (the trace's rule). What
 * rides is what the server knew when the head left — the function that
 * produced a response; for a document, the shell and the boundaries that
 * settled inside it. The Performance-panel adapter paints these under the
 * matching client span (`@solidjs/web/performance-tracks`).
 */
export type TimedWork = {
    type: "invocation";
    event: InvocationEvent;
} | {
    type: "boundary";
    event: BoundaryEvent;
};
/** A derived trace plus whether the browser is told about it (see the header note). */
export interface TraceRecord {
    context: TraceContext;
    emit: boolean;
    /** The request's recorded server work, in completion order (see `TimedWork`). */
    timing: TimedWork[];
    /**
     * The render this request is serving, while one is being recorded — the
     * `"render"` record as it fills (`RenderEvent`): `solid-shell` is its
     * `shellMs`, once the shell is complete.
     */
    render?: RenderEvent;
}
/** `00-<traceId>-<spanId>-<flags>` for a context. */
export declare function formatTraceparent(context: TraceContext): string;
/**
 * The trace record for `key`, derived once: incoming `traceparent` /
 * `tracestate` / `baggage` from `request`, origination when absent, then
 * (observe/dev) the installed provider's answer merged over it.
 */
export declare function traceFor(key: object, request: Request | undefined): TraceRecord;
/**
 * The trace record for a request event — keyed on its `request` (shared by
 * the derived events direct server-function calls run under, so a call
 * during a render sees the render's trace) or on the event itself.
 */
export declare function traceForEvent(event: {
    request?: Request;
}): TraceRecord;
/** Whether `appendTraceServerTiming` has anything to write for `record`. */
export declare function hasServerTiming(record: TraceRecord): boolean;
/**
 * Appends the record to `headers` as `Server-Timing` metrics — its trace
 * entries as `<name>;desc="<value>"` when the browser is told (see
 * `TraceRecord`), never duplicating a name the app already wrote; and the
 * server work it recorded as `<name>;dur=<ms>;desc="<desc>"`, each metric a
 * projection of one record (see `TimedWork`): `solid-shell` first, from the
 * render record, then the invocations and boundaries in completion order.
 * Metrics repeat their names by design (one `solid-boundary` per boundary),
 * so they are not name-deduplicated. Must run before the response head
 * commits.
 */
export declare function appendTraceServerTiming(headers: Headers, record: TraceRecord): void;
/**
 * Folds a `Server-Timing` header value onto `target` entry by entry,
 * skipping names `target` already carries — the header is a list, so a
 * stub's trace entries and a response's own metrics (`db;dur=53`) coexist
 * instead of one replacing the other. Names repeated within `value` itself
 * (one `solid-boundary` per boundary) all fold: the skip is against what
 * the target had, not what this fold added.
 */
export declare function mergeServerTiming(target: Headers, value: string): void;
/**
 * The record's entries as `<meta name content>` tags for the HTML shell's
 * prelude (after charset/base). Empty when the browser is not told.
 */
export declare function traceMetaMarkup(record: TraceRecord): string;
