import { type DiagnosticEvent } from "solid-js";
export type Finding = Omit<DiagnosticEvent, "sequence">;
/**
 * Records a finding — observe and dev tiers — and, in dev, reports it on the
 * console. `subject` locates it (the current server owner by default; its
 * component labels give the `ownerPath`); pass `null` for a finding with no
 * location by nature (a stream event). No-op in prod.
 */
export declare function emitFinding(finding: Finding, subject?: unknown): void;
/**
 * The structured record alone, for a site that THROWS its message: the
 * thrown error is the console face and the core lands the once-per-code
 * footer beneath it. Reporting as well would print the finding twice.
 */
export declare function recordFinding(finding: Finding, subject?: unknown): void;
/**
 * A dev CHECK: `emitFinding` behind the dev gate, so the site reads as one
 * call and the observe and prod artifacts carry none of it. Extra console
 * arguments (the offending descriptor, the caught error) go on `data` — the
 * structured record keeps them, the console face prints the message.
 */
export declare function devCheck(finding: Finding, subject?: unknown): void;
/**
 * Dev CHECK, one code on both platforms: a hole the compiler left unscoped
 * (a bare identifier — `{renderHead}` — is the one shape that can be a
 * function at runtime without the compiler seeing an expression to scope)
 * evaluated to a function that built hydratable content, and that content
 * took its ids from the ENCLOSING owner's counter. A scoped hole reserves
 * its slot at registration and nests its content under it, so it moves the
 * counter by exactly one, at the same point on both sides; an unscoped one
 * moves it by however much it built, when it ran — statement order on the
 * client, walk order on the server — and every id after it permutes. The
 * shape is unreachable from type-checked code (`JSX.Element` excludes
 * functions) and is not scoped in production; this check is its cost.
 *
 * Unscoped allocation alone is not the finding — a function hole that runs
 * at the same counter position on both sides (nothing scoped after it in
 * its template; a boundary's zero-arity fallback thunk at the end of an
 * element) hydrates fine. Each side reports the permutation it can see:
 * the server knows the position the hole was REGISTERED at (`registered`,
 * where the client builds it in statement order) and the one it EVALUATED
 * it at (`before`, walk order, after the scoped holes that follow it
 * reserved theirs) and reports when they differ; the client, which always
 * builds in place, reports when the content it built inside the hole
 * missed its server-rendered keys. `before`/`after` are the counter's next
 * id around the evaluation; `site` names the hole (`data.name` the
 * function, `data.hole` the position). Callers dedupe per site so a row
 * template reports once.
 */
export declare function unscopedHoleAllocatedIds(before: string, after: string, site: {
    name?: string;
    hole?: number;
    registered?: string;
}, subject?: unknown): void;
/**
 * Dev CHECK: a function reached an attribute whose name starts with `on` but
 * is not an event handler — a lowercase `onclick`, or a 1.x `on:click`. Only
 * `on` + an uppercase letter (`onClick`) binds an event in 2.0; anything else
 * is a plain attribute, so the function is stringified into the attribute's
 * text. Reported once per attribute name so a row template reports once.
 */
export declare function lowercaseEventAttribute(name: string, node: Element): void;
/**
 * Dev CHECK, before every compiled or spread write of a stateful DOM
 * property (`input.value`, `input.checked`, `option.selected`,
 * `video.muted`, ...): Solid is about to write the same value it wrote last
 * time, but the element no longer holds what that write left there. Nothing
 * Solid wrote changed it, so the user did — typed, clicked, toggled — and
 * that edit never reached the bound signal; the write is about to erase it.
 * The write re-applies an unchanged value because the binding re-ran
 * without its value changing: another binding in the same template effect
 * changed, a spread re-ran, or the source fired with an equal value
 * (`equals: false`). Warns once per element and property; the write itself
 * goes ahead unchanged. Pair with `recordStatefulWrite` after the write.
 */
export declare function checkStatefulWrite(node: Element, prop: string, value: unknown): void;
/** Dev: remembers what a stateful write left on the element (see `checkStatefulWrite`). */
export declare function recordStatefulWrite(node: Element, prop: string, value: unknown): void;
/** `Name: message` for an Error, `String(value)` otherwise. */
export declare function errorText(error: unknown): string;
