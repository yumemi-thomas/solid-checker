export { ChunkReader, ERROR_HEADER, FLASH_COOKIE, REDIRECT_HEADER, SERVER_FUNCTION_INVOKE, SINGLE_FLIGHT_HEADER, UNKNOWN_HEADER, clearFlashCookie, createChunk, createEventChunk, decodeErrorHeaderValue, decodeRedirectHeaderValue, decodeResponse, decodeResponsePayload, encodeErrorHeaderValue, frameAddress, getServerFunctionMetadata, hasFlashCookie, invoke, isServerFunction, serializeStream, subscribeFlightData, textDigest, withMeta } from "./shared.js";
export { decodeFlashCookie, encodeFlashCookie } from "./flash.js";
import { ResponseEnvelope } from "../response.js";
import { JSONCodecOptions } from "../serializer-decode.js";
import { RequestEvent, ServerErrorHook } from "../server.js";
import type { ServerFunction } from "./shared.js";
export type { FlightDataConsumer, FlightDataContext, InvokeOptions, ServerFunction, ServerFunctionInvoker, ServerFunctionMetadata, SingleFlightPayload } from "./shared.js";
export type { FlashSubmission } from "./flash.js";
/**
 * The request event a server function call runs under: the base
 * `RequestEvent` (request + locals) with `serverOnly` added, set when the
 * call is an in-process SSR invocation whose result never serializes to a
 * client.
 */
export interface ServerFunctionEvent extends RequestEvent {
    serverOnly?: boolean;
}
/**
 * What a server function call resolved to, as seen by the single-flight
 * hook — enough context for any data-production strategy without core
 * assuming one.
 */
export interface ServerFunctionOutcome {
    /** The build-stable id of the function that ran. */
    id: string;
    /**
     * The value the caller will receive: the raw return for plain results,
     * the unwrapped `value` for `ResponseEnvelope`s, `null` for body-less
     * control-flow `Response`s (redirect/reload).
     */
    value: unknown;
    /**
     * The `Response` carrying the result's HTTP metadata, when there is one
     * (from a returned/thrown `Response` or a `ResponseEnvelope`). Read
     * `Location` here for redirect-with-data — the data should describe the
     * destination route — and `X-Revalidate` for the invalidated keys.
     * Undefined for plain values.
     */
    response: Response | undefined;
    /**
     * The original HTTP request, untouched: headers the client integration
     * sent (referrer, custom route context) ride here for the hook to read —
     * core assigns them no meaning.
     */
    request: Request;
    /** Whether the result was thrown rather than returned. */
    thrown: boolean;
    /**
     * The URL the client will show after the mutation — the redirect
     * `Location` when the outcome carries one (resolved against the request
     * URL, as a browser would), the referring page otherwise. Undefined
     * without a usable referer (a non-browser caller has no page to produce
     * data for) and for redirects leaving the app's origin: produce no data
     * when this is undefined.
     */
    targetUrl: string | undefined;
    /**
     * The outcome's `X-Revalidate` keys, split — the invalidation scope the
     * mutation declared. Undefined when the outcome carries none (integrations
     * typically collect everything for the target in that case); `[""]` for
     * an empty declaration (nothing); `["*"]` for `REVALIDATE_ALL`, delivered
     * as declared so a collector can tell "everything" from named keys.
     */
    revalidateKeys: string[] | undefined;
    /**
     * The request headers with the mutation's cookie effects applied: the
     * event response's `Set-Cookie`s (set during the call), then the
     * outcome's own (e.g. `redirect(to, { headers })`), later winning on
     * conflict, deletions honored. Build the data-collection request from
     * these so re-run reads observe post-mutation cookie state.
     */
    foldedHeaders: Headers;
}
/**
 * The single-flight server hook: given the request event and the function's
 * outcome, optionally produce a data payload (possibly async) to fold into
 * the response alongside the return value. Data production is a black box
 * to the protocol — render data-only, run route preloads, query a cache,
 * whatever the integration chooses; the payload just has to be
 * codec-serializable. Return undefined to send the response unchanged
 * (byte-identical to a call without the hook).
 *
 * Runs after `transformResult`, only for scripted calls that sent
 * `SINGLE_FLIGHT_HEADER` on the request, on returned results and thrown
 * `Response`/`ResponseEnvelope` control-flow signals alike (plain thrown
 * errors never collect, and neither do raw body-carrying `Response` values
 * — those are the caller's verbatim payload). The handler owns the
 * enveloping: contributed data ships as `{ value, data }` under the
 * single-flight response header. The generic halves of collection arrive
 * pre-digested on the outcome (`targetUrl`, `revalidateKeys`,
 * `foldedHeaders`); the hook supplies only the data strategy.
 */
export type CollectFlightDataHook = (event: ServerFunctionEvent, outcome: ServerFunctionOutcome) => unknown | Promise<unknown>;
/**
 * Wraps a server function execution — the per-invocation seam for
 * framework policies (per-function middleware, auth, logging, error
 * mapping). Called inside the call's event scope with the invocation
 * identity already established: `getServerFunctionInvocation()` answers
 * before, during and after `run()`. Must return (or resolve to) `run()`'s
 * result — replacing it replaces the function's result; throwing routes
 * through the handler's normal error encoding.
 *
 * The context carries the call's identity (`id`, parsed `args`), its
 * `event`, and how it arrived: `direct` is `true` for in-process SSR calls
 * (where `request` is absent) and `false` for HTTP dispatch. On the direct
 * path the wrapper must stay transparent for synchronous functions —
 * return `run()`'s value, not an unconditional promise, unless it needs to
 * be async.
 */
export type WrapInvocationHook = (run: () => unknown, context: {
    id: string;
    args: unknown[];
    event: ServerFunctionEvent;
    request?: Request;
    direct: boolean;
}) => unknown;
/** Options for `createNoJSHandler`. */
export interface NoJSHandlerOptions {
    /** The app's mount path, for resolving a relative redirect `Location`. */
    base?: string;
}
export type ServerFunctionOriginMatcher = string | readonly string[] | ((origin: string, request: Request) => boolean | Promise<boolean>);
/** Same-origin validation options for server function requests. */
export interface ServerFunctionCSRFOptions {
    /**
     * The origins allowed to call server functions: a single origin, a list,
     * or a matcher `(origin, request) => boolean` (async allowed; anything
     * but a literal `true` refuses, #3169) for multi-tenant hosts. Defaults
     * to the incoming request URL's origin, which admits same-origin callers
     * only.
     *
     * Listing an origin OTHER than the deployment's own is the opt-in for a
     * cross-origin client — a static build in a WebView
     * (`capacitor://localhost`), an embedded widget, a marketing site calling
     * the app's API — whose `configureServerFunctionsClient({ endpoint })`
     * names this handler's absolute URL. A `Sec-Fetch-Site: cross-site` (or
     * `same-site`) request carrying a browser-set `Origin` is decided by this
     * matcher, and an admitted cross-origin caller gets the CORS answer the
     * browser needs to read the response: `Access-Control-Allow-Origin`
     * echoing its exact `Origin` (with `Vary: Origin`), the protocol's
     * response headers exposed, and the `OPTIONS` preflight answered for the
     * transport's methods and headers. Without a configured matcher no
     * cross-origin caller is admitted (#3538); `Sec-Fetch-Site: none` and a
     * request carrying no `Origin` at all stay refused whatever is listed.
     * Configuring a matcher also puts `Vary: Origin` on every `GET`-declared
     * read (the one cacheable answer): its answer now depends on who asked,
     * and a shared cache must not serve one caller's variant to another.
     *
     * The trust decision is the same one this option always claimed: a
     * browser sets `Origin` and a page cannot forge it, so a listed origin's
     * pages may call — with the user's cookies only if `allowCredentials`
     * says so. A cross-origin client should prefer bearer tokens through the
     * client's `prepareRequest`.
     */
    origin?: ServerFunctionOriginMatcher;
    /**
     * Sends `Access-Control-Allow-Credentials: true` to an admitted
     * cross-origin caller, letting a `credentials: "include"` fetch carry
     * and receive cookies. Off by default so that listing an origin never
     * silently turns on cookie sharing; a cookie that is meant to travel
     * cross-site also needs `SameSite=None; Secure`. Has no effect on
     * same-origin responses.
     * @default false
     */
    allowCredentials?: boolean;
    /**
     * Allows requests without `Sec-Fetch-Site`, `Origin`, or `Referer`.
     * Cross-origin metadata is still decided by `origin`: an unlisted origin
     * stays refused.
     * @default false
     */
    allowRequestsWithoutOriginCheck?: boolean;
    /**
     * Applies the origin gate to GET-declared reads as well. By default the
     * gate is skipped for declared reads: same-origin policy already keeps a
     * cross-site caller from READING the response, and the gate's `Vary`
     * fragments (or, on CDNs that ignore Vary, poisons) the shared-cache
     * entries the `GET` helper exists to enable (#3071). The premise that
     * skip rests on is `GET()`'s safety contract — declared reads are safe
     * to EXECUTE from any origin (#3114). A deployment that does not rely
     * on shared caches can enable this to gate its reads too.
     * @default false
     */
    protectDeclaredReads?: boolean;
}
/** Options for `configureServerFunctionsServer`. */
export interface ServerFunctionsServerConfig {
    /**
     * Establishes the request-event scope for a call — the function passed
     * runs with `event` visible to `getRequestEvent()`. Wire it to
     * `provideRequestEvent` from `@solidjs/web/storage` (or the framework's
     * equivalent). When omitted, falls back to the AsyncLocalStorage instance
     * an established request scope parks on the global.
     */
    provideEvent?: <T>(event: ServerFunctionEvent, fn: () => T) => T;
    /**
     * Wraps every server function execution — HTTP dispatch and direct SSR
     * calls alike — with the invocation identity already established (see
     * `WrapInvocationHook`). The per-invocation seam for framework policies:
     * per-function middleware, auth, logging, error mapping. A per-request
     * option overrides it for HTTP dispatch.
     */
    wrapInvocation?: WrapInvocationHook;
    /**
     * The unnamed single-flight hook: produces the data payload folded into
     * responses of calls that opted in (see `CollectFlightDataHook`).
     * Registered once by the integration that owns data production (a
     * router); per-handler `collectFlightData` options override it. Other
     * integrations contribute additively through
     * `registerFlightDataSource(id, hook)` instead of competing for this
     * slot.
     */
    collectFlightData?: CollectFlightDataHook;
    /**
     * Server-wide default for the handler's `transformResult` (same contract
     * — see `HandleServerFunctionRequestOptions`); a per-request option
     * overrides it. Registering it here makes result policies (e.g. frames'
     * `frameTransformResult`) work through generic dispatchers that call
     * `handleServerFunctionRequest(request)` with no options.
     */
    transformResult?(event: ServerFunctionEvent, result: unknown, context: {
        id: string;
        args: unknown[];
        request: Request;
        thrown?: boolean;
    }): unknown | ResponseEnvelope | Promise<unknown | ResponseEnvelope>;
    /**
     * `transformResult`'s counterpart for the single-flight fold: when a
     * call's flight payload needs a body only a policy knows how to build
     * (frames' `frameTransformFlightResult` — an invalidated entry is
     * markup), this gets first refusal on the `{ value, data }` outcome.
     * Return a `Response` to carry the outcome (call headers and cookies are
     * copied onto it), or `undefined` to decline and keep the plain
     * serialized envelope. A per-request option overrides it.
     */
    transformFlightResult?(event: ServerFunctionEvent, outcome: {
        value: unknown;
        data: unknown;
    }, context: {
        id: string;
        args: unknown[];
        request: Request;
    }): Response | undefined | Promise<Response | undefined>;
    /**
     * The in-process mirror of `transformResult` for direct (same-server)
     * calls during document SSR — e.g. frames' `frameTransformDirectResult`.
     */
    transformDirectResult?(value: unknown, options: {
        id: string;
        args: unknown[];
        event: ServerFunctionEvent;
    }): unknown;
    /**
     * Server-wide response builder for calls made without the client runtime
     * (see `handleNoJS` in `HandleServerFunctionRequestOptions`); a
     * per-request option overrides it. Set it to `createNoJSHandler({ base })`
     * to apply the convention to every non-scripted call rather than only to
     * browser form posts, to a handler of your own to replace it, or to
     * `null` to disable the built-in convention and answer form posts with
     * the plain serialized response.
     */
    handleNoJS?: ((result: unknown, request: Request, args: unknown[], thrown?: boolean) => Response | Promise<Response>) | null;
    /**
     * Mount path the HTTP handler answers on. Must match the client
     * configuration — the id travels as the segment after it, a request whose
     * path does not start with it is not a call, and SSR'd reference `url`s
     * (e.g. form actions) derive from it. Prefix it when the app serves from
     * a base path (e.g. `` `${BASE_URL}_server` ``).
     * @default "/_server"
     */
    endpoint?: string;
    /**
     * Same-origin protection for HTTP server function calls. Enabled by
     * default. Set to `false` only when another trusted layer protects the
     * endpoint. `{ origin }` lists the origins allowed to call — the opt-in
     * for a cross-origin client, answered with CORS (see
     * `ServerFunctionCSRFOptions`).
     */
    csrf?: boolean | ServerFunctionCSRFOptions;
    /**
     * Codec options (extra plugins etc.) for decoding arguments and encoding
     * results — must match the client's. Stored in the shared layer, so
     * `decodeResponse` sees them too. One asymmetry is fixed: arguments are
     * client input and never decode `Response` or `Request` values, whatever
     * plugins are configured — a call carrying one is refused with `400`.
     * Results keep the full set. Every plugin added here is a type a client
     * can make the server construct. When `serializeErrorStacks` is omitted,
     * the server-function boundary defaults it from this module's compiled
     * development variant.
     */
    codec?: JSONCodecOptions;
    /**
     * Upper bound, in bytes, on a call's argument payload — the POST body,
     * or the `?args=` query encoding. The payload is buffered and decoded
     * before dispatch, so its cost is paid before application code can
     * decline it; the bound is enforced up front and a request over it is
     * refused with `413` before any decoding (#3115). Raise it for functions
     * that accept large uploads, or set `Infinity` to remove the bound.
     * @default 1_048_576 (1 MiB)
     */
    bodySizeLimit?: number;
    /**
     * Upper bound on the number of arguments a call may carry. The decoded
     * argument array is spread into the function call, so an unbounded list
     * forces a range error out of any function regardless of what it does;
     * past the bound the request is refused with `400` (#3115).
     * @default 1000
     */
    maxArguments?: number;
    /**
     * The DEPLOYMENT SECRET: one value per deployment, from which any feature
     * that needs a key derives its own (domain-separated, so per-purpose keys
     * share no material). Today one feature does — the no-JS flash cookie
     * (#3239): the flash carries the submitted form input — whatever the user
     * typed — so its payload is always AES-GCM encrypted; it never rides the
     * wire or rests in the cookie jar as plaintext. Every instance that can
     * serve the render after a form post must share the secret (behind a load
     * balancer, a per-instance secret would silently lose outcomes), so there
     * is no generated fallback here: when this is not set, the secret falls
     * back to the one the Solid bundler plugin injects into the server build
     * (a fresh value per build), and with neither present the outcome is
     * simply not flashed — the form post still redirects cleanly, and dev
     * builds warn once.
     *
     * Use a HIGH-ENTROPY value, 32 bytes or more, and keep it out of source
     * control:
     *
     * ```sh
     * node -e "console.log(crypto.randomBytes(32).toString('base64url'))"
     * ```
     *
     * A captured cookie is an offline oracle for this value. Key derivation
     * stretches it (PBKDF2-HMAC-SHA-256), which raises the price of a guess
     * but does not make a guessable secret safe, and recovering it means
     * reading every flash payload and forging new ones. A passphrase, an app
     * name, or anything else a person would think up is not enough.
     *
     * Rotating it (or redeploying with the plugin's value) invalidates
     * in-flight flashes. They are 60-second one-shot cookies, so the next
     * render reads "no flash".
     */
    secret?: string;
    /**
     * DEV ONLY — the chaos knob: end every live response this many
     * milliseconds after it opens, the way a dying connection ends it (the
     * body breaks off with the stream still open). The client's `live` loop
     * reads it as a death and reconnects — backoff, `Last-Event-ID`, the
     * digest-equal skip, `onstatus` — so the reconnect path is exercised
     * continuously without a network to break. Applies to every event-stream
     * response the live address answers, data and frames alike. Ignored
     * outside the dev build; `0`/`undefined` is off.
     */
    chaosReconnectEvery?: number;
}
/**
 * A registered server function: its build-stable id paired with the
 * original implementation. Returned by `registerServerReference` and
 * consumed by the server-side `createServerReference`.
 *
 * Compiler ABI shape; hand-written code rarely constructs these.
 * @internal
 */
export interface ServerFunctionReference<T extends any[] = any[], R = any> {
    id: string;
    fn: (...args: T) => R;
    /**
     * The function's source name, emitted by development builds only —
     * `createServerReference` seeds the metadata channel with it.
     * @internal
     */
    name?: string;
}
/** Wire-state transitions a live call's iterable can report (client side).
 * `"closed"` carries the error when a definite rejection (4xx) ended the
 * call instead of the retry loop. */
export type LiveSourceStatus = "connected" | "reconnecting" | "closed";
/**
 * Type-level mirror of the client's live answer shape so isomorphic code
 * assigning `onstatus` typechecks against either build's declarations. On
 * the server the hook is inert: in-process calls hand back the source's
 * own iterable — there is no connection to report on.
 */
export type LiveSource<R> = R & {
    onstatus?: (state: LiveSourceStatus, error?: unknown) => void;
};
/** Identity of the currently executing server function call. */
export interface ServerFunctionInvocation {
    id: string;
    /**
     * The call arrived at the live address: a `live` loop is reading, and the
     * answer is framed as an event stream for as long as it stands (RFC 10,
     * `live(fn)` → Framing). A result policy building the answer's Response
     * itself (`frameTransformResult`) reads this to frame it the same way.
     * `false` for the data and bare addresses, and for in-process calls.
     */
    live: boolean;
    /** A live call to a `broadcast` declaration: its answer is shared. */
    broadcast?: boolean;
    /**
     * For a broadcast call, the arguments as they arrived on the wire: callers
     * whose encodings are equal share one render. Absent when the encoding
     * wasn't kept (an unbuffered body), and then the call is not shared.
     */
    shareKey?: string;
}
/**
 * Hooks layering framework policy onto `handleServerFunctionRequest`.
 * All are optional — the bare handler dispatches, scopes events, and
 * encodes results on its own.
 */
export interface HandleServerFunctionOptions {
    /**
     * Builds the request event a call runs under (default: bare
     * `{ request, locals: {} }`). Integrations supply their richer event
     * (cookies, response helpers, platform handles).
     *
     * `request` is a standards-shaped `Request` — url, method, headers,
     * signal, readable body — and nothing more. Enforcing `bodySizeLimit`
     * puts the runtime between the host's stream and the decoder, so the
     * object handed here may be one the runtime rebuilt; host-specific
     * fields on the inbound object (`request.cf`, srvx's `runtime`, `ip`,
     * `waitUntil`) are not carried. The host has its own request in closure
     * when it calls the handler: read platform handles there and put them on
     * the event (`locals`) rather than through `request`.
     */
    createEvent?(request: Request): ServerFunctionEvent;
    /**
     * Overrides the configured event provider for this handler — same
     * contract as the `provideEvent` config option.
     */
    provideEvent?<T>(event: ServerFunctionEvent, fn: () => T): T;
    /**
     * Overrides the configured per-invocation wrap for this handler — same
     * contract as the `wrapInvocation` config option (see
     * `WrapInvocationHook`), except it is ENTRY-ONLY: it wraps exactly the
     * invocation the request addressed. Nested direct server-function calls
     * made by the dispatched body are not re-wrapped by it — they consult
     * only the configured hook, which is ambient and wraps every direct call
     * (a per-request option can't see direct SSR calls). Policy that must
     * cover every hop belongs on `configureServerFunctionsServer`'s
     * `wrapInvocation`, not here.
     */
    wrapInvocation?: WrapInvocationHook;
    /**
     * This request's server error hook, ahead of `configureServerErrors`' (see
     * `ServerErrorHook` in `@solidjs/web`): the function's throw
     * (`handling: "thrown"`) and a failure escaping through its result graph
     * (`"channel"`), once per error per request, before the wire policy applies. Entry-only
     * like `wrapInvocation`: a direct call the body makes during a render
     * reports through the ambient hook.
     */
    onError?: ServerErrorHook;
    /**
     * Observes or replaces the function's result before encoding — the
     * extension point for response metadata policies (headers, statuses,
     * substituted results). Runs for returned and thrown results alike
     * (`context.thrown` distinguishes). The context carries the call's
     * identity — the function `id` and the parsed `args` the implementation
     * was invoked with — matching the direct-call mirror
     * (`transformDirectResult`), so a policy keying state by the call works
     * over either dispatch path; `context.request` tells a scripted call (the
     * `/data/` address) from a bare-address one. Return the result
     * unchanged to pass through, or a `ResponseEnvelope` (exposed through
     * the core entry) to send HTTP metadata plus a structured payload. Runs
     * before `collectFlightData`, so the flight hook sees the transformed
     * outcome — use `collectFlightData`, not this, to fold data into the
     * response.
     */
    transformResult?(event: ServerFunctionEvent, result: unknown, context: {
        id: string;
        args: unknown[];
        request: Request;
        thrown?: boolean;
    }): unknown | ResponseEnvelope | Promise<unknown | ResponseEnvelope>;
    /**
     * Overrides the configured single-flight hook for this handler — same
     * contract as the `collectFlightData` config option (see
     * `CollectFlightDataHook`).
     */
    collectFlightData?: CollectFlightDataHook;
    /**
     * Overrides the configured single-flight fold policy for this handler —
     * same contract as the `transformFlightResult` config option.
     */
    transformFlightResult?(event: ServerFunctionEvent, outcome: {
        value: unknown;
        data: unknown;
    }, context: {
        id: string;
        args: unknown[];
        request: Request;
    }): Response | undefined | Promise<Response | undefined>;
    /**
     * Builds the response for calls made without the client runtime (at
     * the bare address — no-JS form posts, direct HTTP). Receives the
     * (transformed) result, the request, and the decoded arguments; `thrown`
     * is set when the result was thrown rather than returned.
     *
     * Overrides the configured hook, which in turn overrides the built-in
     * `createNoJSHandler()` applied to browser form posts. Other
     * bare-address callers get the normal serialized response.
     */
    handleNoJS?(result: unknown, request: Request, args: unknown[], thrown?: boolean): Response | Promise<Response>;
    /**
     * Overrides same-origin protection for this handler. Set to `false` only
     * when another trusted layer protects the endpoint.
     */
    csrf?: boolean | ServerFunctionCSRFOptions;
    /** Overrides the configured codec options for this handler. */
    codec?: JSONCodecOptions;
    /**
     * Overrides the configured argument payload bound for this handler (see
     * `ServerFunctionsServerConfig.bodySizeLimit`).
     */
    bodySizeLimit?: number;
    /**
     * Overrides the configured argument count bound for this handler (see
     * `ServerFunctionsServerConfig.maxArguments`).
     */
    maxArguments?: number;
}
export declare function configureServerFunctionsServer(config?: ServerFunctionsServerConfig): void;
export declare function registerFlightDataSource(source: string, hook: CollectFlightDataHook): () => void;
export declare function registerServerFunction<T extends any[], R>(id: string, callback: (...args: T) => R): (...args: T) => R;
export declare function getServerFunction<T extends any[], R>(id: string): (...args: T) => R;
export declare function registerServerReference<T extends any[], R>(id: string, fn: (...args: T) => R, name?: string): ServerFunctionReference<T, R>;
export declare function createServerReference<T extends any[], R>(reference: ServerFunctionReference<T, R>): (...args: T) => R;
export declare function GET<A extends readonly any[], R>(fn: (...args: A) => R): ServerFunction<A, Awaited<R>>;
export declare function live<A extends readonly any[], R>(fn: (...args: A) => R): ServerFunction<A, LiveSource<Awaited<R>>>;
/**
 * Declares a live server function whose answer is the same for every
 * viewer: implies `live` and `GET`, and at the live address every caller
 * with the same arguments shares ONE render (frames server half). The
 * outer body still runs per call — a gate (auth, redirects) — but what it
 * returns is the shared answer's to render.
 * @experimental
 */
export declare function broadcast<A extends readonly any[], R>(fn: (...args: A) => R): ServerFunction<A, LiveSource<Awaited<R>>>;
export declare function getServerFunctionInvocation(): ServerFunctionInvocation | undefined;
export declare function getEventServerFunctionInvocation(event: RequestEvent | undefined): ServerFunctionInvocation | undefined;
export declare function foldSetCookies(headers: Headers, setCookies: readonly string[]): Headers;
export declare function createNoJSHandler(options?: NoJSHandlerOptions): (result: unknown, request: Request, args: unknown[], thrown?: boolean) => Promise<Response>;
/** @internal */
export declare function guardFailures(value: any, state: any): any;
/**
 * The response-side codec stream: `serializeStream` (shared.js) hardened
 * with request-lifetime teardown. Server-only on purpose — the shared half
 * is re-exported into client bundles, where this plumbing is dead weight.
 *
 * An abort of `signal` (the platform fires request.signal when the caller's
 * fetch aborts or the tab goes away) or the consumer cancelling the
 * ReadableStream (how platforms surface a dropped connection to the body)
 * stops pending serialization and tears down EVERY async-iterable or
 * ReadableStream source in the result graph, nested ones included (#3125) —
 * each producer's `iterator.return()` / `reader.cancel()` runs, so
 * generator `finally` blocks execute instead of the server pumping streams
 * nobody is reading. The wiring rides guardFailures' walk: it already wraps
 * every channel before the codec sees the value, so the demand gate and the
 * teardown registry are threaded through its state (`{ items: rows() }` —
 * a cursor beside a total — gets the same two guarantees as `return rows()`).
 *
 * `live` selects the event-stream framing a live address answers in (see
 * encodeLiveResult): the same payloads one per event, a comment heartbeat
 * while idle, and each yield's position — parked on `live.pending` by the
 * live adapter — riding as the `id:` of the record that carries the yield.
 */
export declare function serializeResponseStream(value: any, codecOptions: any, signal: any, scope: any, live: any): ReadableStream<any>;
/**
 * Arms what every live body carries beyond its payloads, whichever writer
 * frames them — the codec stream (`serializeResponseStream`) and a frame
 * stream (`serverComponentResponse` at the live address) alike:
 *
 * - the heartbeat: an event-stream comment every 20s while the response is
 *   open, so a proxy's idle timeout never mistakes a waiting source for a
 *   dead one. Not demand-gated — the two bytes ride ahead of any parked
 *   pull. Unref'd where the runtime allows: the connection holds the
 *   process open, not the timer;
 * - the chaos knob (dev only, `chaosReconnectEvery`): end this response as
 *   a dying connection would — `teardown` first (the producer's own), then
 *   the body errors with the stream still open, so the client reads a
 *   death, not a completion.
 *
 * Returns the disarm; the caller runs it on every road the body ends by, so
 * a response that completed on its own is never touched.
 * @internal
 */
export declare function armLiveBody(controller: ReadableStreamDefaultController<Uint8Array>, teardown: () => void): () => void;
/** Message a sanitized (production) server error carries on the wire. */
export declare const GENERIC_SERVER_ERROR_MESSAGE = "Internal Server Error";
export declare function setServerFunctionsDev(dev: boolean): void;
export declare function sanitizeServerError(value: unknown): unknown;
export declare function serverFunctionUrl<A extends readonly unknown[]>(fn: ServerFunction<A, any>, ...args: A): string;
export declare function serverFunctionActionUrl(fn: ServerFunction | string, ...boundArgs: readonly unknown[]): string;
export declare function parseServerFunctionActionUrl(url: string): string | null;
/**
 * Web-standard HTTP handler for server function calls: resolves the
 * function id from the request, enforces the method allowlist (POST always
 * dispatches; GET and HEAD dispatch only to functions that declared `GET`,
 * with HEAD returning the equivalent GET's status and headers minus the
 * body; every other method answers 405), decodes arguments, runs the
 * function under a request-event scope, and encodes the result (forwarding
 * redirect/revalidation metadata through headers). Mount it on the endpoint
 * the client transport targets (default `/_server`); platform adapters (h3,
 * express, ...) convert their request shape to a web `Request` around it.
 *
 * Requests are same-origin by default. The handler accepts browser requests
 * proven by `Sec-Fetch-Site`, `Origin`, or `Referer`, and rejects requests
 * without usable metadata unless explicitly configured otherwise. A
 * cross-origin browser call is admitted only when `csrf.origin` lists its
 * `Origin`, and is then answered with CORS — `Access-Control-Allow-Origin`
 * echoing that origin, the protocol's headers exposed, the `OPTIONS`
 * preflight answered, credentials only when `csrf.allowCredentials` says so
 * (#3538). GET/HEAD requests to `GET`-declared functions skip this gate:
 * they are reads by contract, cross-site response READING is already
 * blocked by same-origin policy, and skipping it keeps the
 * `Vary: Sec-Fetch-Site, Origin, Referer` it would impose off the responses
 * shared caches are meant to store. Once `csrf.origin` lists an origin,
 * though, a read's answer depends on who asked — `Allow-Origin` for a
 * listed caller, nothing for anyone else — so every declared read then
 * carries `Vary: Origin` (and only that), or a shared cache would serve one
 * caller's variant to the other.
 *
 * Every response leaves with `Cache-Control: no-store` unless the function
 * set its own cache policy (via `respond()` headers or a returned
 * `Response`) — caching is opt-in on the wire, not just in prose.
 *
 * When the event carries a `response` head stub (`event.response`, see the
 * server entry's `ResponseStub`), the handler folds it onto every outgoing
 * response as the head freezes — its `Set-Cookie` values (cookies appended
 * during the call) append cookie-by-cookie alongside the result's own,
 * other stub headers fill gaps (the call's response metadata wins; the
 * protocol-owned family — the error/format/single-flight tags, `Location`,
 * `X-Revalidate` — never fills, and neither does `Content-Type`/`Content-
 * Length` onto a bodiless response) — and marks the stub `committed`, so
 * later cookie/header writes report instead of silently missing the wire.
 *
 * ## Thrown-error sanitization (security default)
 *
 * A thrown `Response`/envelope (`redirect`/`reload`/`respond`) is intentional
 * control flow and is forwarded untouched. A *plain* thrown value (a bare
 * `Error`, string, or object) is different: serialized verbatim it would ship
 * its `message` and every own-property to the client — a driver/ORM error's
 * failing query, connection string, or bound parameters included. So outside
 * the dev build a plain thrown value is replaced with a generic `Error`
 * before serialization; the client still receives *an* `Error` (the shape
 * `submission.error` etc. expect), just with no leaked content. The dev
 * build keeps full fidelity (message, stack, own-props) for DX and the dev
 * toolbar inspector. Dev/prod is the BUILD VARIANT, not `NODE_ENV`:
 * `@solidjs/web` publishes a dev copy of this entry behind the
 * `development` export condition (what Vite dev resolves) and the default
 * resolution sanitizes — as does importing the runtime source directly with
 * no bundler signal (fail-safe).
 *
 * Escape hatch: brand the value with `markSafeError` (`Symbol.for(
 * "solid.SafeError")`) to send its content intact in every environment.
 * A `wrapInvocation`/`transformResult` override that maps errors expresses
 * intent the same way — throw a `Response`/envelope, or brand the mapped
 * error safe; an unbranded plain error it lets propagate is sanitized like
 * any other, so a framework onError policy must brand its result to keep a
 * custom client-facing message in production.
 *
 * @example
 * ```ts
 * import { handleServerFunctionRequest } from "@solidjs/web/server-functions/server";
 * import "virtual:solid-server-function-manifest";
 *
 * // in the server's request handling:
 * if (url.pathname.startsWith("/_server")) {
 *   return handleServerFunctionRequest(request);
 * }
 * ```
 */
export declare function handleServerFunctionRequest(request: Request, options?: HandleServerFunctionOptions): Promise<Response>;
