import { Component, type DynamicOptions } from "solid-js";
import type { JSX } from "./jsx.js";
export * from "./client.js";
export * from "./server-mock.js";
export * from "./response.js";
export type { JSX } from "./jsx.js";
export { For, Show, Switch, Match, Errored, Loading, Repeat, Reveal, NoHydration, Hydration } from "solid-js";
/**
 * Build-time constant indicating whether code is running on the server. This
 * client entry sets it to `false`; the matching server entry (`@solidjs/web`
 * resolved through the `solid` server export condition) sets it to `true`.
 *
 * Bundlers can dead-code-eliminate branches gated on `isServer`, so guarding
 * browser-only code with `if (!isServer) {…}` keeps it out of the SSR bundle
 * entirely.
 *
 * @example
 * ```ts
 * import { isServer } from "@solidjs/web";
 *
 * if (!isServer) {
 *   // Browser-only: tree-shaken out of the SSR bundle.
 *   window.addEventListener("resize", onResize);
 * }
 * ```
 */
export declare const isServer: boolean;
/**
 * Build-time constant indicating whether code is running in a dev build.
 * Replaced statically (`_SOLID_DEV_`) by the bundler integration, so guards
 * like `if (isDev) {…}` are stripped from production builds.
 *
 * Use this to gate dev-only diagnostics, warnings, or expensive invariants
 * that should never ship to production.
 *
 * @example
 * ```ts
 * import { isDev } from "@solidjs/web";
 *
 * if (isDev) {
 *   console.warn("debug-only path");
 * }
 * ```
 */
export declare const isDev: boolean;
export type IntrinsicElement = Extract<keyof JSX.IntrinsicElements, string>;
export type ValidComponent = IntrinsicElement | Component<any> | (string & {});
export type ComponentProps<T extends ValidComponent> = T extends Component<infer P> ? P : T extends keyof JSX.IntrinsicElements ? JSX.IntrinsicElements[T] : Record<string, unknown>;
/** @deprecated Props of the deprecated `<Dynamic>`; see `dynamic()`. */
export type DynamicProps<T extends ValidComponent, P = ComponentProps<T>> = {
    [K in keyof P]: P[K];
} & {
    component: T | null | undefined | false;
};
/**
 * Renders its children into a different part of the DOM (modal roots,
 * tooltips, layers that need to escape an `overflow: hidden` ancestor).
 *
 * If `mount` is omitted, the portal attaches to `document.body`. The portal
 * still participates in the parent's reactive scope and disposes when the
 * parent does.
 *
 * Portals are client-only islands: the server renders nothing for them, and
 * under hydration the children render fresh once hydration settles. Async
 * read inside a portal therefore starts on the client — data that should be
 * fetched on the server belongs above the portal (hoist the read, not the
 * render), and async UI inside one wants its own `<Loading>` boundary.
 *
 * @example
 * ```tsx
 * <Portal mount={document.getElementById("modal-root")!}>
 *   <Dialog />
 * </Portal>
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-web/components/portal
 */
export declare function Portal(props: {
    mount?: Element;
    children: JSX.Element;
}): JSX.Element;
export type { DynamicOptions } from "solid-js";
export { dynamicComponent } from "solid-js";
/**
 * Returns a stable `Component` whose identity is driven by a reactive (and
 * optionally async) `source`. The returned component can be used anywhere a
 * normal component is used; children and props flow through JSX as usual.
 *
 * `source` may return a component, a native tag name (`'input'`, `'textarea'`,
 * etc.), `undefined`, or a `Promise` of any of the above. A pending promise
 * propagates as `NotReadyError` through the surrounding reactive scope, so
 * async swaps compose with `<Loading>` boundaries the same way as `lazy`.
 *
 * During SSR a pending source streams in behind its boundary by default. Pass
 * `{ deferStream: true }` to hold the document's first flush until it settles
 * (the same option `createMemo` takes); the client ignores it.
 *
 * For a tag-name source the element's namespace is inferred from the tag. A
 * tag that exists in both HTML and SVG (`a`, `script`, `style`, `title`) is
 * created as HTML unless the instance passes `xmlns` — the same attribute
 * compiled JSX uses for the same purpose. `is` (customized built-ins) and
 * `xmlns` are read once at creation and then applied as ordinary attributes.
 *
 * `{ static: true }` says the source cannot change: it is called once,
 * untracked, when `dynamic()` is called, and each instance renders the result
 * with no computation of its own — a tag name goes straight to the compiled
 * element path (create or claim, spread), a component is called directly. No
 * owner is created on either side, so hydration keys stay aligned with the
 * compiled output. Use it for a constant (`dynamic(() => "li", { static: true })`
 * in a runtime `styled()`), or per instance from the shape of a prop:
 * `isStatic(props, "as")` is true when the caller wrote `as="button"`
 * (a data property) and false when they wrote `as={cond() ? …}` (a getter),
 * so a polymorphic component keeps a reactive public `as` and still pays
 * nothing for the literal case. A static source may not return a promise.
 *
 * @example
 * ```tsx
 * // `source` can return either a custom Component or a native tag
 * // name — they're interchangeable, and the returned reference is a
 * // stable Component you can use anywhere a normal one would go.
 * const Field = dynamic(() => multiline() ? RichTextEditor : "input");
 * return <Field value={value()} onInput={onInput} />;
 *
 * // An ambiguous tag inside an SVG tree: say which namespace you mean.
 * const Link = dynamic(() => "a");
 * <svg><Link xmlns="http://www.w3.org/2000/svg" href="/x">…</Link></svg>
 *
 * // A polymorphic component: no memo when `as` arrived as a literal.
 * function Polymorphic(props) {
 *   const Tag = dynamic(() => props.as, { static: isStatic(props, "as") });
 *   return <Tag {...omit(props, "as")} />;
 * }
 * ```
 *
 * @description https://v2.solidjs.com/reference/solid-web/components/dynamic
 */
/**
 * A component from a reactive source. The source may answer with the
 * component itself, a promise of it, or an async iterable of it — a `live`
 * server component reference's answer is the last: the memo underneath pumps
 * the iterable as it pumps any async source, and its value is the component
 * the server answered with (a reconnect re-yields the same binding and is
 * equality-quiet; nothing here re-mounts).
 *
 * Under SSR an async answer is an ordinary async memo's: its landing is
 * serialized per instance and adopted here at hydration, so the source may
 * stay async only when what it resolves to can cross — a server component
 * (as a reference) or a serializable value (a tag name). A promise of a
 * client component function is a dev error on the server
 * (`DYNAMIC_ASYNC_COMPONENT`): resolve the async upstream, or use `lazy()`.
 *
 * Cost: because a source may answer with a tag name, one `dynamic` on a page
 * retains the element runtime (create/claim, `spread`, the namespace tables)
 * for everyone. A source that only ever answers with a component — a server
 * component mount — should use `dynamicComponent`, which never does.
 */
export declare function dynamic<T extends ValidComponent>(source: () => T | Promise<T> | AsyncIterable<T> | null | undefined | false, options?: DynamicOptions): Component<ComponentProps<T>>;
/**
 * @deprecated Use `dynamic()`. `<Dynamic>` is the same primitive, but its
 * shape puts the tag in the same bag as the element's props: every instance
 * merges `component` in at the call site, `omit()`s it back out here, and
 * builds a fresh `dynamic()` factory (with its memo) because there is nowhere
 * to hoist one. `dynamic()` has none of that and is one line longer:
 *
 * ```tsx
 * // before
 * <Dynamic component={multiline() ? RichTextEditor : "input"} value={value()} />
 *
 * // after — hoist per component instance (or per module for a constant)
 * const Field = dynamic(() => multiline() ? RichTextEditor : "input");
 * <Field value={value()} />
 * ```
 *
 * Remains available in 2.0 (deprecated, no runtime warning); prefer `dynamic()`
 * in new code.
 */
export declare function Dynamic<T extends ValidComponent>(props: DynamicProps<T>): JSX.Element;
/**
 * Wraps a dynamically imported component so it renders only in the browser.
 * The server renders `props.fallback` (and nothing else); the client shows
 * the fallback until the import resolves and the tree has mounted, then
 * swaps the real component in.
 *
 * Unlike `lazy()`, this avoids Suspense entirely and never server-renders
 * the wrapped component — only the fallback — so the component participates
 * in no hydration asset manifest and its code is guaranteed to never run on
 * the server (safe for browser-only libraries touching `window`, DOM
 * measurement, etc.). The mount gate keeps hydration safe: during hydration
 * the fallback is rendered exactly as the server did, and the swap happens
 * only after settle, so there is no mismatch.
 *
 * By default the import starts as soon as `clientOnly` is called (module
 * load); pass `{ lazy: true }` to defer the import to the component's first
 * render. Pass `{ export: "Name" }` to use a named export of the resolved
 * module instead of its default (mirrors `lazy()`'s option).
 *
 * @example
 * ```tsx
 * const Chart = clientOnly(() => import("./Chart.jsx"));
 * // <Chart fallback={<div>Loading chart…</div>} data={data()} />
 * ```
 */
export declare function clientOnly<M extends Record<string, any>, K extends keyof M & string>(fn: () => Promise<M>, options: {
    lazy?: boolean;
    export: K;
}, moduleUrl?: string): Component<ComponentProps<M[K]> & {
    fallback?: JSX.Element;
}>;
export declare function clientOnly<T extends Component<any>>(fn: () => Promise<{
    default: T;
}>, options?: {
    lazy?: boolean;
    export?: string;
}, moduleUrl?: string): Component<ComponentProps<T> & {
    fallback?: JSX.Element;
}>;
/**
 * Declares the HTTP response status (and optional status text) for the
 * lifetime of the current reactive scope during SSR — call it bare in a
 * component or reactive-scope body where the status is decided (a 404
 * route, an error fallback). Client build: a no-op — the response head was
 * sent long ago.
 *
 * Naming note — this is a scope-tied *declaration*, not a mutation: "while
 * this reactive scope is live, the response has this status." Solid
 * reserves `set*` verbs for event-time mutation; like
 * `createSignal`/`onCleanup` this is called in scope bodies and un-declares
 * on scope disposal.
 *
 * Retraction semantics (server): the write snapshots the previous
 * `event.response` status at write time and restores it when the owning
 * scope is disposed — so a boundary that errored, declared a status, and
 * then recovered retracts its write instead of stomping a status a
 * surviving part of the tree legitimately set. Once the response head is
 * `committed` (head derived/sent — the shell flush of a piped
 * `renderToStream`, the completion of an awaited one or of
 * `renderToString`), writes and retractions are no-ops.
 */
export declare function httpStatus(_code: number, _text?: string): void;
/**
 * Declares an HTTP response header (or with `append`, appends to one) for
 * the lifetime of the current reactive scope during SSR — call it bare in a
 * component or reactive-scope body. Client build: a no-op — the response
 * head was sent long ago.
 *
 * Naming note — this is a scope-tied *declaration*, not a mutation: "while
 * this reactive scope is live, the response has this header." Solid
 * reserves `set*` verbs for event-time mutation; like
 * `createSignal`/`onCleanup` this is called in scope bodies and un-declares
 * on scope disposal.
 *
 * Retraction semantics (server): the header's prior value is snapshotted at
 * write time and restored when the owning scope is disposed (deleted if
 * there was none) — a boundary that errors or recovers retracts its writes.
 * Once the response head is `committed` (head derived/sent — the shell
 * flush of a piped `renderToStream`, the completion of an awaited one or
 * of `renderToString`), writes and retractions are no-ops.
 */
export declare function httpHeader(_name: string, _value: string, _options?: {
    append?: boolean;
}): void;
