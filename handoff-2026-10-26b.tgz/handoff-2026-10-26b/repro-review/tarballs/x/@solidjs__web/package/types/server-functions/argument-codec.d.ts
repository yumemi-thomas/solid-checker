/** The refusal: thrown by the encoder, and answered as a 400 by dispatch. */
export declare function refusedArgumentError(name?: string): TypeError;
/** The refusal behind `error`, if any: the codec reports a plugin's throw as the `cause` of its own error. */
export declare function refusedArgument(error: any): any;
/**
 * The codec options server-function arguments decode with: `codec` with its
 * complete plugin list resolved and the refused types filtered out.
 * `defaults` is the codec's default plugin set (from the lazily loaded
 * decode module).
 */
export declare function argumentDecodeCodec(codec: any, defaults: any): any;
/**
 * Whether a framed argument payload names a refused type. Read only on a
 * decode that already failed: a payload naming one can never decode (its
 * tag has no plugin), so this tells the refusal apart from every other
 * malformed payload. A plugin node spells its tag as `"c":"<tag>"`; inside a
 * JSON string the quotes would be escaped, so payload data cannot spell it.
 */
export declare function namesRefusedType(payload: any): boolean;
/**
 * The configured codec options with encode-side refusals ahead of every
 * plugin. `extra` holds plugins for one call (the upload serializer), which
 * go first.
 */
export declare function argumentEncodeCodec(codec: any, extra?: any[]): any;
/**
 * Decode options from `argumentDecodeCodec` with plugins for one request
 * (the upload deserializer) ahead of the resolved list.
 */
export declare function withArgumentPlugins(argumentCodec: any, extra: any): any;
