export type { InvokeOptions, ServerFunction, ServerFunctionInvoker, ServerFunctionMetadata, ServerFunctionRPC } from "./shared.js";
import type { InvokeOptions } from "./shared.js";
export declare const SERVER_FUNCTION_METADATA: unique symbol;
/**
 * Reads a server function reference's declaration metadata (e.g.
 * `method: "GET"` for `GET(fn)` references). Returns undefined when `fn`
 * is not a server function reference; plain references carry an empty
 * metadata object.
 */
export declare function getServerFunctionMetadata(fn: any): any;
/**
 * Whether `fn` is a server function reference (a client proxy or a
 * server-side registered callable). Detection is by the registered-symbol
 * metadata brand, so it holds across duplicated module instances.
 */
export declare function isServerFunction(fn: any): boolean;
/**
 * Attaches user-declared transport metadata to a server function reference
 * (client proxy or server-registered callable) and returns the reference.
 * Writes ride the same channel `GET` uses: later writes shallow-merge over
 * earlier ones, and `getServerFunctionMetadata(fn)` reads the merged bag —
 * so `withMeta` composes with `GET` in either order.
 *
 * The pattern is declare-on-function, react-in-hook: metadata declared
 * here is what `prepareRequest` receives as `context.meta`, letting
 * session-dynamic transport policy key on declarations instead of
 * comparing function ids:
 *
 * ```ts
 * export const chargeCard = withMeta(async (amount: number) => {
 *   "use server";
 *   // ...
 * }, { requiresAuth: true });
 *
 * configureServerFunctionsClient({
 *   prepareRequest(init, { meta }) {
 *     if (meta?.requiresAuth) {
 *       return {
 *         ...init,
 *         headers: { ...init.headers, Authorization: `Bearer ${session.token()}` }
 *       };
 *     }
 *     return init;
 *   }
 * });
 * ```
 */
export declare function withMeta(fn: any, meta: any): any;
export declare const SERVER_FUNCTION_INVOKE: unique symbol;
/**
 * Applies a server function once with per-call, invocation-scoped options —
 * `Function.prototype.call` for server functions, the options bag in the
 * `thisArg` slot (declaration wrappers like `GET` and `withMeta` are `bind`:
 * they return a new reference with context baked in; `invoke` applies one
 * call and leaves no residue on the reference).
 *
 * ```ts
 * import { invoke } from "@solidjs/web/server-functions";
 *
 * const user = await invoke(getUser, { signal: controller.signal }, id);
 * ```
 *
 * Options are strictly invocation-scoped — things that vary between calls
 * of the SAME function and cannot be declared or configured: `signal`
 * (the call's lifecycle; aborting rejects the call and cancels the
 * request), `keepalive` (calls made while the page unloads), `priority`
 * (fetch priority hint). Anything with a longer lifetime is refused with a
 * pointer to its home: session-dynamic transport policy → `prepareRequest`;
 * declaration-static shape → `GET`/`withMeta`; call policy (retries,
 * dedupe, deadlines) → the data layer that owns the call, wired through
 * `signal`.
 *
 * Dispatches through the reference's invocation channel
 * (`SERVER_FUNCTION_INVOKE`). Core's declaration wrappers forward it —
 * `GET` invokes over its query encoding, `live` ends its iteration on
 * abort. Wrappers that share calls (caches, channels) may adapt or decline
 * it; a data layer needs neither — it holds the reference below such
 * wrappers and invokes it directly with its own signal. On the server the
 * call runs in-process: `signal`
 * rejects the caller (the work, like a server behind HTTP, runs on unless
 * the function observes a signal itself) and the transport hints are
 * no-ops, since they describe a wire that does not exist.
 */
export declare function invoke<A extends readonly any[], R>(fn: (...args: A) => R, options: InvokeOptions, ...args: A): R;
export declare const LIVE_SOURCE: unique symbol;
export declare const LIVE_RESUME_FROM: unique symbol;
export declare const LIVE_LOCAL: unique symbol;
/**
 * Fills the RPC seam. Called by the transport halves (client fetch RPC,
 * server in-process dispatch) when the first server function reference is
 * created; first write wins — both halves register equivalent surfaces, and
 * a per-build half never coexists with the other build's.
 * @internal
 */
export declare function provideServerFunctionRPC(rpc: any): void;
/**
 * The registered RPC surface, or undefined when no server function exists
 * in this build's graph. Integration plumbing (routers): gate every use of
 * the transport/codec behind this read instead of importing it. Both halves
 * carry `GET` and `decodeResponse`. (A handler re-asking a call it answered
 * does so through the call's own `retry` thunk — `responseHandler` in the
 * client config — not through this slot.)
 * @internal
 */
export declare function getServerFunctionRPC(): any;
