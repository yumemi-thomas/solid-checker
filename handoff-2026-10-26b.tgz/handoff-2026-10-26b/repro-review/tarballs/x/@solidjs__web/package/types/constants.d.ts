/**
 * Flags
 *
 * - 1 - Stateful property - value derives from reactive state
 * - 2 - Locked to property - value not specially treated
 */
declare const DOMWithState: Record<string, Record<string, 1 | 2>>;
declare const ChildProperties: Set<string>;
declare const LinkAttributes: Set<string>;
declare const $$SLOT: unique symbol;
declare const $$HOST: unique symbol;
declare const DelegatedEvents: Set<string>;
declare const SVGElements: Set<string>;
declare const MathMLElements: Set<string>;
declare const Namespaces: Record<string, string>;
declare const VoidElements: Set<string>;
declare const RawTextElements: Set<string>;
declare const DOMElements: Set<string>;
declare const COMPOSED_BODY_FRAMING: ReadonlySet<string>;
declare function isHttpNavigationTarget(target: string): boolean;
declare function isEventName(name: string): boolean;
export { DOMWithState, ChildProperties, LinkAttributes, DelegatedEvents, SVGElements, MathMLElements, VoidElements, RawTextElements, Namespaces, DOMElements, $$SLOT, $$HOST, COMPOSED_BODY_FRAMING, isHttpNavigationTarget, isEventName };
