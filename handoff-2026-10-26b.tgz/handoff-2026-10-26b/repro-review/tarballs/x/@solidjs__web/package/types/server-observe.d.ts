import { type FrameProducedEvent, type RenderEvent } from "./observe.js";
import type { NavigationRef } from "solid-js";
import { type TraceRecord } from "./trace.js";
import type { RequestEvent } from "./server.js";
/**
 * The one gate for a server record and the `Server-Timing` metric projected
 * from it (`TimedWork` in trace.ts): whether the runtime builds the record
 * of `type` — `"invocation"` (→ `solid-invocation`), `"render"` (→
 * `solid-shell`), `"boundary"` (→ `solid-boundary`, gated in the reactive
 * library's boundary with this same rule). Dev builds always: dev is the
 * panel's home, and the boundary already measures for its dev checks.
 * Observe builds while a listener is on the type (`observed`), so an app
 * with no observer sees no wire change; the record is then delivered AND
 * the metric written from it — one clock, one object. `false` in prod,
 * where `records()` is `undefined`.
 */
export declare function timesServerWork(type: "invocation" | "render" | "boundary"): boolean;
/** What the renderer holds while a render is being recorded. */
export interface RenderObservation {
    /**
     * The shell is complete — for a stream, handed to the sink; for a string,
     * the document assembled: stamps `shellMs`, the `solid-shell` metric's
     * duration. Once; a later call is ignored.
     */
    shell(): void;
    /** A `<Loading>` boundary the shell waited on settled: counts it (`boundaries`). */
    boundary(): void;
    /**
     * The router declared the render's route (`_declareRoute` on the render
     * context): keeps the ref, read at `settle` into `RenderEvent.route`. A
     * later declaration replaces an earlier one (a router remounted by a
     * boundary's second pass describes the same route again).
     */
    route(ref: NavigationRef): void;
    /** The render ended; delivers the record. Once. */
    settle(outcome: RenderEvent["outcome"]): void;
}
/**
 * Opens the `"render"` record for a render of `mode` — on the request's
 * trace record, where the head commit reads it (`TraceRecord.render`) —
 * when `timesServerWork("render")`; `undefined` otherwise, and the renderer
 * then does nothing extra, not even read the clock. The record is built as
 * the render proceeds and delivered at `settle`, to a listener if there is
 * one; `event` is the request the render serves, the record's live half.
 */
export declare function observeRender(trace: TraceRecord, mode: RenderEvent["mode"], event: RequestEvent | undefined): RenderObservation | undefined;
/** What the runtime passes an observation from either dispatch leg. */
export interface InvocationContext {
    id: string;
    direct: boolean;
    event: RequestEvent;
    request?: Request;
    args: unknown[];
}
/** What the frame producer hands an observation: the stream's identity. */
export interface FrameObservation {
    /** Counts the chunk — call for every chunk written after `start`. */
    chunk(message: {
        type?: string;
        id: string;
        r?: Record<string, any>;
    }): void;
    /** Delivers the record. `error` is the value thrown on the synchronous failure path. */
    settle(outcome: FrameProducedEvent["outcome"], error?: unknown): void;
}
/**
 * Opens the observation of one frame stream, at its `start`; the producer
 * feeds it every chunk and settles it at `complete`. `undefined` with no
 * listener or outside observe builds — the producer then does nothing
 * extra, not even read the clock.
 */
export declare function observeFrame(frame: {
    id: string;
    version: number;
}): FrameObservation | undefined;
/**
 * Runs `execute` — the wrapped server-function execution — and reports it
 * as an `"invocation"` record once it settles: synchronously for a sync
 * return or throw, at resolution/rejection for a promise. Returns
 * `execute`'s value (a promise is re-wrapped, still a native Promise);
 * throws what it throws. Timed while `timesServerWork("invocation")` — the
 * duration also rides the response's `Server-Timing` — and, with no
 * listener in an observe build or outside observe builds altogether, it is
 * `execute()` and nothing else.
 */
export declare function observeInvocation<T>(context: InvocationContext, execute: () => T): T;
