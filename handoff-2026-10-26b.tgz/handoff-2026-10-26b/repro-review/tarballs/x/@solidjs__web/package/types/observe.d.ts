import type { ChangeOrigin, Records } from "solid-js";
import type { RequestEvent } from "./server.js";
import type { TraceContext } from "./trace.js";
/**
 * The records channel — `OBSERVE.records` — or `undefined` outside observe
 * builds and where no observing core has loaded. An emitter's first check.
 */
export declare function records(): Records | undefined;
/**
 * One server function execution, delivered on
 * `OBSERVE.records.subscribe("invocation", …)` once it settled.
 * Serializable — the live handles (`event`, `args`, the thrown error)
 * travel beside it in `InvocationLive`, not on it.
 */
export interface InvocationEvent {
    /** The function id — the name a span or a log line carries. */
    id: string;
    /** `true` for an in-process call during SSR, `false` for HTTP dispatch. */
    direct: boolean;
    /** `performance.now()` when the execution started. */
    at: number;
    /**
     * Start → settle of the execution, in milliseconds. The execution is the
     * `wrapInvocation`-wrapped run: what the request spent on the call,
     * policy included (auth guards, per-function middleware). A generator or
     * stream body settles at handoff — see `deferred`.
     */
    durationMs: number;
    outcome: "ok" | "error";
    /**
     * The settled value is a body the caller drives — a generator, a
     * `ReadableStream` — so `durationMs` covers the call that produced it,
     * not its consumption.
     */
    deferred?: true;
    /**
     * Direct calls only: the hydration id of the `<Loading>` boundary whose
     * render pass made the call — the `id` of that boundary's `"boundary"`
     * record — so a boundary's wait can be read as the server-function calls
     * it consisted of. Absent for a call outside any boundary's pass (the
     * shell, or HTTP dispatch).
     */
    boundary?: string;
}
/**
 * The live half of an invocation, for in-process consumers. Not part of the
 * record: `args` and `result` are application data (name/PII policy belongs
 * to the consumer), `error` is the value AS THROWN — before the HTTP
 * handler's production sanitization replaces it on the wire — and `event`
 * is the request event the call ran under (the per-call derived event for
 * direct calls).
 */
export interface InvocationLive {
    event: RequestEvent;
    /** HTTP dispatch only; absent for direct calls. */
    request?: Request;
    args: unknown[];
    /** The settled value, when `outcome` is `"ok"`. */
    result?: unknown;
    /** The thrown value, when `outcome` is `"error"`. */
    error?: unknown;
}
export type InvocationListener = (event: InvocationEvent, live: InvocationLive) => void;
/**
 * One server render — a `renderToString` or a `renderToStream` (a document,
 * or a frame stream over the same core) — delivered on
 * `OBSERVE.records.subscribe("render", …)` once it ended: the document
 * returned, the stream's last fragment written, or the render torn down.
 * The server-side account of the head's timing: what the shell cost, and
 * how many `<Loading>` boundaries it waited on (each also a `"boundary"`
 * record) — the facts the response's `Server-Timing` `solid-shell` metric
 * is projected from. Serializable; the request the render served and its
 * trace ride beside it in `RenderLive`.
 */
export interface RenderEvent {
    /** `"string"` for `renderToString`, `"stream"` for `renderToStream`. */
    mode: "string" | "stream";
    /** `performance.now()` when the render began. */
    at: number;
    /**
     * Render start → the shell complete, in milliseconds: for a stream, the
     * head and shell handed to the sink (the head is frozen from here — a
     * fragment can no longer add to it); for a string, the document assembled
     * (the whole render). What `solid-shell` carries. Absent when the render
     * ended before its shell — torn down or failed pre-shell.
     */
    shellMs?: number;
    /**
     * Render start → the render's end, in milliseconds: the document
     * returned (`"string"`, equal to `shellMs`), the stream complete (every
     * fragment written), or the teardown for the other outcomes.
     */
    durationMs: number;
    /**
     * `<Loading>` boundaries the shell waited on — discovered with pending
     * async and settled before the shell completed, each a `"boundary"`
     * record with `streamed: false` and a `solid-boundary` metric. A boundary
     * that settled after the shell streamed as a fragment and is not counted
     * here (its own record says `streamed: true`). Counted from the
     * `"boundary"` records the render filed, under that record's gate: in an
     * observe build with a `"render"` listener but no `"boundary"` listener
     * the boundaries are not measured and this is `0`.
     */
    boundaries: number;
    /**
     * `"complete"` — the render ran to its end; `"abandoned"` — the consumer
     * left mid-stream (the sink threw, the readable was cancelled — the
     * `SSR_STREAM_ABANDONED` finding is that request's account) and the
     * render was torn down, or `createSSRResponse` discarded the page for a
     * pre-flush redirect (no finding); `"error"` — the render failed: a
     * string render threw, a stream's uncontained failure wound it down
     * through `onError`.
     */
    outcome: "complete" | "abandoned" | "error";
    /**
     * The route the render resolved to, as the router declared it while
     * building its context under this render (`OBSERVE.attribution.withOrigin`
     * with an `initial` ref — the same declaration the client's first
     * `"navigation"` record comes from): `name` the matched pattern
     * (`/users/:id`), `to` the concrete path, `params` what the pattern
     * bound. Read from the router's ref when the render settles, so a match
     * refined during the render is what lands. Absent when no router declared
     * one — a render without a router, or a router that does not yet. What a
     * consumer names the request by (`http.route`), where the URL would
     * scatter one page across as many names as it has parameters.
     */
    route?: RenderRoute;
}
/** `RenderEvent.route` — the route a render resolved to, as the router matched it. */
export interface RenderRoute {
    /** The matched route pattern — `/users/:id`. */
    name?: string;
    /** The concrete path. */
    to?: string;
    /** The params the pattern bound (optional params unbound: `undefined`). */
    params?: Readonly<Record<string, string | undefined>>;
}
/** The live half of a render record. */
export interface RenderLive {
    /** The request event the render ran under; absent for a render outside a request scope. */
    event?: RequestEvent;
    /** The trace the render belongs to — `getTraceContext()`'s answer for it. */
    trace: TraceContext;
}
export type RenderListener = (event: RenderEvent, live: RenderLive) => void;
/**
 * One server-function call made from the browser — the fetch and its
 * decode, as the caller awaited it — delivered on
 * `OBSERVE.records.subscribe("call", …)` once it settled. The client twin
 * of the server's `"invocation"` record: the two join by `id` (this is the
 * call; that is the execution it caused), and the difference between their
 * durations is the wire. A call an integration answered locally (a
 * handler's `intercept`, at t = 0) made no request and emits nothing.
 */
export interface CallEvent {
    /** The function id — the same `id` the server's `"invocation"` record carries. */
    id: string;
    /**
     * The function's source name, from the reference's metadata
     * (`ServerFunctionMetadata.name`): the compiled function's name, which
     * the compiler seeds in development builds only, or an explicit label
     * (`withMeta`, the `name` argument to `createServerReference`), which
     * survives to production. A label, not an identity: not unique, and
     * absent when the metadata carries none.
     */
    name?: string;
    /** `performance.now()` when the call was made. */
    at: number;
    /**
     * Call → settle, in milliseconds: the request built and sent, the
     * response received and decoded (or claimed by the configured
     * `responseHandler`) — the whole await the caller saw. A streaming
     * result settles at handoff — see `deferred`.
     */
    durationMs: number;
    /** `GET` for a GET-encoded read (`GET(fn)`), `POST` otherwise. */
    method: "GET" | "POST";
    outcome: "ok" | "error";
    /**
     * The response's HTTP status, once one arrived. Absent when the call
     * failed before a response (the fetch itself rejected).
     */
    status?: number;
    /**
     * What the call ran for, when the attribution engine
     * (`solid-js/attribution`) is enabled and knows: the interaction whose
     * handler made it (`kind: "interaction"`), the navigation whose data
     * needed it (`kind: "navigation"`, its `interaction` the click), the
     * effect or action step, the async landing whose recompute called again —
     * the engine's own origin object, so it IS `InteractionEvent.origin` /
     * `NavigationEvent.origin` / `HoldEvent.origin` by identity: an observer
     * puts the call under the interaction's record without a time join. Read
     * at dispatch, so a call made after an `await` in a handler stamps
     * nothing (the same escape a write there has). Absent without an engine.
     */
    origin?: ChangeOrigin;
    /**
     * The settled value is a body the caller drives — an async iterable
     * (a `live()` source, a generator result) — so `durationMs` covers the
     * call that produced it, not its consumption.
     */
    deferred?: true;
}
/**
 * The live half of a call, for in-process consumers — ONE object across
 * the call's records: the same `CallLive` is handed to the `"request"`
 * listener at the send and to the `"call"` listener at settle, filled in
 * as the call proceeds (`args` from the start, `request` at the send,
 * `response` and `result`/`error` at settle — filled on every settle,
 * whether or not a `"call"` record goes out, so a `"request"` listener
 * holding it reads the outcome off it too), so an in-process consumer
 * joins a call's request to its settle by identity — the way `origin`
 * joins a record to the interaction's — with no id-plus-time join and no
 * sequence number. One MUTABLE object shared by both records' listeners:
 * treat it as read-only — a write shows up on the other record's
 * listener. `error` is the value as thrown to the caller — a
 * decoded server error, or the transport's own failure. The bodies —
 * `request`, and `response` as an unread clone — are a body viewer's
 * (devtools' network panel), and are taken only while a listener asked for
 * them (`OBSERVE.records.subscribe("call", fn, { bodies: true })`, or the
 * same on `"request"` for the request alone): each costs the call a
 * reconstruction and a transient double-buffer of the payload, which a
 * consumer that reads ids, statuses and timings never pays. With no such
 * listener `request` is absent and `response` is the transport's own
 * object, consumed by its decode. Whether bodies are taken is read once,
 * as the call starts.
 */
export interface CallLive {
    args: unknown[];
    /**
     * Bodies opted in — by a `"call"` listener or a `"request"` listener
     * (`observed("call", "bodies") || observed("request", "bodies")`): the
     * request as dispatched — the final url and `RequestInit` (the
     * transport's headers, the `prepareRequest` hook applied), built into a
     * `Request` of the listener's own at the send, so its headers and body
     * are readable in full and reading them touches nothing the transport
     * sent. Set before the `"request"` record is delivered, so that listener
     * reads it too — and it is ONE `Request`, shared by the call's
     * `"request"` and `"call"` records: a body reads once, so a listener that
     * wants it reads through `request.clone()` (`live.request.clone().text()`)
     * and the other record's listener can still read it; a direct
     * `live.request.text()` leaves `bodyUsed` true for whoever reads next.
     * Built WITH the body only when the body has a shape a
     * second `Request` can hold without a competing consumer — `string`,
     * `URLSearchParams`, `FormData`, `Blob`, `ArrayBuffer` or a view of one
     * — and WITHOUT it otherwise (a `ReadableStream` or an async iterable,
     * the transport's streaming-upload contract: reconstructing one would
     * consume it ahead of the send), so the request then reads as bodyless.
     * Absent without the opt-in; when the call failed before the request was
     * built (argument serialization threw); when the address is relative and
     * there is no `location` to resolve it against (absent beats a URL that
     * was never sent); and when the reconstruction itself failed (an init
     * the `Request` constructor rejects but the configured `fetch`
     * tolerates) — a reconstruction never fails the call.
     */
    request?: Request;
    /**
     * The response: with bodies opted in, one with an UNREAD body — a
     * `clone()` taken as the response arrived, before the transport's
     * decode, so the listener reads status, headers and body while the
     * caller still gets its result from the original. The transport's own
     * object instead — status and headers readable, body consumed by the
     * transport's decode — without the opt-in, and, with it, for a response
     * whose clone would be a branch nobody drains: an event-stream response
     * (a `live()` source, `text/event-stream`, a connection open for the
     * page's life), a deferred result (a generator's stream, `deferred:
     * true`, served for the stream's life — its clone, taken before the
     * result's shape was known, is cancelled at settle), and a response the
     * `clone()` refused (one a configured `fetch` handed over already read).
     * A response a `responseHandler` claimed whose result is not a deferred
     * body — a non-live `application/x-frame-stream` frame render the frames
     * transport claims, say — keeps its clone, so under the opt-in the
     * clone's branch buffers that render until the listener reads it or
     * drops the record; live frames are `text/event-stream` and are never
     * cloned. Absent when the fetch itself rejected.
     */
    response?: Response;
    /** The settled value, when `outcome` is `"ok"`. */
    result?: unknown;
    /** The thrown value, when `outcome` is `"error"`. */
    error?: unknown;
}
export type CallListener = (event: CallEvent, live: CallLive) => void;
/**
 * One server-function request LEFT the browser — delivered on
 * `OBSERVE.records.subscribe("request", …)` at the send: after the
 * arguments were serialized and `prepareRequest` had its say, immediately
 * before the transport's `fetch` is handed the request. "Left" means
 * HANDED TO `fetch`, not that it reached the network: a `fetch` that
 * throws synchronously still has its `"request"` (and a `"call"` with
 * `outcome: "error"`). The `"call"` record of the same call follows at
 * settle; this one exists because that one cannot show a call that is
 * still in flight, or one that never settles (a hung fetch) — a network
 * panel's pending row. The two records share their `CallLive` by identity
 * (see `CallLive`): the object handed here is the object handed to the
 * `"call"` listener, so an in-process consumer joins them with no
 * id-plus-time join and no sequence number.
 *
 * Emitted only for a request that was handed over: a call that failed
 * before its request was built (argument serialization threw, or
 * `prepareRequest` did) emits no `"request"` — only its `"call"` settle; a
 * call an integration answered locally (a handler's `intercept`) made no
 * request and emits neither. A deferred or streaming result emits
 * `"request"` at the send and `"call"` at handoff, as today. Serializable;
 * `live.request` (under `bodies`) rides beside it.
 *
 * Listeners run synchronously, on the call's path, BEFORE the send: a slow
 * listener delays the fetch and the time it spends is inside the call's
 * `durationMs`. Read what is needed and hand the work off to a microtask
 * (the same guidance the engine's records give).
 */
export interface CallRequestEvent {
    /**
     * Which end recorded it. Only `"client"` exists today — the request left
     * the browser. The server half (the request arrived, ahead of its
     * `"invocation"`) is `"server"`, additive later, the way the `"frame"`
     * record has two halves.
     */
    side: "client";
    /** The function id — the same `id` the call's `"call"` and the server's `"invocation"` carry. */
    id: string;
    /** The function's source name, by the same rule as `CallEvent.name`. */
    name?: string;
    /**
     * `performance.now()` at the send — when the request was handed to
     * `fetch`, after serialization and `prepareRequest`. NOT the call's
     * `CallEvent.at`, which is when the call was made: the gap between them
     * is what building the request cost (an async `prepareRequest`
     * included), and `CallEvent.at + durationMs` is never before this.
     */
    at: number;
    /** `GET` for a GET-encoded read (`GET(fn)`), `POST` otherwise — as on `CallEvent`. */
    method: "GET" | "POST";
    /**
     * What the call ran for — the same object `CallEvent.origin` carries,
     * read at dispatch (see `CallEvent.origin` for the rule).
     */
    origin?: ChangeOrigin;
}
export type CallRequestListener = (event: CallRequestEvent, live: CallLive) => void;
interface FrameEventBase {
    /**
     * The frame id on the wire: the server function's id when the stream is a
     * server-function response (the same `id` that call's `"invocation"` and
     * `"call"` records carry), or what the producer named it; `""` for a bare
     * `renderToFrameStream` with no `frame` option.
     */
    id: string;
    /**
     * The stream version: as the producer stamped it on the server; as the
     * client restamped it on the client (the consumer owns versions — one
     * per stream a boundary consumed — so this is the number the frame's
     * stale-guard saw).
     */
    version: number;
    /** `performance.now()` at the stream's `start` chunk — written, or read. */
    at: number;
    /**
     * Start → `complete`, in milliseconds: the whole stream, fragments
     * included. On the client this is the body's read and apply — the
     * request that produced the response is the `"call"` record's time.
     */
    durationMs: number;
    /**
     * Start → the shell (`html`) chunk, in milliseconds: the time to first
     * content. Absent when the stream carried no shell (the server's
     * synchronous failure path).
     */
    shellMs?: number;
    /** Chunks between `start` and `complete` (exclusive), all types. */
    chunks: number;
    /** `fragment` chunks: `<Loading>` content that settled after the shell. */
    fragments: number;
    /** `slot` chunks: render-prop invocations the client fills. */
    slots: number;
    /**
     * Nested server-content regions (a server JSX slot argument): `html`
     * chunks addressed to a child frame id rather than the stream's own.
     */
    regions: number;
    /** `error` chunks: fragments that failed (their fallback still revealed), plus a sync failure. */
    errors: number;
}
/**
 * The server half of a `"frame"` record: one frame stream produced — a
 * server component rendered to the frame transport
 * (`renderServerComponent` / `renderToFrameStream`), from its `start`
 * chunk to its `complete` — delivered once it completed.
 */
export interface FrameProducedEvent extends FrameEventBase {
    side: "server";
    /**
     * `complete` — the render ran to the end (fragment failures, if any, are
     * in `errors`); `error` — the render threw synchronously, the stream
     * carried the failure as its only content and completed.
     */
    outcome: "complete" | "error";
}
/**
 * The client half of a `"frame"` record: one frame stream applied — a
 * frame-stream response read chunk by chunk into the frame host
 * (`applyFrameResponse`), from its `start` to its `complete` — delivered
 * once the stream ended. A single-flight response carries one stream per
 * frame it refreshed; each is its own record, as on the server.
 */
export interface FrameAppliedEvent extends FrameEventBase {
    side: "client";
    /**
     * The local id the chunks were applied under, when the consumer remapped
     * the producer's root id onto its own boundary (`applyFrameResponse`'s
     * `as` — the call's address, for the server-component transport).
     * Absent when applied under the wire id.
     */
    address?: string;
    /**
     * `complete` — the `complete` chunk arrived; `truncated` — the body ended
     * before it (the connection dropped, the producer abandoned the stream);
     * `error` — the read failed (a malformed chunk, a body error), with the
     * failure in `live.error`.
     */
    outcome: "complete" | "truncated" | "error";
}
/**
 * One frame stream, from whichever end observed it — delivered on
 * `OBSERVE.records.subscribe("frame", …)`; `side` says which. The two
 * halves share their shape (the same census, the same timings measured
 * where each stands), so a consumer joins them by `id` and `version` and
 * the difference is the wire.
 */
export type FrameEvent = FrameProducedEvent | FrameAppliedEvent;
/** The live half of a frame record. */
export interface FrameLive {
    /** The value thrown: the server's sync failure, or the client's read failure. */
    error?: unknown;
    /** Client only: the response the stream was read from. */
    response?: Response;
}
export type FrameListener = (event: FrameEvent, live: FrameLive) => void;
declare module "solid-js" {
    interface HostRecordTypes {
        /** Server-function executions, on the server — see `InvocationEvent`. */
        invocation: {
            event: InvocationEvent;
            live: InvocationLive;
        };
        /** Server renders — a document or a frame stream — see `RenderEvent`. */
        render: {
            event: RenderEvent;
            live: RenderLive;
        };
        /** Server-function calls, from the client — see `CallEvent`. */
        call: {
            event: CallEvent;
            live: CallLive;
        };
        /**
         * Server-function requests left, from the client — see
         * `CallRequestEvent`; the `live` is the call's own, shared with its
         * `"call"` record.
         */
        request: {
            event: CallRequestEvent;
            live: CallLive;
        };
        /** Frame streams, produced or applied — see `FrameEvent`. */
        frame: {
            event: FrameEvent;
            live: FrameLive;
        };
    }
}
export declare function settledPromise(value: unknown): Promise<unknown> | undefined;
export declare function isDeferredBody(value: unknown): boolean;
/**
 * The census of one wire message (frame-sink.ts), kept by either half so
 * both add up to the same numbers: a message counts once, and each record
 * by what it writes — the root's content (`""`) a shell (or, addressed to
 * a nested region, a region), `seg:<k>` content a fragment, `slot:<k>` a
 * slot, any `:error` record an error. The end of the response (`:complete`,
 * `:bound`) is not counted: a message writing only that is none.
 */
export declare function frameRecordCensus(event: FrameEventBase, message: {
    type?: string;
    r?: Record<string, any>;
}, own: boolean): void;
/** What the client runtime hands a call observation as the call proceeds. */
export interface CallObservation {
    /**
     * The request is about to be sent: the address and the final
     * `RequestInit` — what the transport's `fetch` receives, hook applied.
     * The `"request"` record is delivered from here.
     */
    request(url: string, init: RequestInit): void;
    /** The response arrived (before decode); its status goes on the record. */
    response(response: Response): void;
    /** The call settled as the caller sees it: the value returned, or the error thrown. */
    settle(outcome: "ok" | "error", value: unknown): void;
}
/**
 * Opens the observation of one server-function call from the client, as
 * the request is about to be built; the runtime reports the request as it
 * is sent (the `"request"` record), the response when it arrives and the
 * settle when the caller gets its answer (the `"call"` record). `undefined`
 * with no listener for either record or outside observe builds — the
 * runtime then does nothing extra, not even read the clock.
 */
export declare function observeCall(id: string, method: "GET" | "POST", args: unknown[], name?: string): CallObservation | undefined;
/** What the client's stream reader hands a frame observation. */
export interface FrameApplyObservation {
    /**
     * Every message read, after the consumer's remapping (`as`, `version`) —
     * `wireId` is the id the message carried before it.
     */
    chunk(chunk: {
        type?: string;
        id: string;
        version: number;
        r?: Record<string, unknown>;
    }, wireId: string): void;
    /**
     * The apply ended — cleanly, or with the failure it threw (a read that
     * failed, a chunk that would not parse, a host that rejected a chunk).
     */
    end(error?: unknown): void;
}
/**
 * Opens the observation of one frame-stream response on the client: every
 * `start` chunk opens a stream record (a single-flight response carries
 * several, in sequence), every chunk until its `complete` is counted to
 * it, and the record is delivered at `complete` — or at the body's end as
 * `truncated`, or at a read failure as `error`. `undefined` with no
 * listener or outside observe builds.
 */
export declare function observeFrameApply(response: Response): FrameApplyObservation | undefined;
export {};
