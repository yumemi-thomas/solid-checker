export interface CookieOptions {
    /** Cookie `Path` attribute. Defaults to `/`. */
    path?: string;
    /** Cookie `Domain` attribute. Emitted only when provided. */
    domain?: string;
    /** Cookie `Max-Age` attribute, in seconds (truncated to an integer). */
    maxAge?: number;
    /** Cookie `Expires` attribute. */
    expires?: Date;
    /** Emit the `HttpOnly` attribute. */
    httpOnly?: boolean;
    /** Emit the `Secure` attribute. */
    secure?: boolean;
    /** Cookie `SameSite` attribute, any case. */
    sameSite?: "lax" | "strict" | "none" | "Lax" | "Strict" | "None";
    /**
     * Emit the `Partitioned` attribute (CHIPS): a third-party cookie keyed to
     * the top-level site it was set under — the only third-party cookie that
     * keeps working as browsers finish removing the rest. Requires `secure`.
     */
    partitioned?: boolean;
}
/**
 * Parses a `Cookie` request header into a name → value map. Names and
 * values are `decodeURIComponent`-decoded (falling back to the raw text
 * when decoding throws — cookies set by other producers are not
 * necessarily percent-encoded); a quoted value keeps its content, per the
 * RFC 6265 grammar. `null`/empty input parses to an empty map.
 *
 * The read half of the platform gap — the blessed request-cookie read is
 * `parseCookieHeader(event.request.headers.get("cookie"))`.
 */
export declare function parseCookieHeader(header: string | null | undefined): Record<string, string>;
export declare function serializeCookie(name: string, value: string, options?: CookieOptions): string;
export declare const FLASH_COOKIE = "flash";
/** Whether a Cookie header carries a flash cookie (readable or not). */
export declare function hasFlashCookie(cookieHeader: string | null): boolean;
/** The raw encoded flash payload out of a Cookie header, if present. */
export declare function matchFlashCookie(cookieHeader: string | null): string | undefined;
/** The Set-Cookie value clearing the flash cookie after it has been read. */
export declare function clearFlashCookie(): string;
