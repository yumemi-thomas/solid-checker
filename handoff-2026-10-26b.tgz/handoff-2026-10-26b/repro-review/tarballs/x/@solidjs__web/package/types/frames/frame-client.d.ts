/**
 * Client frame runtime — the consumer side of a frame stream. A frame
 * renders server-owned content into a DOM boundary from a resident keyed
 * record store: chunks are writes, not events, so application is
 * prerequisite-driven and order-independent. Client-owned slot ranges
 * inside the boundary are preserved across server updates — the
 * version is a stale-guard only ("policy A"): newer content morphs in
 * place, and teardown is `dispose()`, never a version bump.
 *
 * EXPERIMENTAL — the frames/server-components surface ships as an
 * experimental preview, excluded from the 2.0 stability guarantee: API
 * shapes and the wire format may change between prereleases (RFC 11).
 * Every export in this module is `@experimental`.
 */
/**
 * Row ops for a live hole whose value is a `For`'s rows (#4064): the new
 * row count `n` and the rows that changed or were appended, as
 * `[index, html]`. A count below the range's truncates it.
 */
export type HoleRows = {
    n: number;
    r: [number, string][];
};
/**
 * A `data` message: one node of the response-scoped data table the
 * records' `{$ref}` args resolve through — not frame state (it never enters
 * the store), ordered ahead of the records that read it.
 * @experimental
 */
export type FrameData = {
    type: "data";
    id: string;
    version: number;
    key?: string;
    node?: unknown;
    initial?: boolean;
    /** Eval-style hydration script — only when produced with the hydration serializer. */
    payload?: string;
};
/**
 * The in-band tier announcement (frames savings pass §2; additive — RFC 11
 * addendum): the frames-client tiers the render first needed since the
 * last message left — `"regions"`, `"assets"`, `"trace"`, `"wire"` — on whichever chunk leaves next. The response head carries the
 * tiers minted before it (`X-Frame-Tiers`); a tier minted later rides
 * here. The client starts each named tier's load before applying the
 * chunk; a `data` chunk additionally AWAITS them (its node tree needs the
 * tier to decode). Absent on every chunk of a response that minted nothing
 * after its head, and ignored by a client that predates it.
 * @experimental
 */
export interface TierAnnouncement {
    tiers?: string[];
}
/**
 * One message of a frame stream on the wire, addressed by frame `id`: a
 * versioned batch of keyed records — the store write itself (`r`, see
 * `FrameWrite`) — or one of the messages that are not records: `start`
 * (a response's version opens on the address), `data` (a node of the
 * response's data table). Any message may carry `tiers` (see
 * `TierAnnouncement`).
 * @experimental
 */
export type FrameMessage = ({
    type?: undefined;
    id: string;
    version: number;
    r: Record<string, unknown>;
} | {
    type: "start";
    id: string;
    version: number;
    /** Observe tier: when the response's request went out (see `landing`). */
    startedAt?: number;
} | FrameData) & TierAnnouncement;
/**
 * One store write applied to a frame: `r` maps record keys to values (a
 * wire batch's own `r`) and `version` is the stream stamp — an older
 * version than the frame's current one is ignored.
 * @experimental
 */
export interface FrameWrite {
    version: number;
    r: Record<string, unknown>;
}
/**
 * Context passed to a slot callback.
 * @experimental
 */
export interface SlotContext {
    /**
     * True only for the hydration-attach invocation of an adopted
     * document-SSR range — the one call a consumer may answer with a claim
     * (`existing` IS the server-rendered output for these args). Unset on
     * stream-driven re-calls: those must render for real, or content the
     * re-call displaced (e.g. `{$frame}` region ranges) is dropped.
     */
    adopted?: boolean;
    /**
     * Whether this occurrence is a render-prop CALL (the producer placed it
     * with arguments — possibly empty — via a slot record) as opposed to a
     * direct-insert position. Consumers cannot tell from the resolved props
     * alone: an argless render prop and a direct insert both arrive as `{}`,
     * but one is a function to invoke and the other a value to place.
     */
    invoked?: boolean;
    /**
     * Register cleanup for when this occurrence's range is removed from the
     * server content, or the owning frame is disposed.
     */
    onCleanup(fn: () => void): void;
    /**
     * Live-props opt-in: a binding that registers here receives the
     * re-resolved props when a re-sent record's args CHANGE in value, instead
     * of the occurrence being re-called — the invocation's instance (and its
     * client state) survives the change. Register synchronously during the
     * invocation; one updater per occurrence (last registration wins). A
     * genuine re-call or unmount clears it before/with the binding it served.
     */
    onUpdate(fn: (props: Record<string, unknown>) => void): void;
    /**
     * The range's current interior — server-rendered client content on an
     * adopted document-SSR boot, or the previous output on a re-call. A
     * framework binding hydrates onto it (a claim: zero DOM mutation) or
     * replaces it.
     */
    existing: ChildNode[];
    /**
     * The range's own marker comments, when the occurrence has a placed range
     * — the anchor the fill owns its interior through: bind or place the
     * output before `end` (over `existing`) with the framework's insert
     * primitive. The frame never touches a range's interior itself (server
     * morphs protect slot ranges). Absent for a range whose end marker is
     * missing.
     */
    range?: {
        start: Comment;
        end: Comment;
    };
}
/**
 * Client content for a server-declared slot. Direct-insert occurrences
 * call it with empty props; render-prop occurrences pass the occurrence's
 * resolved args (primitives literal, `{$ref}` data resolved through the
 * host, `{$frame}` regions as frame elements). The fill owns its range: it
 * places or binds its output before `ctx.range.end`, over `ctx.existing`
 * (claimed in place on hydration), and disposes it through `ctx.onCleanup`.
 * The return value is not read.
 * @experimental
 */
export type Slot = (props: Record<string, unknown>, ctx: SlotContext) => void;
/** @experimental */
export interface Frame {
    /** Merge a write into the store and flush (morph/reveal/slot sync). */
    apply(write: FrameWrite): void;
    /** The active version, or undefined before the first apply. */
    readonly version: number | undefined;
    /** Read-only view of the resident record store. */
    readonly store: Readonly<Record<string, unknown>>;
    /** The stream's error record, if an `error` chunk arrived. */
    readonly error: unknown;
    /**
     * Re-key this live frame to a different boundary id (the mount-preserving
     * half of a call-site handoff): nothing tears down — the element, store,
     * and slot state stay — while leaving the old id stashes a retention
     * snapshot under it and joining the new id seeds/drains its retained
     * store and buffered chunks. Version affinity resets: histories are per
     * boundary id.
     */
    rebind(id: string): void;
    /**
     * Push a staged response's slot args into the live occurrences they
     * address, ahead of the records' real apply (see `FrameHost.preview`).
     * @internal
     */
    preview?(records: Record<string, unknown>): void;
    /** Tear down: slot cleanups cascade, later chunks are ignored. Idempotent. */
    dispose(): void;
}
/**
 * Routes a flat stream of addressed messages to frames by id, writing each
 * batch into the address's resident store (an address no frame has
 * registered for yet simply warms). `data` messages are response-scoped and
 * go to `applyData`; a `slot:` record's `{$ref}` args are resolved at the
 * write, through the response's data (a value, or a pending read the
 * response settles).
 *
 * An id may have several frames (the same server component mounted more
 * than once): chunks fan out to all of them, and a frame registering after
 * delivery is seeded from a sibling's store.
 * @experimental
 */
export interface FrameHost {
    register(id: string, frame: Frame): void;
    /** Remove one frame (or all frames of the id when `frame` is omitted). */
    unregister(id: string, frame?: Frame): void;
    apply(msg: FrameMessage): void;
    /**
     * The reactive half of a staged response (see
     * `createServerComponentHandler`): a batch's `slot:` records' args —
     * settled through its own response's table, as at a write — reach the
     * occurrences mounted under its id as re-resolved props into their live
     * bindings, while the store, the markup, and every structural change
     * wait for the batch's `apply`. Other records are ignored.
     * @internal
     */
    preview?(msg: FrameMessage): void;
    /** The first registered frame under the id, if any. */
    get(id: string): Frame | undefined;
    /**
     * The address as an async source: its first landing is the first flush of
     * the first response for it — the root content or its completion; the
     * stream's error is the source ERRORING (frames-rulings 3.3, A0
     * corollary 4 outward: the frame is one async value, and its `:error`
     * is that value rejecting, exactly as any `createAsync` that rejects). A
     * promise resolved at the write that lands it while that response is in
     * flight and REJECTED with the error record at an `:error` write;
     * `undefined` once the address has a landing to show (a later response
     * in flight then morphs over it — the committed value holds), or when
     * nothing has begun for the address. An errored address has no landing
     * to show: a read of it is a promise for the NEXT flight's landing — an
     * errored landing is not a landing for a fresh consumer, and the
     * consumer that reads it re-asks (the integration's `reset`). A mount's
     * covering `<Loading>` pends on this — and on nothing inside the frame —
     * exactly as it pends on any async source's first landing.
     */
    landing(id: string): Promise<void> | undefined;
    serialize(value: unknown): {
        $ref: string;
    };
    /**
     * See FrameHostOptions.revive. Assignable after creation: the frames
     * client's traces tier installs the container-trace reviver on the
     * shared host when its chunk loads (`@solidjs/web/frames/trace`).
     */
    revive?(value: unknown, claiming?: boolean): unknown;
}
/**
 * Options for `createFrameHost`.
 * @experimental
 */
export interface FrameHostOptions {
    /**
     * Backs `{$ref}` slot args (typically a codec data table's `resolve`).
     * Called at a `slot` chunk's write with the chunk's frame id and version
     * — the RESPONSE the record belongs to (data tables are response-scoped;
     * one response is one version of one id), so the integration answers from
     * that response's table and never a later one's. Answers the key's value,
     * or — for a key the response has not delivered yet — the table's own
     * PENDING READ: a promise marked `s = 0`, carrying `c` (the callbacks run
     * when it settles), that the key's `data` chunk settles (stamped `s`/`v`
     * as it does) and `closeData` rejects (frames-rulings 1.3; the L1 rule —
     * a value that never comes is an error, not a silence). The host counts
     * a record's pending reads so a fresh mount waits for them
     * (`record.pending`) and re-applies the record when the last settles.
     * `current` is the version the id's store is at — every version below it
     * is superseded, and an integration keeping a table per response may
     * drop theirs.
     */
    resolve?(ref: {
        $ref: string;
    }, frameId: string, version: number, current?: number): unknown;
    /** Test/host-side counterpart of `resolve`. */
    serialize?(value: unknown): {
        $ref: string;
    };
    /**
     * Receives each `data` chunk whole. Wire a codec table:
     * `applyData: c => table.apply(c)` (see `createJSONDataTable`); a table
     * per response keys on `chunk.version` (see `resolve` for `current`).
     */
    applyData?(chunk: FrameData, current?: number): void;
    /**
     * The response (one version of one id) has ended — its `complete`, or
     * its `error` with no key — and a key it never delivered never comes:
     * the integration closes that response's table so every pending read of
     * it rejects (`table.close(error)`, with the response's error record when
     * it ended by one). Called after the end chunk's own apply, so the frame
     * has the response's last word first.
     */
    closeData?(frameId: string, version: number, error?: unknown): void;
    /**
     * A lazily-loaded deserializer's load, awaited by the transport before it
     * delivers a `data` chunk or a `slot` chunk whose args carry a `{$ref}` —
     * `applyData`/`resolve` can assume the codec is resident when a chunk
     * that reads data arrives. Keeps codec weight out of the eager client
     * graph for responses that never carry serialized data.
     */
    prepareData?(): Promise<unknown>;
    /**
     * Revive protocol markers inside LITERAL slot args (values that are
     * neither `{$ref}` nor `{$frame}`) at arg-resolution time — the mount's
     * read of the record, where an adopted occurrence's claim can read the
     * revived value as the markup was rendered from it. Document-face
     * container traces ride this way — inline in the record, revived by the
     * integration (`reviveContainerTraces`) into live local containers.
     * `claiming` marks the args of an adopt-time mount — the occurrence is
     * about to hydrate server markup rendered from these values (the
     * materializer parks a trace's backlog beyond the snapshot the markup
     * shows until hydration ends — frames-rulings 3.6 (iii)).
     */
    revive?(value: unknown, claiming?: boolean): unknown;
}
/**
 * Options for `createFrame` / `createFrameElement`.
 * @experimental
 */
export interface FrameOptions {
    /** Register with this host under `id`, receiving routed/buffered chunks. */
    host?: FrameHost;
    id?: string;
    /** Client content keyed by prop name (occurrences resolve by prop). */
    slots?: Record<string, Slot>;
    /**
     * Adopt existing server-rendered DOM: the first apply morphs against it,
     * and slots sync immediately (hydration attach) — a document-SSR boot
     * needs no chunk.
     */
    adopt?: boolean;
    /**
     * With `adopt`: leave the slot occurrences unmounted for the client's
     * deferred-hydration driver (`setDeferDriver`) to mount on demand. Region
     * frames inside such a frame inherit it. Ignored with no driver set.
     * @internal
     */
    defer?: boolean;
    /** Called after each apply flush (tests/telemetry). */
    onApply?(info: {
        version: number;
        reason: "materialize" | "morph" | "reveal" | "error";
    }): void;
    /**
     * Wraps element-claim sweeps (`a[href]`/`form[action]` in materialized
     * server content — and only those) so claim consumers register their
     * per-element cleanup against the boundary's reactive owner, e.g.
     * `fn => runWithOwner(owner, fn)`. Nested region frames inherit it.
     * Without it, sweeps run under whatever owner is current (none, for
     * streamed chunks).
     */
    ownerScope?<T>(fn: () => T): T;
    /**
     * Boundary-driven segment reveal. `#revealSegment` hands the placeholder
     * seam to this hook: the binding reconstructs a client `<Loading>` there —
     * `fallback` is the placeholder's own template content (shown while
     * holding), `content()` materializes the segment and renders its client
     * fills INSIDE the boundary so their readiness gates the reveal — and
     * inserts it before `before`. An unboundaried async fill suspends up to
     * that boundary and is covered instead of orphaned; one boundary per
     * revealed segment, i.e. per author-placed `<Loading>`. Omitted, the
     * default seam inserts `content()` before `before` at once and removes
     * `before` (the framework-agnostic swap: no boundary, no reactive reveal).
     */
    reveal?(seam: {
        before: Node;
        fallback: Node[];
        content: () => Node | DocumentFragment;
    }): void;
    /**
     * Adopt path only. Called when a sync leaves an adopted occurrence
     * waiting — for its args record, for a read of it to settle, or for the
     * tier its mount needs to load — while none was before; returns the
     * release, called when a sync leaves none waiting or the frame disposes. The
     * integration registers the hold with whatever counts its page as not
     * yet settled (hydration-done counts it as a pending boundary —
     * frames-rulings 3.1): a claim the frame has not made yet is page work
     * still pending. The record's delivery is the integration's to observe
     * (the document declares it at the marker and settles it — see
     * `adoptBoundary`); the frame only re-syncs on the write.
     */
    hold?(): () => void;
}
export declare const CLAIMED_ELEMENTS = "a[href], form[action]";
export declare const claimedAttr: (name: any) => boolean;
export declare const SLOT_START: RegExp;
export declare const SLOT_END: RegExp;
export declare const slotEnd: (id: any) => string;
/**
 * Whether a slot arg value is an async value passed whole (a promise or an
 * async iterable) — DR-2's value tier. The server never resolves these to
 * dead values; the client suspends at the consumption read.
 * @internal (the client entry's)
 */
export declare function isAsyncValue(v: any): boolean;
/** @experimental */
export declare function createFrameHost(options?: FrameHostOptions): FrameHost;
/**
 * The bubbling DOM event a frame dispatches from its parent element after
 * server content lands in the document (root materialize/morph, segment
 * reveal, fallback materialization) — `detail: { id, version, reason }`.
 * Document-level listeners (router affordance reflection, scroll
 * restoration) react to server-driven DOM changes without a
 * MutationObserver; nested region frames dispatch too and the event
 * bubbles, so one listener sees every boundary. Client-side renders never
 * fire it — client code has reactivity to subscribe with.
 */
export declare const FRAME_APPLIED_EVENT = "frame:applied";
/**
 * A frames-client tier's module, as its loader resolves it: its exports are
 * the tier's appliers — the functions the runtime dispatches to once the
 * module is resident (the regions tier's `resolve` / `bind` / …, the assets
 * tier's `gate` / `apply`) — and the optional `install()` runs once at the
 * load, for state that lives outside the runtime's dispatch (the traces
 * tier sets the shared host's `revive`). The index signature is what lets a
 * module with no `install` — a module whose exports are all appliers — be
 * one (TypeScript's weak-type rule would otherwise reject it).
 * @experimental
 */
export interface TierModule {
    install?(): void;
    [applier: string]: unknown;
}
export declare const tierLoaders: Record<string, () => Promise<TierModule>>;
/** @internal */
export declare const tierLoads: Record<string, Promise<void> & {
    r?: any;
}>;
/**
 * Deferred hydration (see client.ts `installServerComponents`): while a
 * driver is installed, an adopting frame with slots mounts NO occurrence at
 * adoption — no walk, no record resolution, no fill — and hands itself to
 * the driver, which mounts occurrences when an event lands in one
 * (`mountEnclosing`), before a write lands (`mountDeferred` with no
 * deadline) and in idle slices (`mountDeferred` with one). Unset, every
 * frame mounts at adoption.
 * @internal
 */
export declare let deferDriver: ((frame: any) => void) | null;
/** @internal */
export declare function setDeferDriver(driver: ((frame: any) => void) | null): void;
/**
 * @internal Dev only: wraps every deferred occurrence mount, with the claim
 * scope (the document frame's site) and the occurrence id — the frames
 * client's identity-drift check (client.ts).
 */
export declare let deferMountWatch: ((site: string, id: string, mount: () => void) => void) | null;
/** @internal */
export declare function setDeferMountWatch(watch: ((site: string, id: string, mount: () => void) => void) | null): void;
/** @internal The live frames still owing their adoption-time mounts, outermost first. */
export declare function deferredFrames(): any[];
/** @internal Deferred hydration finished page-wide: every frame's adoption hold lifts. */
export declare function releaseDeferHolds(): void;
/** @internal The innermost live frame whose element contains `node`. */
export declare function liveFrameAt(node: Node): any;
/**
 * Start (or join) a tier's load. Idempotent per name; a name with no loader
 * is resident already and resolves at once. Resolves once the module has
 * installed and every live frame has been flushed.
 * @internal The frames client's own seam (the announcement reads call it).
 */
export declare function prepareTier(name: string): Promise<void> & {
    r?: any;
};
/**
 * Whether a tier's code is resident — eager (no loader: `true`), or
 * installed (its module). A tier that is neither has its load started here
 * (the un-announced fallback: detection at the readiness check), and the
 * caller holds. A tier dispatched off the stamp (`assets`) needs its loader
 * wired — the client entry does; a spec driving this module directly wires
 * and warms it (see frames-assets-client.spec).
 */
/**
 * A call is about to go to the wire on a page that shows frames: its answer
 * will most likely land over content (a navigation, a refetch), and that
 * morph rides the wire tier — start its load now, so it races the request
 * instead of following the response's header.
 * @internal
 */
export declare const prepareMorph: () => Promise<void> & {
    r?: any;
};
export declare function createFrame(boundary: Element, options?: FrameOptions): Frame;
export declare const FRAME_TAG = "solid-frame";
export declare const FRAME_ID_ATTR = "data-fid"; /**
 * Create a boundary/region ELEMENT and bind a host-registered frame to it.
 * The frame mounts INTO the element (server content is its children, morphed
 * in place). Because the boundary is a real node, `insert` places the
 * returned `element` in any position — single, array, or fragment — with no
 * special-casing. One frame per element; lifecycle belongs to the creator via
 * `dispose()` (register it with your owner's cleanup).
 * @experimental
 */
export declare function createFrameElement(options: FrameOptions): {
    readonly element: Element;
    readonly frame: Frame;
    dispose(): void;
};
/**
 * Create a bare boundary/region element (no frame bound yet). `<solid-frame>` is
 * inlined as `display:contents` — not a stylesheet or custom-element
 * registration — so it holds before any bundle loads and needs nothing
 * defined: an undefined custom element is inert HTMLUnknownElement, and
 * `display:contents` makes it generate no box, so its children lay out in the
 * frame's parent.
 *
 * Exported (with `isFrameElement` and `eachInRange`) for the regions tier
 * (`regions-tier.ts`), which bundles its own copy of these pure helpers;
 * the eager entry re-exports none of them.
 * @internal
 */
export declare function makeFrameElement(id: any): HTMLElement;
/** Whether `node` is a frame boundary/region element (carries our id attr).
 *  @internal */
export declare function isFrameElement(node: any): any;
/** Parse an HTML string into a document fragment, preserving comments. */
export declare function parseFragment(html: any): DocumentFragment;
/** The `<!--pl-KEY-->` comment closing a placeholder range, or null. */
export declare function rangeClose(start: any, id: any): any;
/**
 * Walk a slot range's interior — every node between `start` and the range's
 * end marker — calling `cb` on each. The next sibling is captured before the
 * callback runs, so callbacks may detach the node. Returns the end marker
 * (null if the range is truncated).
 * @internal (exported for the regions tier — see `makeFrameElement`)
 */
export declare function eachInRange(start: any, key: any, cb: any): any;
/** If `node` is a `slot:<id>:start` comment, return its id; else `null`. */
export declare function slotStartId(node: any): string;
export declare function preservesOpen(el: any): boolean;
/** The sibling immediately after the `slot:<id>:end` marker for `start`. */
export declare const afterRange: (start: any, id: any) => any;
