import { getOwner, createComponent, untrack, merge as mergeProps } from "solid-js";
import type { ClientErrorHook, Owner } from "solid-js";
import { effect, memo } from "./render.js";
import { JSX } from "./jsx.js";
import type { RequestEventLocals, HydrationWriter, HydrationValue, LinkClaimHandler } from "./server.js";
import type { TraceContext } from "./trace.js";
type MountableElement = Element | Document | ShadowRoot | DocumentFragment | Node;
/**
 * A head tag descriptor. Props values may be getters (reactive on the
 * client); `children` is the text body. `key` overrides the built-in dedupe
 * identity (`title` is a hard singleton that `key` cannot fork).
 *
 * Getters must be plain reads: they evaluate inside registry-owned
 * computations here and at flush time on the server, so a getter that
 * allocates a reactive owner (`createMemo`, a `children()` helper) consumes
 * a hydration id slot on one side only and desyncs every id allocated after
 * the `useHead` call. Create such helpers eagerly at component position and
 * read them from the getter. See docs/head-management-rfc.md.
 */
export type HeadTag = {
    tag: "title" | "meta" | "link" | "style" | "script" | "base";
    props: Record<string, any>;
    key?: string | (() => string);
};
export type AssetDescriptor = {
    type: "style";
    href: string;
    attrs?: Record<string, string>;
} | {
    type: "inline-style";
    id: string;
    content?: string;
    attrs?: Record<string, string>;
} | {
    type: "module";
    href: string;
} | ExclusiveAssetDescriptor<any>;
export interface ExclusiveAssetDescriptor<T> {
    policy: "exclusive";
    key: string;
    value: T;
    get(): T;
    set(value: T): void;
}
/**
 * Registry entry returned by `warmAsset`. Stylesheet entries carry load
 * tracking for the client reveal gate (docs/client-css-reveal-gating.md):
 * `loadPromise` resolves on load OR error (never rejects) — an errored
 * sheet releases the gate, parity with the server gate.
 */
export interface AssetEntry {
    loadState?: "pending" | "loaded" | "errored";
    loadPromise?: Promise<void>;
}
/**
 * See the server entry's `ResponseStub` — the shape of the mutable response
 * head integrations expose as `event.response` via module augmentation.
 */
export interface ResponseStub {
    status?: number;
    statusText?: string;
    headers: Headers;
    /**
     * Set by the integration once the response head has been derived/sent
     * from this stub (status/headers can no longer change); consumers must
     * treat later writes and cleanup-time retractions as no-ops.
     */
    committed?: boolean;
}
/**
 * See the server entry's `RequestEventLocals` — the augmentable type of
 * `RequestEvent.locals`. Re-exported (not re-declared) so both entries
 * share ONE interface identity and a single augmentation reaches every
 * `locals`, whichever entry typed the event.
 */
export { RequestEventLocals } from "./server.js";
export type { HydrationWriter, HydrationValue, LinkClaimHandler } from "./server.js";
export interface RequestEvent {
    request: Request;
    locals: RequestEventLocals;
}
export type { CookieOptions } from "./cookies.js";
export type { CallEvent, CallListener, CallLive, CallRequestEvent, CallRequestListener, FrameAppliedEvent, FrameEvent, FrameListener, FrameLive, FrameProducedEvent, InvocationEvent, InvocationListener, InvocationLive, RenderEvent, RenderListener, RenderLive, RenderRoute } from "./observe.js";
export type { TraceContext, TraceProvider } from "./trace.js";
export type { ServerFunction, ServerFunctionMetadata, ServerFunctionRPC } from "./server-functions/shared.js";
export declare const waitAsset: (promise: Promise<unknown>) => void;
export { DOMWithState, ChildProperties, DOMElements, SVGElements, MathMLElements, VoidElements, RawTextElements, Namespaces, DelegatedEvents } from "./constants.js";
type CSPNonce = string | {
    script: string | false;
    style: string | false;
};
/** Client stub — hydration bootstrap is a server-only emit. */
export declare function generateHydrationScript(_options?: {
    eventNames?: string[];
    nonce?: CSPNonce;
}): string;
/** Client stub — valid JSX component, renders nothing. */
export declare function HydrationScript(_props?: {
    nonce?: CSPNonce;
    eventNames?: string[];
}): null;
export { effect, memo, untrack, getOwner, createComponent };
/**
 * Compiler-emitted prop-spread helper. The JSX transform emits
 * `mergeProps(...)` when compiling prop spreads on components — not a
 * user-facing API. Application code should import `merge` from `solid-js`.
 * @internal
 */
export { mergeProps };
export declare const getRequestEvent: () => RequestEvent | undefined;
/** Client stub — values are written by the server render. See the server entry. */
export declare const getHydrationWriter: () => HydrationWriter | undefined;
/**
 * Removes and returns the value the server render wrote under `key` with
 * `getHydrationWriter().write(key, value)`, or `undefined` when the page
 * carries none (or it was already taken). A written promise arrives as
 * `"pending"` until its settlement streams in, then as `"resolved"` or
 * `"rejected"`. Readable before `hydrate()` runs and after hydration has
 * ended. Server: `undefined`.
 *
 * The page's values live on `globalThis._$HY.r`; a test seeds them with
 * `globalThis._$HY = { r: { "sq:key": value } }`.
 */
export declare function takeHydrationValue<T = unknown>(key: string): HydrationValue<T> | undefined;
/**
 * Client stub — a render's link handler is set during server rendering
 * (see the server entry's `setLinkClaim`). Always `false` here, so a router
 * can call it unguarded from isomorphic setup code.
 * @internal
 */
export declare function setLinkClaim(_handler: LinkClaimHandler | undefined): boolean;
/**
 * Whether the server render that produced this document ran a link handler
 * (`setLinkClaim`), so its anchors carry the server's link state
 * (`aria-current="page"`, `data-active`) in the HTML. Reads the `links`
 * hydration record the render wrote once; non-destructive, readable before
 * and after hydration. `false` on a page rendered without the router — the
 * absence of link state on an anchor then means nothing, and a link
 * consumer must resolve it itself. Server: `false`.
 * @internal
 */
export declare function hasServerLinkState(): boolean;
/**
 * Client stub — the trace a request belongs to is a server-side reading
 * (the incoming `traceparent`, the render's origination); the browser SDK
 * that continues it reads the document's `<meta>`/`Server-Timing` instead.
 */
export declare const getTraceContext: () => TraceContext | undefined;
export { parseCookieHeader, serializeCookie } from "./cookies.js";
export { clearFlashCookie, hasFlashCookie } from "./cookies.js";
export { getServerFunctionMetadata, getServerFunctionRPC, isServerFunction } from "./server-functions/registry.js";
/**
 * Renders a component tree into a DOM element. Returns a dispose function
 * that tears the tree down and cleans up reactive scopes when called.
 *
 * The top-level insert is queued via `{ schedule: true }` so its initial
 * DOM attach goes through the effect queue rather than executing inline.
 * This lets the mount participate in transitions: if an uncaught async
 * read surfaces during the initial render (no `Loading` ancestor absorbs
 * it), the mount is held by the transition and attaches atomically once
 * all pending settles. On the no-async happy path the tail `flush()`
 * drains the queued callback so the attach is synchronous by the time
 * `render()` returns. The dev enforcement window scopes
 * `ASYNC_OUTSIDE_LOADING_BOUNDARY` to the initial mount only.
 */
export declare function render(code: () => JSX.Element, element: MountableElement, init?: JSX.Element, options?: {
    owner?: unknown;
    renderId?: string;
    /**
     * This root's client error hook, ahead of `configureClientErrors`':
     * every failure an error boundary under it renders a fallback for —
     * the one event no global handler sees (an uncaught error halts the
     * reactive system and reaches `reportError` / `window.onerror`). Once
     * per error object; no return — the client has no wire to map for.
     */
    onError?: ClientErrorHook;
}): () => void;
export declare function template(html: string, flag?: 1 | 2): () => Element;
export declare function delegateEvents(eventNames: string[]): void;
export declare function registerDelegatedRoot(root: MountableElement): void;
export declare function unregisterDelegatedRoot(root: MountableElement): void;
export declare function registerDelegatedContainer(container: MountableElement, owner?: MountableElement): void;
export declare function unregisterDelegatedContainer(container: MountableElement, owner?: MountableElement): void;
/**
 * Runs `fn` as a handler of the DOM event `e`, inside the interaction frame
 * the runtime opens for `e` — the one its own listeners for `e` run in. A
 * listener the runtime did not attach (a router's `document` click handler,
 * analytics, drag-and-drop) wraps its body in this, so its work joins the
 * same interaction record as the component handlers for the same event
 * instead of running outside one. In production builds this is `fn()`.
 *
 * Use it for listeners that respond to the user (`click`, `submit`,
 * `keydown`), not for passive ones (`mousemove`, `focusin` preloads), which
 * would each record an interaction.
 *
 * @example
 * ```ts
 * document.addEventListener("click", e =>
 *   dispatchAsInteraction(e, () => handleAnchorClick(e))
 * );
 * ```
 */
export declare function dispatchAsInteraction<T>(e: Event, fn: () => T): T;
export declare function getDelegatedRoot(node: MountableElement): MountableElement | undefined;
export declare function setProperty(node: Element, name: string, value: any): void;
/**
 * A stateful DOM property write (`input.value`, `input.checked`,
 * `option.selected`, `video.muted`, ...) from dev-compiled, non-hydratable
 * DOM output: exactly `node[name] = value`, which is what production
 * output inlines. The dev runtime checks it first and warns
 * (`UNCOMMITTED_INPUT_OVERWRITTEN`) when it re-applies an unchanged bound
 * value over an edit the user never committed to the signal. Production
 * compile output never imports it, so it tree-shakes away.
 *
 * @internal Compiler output only.
 */
export declare function setStatefulProperty(node: Element, name: string, value: any): void;
/**
 * Options for `registerElementClaim`.
 * @internal
 */
export type ElementClaimOptions = {
    /**
     * Attribute names whose compiler-owned writes re-claim an already claimed
     * element, as plain names: `href` covers the `href` attribute, the
     * `prop:href` property path and the `xlink:href` namespaced path alike.
     * Defaults to `["href", "action"]`. The write sites consult the union of
     * every registered consumer's set.
     */
    attributes?: readonly string[];
}; /**
 * Register a consumer for compiler-emitted element claims. Compiled DOM
 * output claims navigation-relevant elements (`a[href]`, `form[action]`)
 * once at mount, after their initial attributes are applied — so a handler
 * sees the element's final initial attributes and is told about one mount
 * exactly once. Afterwards compiler-owned writes to an attribute in the
 * consumer's declared set (`options.attributes`, default `href`/`action`;
 * `prop:href` and `xlink:href` map to `href`) re-invoke the handlers — so
 * handlers must be idempotent and must check the element's relevance
 * themselves. Handlers run under the reactive owner the element was created
 * with; scope per-element state and cleanup through your own reactive
 * system. Dormant until registered — without a handler the emitted claims
 * are null checks. Returns an unregister function.
 *
 * Integration plumbing (routers register the consumer); not meant for
 * application code.
 * @internal
 */
export declare function registerElementClaim(handler: (element: Element) => void, options?: ElementClaimOptions): () => void;
export declare function claimElementTree<T extends Node>(root: T): T;
export declare function claimElement<T extends Element>(node: T, owner?: Owner | null): T;
export declare function setAttribute(node: Element, name: string, value: string): void;
export declare function setAttributeNS(node: Element, namespace: string, name: string, value: string): void;
export declare function className(node: Element, value: JSX.ClassValue, prev?: JSX.ClassValue): void;
export declare function addEvent(node: Element, name: string, handler: EventListener | EventListenerObject | (EventListenerObject & AddEventListenerOptions), delegate: boolean): EventListener | EventListenerObject | void;
export declare function style(node: Element, value: {
    [k: string]: string;
}, prev?: {
    [k: string]: string;
}): void;
/** Compiler-emitted primitive; not for hand-written code. @internal
 *
 * Read an object-valued `style` / `class` binding ONE layer deep, TRACKED, in
 * the compute half of its effect. (Not solid-js's `snapshot()`, which is a
 * deep, untracked structural copy.) `style()` and `className()` enumerate their object in the
 * effect's untracked commit phase, so a proxy-backed object (a store
 * sub-object, merged props) was identity-reactive only: in-place key
 * mutations never re-applied and every leaf read tripped
 * STRICT_READ_UNTRACKED in dev. The compiler wraps the compute value of a
 * non-inline `style={expr}` / `class={expr}` in this; spread() applies it to
 * those two keys as it copies. Inline literals never get here — they compile
 * per property. Identity passthrough for strings and plain objects (a fresh
 * literal is already the compute's own); a proxy is copied with ONE
 * `ownKeys` trap (its own trap keeps the key set tracked) plus one tracked
 * read per key; a clsx-style class array is re-mapped element-wise (className
 * allocates for an array anyway; measured at parity).
 *
 * The proxy's keys are read with `Reflect.ownKeys` directly — what
 * `sourceKeys(value, SOURCE_PROXY)` resolves to by definition (`leafOf` is
 * the identity for a proxy kind; `leafKeys` answers a proxy with one
 * `ownKeys` trap) — rather than through `sourceKeys`, whose kind argument is
 * a runtime value: calling it here retained the merge/omit view walkers
 * (`collectKeys`, `mergeKeysOf`, `hiddenByAny`, …, ≈ 1.1 KB minified) on
 * every compiled page with a dynamic `class`/`style`, reached by nothing
 * (hydration-split-measured.md, candidate (e)). `spread()` still reads its
 * sources through `sourceKeys`, so a page with an element spread keeps them. */
export declare function readShallow(value: unknown): unknown;
/** Compiler-emitted primitive; not for hand-written code. @internal */
export declare function setStyleProperty(node: Element, name: string, value: any): void;
export declare function spread(node: Element, sources: unknown[], skipChildren?: Boolean, skip?: (key: string) => boolean, name?: string, loc?: string): void;
export declare function spread<T>(node: Element, accessor: T, skipChildren?: Boolean, skip?: (key: string) => boolean, name?: string, loc?: string): void;
export declare function dynamicProperty(props: unknown, key: string): unknown;
export declare function applyRef<T extends Element = Element>(r: ((element: NoInfer<T>) => void) | ((element: NoInfer<T>) => void)[], element: T): void;
export declare function ref(fn: () => ((element: Element) => void) | ((element: Element) => void)[], element: Element): void;
/** Compiler-emitted primitive; not for hand-written code. @internal */
export declare function scope<T extends () => any>(fn: T): T;
export declare function installHydrationRuntime(): void;
/**
 * Compiler-emitted primitive; not for hand-written code.
 * @internal
 */
export declare function insert<T>(parent: MountableElement, accessor: (() => T) | T, marker?: Node | null, init?: JSX.Element, options?: {
    /**
     * Live accessor for the slot's logical host in the source tree (portals).
     * Each top-level node the slot manages is tagged with a `_$host` getter
     * backed by this accessor so delegated events retarget correctly.
     */
    host?: () => Node | null;
    /** Defer the insert effect to the queue instead of running it inline. */
    schedule?: boolean;
    /**
     * Label for the hole's render effects (the outer and, for a nested
     * accessor, the inner unwrapping effect) — the compiler emits the parent
     * tag as written under `sourceNames.bindings` (`div.children`). Dev and
     * observe runtimes carry it on the node; production ignores it.
     */
    name?: string;
    /**
     * Source location of the hole (`src/App.tsx:14:7`, root-relative
     * `file:line:col`) — the compiler's `sourceNames` `locations` kind. Dev
     * and observe runtimes carry it on the node for console reports and
     * diagnostic events; production ignores it.
     */
    loc?: string;
}): JSX.Element;
export declare function assign(node: Element, props: any, skipChildren?: Boolean, prevProps?: any, skipRef?: Boolean): void;
export declare function warmAsset(descriptor: AssetDescriptor): AssetEntry | undefined;
export declare function acquireAsset(descriptor: AssetDescriptor): () => void;
export declare function useHead(tag: HeadTag | HeadTag[] | (() => HeadTag | HeadTag[])): void;
/**
 * Resumes a server-rendered tree on the client, attaching event listeners
 * and reactive bindings without reconstructing the DOM. Returns a `dispose`
 * function that tears down reactive scopes (DOM nodes are left in place).
 *
 * Use this when the page HTML was produced by `renderToString` or
 * `renderToStream`. For client-only apps, use `render` instead.
 *
 * Pass `options.renderId` to hydrate one of multiple roots emitted by a
 * server render that used the same id.
 *
 * When the server renders a full document but the client hydrates only the
 * app subtree, the server must give that subtree its own id namespace: wrap
 * the document shell in `<NoHydration>` and re-enter with `<Hydration>`
 * around the app. Otherwise the app's hydration ids are allocated under the
 * document component's owner tree and this walk can never claim them.
 */
export declare function hydrate(fn: () => JSX.Element, node: MountableElement, options?: {
    renderId?: string;
    owner?: unknown;
    onError?: ClientErrorHook;
}): () => void;
export declare function getNextElement(template?: () => Element): Element;
export declare function getNextMatch(start: Node, elementName: string): Element;
export declare function getNextMarker(start: Node): [Node, Array<Node>];
export declare function getFirstChild(node: any, expectedTag: any): any;
export declare function getNextSibling(node: any, expectedTag: any): any;
export declare function runHydrationEvents(): void;
/**
 * Installs the server-component half of hydration — solid's
 * (`enableServerComponentHydration`: the hold, the claim window, fragment
 * ownership, the ledger's published answer) and this runtime's two terms of
 * the claim walk:
 *
 * - `sharedConfig.claimRoots` (ruling 95): a claimed tree isn't always IN
 *   the document — a frame adoption whose slot fill resolved async claims
 *   its server-rendered range after a pending boundary displaced it
 *   (re-inserted on reveal). Such claim scopes declare their roots, and
 *   descent from one is as claimed as being connected; fresh clones
 *   descend from neither.
 * - The root sweep's frame exclusion (ruling 97): frame regions
 *   (`data-fid` — the frame runtime's element brand, an importless
 *   duplicate like FRAME_ID_ATTR in frame-client/frame-sink) are another
 *   layer's property. Their fills claim through their own windows on their
 *   own schedule (a lazy route module may adopt long after the root
 *   completes), so collecting them in the ambient sweep only sets up the
 *   completion sweep to report legitimately-late claims as unclaimed.
 *   Whether the root has frames is one question about the page, not one
 *   per keyed node: found once per sweep, containment-tested against the
 *   list rather than `closest("[data-fid]")` from every node.
 *
 * The same shape as `hydrate()` — solid's half, then this runtime's — one
 * call for the integration. Before `hydrate()` runs its root sweep (the
 * frames client calls it from `installServerComponents()`, which precedes
 * `hydrate()` in every entry) and again wherever it re-attempts its reveal
 * hook; idempotent. Cross-package wiring; not for application code.
 *
 * @internal
 */
export declare function installServerComponentHydration(): void;
export declare function getHydrationKey(): string | undefined;
export declare const RequestContext: unique symbol;
