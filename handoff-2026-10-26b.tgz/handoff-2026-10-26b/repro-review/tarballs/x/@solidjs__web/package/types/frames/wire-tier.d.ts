import type { FrameHost, FrameHostOptions } from "./frame-client.js";
/**
 * A frame's mount as the live appliers reach it (the frame's `#live`):
 * `e` its element, `t` its live-target cache, `c` its claim, `k` its slot
 * index builder, `s` what each hole's range shows, `x` the give-up for a row-op record (mark it spent,
 * cancel the connection so the resume re-sends the hole whole); `w`, in
 * dev builds only, the diagnostic for a hole whose closing comment is gone
 * (this chunk is built once for every condition, so the gate is the eager
 * client's).
 */
interface LiveMount {
    e: Element;
    t: Map<string, Node>;
    c: unknown;
    k(found: Map<string, any>): void;
    s(): Record<string, string>;
    x(key: string, record: unknown): void;
    w?: false | ((marker: string, open: Node) => void);
}
/**
 * The host the handler hands over: the frame host, carrying the lazily
 * loaded deserializer's load (`prepareData`) the transport awaits before a
 * chunk that reads data — forwarded unchanged to the connection's proxy.
 */
type Host = FrameHost & Pick<FrameHostOptions, "prepareData">;
/** A live loop's wire slot (see `LIVE_WIRE` in server-functions/shared.ts). */
interface WireSlot {
    connection: Connection;
    open(body: ReadableStream<Uint8Array> | null): {
        next(): Promise<IteratorResult<string>>;
        cancel?(reason?: unknown): unknown;
    };
}
/** The connection slot the loop renews per connect (`wire.connection`). */
interface Connection {
    ended?: Promise<ConnectionEnd>;
    cancel?(reason: Error): void;
    done?: boolean;
}
/** How a connection ended, as the loop reads it off `connection.ended`. */
interface ConnectionEnd {
    open: number;
    error: Error;
    sweep(): void;
    close(): void;
}
/**
 * Ledger upkeep for an applied content record (the frame's `#recordHave`
 * hands every one here): `""` is the root and RESETS the ledger to the
 * root's digest and hole map; any other key takes the record's digest and
 * the map of holes inside it. A record without a digest (an older
 * producer) leaves the entry as it was. Without a ledger (no digest-
 * carrying root applied) there is nothing to keep — the next resume is a
 * full snapshot either way.
 * @internal
 */
export declare function have(frame: object, key: string, record: {
    digest?: string;
    holes?: Record<string, string>;
}): void;
/**
 * The have-list of what a mount shows — the server-minted digests of the
 * root skeleton under `""`, each live hole and attr hole by ledger key,
 * each revealed fragment by name. `undefined` when the content's provenance
 * carried no digests, or applied before this tier was resident (a
 * document-adopted interior, a plain call's response): a resume then takes
 * the full snapshot.
 * @internal
 */
export declare function haveOf(frame: object): Record<string, string> | undefined;
/**
 * Encodes a have-list for the header: `key=digest` pairs, comma-joined
 * (keys never contain either separator; the root's key is empty).
 * `undefined` when the list is empty or over budget.
 * @internal
 */
export declare function encodeHaveList(have: Record<string, string>): string | undefined;
/**
 * What a `live` (re)connect of a call resumes from (the handler's
 * `resume`): the address's version ordinal as the position and, when a
 * mount shows the address with a ledger, its have-list under
 * `FRAME_HAVE_HEADER` — omitted over budget, so the render is a full
 * snapshot then. `undefined` when nothing here has shown the call. The
 * ledger is the MOUNT's (it tracks what the DOM shows); the first mount
 * under the address speaks for all — they show the same store.
 * @internal
 */
export declare function resume(host: FrameHost, info: {
    id: string;
    args: unknown[];
}, versions: Map<string, number>): {
    position: string;
    headers?: Record<string, string>;
} | undefined;
/**
 * Supersession (§9.5, Client face 4): a newer version for the address from
 * another response — a getter refetch, a preload, a mutation's region —
 * makes the open connection's later chunks inert under the stale-guard, so
 * it is cancelled and the loop reconnects from the death. The handler's
 * `bump` calls this for every bump, the loop's own reconnect included
 * (whose predecessor has already ended and left the slot).
 * @internal
 */
export declare function cancel(host: object, address: string): void;
/**
 * The live arm of the handler's `handle` (§9.5, Client face 2): the binding
 * resolves the call now, and the response's lifetime — its end and how it
 * ended — reaches the loop through its wire slot, so frames CONSUME the
 * loop rather than mirror it: death → the loop's backoff and re-invoke,
 * which resolves this same binding again (stable per address, so an
 * equals-gated reader keeps its instance); completion → the loop
 * completes.
 *
 * A live connection already streaming this address is JOINED: this
 * response is ended here (the server tears its render down on the
 * cancel) and the joining loop sees the shared connection's death when it
 * comes, reconnecting like the loop that owns it (one of the two wins the
 * next slot; the other joins again). Otherwise the response OPENS the
 * address's connection: `bump` versions it and `begin` moves the store to
 * the version at the header; the body is read through the loop's reader
 * when it is framed as an event stream (`ChunkReader` otherwise), handed to
 * the transport under the wire slot; and the end is judged HERE by what the
 * body left open — `complete` is the bounded signal, an unkeyed `error` the
 * failing kind of it; a body that ends with any still open is a DEATH, never
 * a completion (§9.5, Wire) — and told to the loop with the sweep it may run
 * over the open frames if the iteration ends for good by error (`close`
 * leaves them as they stand: a superseding reconnect re-renders them). The
 * transport's own end-of-body sweep (an error record per open frame, the
 * no-loop verdict) is swallowed: the loop decides. A rejected read is a
 * death the loop already sees, not an error record.
 * @internal
 */
export declare function connect(response: Response, wire: WireSlot, address: string, binding: unknown, host: Host, bump: (address: string) => number, begin: (address: string, version: number) => void): unknown;
/**
 * Morph a live hole's marked range (`<!--lh:N-->…<!--lh:/N-->`, marker =
 * `lh:N`) to its re-emitted html — the client half of the Stage 3 hole
 * ledger. The same range-anchored reconcile as the root morph, so
 * interior element identity (focus, media, third-party widget state)
 * survives value ticks. A hole's content may hold slot ranges: the morph
 * then resolves them against the frame's displaced-range index (`index`,
 * one per flush pass: `r` the slot ranges by occurrence, `g` the subtrees
 * the morphs inserted whole), as the root's does, so an occurrence the new
 * content still has keeps its range — interior and mounted state —
 * wherever it moved; the sync after the pass mounts the new ones and
 * unmounts the ones gone. Returns whether the markers were found and the
 * morph ran.
 * @internal
 */
export declare function hole(f: LiveMount, marker: string, record: any, index: {
    r?: Map<string, any>;
    g?: Node[];
}): boolean;
/**
 * Apply a live attr-hole re-emission: find the element addressed
 * `data-lha="addr"` in the frame's range, parse the rebuilt attribute
 * text through a scratch element (native entity decoding), and patch the
 * element to match it the way the root morph matches server output
 * (`morphAttributes`): set what's present, remove what is not — the text
 * is the tag's WHOLE attribute area, so a name absent from it has
 * vanished on the server, whether or not the emission names it in
 * `removed` (a resume's re-emission cannot: the server holds the client's
 * previous text only as a digest). The address itself and a
 * `<details>`/`<dialog>` `open` are the morph's exceptions here too.
 * Returns false when the element isn't in the DOM yet (pending; later
 * flushes retry).
 * @internal
 */
export declare function attrs(f: LiveMount, addr: string, record: any): boolean;
export { graft, morph } from "./frame-morph.js";
