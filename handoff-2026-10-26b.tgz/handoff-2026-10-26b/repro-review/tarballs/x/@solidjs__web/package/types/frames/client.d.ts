import { type TierModule } from "./frame-client.js";
export { createFrame, createFrameHost, createFrameElement, FRAME_APPLIED_EVENT } from "./frame-client.js";
export type { TierModule } from "./frame-client.js";
export { FRAME_STREAM_HEADER, applyFrameResponse, isFrameStreamResponse, createServerComponentHandler } from "./frame-transport.js";
export type { Slot } from "./server.js";
/**
 * Client-condition twin of the server face's `asyncArg` (DR-2 value tier):
 * the identity that types an async value crossing the slot border as its
 * settled value. Server component modules are authored in universal code and
 * may resolve under the browser condition at typecheck/bundle time — the
 * call never runs here (the `"use server"` body executes server-side), but
 * the symbol must exist.
 */
export declare function asyncArg<T>(value: PromiseLike<T> | AsyncIterable<T>): T;
/**
 * The app-wide shared frame host (created lazily): one chunk router with
 * per-response codec data tables.
 * @experimental
 */
export declare function getFrameHost(): any;
/**
 * Turn deferred hydration off (or back on) for the frames this client
 * adopts from now on: off, an adopted occurrence mounts in the adoption
 * pass. A test seam for the specs that pin adoption-time ordering.
 * @internal
 */
export declare function setDeferredHydration(on: boolean): void;
/**
 * Options for `installServerComponents`.
 * @experimental
 */
export interface InstallOptions {
    /**
     * Frames-client tiers by name → loader. A tier's module's exports are its
     * appliers (the runtime dispatches to them once resident) and its
     * optional `install()` is called once the import resolves; every live
     * frame is then flushed so what the tier makes applicable applies (a held
     * occurrence mounts, a style-gated segment requests its sheets). A name
     * with no loader is resident (eager); `trace` (`@solidjs/web/frames/trace`),
     * `regions` (`@solidjs/web/frames/regions`) and `assets`
     * (`@solidjs/web/frames/assets`) have built-in loaders that an entry here
     * replaces. See `installServerComponents`.
     */
    tiers?: Record<string, () => Promise<TierModule>>;
}
/**
 * Installs the server-component transport policy on the server-function
 * client — the identity split (DR-1): CONTENT is keyed by the call's
 * intrinsic (function, arguments) address — per-args, exactly like the
 * query cache, so a cached resolution always names the content it was
 * cached for — while the MOUNT belongs to the call site. Every call of a
 * function resolves a binding wrapping the same per-function component
 * (the document placeholder), so `dynamic` keeps its instance across both
 * refetches AND argument changes; the instance follows delivered addresses
 * by re-binding its frame's pull, and a preload for unshown args only ever
 * warms that address's resident store.
 *
 * Call once in the client entry (an explicit call — the package is
 * `sideEffects: false`, so a bare import would be tree-shaken away);
 * call again to rebind to a custom host.
 *
 * `options.tiers` maps a frames-client tier's name to its loader (`() =>
 * import(...)`, the module whose exports are the tier's appliers, with an
 * optional `install()`): the client resolves tier chunks itself, so the
 * server announces NAMES only (`_$HY.r["sc:tiers"]`, `X-Frame-Tiers`) and
 * the loads start here from the document's record — the `modulepreload`
 * the document may also carry made the fetch warm. The built-in table
 * carries `trace` (the container tier's client half,
 * `@solidjs/web/frames/trace`), `regions` (nested server-content regions,
 * `@solidjs/web/frames/regions`) and `assets` (the head mirror and the
 * stylesheet gate, `@solidjs/web/frames/assets`); a loader given here for
 * a name replaces the built-in one (tests gate a tier's load this way).
 * @experimental
 */
export declare function installServerComponents(host?: any, options?: InstallOptions): void;
