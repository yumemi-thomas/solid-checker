export declare function enableRichArguments(): void;
