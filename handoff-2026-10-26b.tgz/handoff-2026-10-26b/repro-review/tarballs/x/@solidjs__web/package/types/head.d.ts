export declare const HEAD_ELIGIBLE_TAGS: Set<string>;
export declare const HEAD_ATTR_NAME: RegExp;
export declare const RESOURCE_LINK_RELS: Set<string>;
export declare const RESOURCE_QUALIFIERS: string[];
export declare const STYLESHEET_FETCH_META: Set<string>;
export declare function evalHeadValue(v: any): any;
export declare function evalHeadProps(props: any, presets: any): {};
export declare function classifyHeadTag(desc: any): {
    resource: boolean;
    rel: any;
} | {
    resource: boolean;
    rel?: undefined;
};
export declare function qualifierValue(name: any, value: any): any;
export declare function asciiLowerCase(value: any): any;
export declare function headBodyText(tag: any, props: any, text: any): any;
export declare function resourceIdentity(tag: any, props: any): string;
export declare function replaceableIdentity(tag: any, props: any, key: any, unique: any): any;
export declare function resolveHead(groups: any): Map<any, any>;
