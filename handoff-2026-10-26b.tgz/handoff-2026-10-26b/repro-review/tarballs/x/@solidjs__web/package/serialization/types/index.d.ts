import { Serializer } from "seroval";
import type { JSONCodecOptions, PluginInfo, SerializerPlugin, SerovalNode } from "./serializer-decode.js";
export { DEFAULT_WEB_PLUGINS, createJSONDataTable, createJSONDeserializer, resolveSerializerPlugins } from "./serializer-decode.js";
export type * from "./serializer-decode.js";
/**
 * Options for `createSerializer`.
 *
 * Integration-facing; may change (see the entry banner).
 */
export interface WebSerializerOptions {
    /** Name of the global object the emitted scripts write resolved values into. */
    globalIdentifier: string;
    /** Cross-reference scope id, for isolating multiple streams on one page. */
    scopeId?: string;
    /**
     * Seroval feature bitflags to exclude from output. Defaults to disabling
     * post-ES2017 features (AggregateError, BigInt typed arrays). Outside
     * development, `Error.prototype.stack` is additionally stripped on top of
     * any override — serialized stacks leak server paths to the client.
     */
    disabledFeatures?: number;
    /**
     * Whether serialized `Error`s carry their `.stack`. Defaults to
     * `NODE_ENV === "development"`; set `false` to pin production disclosure
     * to the deployment rather than the ambient variable (#3152 — see
     * `JSONCodecOptions.serializeErrorStacks`).
     */
    serializeErrorStacks?: boolean;
    /** Extra plugins, composed ahead of `DEFAULT_WEB_PLUGINS`. */
    plugins?: SerializerPlugin[];
    /** Receives each emitted script chunk. */
    onData: (result: string) => void;
    onError?: (error: unknown) => void;
    /** Fires once all async values have settled. */
    onDone?: () => void;
}
/**
 * Options for `createHydrationSerializer` — `WebSerializerOptions` minus
 * the knobs hydration pins (`globalIdentifier`, `disabledFeatures`).
 * @internal
 */
export type HydrationSerializerOptions = Omit<WebSerializerOptions, "globalIdentifier" | "disabledFeatures">;
/**
 * Options for `serializeJSON`.
 *
 * Integration-facing; may change (see the entry banner).
 */
export interface JSONSerializeOptions extends JSONCodecOptions {
    /**
     * Receives each serialized node; `initial` is true for the first chunk
     * (the source value itself). Async values produce additional chunks as
     * they resolve.
     */
    onParse: (node: SerovalNode, initial: boolean) => void;
    onError?: (error: unknown) => void;
    /** Fires once all async values have settled. */
    onDone?: () => void;
}
/** Options for `createJSONSerializer`. */
export interface JSONSerializerOptions extends JSONCodecOptions {
    /**
     * Receives each keyed record — `initial` is true for a key's first node
     * (the written value itself); async values patch through later records
     * under the same key. The decoding peer is `createJSONDataTable`.
     */
    onData: (record: {
        key: string;
        node: SerovalNode;
        initial: boolean;
    }) => void;
    onError?: (error: unknown) => void;
    /** Fires once `flush()` has been called and every pending value settled. */
    onDone?: () => void;
}
export declare const createPlugin: <Value, Info extends PluginInfo>(plugin: SerializerPlugin<Value, Info>) => SerializerPlugin<Value, Info>;
export interface OpaqueReference<V = unknown, R = undefined> {
    readonly value: V;
    readonly replacement?: R;
}
export declare const OpaqueReference: {
    new <V, R = undefined>(value: V, replacement?: R): OpaqueReference<V, R>;
};
/**
 * Creates a streaming Seroval serializer preconfigured with the web plugin
 * set and the default feature policy. Emits JavaScript chunks (through
 * `onData`) that reconstruct the values under `globalIdentifier` when
 * evaluated — the script-injection form of serialization renderers build
 * on. For a JSON-based wire codec (no eval on the receiving side), use
 * `serializeJSON` / `createJSONDeserializer` instead.
 *
 * Integration-facing; may change (see the entry banner).
 */
export declare function createSerializer(options: WebSerializerOptions): Serializer;
export declare function createHydrationSerializer(options: HydrationSerializerOptions): Serializer;
export declare function getLocalHeaderScript(id?: string): string;
export declare function serializeJSON(value: unknown, options: JSONSerializeOptions): () => void;
export declare function createJSONSerializer(options: JSONSerializerOptions): {
    write(key: string, value: unknown): void;
    flush(): void;
    close(): void;
};
