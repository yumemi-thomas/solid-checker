/**
 * Seroval's node shape — the intermediate representation `serializeJSON`
 * emits and `createJSONDeserializer` consumes. Safe to `JSON.stringify`.
 * Declared by hand like the plugin types below (same rationale): the
 * observable envelope — a numeric type tag, an optional reference id —
 * with the rest owned by the codec. Real seroval nodes satisfy it; treat
 * it as an opaque token.
 *
 * Integration-facing; may change (see the entry banner).
 */
export interface SerovalNode {
    /** Node type tag (seroval-internal enum). */
    t: number;
    /** Reference id, when the node participates in cross-referencing. */
    i?: number | undefined;
    [key: string]: unknown;
}
/** Per-plugin bookkeeping seroval hands each plugin callback. */
export interface PluginData {
    id: number;
}
/**
 * The shape of a plugin's parsed payload: a map of `SerovalNode`s produced
 * by the parse contexts, consumed by `serialize`/`deserialize`.
 */
export type PluginInfo = {
    [key: string]: SerovalNode;
};
/** Parse context for `parse.sync`: turns child values into nodes. */
export interface SyncParsePluginContext {
    parse<T>(current: T): SerovalNode;
}
/** Parse context for `parse.async`: like sync, but child parses await. */
export interface AsyncParsePluginContext {
    parse<T>(current: T): Promise<SerovalNode>;
}
/**
 * Parse context for `parse.stream`: sync parsing plus the streaming
 * lifecycle (pending-state tracking, late node emission, cleanup).
 */
export interface StreamParsePluginContext {
    parse<T>(current: T): SerovalNode;
    parseWithError<T>(current: T): SerovalNode | undefined;
    isAlive(): boolean;
    pushPendingState(): void;
    popPendingState(): void;
    onParse(node: SerovalNode): void;
    onError(error: unknown): void;
    addCleanup(callback: () => void): void;
}
/** Serialize context: renders child nodes to JS source. */
export interface SerializePluginContext {
    serialize(node: SerovalNode): string;
}
/** Deserialize context: revives child nodes to runtime values. */
export interface DeserializePluginContext {
    deserialize<T>(node: SerovalNode): T;
}
/**
 * A Seroval plugin usable with the web serializers — teaches the codec how
 * to encode/decode a custom value type (`Value` is the value it matches,
 * `Info` its parsed payload). Supply matching plugins on both peers of a
 * transport. Bare `SerializerPlugin` (both parameters defaulted to `any`)
 * is the list-element type every `plugins` option accepts.
 *
 * Integration-facing; may change (see the entry banner).
 */
export interface SerializerPlugin<Value = any, Info extends PluginInfo = any> {
    /** A unique string identifying the plugin — namespace it (`"app/Thing"`). */
    tag: string;
    /** Dependency plugins, resolved ahead of this one. */
    extends?: SerializerPlugin[];
    /** Whether `value` is this plugin's to encode. */
    test(value: unknown): boolean;
    /** Parsing modes — provide the ones the transports you target use. */
    parse: {
        sync?: (value: Value, ctx: SyncParsePluginContext, data: PluginData) => Info;
        async?: (value: Value, ctx: AsyncParsePluginContext, data: PluginData) => Promise<Info>;
        stream?: (value: Value, ctx: StreamParsePluginContext, data: PluginData) => Info;
    };
    /** Renders the parsed payload as JS source (script-injection form). */
    serialize(node: Info, ctx: SerializePluginContext, data: PluginData): string;
    /** Revives the parsed payload back into the runtime value. */
    deserialize(node: Info, ctx: DeserializePluginContext, data: PluginData): Value;
}
/**
 * Options shared by both halves of the JSON codec. All of them must match
 * on the serializing and deserializing peer or payloads will not
 * round-trip — for server functions, set them once through the
 * client/server `codec` config option.
 *
 * Integration-facing; may change (see the entry banner).
 */
export interface JSONCodecOptions {
    /** Extra plugins, composed ahead of `DEFAULT_WEB_PLUGINS`. Must match on both peers. */
    plugins?: SerializerPlugin[];
    /**
     * Seroval feature bitflags to exclude. Defaults to disabling `RegExp`
     * (payloads may come from an untrusted peer). Must match on both peers.
     * Outside development, the encoding side additionally strips
     * `Error.prototype.stack` on top of any override — serialized stacks leak
     * server paths to the client. Decoding stays permissive, so payloads from
     * a development peer still round-trip.
     */
    disabledFeatures?: number;
    /** Maximum parse/deserialize depth. Defaults to 64. Must match on both peers. */
    depthLimit?: number;
    /**
     * Whether serialized `Error`s carry their `.stack` — server file paths,
     * internal function names, the shape of the deployment — to the peer.
     * Defaults to `NODE_ENV === "development"`, but that signal describes the
     * PROCESS, not the artifact: a production build running with
     * `NODE_ENV=development` (a base image, a stray dotenv) ships stacks to
     * the wire — including for errors marked safe with `markSafeError`, whose
     * stacks traverse application code (#3152). Set `false` to pin production
     * disclosure regardless of the ambient variable. Encode-side only; the
     * decode side is always permissive, so it need not match peers.
     */
    serializeErrorStacks?: boolean;
}
/**
 * A resident, response-scoped decode table over the keyed JSON codec: apply
 * each frame `data` chunk with `apply`, resolve `{ $ref }` slot args with
 * `resolve`, and `close` it when the response ends. The frames client host
 * wires one per response (`applyData: c => table.apply(c)`,
 * `closeData: (…) => table.close(error)`).
 *
 * A `{ $ref }` to a key no `apply` has delivered yet is a PENDING READ the
 * table owns (`@internal` behaviour — the frames client is its consumer): a
 * promise marked `s = 0`, settled by the key's `apply` and rejected by
 * `close` — the response ended without delivering the key, so a value that
 * never comes is an error where it is read, not a silence. Stamped `s`/`v`
 * as it settles (`1` fulfilled, `2` rejected — the hydration serializer's
 * marks, which a reader adopts synchronously).
 *
 * Integration-facing; may change (see the entry banner). This serialization
 * entry is the single home of the data table — the frames client consumes
 * it internally rather than re-exporting it.
 */
export interface JSONDataTable {
    apply(chunk: {
        key?: string;
        node?: unknown;
        initial?: boolean;
    }): void;
    /**
     * The value under `ref`, or the table's pending read of it: a promise
     * marked `s = 0` carrying `c`, the callbacks the table runs in the
     * `apply` / `close` that settles it — the key delivered (whatever its
     * value's shape: a delivered promise is adopted by the read, the
     * callbacks do not wait for it) or the table closed.
     */
    resolve<T = unknown>(ref: {
        $ref: string;
    }): T;
    /**
     * The response has ended: every pending read of a key it never
     * delivered rejects — with `error` (the response's own) when given, with
     * an `Error` naming the key otherwise. Idempotent.
     */
    close(error?: unknown): void;
}
/**
 * Baseline plugin set for serializing web-platform values. Shared by the
 * hydration serializer and any consumer building its own serializer (e.g.
 * server function transports). Plugin objects carry both their serialize
 * and deserialize halves, so the set lives on the decode side and the
 * encode module composes over it.
 */
export declare const DEFAULT_WEB_PLUGINS: readonly ({
    tag: string;
    test(value: any): boolean;
    parse: {
        sync(): never;
        async(value: any, ctx: any): Promise<{
            a: number;
            i: any;
        }>;
        stream: (value: any, ctx: any) => {
            a: number;
            i: any;
        };
    };
    serialize(node: any, ctx: any): string;
    deserialize(node: any, ctx: any): any;
} | import("seroval").Plugin<AbortSignal, {
    reason?: import("seroval").SerovalNode;
    controller?: import("seroval").SerovalNode;
    factory?: import("seroval").SerovalNode;
}> | import("seroval").Plugin<CustomEvent<any>, {
    type: import("seroval").SerovalNode;
    options: import("seroval").SerovalNode;
}> | import("seroval").Plugin<DOMException, {
    name: import("seroval").SerovalNode;
    message: import("seroval").SerovalNode;
}> | import("seroval").Plugin<Event, {
    type: import("seroval").SerovalNode;
    options: import("seroval").SerovalNode;
}> | import("seroval").Plugin<FormData, {
    factory: import("seroval").SerovalNode;
    entries: import("seroval").SerovalNode;
}> | import("seroval").Plugin<Headers, {
    value: import("seroval").SerovalNode;
}> | import("seroval").Plugin<ReadableStream<any>, {
    factory: import("seroval").SerovalNode;
    stream: import("seroval").SerovalNode;
}> | import("seroval").Plugin<Request, {
    url: import("seroval").SerovalNode;
    options: import("seroval").SerovalNode;
}> | import("seroval").Plugin<Response, {
    body: import("seroval").SerovalNode;
    options: import("seroval").SerovalNode;
}> | import("seroval").Plugin<URLSearchParams, {
    value: import("seroval").SerovalNode;
}> | import("seroval").Plugin<URL, {
    value: import("seroval").SerovalNode;
}>)[]; /**
 * Composes custom plugins with `DEFAULT_WEB_PLUGINS`. Custom plugins come
 * first so they can shadow a default for values both would match. Returns a
 * fresh array; the defaults are never mutated. Useful when handing a full
 * plugin list to another serialization layer.
 *
 * Integration-facing; may change (see the entry banner).
 */
export declare function resolveSerializerPlugins(customPlugins?: SerializerPlugin[]): SerializerPlugin[];
export declare function resolveCodecOptions(options?: JSONCodecOptions): {
    plugins: any;
    disabledFeatures: number;
    depthLimit: number;
    serializeErrorStacks: boolean;
}; /**
 * Creates the decoding counterpart of `serializeJSON`. Cross-references
 * between chunks resolve through state shared across calls, so all chunks
 * from one stream must go through the same deserializer instance. The first
 * chunk's return value is the decoded source value; feeding later chunks
 * settles the async values referenced inside it.
 *
 * Integration-facing; may change (see the entry banner).
 */
export declare function createJSONDeserializer(options?: JSONCodecOptions): <T>(node: SerovalNode) => T;
export declare function createJSONDataTable(options?: JSONCodecOptions): JSONDataTable;
