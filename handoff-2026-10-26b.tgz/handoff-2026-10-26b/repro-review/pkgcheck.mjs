import {readFileSync,readdirSync,statSync,existsSync,mkdirSync} from "node:fs";
import {createHash} from "node:crypto";
import {execFileSync} from "node:child_process";
import {join} from "node:path";
const D=process.argv[2], NM="/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker/fixtures/uncertifiable-repro/node_modules";
const P=JSON.parse(readFileSync(NM+"/../packages.json","utf8"));
const h=(alg,b,enc="hex")=>createHash(alg).update(b).digest(enc);
let bad=0, checked=0; const listed=new Set();
for(const x of P.packages){
  const tgz=join(D,x.name.replace("@","").replace("/","-")+"-"+x.version+".tgz");
  if(!existsSync(tgz)){console.log("NO TARBALL",x.name);bad++;continue;}
  const integ="sha512-"+h("sha512",readFileSync(tgz),"base64");
  if(integ!==x.integrity){console.log("INTEGRITY MISMATCH",x.name,integ,x.integrity);bad++;}
  const ex=join(D,"x",x.name.replace("/","__")); mkdirSync(ex,{recursive:true});
  execFileSync("tar",["-xzf",tgz,"-C",ex]);
  for(const [f,sha] of Object.entries(x.files)){
    checked++; listed.add(x.name+"/"+f);
    const pub=readFileSync(join(ex,"package",f)); const loc=readFileSync(join(NM,x.name,f));
    if(h("sha256",pub)!==sha){console.log("RECORDED != PUBLISHED",x.name,f);bad++;}
    if(h("sha256",loc)!==sha){console.log("LOCAL != RECORDED",x.name,f);bad++;}
  }
}
const walk=(d,pre="")=>readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(join(d,e.name),pre+e.name+"/"):[pre+e.name]);
const extra=walk(NM).filter(f=>{const parts=f.split("/");const name=parts[0].startsWith("@")?parts.slice(0,2).join("/"):parts[0];return !listed.has(f);});
console.log("checked",checked,"bad",bad,"unlisted local files",extra.length, extra.slice(0,10));
