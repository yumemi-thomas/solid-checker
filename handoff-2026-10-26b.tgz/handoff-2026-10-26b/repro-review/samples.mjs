import {readFileSync} from "node:fs";
const cls=JSON.parse(readFileSync("classified.json","utf8"));
const cases=JSON.parse(readFileSync("/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker/fixtures/uncertifiable-repro/cases.json","utf8")).cases;
const caseFor=(c)=>{let b=null,l=-1;for(const e of cases)for(const p of e.causes)if((c===p||c.startsWith(p+"/"))&&p.length>l){b=e;l=p.length;}return b;};
const id=process.argv[2], n=+(process.argv[3]||6);
const mine=cls.filter(e=>caseFor(e.cause)?.id===id);
const apps={}; for(const e of mine) apps[e.app]=(apps[e.app]||0)+1;
console.log(id, mine.length, JSON.stringify(apps));
// deterministic spread: pick every k-th
const step=Math.max(1,Math.floor(mine.length/n));
for(let i=0;i<mine.length&&i/step<n;i+=step){const e=mine[i]; console.log(` ${e.app}/${e.project.replace("tsconfig.json","")} ${e.path}:${e.line} ${e.cause} :: ${e.site}`);}
