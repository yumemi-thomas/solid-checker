import {readFileSync} from "node:fs";
for (const p of process.argv.slice(2)) {
  const r = JSON.parse(readFileSync(p,"utf8"));
  const keys = Object.keys(r).filter(k=>k!=="results");
  let u=0, v=0, apps=new Set();
  for (const row of r.results) { apps.add(row.app); for (const f of row.findings) { if (f.kind==="uncertifiable") u++; else if (f.kind==="violation") v++; } }
  console.log(p.split("/").pop(), JSON.stringify(Object.fromEntries(keys.map(k=>[k, typeof r[k]==="object"? JSON.stringify(r[k]).slice(0,300): r[k]]))), "rows",r.results.length,"apps",apps.size,"unc",u,"viol",v);
}
