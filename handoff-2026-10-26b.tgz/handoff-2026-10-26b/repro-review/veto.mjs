import {readFileSync} from "node:fs";
import {relative} from "node:path";
const S="/Users/thomas.guehenneux/EDF/tmp/sc-sweep/";
const head=JSON.parse(readFileSync(S+"rc17-sweep-head.json","utf8"));
const nov=JSON.parse(readFileSync(S+"rc17-sweep-head-noveto.json","utf8"));
const cls=JSON.parse(readFileSync("classified.json","utf8"));
const projs=new Set(nov.results.map(r=>r.app+"|"+r.project));
const k=(app,proj,rule,path,line)=>[app,proj,rule,path,line].join("|");
const novCount=new Map();
for(const row of nov.results) for(const f of row.findings){ if(f.kind!=="uncertifiable")continue; const kk=k(row.app,row.project,f.id,relative(row.root,f.primaryLocation.path),f.primaryLocation.line); novCount.set(kk,(novCount.get(kk)||0)+1);}
const novViol=new Map();
for(const row of nov.results) for(const f of row.findings){ if(f.kind!=="violation")continue; const kk=k(row.app,row.project,f.id,relative(row.root,f.primaryLocation.path),f.primaryLocation.line); novViol.set(kk,(novViol.get(kk)||0)+1);}
const stats={};
const keep=[];
for(const e of cls){ if(!projs.has(e.app+"|"+e.project)) continue;
  const veto=/dispatch-veto/.test(e.cause)?e.cause.replace(/^.*dispatch-veto:/,"veto:"):"other";
  const kk=k(e.app,e.project,e.rule,e.path,e.line);
  const n=novCount.get(kk)||0; let st;
  if(n>0){novCount.set(kk,n-1); st="still-unc";} else if((novViol.get(kk)||0)>0){st="became-violation";} else st="gone";
  const s=stats[veto]??={}; s[st]=(s[st]||0)+1;
  if(veto!=="other"&&st!=="gone") keep.push(e);
}
console.log("projects in noveto:", [...projs].join(", "));
console.log(JSON.stringify(stats,null,1));
console.log("veto-attributed but still present without veto:", keep.length);
for(const e of keep.slice(0,15)) console.log(e.app,e.path+":"+e.line,e.rule,e.cause, e.site);
