import {readFileSync} from "node:fs";
const cls=JSON.parse(readFileSync("classified.json","utf8"));
const cases=JSON.parse(readFileSync("/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker/fixtures/uncertifiable-repro/cases.json","utf8")).cases;
const caseFor=(c)=>{let b=null,l=-1;for(const e of cases)for(const p of e.causes)if((c===p||c.startsWith(p+"/"))&&p.length>l){b=e;l=p.length;}return b;};
let s=12345; const rnd=()=>{s=(s*1103515245+12345)%2147483648; return s/2147483648;};
const cov=cls.filter(e=>caseFor(e.cause)), un=cls.filter(e=>!caseFor(e.cause));
const pick=(a,n)=>{const o=[];const seen=new Set();while(o.length<n){const i=Math.floor(rnd()*a.length);if(!seen.has(i)){seen.add(i);o.push(a[i]);}}return o;};
const root="/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps/";
for(const [label,arr,n] of [["REPRODUCED",cov,10],["NOT",un,5]]) for(const e of pick(arr,n)){
  const L=readFileSync(root+e.app+"/"+e.path,"utf8").split("\n");
  console.log(`\n### ${label} ${caseFor(e.cause)?.id??"-"} | ${e.app}/${e.path}:${e.line} | ${e.cause}`);
  for(let i=Math.max(0,e.line-7);i<Math.min(L.length,e.line+2);i++) console.log((i+1)+(i+1===e.line?">":" ")+L[i].slice(0,150));
}
