# Reproduction set (ADR 0404): independent review and the fixes still to do

PR #116 branch `claude/catalog-review-adr-0381-0400` at 8a2e977db holds the set
(`fixtures/uncertifiable-repro`, 139 cases, 8 projects, 2,857 lines, 3.4 MB of
published package bytes). The owner deletes the rc.17 corpus only after a
second independent review of the fixed set says yes.

## Review verdict (Opus 5.5, 2026-10-26): not yet

Mechanically sound: every case gives its expected result, no result falls
outside a case file, all 18 tarballs match their sha512 and all 197 files
their sha256, tsc 5.9.3 is clean on all 8 projects, and five cases run alone
give the same results as in their shared project.

But the 97.4% counts corpus results whose classifier label shares a prefix
with a case, not results reproduced by the same mechanism. Estimated
mechanism-faithful coverage: ~35-55% (15 cases, ~50 sites; an estimate).

Per case:
- faithful: open-program-boundary (693; only 302 distinct lines, and 408 also
  vanish without the veto), write-after-await (307), the small cases
  prop-presence-in-show, write-in-returned-tuple, dependency-source-getter.
- mostly: veto-listener-wrapper (258; probus-hk's 48 are `searchLink.click()`
  in a `createHotkey` callback; 56 stay uncertifiable without the veto).
- partial: veto-event-target (465; app-game is also withheld by the helper-kind
  sites cursor-emulation/eventDispatcher.ts:168,189, which no case reproduces,
  so certifying the case moves zero corpus results; 52 survive without the
  veto), write-in-factory-member (342; source reaches consumers through
  createContext<AppStore>, returned interface types, nested factories),
  callback-in-options-object (238; @tanstack Virtualizer behind a Proxy),
  param-member-mutation-client (228; kui's Provider is in another workspace
  package; Dialog.tsx:99 is another mechanism), handler-member (190; source
  passes `rows.retry`, a factory-result member; 44 other-member results folded
  in), leaf-package-member (136; typegpu builder chain).
- not faithful: param-use-object (339; all 598 results share context
  parameter-use-unmodeled, split only by argument type; 1 of 5 samples
  matches), param-use-primitive (152, same), write-mixed-entries (134;
  via-callers:mixed is a catch-all).

Attribution: 790 results carry a veto label (not 1,368); in the no-veto sweep
681 clear and 109 stay. The no-veto sweep came from the uncommitted scratch
build `sc-exp-target` (worktree /Users/thomas.guehenneux/EDF/tmp/sc-exp-worktree
on the old machine, with a stash); confirm what it changed. About 200 results
under non-veto cases also clear without the veto. Classifier bug:
`afterSuspension` misses an await on a loop back edge (app-game
abr-viewer/App.tsx:85). kui's 1,650 results are 616 distinct lines.

Other defects: no violation or clean cases (no false-positive guard); project
budget full (8 of 8); repro-budget.mjs never checks hashes against the
registry; param-use-object.tsx cites dragSensor/solid.ts:103 but the callee is
createDragSensor.tsx:515-523.

Reviewer scratch: `repro-review/` (classified.json, report.txt, set.txt,
veto.mjs, pkgcheck.mjs).

## Fixes to do, in order (green commits; Sonnet 5.5 high helpers allowed)

1. Archive: done on the old machine (`corpus-archive/` here: classified,
   corpus-freeze, meta, sweeps; the 337 MB `apps-source.tar.gz` stayed on the
   old machine). Restore the corpus with `corpus-freeze/restore.mjs`.
2. Fix `afterSuspension` in scripts/uncertifiable-causes.mjs (loop back edge).
   A 20-line work-in-progress patch, untested: `wip-loop-await-classifier.patch`.
   Re-run attribution.
3. Veto: add a helper-kind veto case (raise the project budget deliberately,
   e.g. to 10, with a comment) or re-attribute; attribute veto weight only to
   results the no-veto sweep actually clears, after confirming that build.
4. Split heterogeneous buckets into per-mechanism cases (param-use-object,
   param-use-primitive, via-callers:mixed, handler-member other-member,
   param-member-mutation-client, callback-in-options-object,
   write-in-factory-member, leaf-package-member), or mark them label-only.
5. cases.json and ADR 0404 report `labelWeight` (today's number) and
   `verifiedWeight` (results whose mechanism was verified by reading sources
   for a recorded sample per case, with the sample size); quote coverage only
   as verified coverage; count distinct source sites, not per-project
   duplicates.
6. False-positive guard: triage the corpus's non-style violations (SC1001 118,
   SC4001 11, SC1004 2, SC3001 2, SC6001 1, SC8014 2, SC9015 2 [both checked:
   real `attr:data-z` in app-game camera-projection-svg cube.tsx:50 and
   polygon.tsx:22]; SC8015 prefer-show 236 by sample). Real defect -> one
   positive case per mechanism (runtime probe on rc.17 where not obvious).
   A false positive -> STOP and report to the owner (checker bug, invariant 2).
   Add clean cases for a sample of certified shapes from the same files. Own
   budget lines exist (16 files / 400 lines each).
7. Opt-in network script to verify recorded hashes against registry tarballs;
   keep `make verify` offline.
8. Fix the param-use-object.tsx citation.
Then `make coverage`, `make ownership-gate`, `make verify`; commit; ask the
owner before pushing. Then a second independent review (Opus 5.5 medium, give
it the code, not conclusions) answering: is it safe to delete the corpus?

Violation diff sweep 9 -> PR head: 0 disappeared, 2 new (the SC9015 above).
