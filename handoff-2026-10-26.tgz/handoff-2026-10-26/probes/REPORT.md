# rc.17 runtime probes: mapper window, provider value, unnamed derived signals

Read-only. Probes are in `/tmp/sc-probes`; full transcripts are in `out/<n>-<name>.client.txt` and `.server.txt`. Nothing in the repo or `../solid-checker-rc17-corpus` was touched, and no cargo or make ran. Node v24.22.1 (mise).

## Packages

Installed with `npm install --ignore-scripts --save-exact solid-js@2.0.0-rc.17 @solidjs/signals@2.0.0-rc.17 @solidjs/web@2.0.0-rc.17`. `npm view <pkg>@2.0.0-rc.17 dist.integrity` matches `package-lock.json`:

- solid-js 2.0.0-rc.17: `sha512-ym3x2kzC+vzgD9VNqhqExn3qWzkrpJco3vane0wTFHCVPS9HBXI3GgSp+ieZ1h72zcb2z27PXFSbMsi8Ot+Hxw==`
- @solidjs/signals 2.0.0-rc.17: `sha512-GXXWBlJsiZeBCTw3a941Y/HVBYfwupCfctPnwNjFJV+u3tZnRe/SL+NeStI1247zfxlvkH4p9PWzdZK/yX1I1Q==`
- @solidjs/web 2.0.0-rc.17: `sha512-cJ+8GzVYWBi+/glbgWt6cVgRTxvVa4TG+rShaEuQnPHjUZQTsHh8hvR89KVdFB+5XQJnAajWDNpxz7LkD4MkDg==`

## Resolved files (`import.meta.resolve`)

- `node --conditions=development` (as instructed): solid-js → `dist/server.dev.js`; signals → `dist/dev.js`; web → `dist/server.dev.js`. solid-js's `"."` lists `node` before `development`, so Node takes the server build (`solid-js/package.json` exports).
- `node --conditions=browser --conditions=development` (**used for every verdict**): solid-js → `dist/solid.dev.js`; signals → `dist/dev.js`; web → `dist/web.dev.js`.
- Why the server build is not used: its `createSignal` returns a plain closure (`server.dev.js:645` `const read = () => first;`), its setter only warns `SERVER_WRITE` (`server.dev.js:647`), and its `createEffect` forwards to `serverEffect(compute, undefined, …)` (`server.dev.js:1318-1319`). In the probe the effect callback never ran (`effectRuns: 0`). Server outputs are kept for comparison.
- Hook: no `setDiagnosticHandler` or `onDiagnostic` in the client dev files (0 hits). Structured channel: `OBSERVE.diagnostics.subscribe` (`dev-shared.js:416-420`, `505-506`; every `emitDiagnostic` at `634-671`). Console text: `reportDiagnostic` (`733-741`), captured by wrapping `console.warn`/`console.error`. Subscribers: `DEV.getObservers(accessor[$REFRESH])` (`dev-shared.js:868`; accessors tag their node at `dev.js:2407-2410`).
- No DOM needed; jsdom/happy-dom not installed. JSX was not compiled: `<Ctx value>` is written as its `createComponent` call, and the `style` attribute as a `createRenderEffect`.

## Q1. Does a read inside a mapArray / repeat mapper warn, and is it tracked?

Probe `1-mapper-window.mjs`: module-scope and component-body (`createComponent`) mapArray and repeat, without and with `{ name }`. Control H reads inside the list function.

Code path:
- The strict window opens only when `name` is passed: mapArray `dev.js:3093-3102`, repeat `dev.js:3623-3633`.
- The mapper runs under `runWithOwner`: `dev.js:3347` (mapArray; per item `3362-3377`, general path `3406`), `dev.js:3661` and `3694` (repeat). `runWithOwner` sets `tracking = false` (`dev-shared.js:5779`) and leaves `strictRead` alone.
- A computed pass resets `strictRead` to false (`dev-shared.js:4196-4200`), so the component label does not leak into a mapper without `name`.
- The warning fires only on read()'s slow path (`dev-shared.js:5441-5446`; the fast path needs `!strictRead`, `:5287`). Text: `dev-shared.js:761-781`.

Observed (client), verbatim excerpts:
```
  A2 after setTag('b')+flush: value: ["1a","2a"]      (A: no name, module scope; A2 mapper runs: 2)
  A2 observers(tag): []
  C1 diag warn STRICT_READ_UNTRACKED: [STRICT_READ_UNTRACKED] Reactive value "cTag" read directly in cRows will not update. Move it into a tracking scope (JSX, a memo, or an effect's compute function).   (x2: one per mapper call)
  E1 ... Reactive value "eTag" read directly in eRows will not update. ...   (x2)  then "in <ERows>"
  G1 ... Reactive value "gTag" read directly in gRep will not update. ...     (x2)  then "in <GRep>"   (repeat, component)
  B2 ... Reactive value "b2Tag" read directly in bRep will not update. ...    (x2)                      (repeat, module scope)
  D2 tracked render-effect value after setTag('b'): ["1a","2a"]   (D: no name, component body; no diagnostics)
  H1 observers(tag): ["computed"]
  H2 tracked render-effect value after setTag('b'): ["1b","2b"]  H2 mapper runs: 4   (control)
```
Every no-name case (A, B, D, F) has no diagnostics. Every named case (B2, C, E, G) warns once per mapper call. In every mapper case, `setTag("b")` leaves the run count and output unchanged, and `observers(tag)` is `[]` wherever it was printed. Only the control H re-runs.

Verdict: **defect (what the runtime does)**: a read inside a mapArray or repeat mapper is tracked by neither the mapper's owner nor the mapArray node, so the write is silently ignored. STRICT_READ_UNTRACKED fires only when the call passes `name`.
Audit row (`docs/release-audits/2026-10-22-solid-2-rc17/signals.md:198`, "holds [M]"): holds only with `name`. Its first citation (`dev.js:8889, 9332`) is unrelated code in this dist; the second (`dev.js:3095, 3626`) is the `setStrictRead` pair.

## Q2. Context provider `value` read once or tracked?

Probe `2-context-provider.mjs`: `createComponent(Ctx, { get value() { valueReads++; return count(); }, get children() { return createComponent(Child, {}); } })`. Child's memo calls `useContext(Ctx)`. A control memo in the same child reads `count()`.

Code path:
- The provider reads `props.value` once: `solid.dev.js:9-16`. `setContext` stores a snapshot (`dev.js:1834-1844`, `owner._context = {…, [id]: value}`). `useContext` → `getContext` (`solid.dev.js:22-24`; `dev.js:1811-1824`) subscribes to nothing.
- Warning source: the function is named `provider`, so its label is `<provider>` (`solid.dev.js:48-49`). `observedComponent` runs it under `untrack(() => Comp(props), label)` (`solid.dev.js:65`), which sets `strictRead` (`dev-shared.js:5099-5105`). `createRoot` → `runWithOwner` (`dev-shared.js:1537-1543`, `5776-5785`) does not clear it, so the read warns (`dev-shared.js:5441-5446`).
- Server copy (`server.dev.js:2218-2225`): same provider logic, but its signals are inert.

Observed (client), verbatim excerpts:
```
  valueReads after creation: 1
  diag warn STRICT_READ_UNTRACKED: [STRICT_READ_UNTRACKED] Reactive value "count" read directly in <provider> will not update. Move it into a tracking scope (JSX, a memo, or an effect's compute function).
  -- after setCount(2) + flush --
  childRuns: 1
  controlRuns: 2
  childMemo value (top-level read): 1
  useContext(Ctx) run inside the child's owner now: 1
  valueReads: 1
  observers(count): ["controlMemo"]
```
A dev warning is raised when the provider reads `value`. The child does not see the new value: its memo never re-runs and the getter is not called again. The provider subscribes to nothing; the control memo proves the harness re-runs tracked reads.

Verdict: **defect (what the runtime does)**: the provider snapshots `value` once, children never see later writes, and the runtime raises STRICT_READ_UNTRACKED for `<provider>` at creation.

## Q3. Unnamed derived signals (badUnnamedDerivedSignal)

Probe `3-unnamed-derived.mjs`. Upstream cases: `reactivity.md:358-375` (#34) and `:891-935` (#32, #33, #35); case-map rows at `reactivity-case-map.md:55-58`. The upstream file has four badUnnamedDerivedSignal cases (`reactivity.md:22`). None is `createEffect(() => () => count())` or `createMemo(() => () => count())`, so those are probed as the user's shapes. Upstream `console.log` became `logged.push`.

| case | dev diagnostic | observed (client) | verdict |
|---|---|---|---|
| 3a `createEffect(() => () => count(), fn)` | none | runs 1→1; `observers(count)` `[]`; `fn()` at top level 2 | legal (compute returns a function and reads nothing) |
| 3a-2 same, effect callback calls `fn()` | STRICT_READ_UNTRACKED "…read directly in an effect callback…" | runs 1→1; seen stays 1 | defect (warned, stale) |
| 3b `createMemo(() => () => count())`; tracked consumer calls `memo()()` | none | memo runs 1→1; consumer 1→2, sees 2; observers `[]` then `["effect"]` | legal |
| 3c component returns `() => v()`, (i) tracked effect | none | re-runs 1→2, sees 2 | legal |
| 3c (ii) same fn read in a parent body | "v" read directly in <Parent> | stays 1 after `setV(2)` | defect (warned, stale) |
| 3c (iii) same fn read at top level | none | 2 (fresh, untracked) | legal |
| 3d #32, 2-arg form | none | runs 1→1; logged `[0]`; observers `[]` | defect (silent stale; `dev-shared.js:5779`) |
| 3d #32 exact 1-arg form | throws `[MISSING_EFFECT_FN]` | never runs (`dev.js:2504-2517`) | n/a |
| 3e #33, inside a component | none | same as 3d | defect (silent stale) |
| 3f #34, `props.big ? () => …` | "big" read directly in <Card> | style stays `{"fontSize":12}` after `setBig(false)`; `props.size` updates | defect for the condition (warned, read once); the arrow is legal |
| 3g #35, `dynamic(() => test(count()))` | none | some-lib is not installed. Control (Solid's `dynamic`): source 1→2, `"A"`→`"B"`, `observers` `["computed"]` | undecided for some-lib (no source); legal for Solid's `dynamic` |

Byte refs: the "effect callback" label is set at `dev.js:1993`. The dynamic source runs inside a memo (`solid.dev.js:1444`, `1472-1481`); `dynamic` is at `web.dev.js:2466-2468`.

Verdict (Q3): defect for 3a-2, 3c(ii), 3d, 3e (silent), and the 3f condition; legal for 3a, 3b, 3c(i) and 3c(iii); undecided for 3g's some-lib (Solid's own `dynamic` is legal). The probe answers the open question in case-map rows 32-33 (`reactivity-case-map.md:55-56`): the `runWithOwner` read stays untracked and raises no dev warning.

## Limits

- Verdicts use the client build only. Server output is non-reactive and is not a basis for any verdict.
- Not probed: SSR, hydration, DOM rendering, and solid-checker rule behaviour. The `style` attribute and `<Ctx value>` are emulated, not compiled.
