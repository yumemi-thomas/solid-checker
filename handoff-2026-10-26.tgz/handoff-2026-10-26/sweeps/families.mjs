import { readFileSync } from "node:fs";
const s = JSON.parse(readFileSync(process.argv[2], "utf8"));
const fam = (m) => m.replace(/"[^"]*"/g,'"_"').replace(/`[^`]*`/g,'`_`').replace(/\b(in|of|to|on) [A-Z][\w$]*/g,'$1 X').replace(/^[\w$.]+ (receives|invokes|reads|hands|is)/,'_ $1').replace(/^(component prop|reactive accessor|setter|effect|\.\.\.spread hands) [^ ]+/,'$1 _').replace(/\b[\w$]+\(\)/g,'f()').replace(/\b\d+\b/g,'N').slice(0,140);
const by = {};
for (const r of s.results) for (const f of r.findings) if (f.kind==="uncertifiable") { const k=f.id; by[k]??={}; const m=fam(f.message)+" || "+(f.analysisContext&&!/^[A-Z]/.test(f.analysisContext)?f.analysisContext:""); by[k][m]=(by[k][m]||0)+1; }
for (const id of ["SC9012","SC2001","SC1001","SC4001"]) { const e=Object.entries(by[id]).sort((a,b)=>b[1]-a[1]); console.log(`\n== ${id} ${e.reduce((a,b)=>a+b[1],0)}`); for (const [m,n] of e.slice(0,14)) console.log(String(n).padStart(5), m); }
