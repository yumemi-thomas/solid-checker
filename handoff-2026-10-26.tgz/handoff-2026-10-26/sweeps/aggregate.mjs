import { readFileSync } from "node:fs";
const sweep = JSON.parse(readFileSync(process.argv[2], "utf8"));
const norm = (m) => m.replace(/"[^"]*"/g, '"_"').replace(/`[^`]*`/g, "`_`").replace(/\b\d+\b/g, "N").replace(/\b[A-Za-z_$][\w$]*\(\)/g, "f()");
const byRule = {}; let tot = 0, unc = 0, viol = 0;
const failed = sweep.results.filter((r) => r.exitCode !== 0 || r.parseError);
for (const r of sweep.results) for (const f of r.findings) {
  tot++; const k = `${f.id} ${f.rule}`; byRule[k] ??= { v: 0, u: 0, apps: new Set(), ctx: {}, msg: {} };
  if (f.kind === "uncertifiable") { unc++; byRule[k].u++; byRule[k].apps.add(r.app); const c = f.analysisContext || "(none)"; byRule[k].ctx[c] = (byRule[k].ctx[c] || 0) + 1; const m = norm(f.message).slice(0, 150); byRule[k].msg[m] = (byRule[k].msg[m] || 0) + 1; }
  else { viol++; byRule[k].v++; }
}
console.log(`projects ${sweep.projectCount} failed ${failed.length} findings ${tot} violations ${viol} uncertifiable ${unc} wall ${Math.round(sweep.results.reduce((s, r) => s + r.wallMs, 0) / 1000)}s`);
for (const f of failed) console.log(`  FAILED ${f.app} ${f.project} exit=${f.exitCode} ${f.parseError ?? ""} ${f.stderr.slice(-300).replace(/\n/g, " | ")}`);
const top = (o, n) => Object.entries(o).sort((a, b) => b[1] - a[1]).slice(0, n);
for (const [k, v] of Object.entries(byRule).sort((a, b) => b[1].u - a[1].u)) {
  console.log(`\n${k.padEnd(42)} viol ${String(v.v).padStart(5)}  unc ${String(v.u).padStart(5)}  apps-with-unc ${v.apps.size}`);
  for (const [c, n] of top(v.ctx, 5)) console.log(`   ctx ${String(n).padStart(5)}  ${c.slice(0, 100)}`);
  for (const [m, n] of top(v.msg, 4)) console.log(`   msg ${String(n).padStart(5)}  ${m}`);
}
