import fs from "node:fs";
const pl=JSON.parse(fs.readFileSync("pl-sc1001b.json","utf8"));
const j=JSON.parse(fs.readFileSync("pl-sc1001j.json","utf8"));const kmap=new Map(j.map(x=>[x.app+x.file+x.line+x.msg,x.k]));
const fac=JSON.parse(fs.readFileSync("fac-sc1001.json","utf8"));const fk=new Map(fac.map(x=>[x.app+"|"+x.file+"|"+x.line+"|"+x.ctx,x]));
const cen=JSON.parse(fs.readFileSync("compcensus.json","utf8"));const ck=new Map(cen.map(x=>[x.app+"|"+x.file+"|"+x.line,x]));
const flat=JSON.parse(fs.readFileSync("flat.json","utf8")).filter(f=>f.id==="SC1001");const enumMsg=new Set(flat.filter(f=>/cannot be enumerated/.test(f.msg)).map(f=>f.app+"|"+f.file+"|"+f.line));
const veto=new Set(["app-game","inferay","kui","probus-hk","skyjtx-website"]);
const t={};
for(const x of pl){const l=x.chain&&x.chain[0];const u=l?l.uses:[];const f=fk.get(x.app+"|"+x.file+"|"+x.line+"|"+x.ctx);const key=x.app+"|"+x.file+"|"+x.line;
 let c;
 if(enumMsg.has(key)){const cc=ck.get(key);c=!cc?"E ?":(cc.spreadCallers>0?"E3 callers spread into component (stays)":(cc.other&&cc.other.filter(z=>z!=="TypeQuery").length)?"E4 non-JSX refs to component (stays)":cc.jsx===0?"E2 exported, no JSX callers (route/lazy/dead)":"E1 exported/enumerable JSX callers (closed-program census)")}
 else if(l&&!l.comp&&veto.has(x.app)&&u.length&&u.every(s=>s.startsWith("jsx:intrinsic")))c="1 dispatch-veto (handler-only fn in veto app)";
 else if(f&&((f.G&&!/Statement|Expression|Kind|none/.test(f.G))||(f.uses||[]).includes("objlit")||(l&&(l.kind==="GetAccessor"||l.kind==="MethodDeclaration"))||u.some(s=>s.startsWith("objprop"))))c="3 closure stored in object (factory result / context value / module store)";
 else if(u.some(s=>s.startsWith("jsx:component")))c="4 callback prop to project component";
 else if(u.some(s=>/^arg\d+-of:project/.test(s)))c="5 argument of project function";
 else if(u.some(s=>/^arg\d+-of:(pkg|nosym)/.test(s)))c="6 callback argument of package function";
 else if(l&&l.comp)c="7 read in component body/other (not enumerated msg)";
 else c="8 other ("+(u[0]||"none").slice(0,24)+")";
 t[c]=(t[c]||0)+1}
let tot=0;for(const [k,v] of Object.entries(t).sort()){tot+=v;console.log(String(v).padStart(5),k)}console.log(tot);
