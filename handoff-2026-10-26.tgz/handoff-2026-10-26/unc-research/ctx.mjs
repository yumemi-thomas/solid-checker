// usage: node ctx.mjs app file-substr line [before after]
import fs from "node:fs";
const [app,sub,line,b="6",a="6"]=process.argv.slice(2);
const root="/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps/";
import {execSync} from "node:child_process";
const p=execSync(`find ${root}${app} -path '*node_modules' -prune -o -type f -path '*${sub}' -print | head -1`).toString().trim();
const L=fs.readFileSync(p,"utf8").split("\n");console.log("##",p.replace(root,""));
for(let i=Math.max(0,line-1-b);i<Math.min(L.length,+line+ +a);i++)console.log((i+1==line?">":" ")+String(i+1).padStart(4)+" "+L[i].slice(0,180));
