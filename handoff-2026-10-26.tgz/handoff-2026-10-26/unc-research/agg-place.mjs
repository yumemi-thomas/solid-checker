import fs from "node:fs";
const r=JSON.parse(fs.readFileSync(process.argv[2],"utf8"));
const norm=u=>u.replace(/:[A-Za-z_$][\w$]*$/,"").replace(/^bound:.*/,"bound").replace(/^called@fn:.*/,"called@fn").replace(/^objprop:.*/,"objprop").replace(/arg(\d+)-of:([^:]*):.*/,(m,i,w)=>"arg-of:"+w).replace(/^jsx:component:[^:]*:(.*)/,"jsx:component-prop").replace(/^called@inline-in:(.*)/,"called@inline");
const sigs={};
for(const x of r){ if(!x.chain){const k="NOCHAIN "+(x.top||x.pl);(sigs[k]??=[]).push(x);continue;}
 const l0=x.chain[0]; const set=[...new Set(l0.uses.map(norm))].sort(); 
 const k=(x.awaitBefore?"AFTER-AWAIT ":"")+(l0.comp?"COMPONENT-BODY":l0.kind+(l0.name?"(named)":"(anon)"))+" uses=["+set.join(",")+"]";(sigs[k]??=[]).push(x);}
const ent=Object.entries(sigs).sort((a,b)=>b[1].length-a[1].length);
console.log("total",r.length,"signatures",ent.length);
for(const [k,v] of ent.slice(0,+process.argv[3]||40))console.log(String(v.length).padStart(4),k.slice(0,230),"|",v[0].app+"/"+v[0].file.split("/").pop()+":"+v[0].line);
