import fs from "node:fs"; import path from "node:path"; import {createRequire} from "node:module";
const ts=createRequire(import.meta.url)("/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps/ai-memory-ui/node_modules/typescript/lib/typescript.js");
const sweep=JSON.parse(fs.readFileSync("/tmp/sc-sweep/rc17-sweep-rebuilt-9.json","utf8"));
const rootOf={};for(const r of sweep.results)rootOf[r.app+"|"+r.project]=r.root;
const flat=JSON.parse(fs.readFileSync("flat.json","utf8")).filter(f=>f.id==="SC4001"&&f.ctx==="handler-spread-unresolved").sort((a,b)=>a.app<b.app?-1:1);
const programs={};let last=null;
function prog(root,project){const k=root+"|"+project;if(programs[k])return programs[k];const cfgPath=path.join(root,project);const cfg=ts.readConfigFile(cfgPath,ts.sys.readFile);const parsed=ts.parseJsonConfigFileContent(cfg.config,ts.sys,path.dirname(cfgPath));const p=ts.createProgram({rootNames:parsed.fileNames,options:{...parsed.options,noEmit:true,skipLibCheck:true}});return programs[k]={p,c:p.getTypeChecker()};}
function nodeAt(sf,start,end){let best;(function v(n){if(n.getStart(sf)<=start&&n.end>=end){best=n;ts.forEachChild(n,v);}})(sf);return best;}
function sym(c,n){let s=c.getSymbolAtLocation(n);if(s&&(s.flags&ts.SymbolFlags.Alias)){try{s=c.getAliasedSymbol(s)}catch{}}return s;}
const isFn=n=>ts.isArrowFunction(n)||ts.isFunctionExpression(n)||ts.isFunctionDeclaration(n);
const evt=a=>/^on[A-Z:]/.test(a)||/^on:/.test(a)||/^on[a-z]/.test(a)&&a!=="once";
const out=[];
for(const f of flat){ if(f.app!==last){for(const k of Object.keys(programs))delete programs[k];last=f.app;if(global.gc)global.gc();}
 const cands=Object.keys(rootOf).filter(k=>k.startsWith(f.app+"|"));let P,sf;for(const k of cands){const PP=prog(rootOf[k],k.split("|")[1]);const s=PP.p.getSourceFile(f.path);if(s){P=PP;sf=s;break;}}
 if(!sf)continue;const c=P.c;const start=Buffer.from(sf.text).subarray(0,f.s).toString().length,end=Buffer.from(sf.text).subarray(0,f.e).toString().length;
 let n=nodeAt(sf,start,end);let fn=n;while(fn&&!isFn(fn))fn=fn.parent;const info={app:f.app,file:f.file,line:f.line};
 // component = outermost function that has capitalised name
 let comp=null;let q=fn;while(q){if(isFn(q)){let nm=q.name?q.name.text:(ts.isVariableDeclaration(q.parent)&&ts.isIdentifier(q.parent.name)?q.parent.name.text:null);if(nm&&/^[A-Z]/.test(nm)&&!(q.parent&&ts.isCallExpression(q.parent)&&false)){comp={fn:q,name:nm,decl:ts.isFunctionDeclaration(q)?q:q.parent};}}q=q.parent;}
 // spread expression origin
 info.spreadText=sf.text.slice(start,end).replace(/\s+/g," ").slice(0,40);
 if(!comp){info.cls="no-comp";out.push(info);continue;}
 info.comp=comp.name;const nameNode=ts.isFunctionDeclaration(comp.fn)?comp.fn.name:comp.decl.name;const s=sym(c,nameNode);
 let jsxCalls=0,evtAttr=0,spreadAttr=0,otherUse=0,exported=false,attrs={};
 const ex=(ts.isFunctionDeclaration(comp.fn)&&comp.fn.modifiers&&comp.fn.modifiers.some(m=>m.kind===ts.SyntaxKind.ExportKeyword))||(ts.isVariableDeclaration(comp.decl)&&comp.decl.parent.parent.modifiers&&comp.decl.parent.parent.modifiers.some(m=>m.kind===ts.SyntaxKind.ExportKeyword));
 for(const sf2 of P.p.getSourceFiles()){if(sf2.isDeclarationFile||sf2.fileName.includes("/node_modules/"))continue;if(!sf2.text.includes(comp.name))continue;(function v(x){if(ts.isIdentifier(x)&&x.text===comp.name){let t=sym(c,x);if(t===s&&!(x.parent===comp.decl||x.parent===comp.fn)){const p=x.parent;if((ts.isJsxOpeningElement(p)||ts.isJsxSelfClosingElement(p))&&p.tagName===x){jsxCalls++;for(const a of p.attributes.properties){if(ts.isJsxSpreadAttribute(a))spreadAttr++;else{const an=a.name.getText();if(evt(an))evtAttr++;attrs[an]=1}}}else if(ts.isJsxClosingElement(p)){}else if(ts.isExportSpecifier(p)||ts.isImportSpecifier(p)||ts.isImportClause(p)){}else otherUse++;}}ts.forEachChild(x,v)})(sf2)}
 info.jsxCalls=jsxCalls;info.evtAttr=evtAttr;info.spreadAttr=spreadAttr;info.otherUse=otherUse;info.exported=!!ex;
 info.cls=(evtAttr===0&&spreadAttr===0&&otherUse===0&&jsxCalls>0)?"no-listener-callers":evtAttr>0?"callers-pass-listener":spreadAttr>0?"callers-spread":otherUse>0?"non-jsx-use":"no-callers";
 out.push(info);}
fs.writeFileSync("spreadcal.json",JSON.stringify(out));
const g={};for(const o of out){g[o.cls]=(g[o.cls]||0)+1}console.log(out.length,g);
const g2={};for(const o of out){const k=o.app+" "+o.cls;g2[k]=(g2[k]||0)+1}console.log(JSON.stringify(g2));
