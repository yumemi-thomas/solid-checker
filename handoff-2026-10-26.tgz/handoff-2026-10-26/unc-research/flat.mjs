import fs from "node:fs";
const s=JSON.parse(fs.readFileSync("/tmp/sc-sweep/rc17-sweep-rebuilt-9.json","utf8"));
const root="/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps/";
const out=[];
for(const r of s.results) for(const f of r.findings){ if(f.kind!=="uncertifiable") continue;
 const p=f.primaryLocation; out.push({id:f.id,ctx:f.analysisContext||"",app:r.app,project:r.project,file:p.path.replace(root,""),path:p.path,line:p.line,col:p.column,s:p.startByte,e:p.endByte,msg:f.message,ev:(f.evidence||[]).map(e=>e.message+" @"+(e.location?e.location.path.replace(root,"")+":"+e.location.line:""))});}
fs.writeFileSync("flat.json",JSON.stringify(out));
console.log(out.length);
