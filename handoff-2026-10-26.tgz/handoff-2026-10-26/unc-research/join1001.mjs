import fs from "node:fs";
const fl=JSON.parse(fs.readFileSync("flat.json","utf8")).filter(f=>f.id==="SC1001");
const pl=JSON.parse(fs.readFileSync("pl-sc1001.json","utf8"));
// pl is in same order as sorted flat (app,file)... join by app+file+line+first 30 of msg
const m=new Map();for(const f of fl)m.set(f.app+"|"+f.file+"|"+f.line+"|"+f.msg.slice(0,90),f);
const cls=msg=>/passed to a consumer that is not proven/.test(msg)?"A":/but no compiler or semantic fact places/.test(msg)?"B":/while evaluating a condition/.test(msg)?"C":/does not track/.test(msg)?"E-direct":"D";
const norm=u=>u.replace(/^bound:.*/,"bound").replace(/^called@fn:.*/,"called@fn").replace(/^objprop:.*/,"objprop").replace(/^arg(\d+)-of:([^:]*):.*/,(m,i,w)=>"arg-of:"+w).replace(/^jsx:component:[^:]*:(.*)/,"jsx:component-prop").replace(/^called@inline-in:(.*)/,"called@inline").replace(/^jsx:intrinsic:.*/,"jsx:intrinsic-on");
const out=[];for(const x of pl){const f=m.get(x.app+"|"+x.file+"|"+x.line+"|"+x.msg);if(!f)continue;out.push({...x,full:f.msg,k:cls(f.msg)})}
fs.writeFileSync("pl-sc1001j.json",JSON.stringify(out));
const tot={};for(const x of out)tot[x.k]=(tot[x.k]||0)+1;console.log(out.length,tot);
for(const K of ["A","B","C","D","E-direct"]){const g={};for(const x of out.filter(x=>x.k===K)){let k;if(!x.chain)k="NOCHAIN";else{const l0=x.chain[0];k=(l0.comp?"COMP-BODY":l0.kind+(l0.name?"(named)":"(anon)"))+" ["+[...new Set(l0.uses.map(norm))].sort().join(",")+"]"}(g[k]??=[]).push(x)}
 console.log("\n=== class",K,out.filter(x=>x.k===K).length);for(const [k,v] of Object.entries(g).sort((a,b)=>b[1].length-a[1].length).slice(0,8)){const apps={};for(const x of v)apps[x.app]=(apps[x.app]||0)+1;console.log(String(v.length).padStart(4),k.slice(0,130),"|",Object.entries(apps).sort((a,b)=>b[1]-a[1]).slice(0,3).map(([a,n])=>a+":"+n).join(","),"|",v[0].app+"/"+v[0].file.split("/").pop()+":"+v[0].line)}}
