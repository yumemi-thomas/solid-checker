import {spawn} from "node:child_process"; import fs from "node:fs";
const sweep=JSON.parse(fs.readFileSync("/tmp/sc-sweep/rc17-sweep-rebuilt-9.json","utf8"));
const rows=sweep.results.filter(r=>r.findings.some(f=>f.kind==="uncertifiable"));
const out={};let i=0;
async function w(){while(i<rows.length){const r=rows[i++];await new Promise(done=>{const ch=spawn("/tmp/sc-unc-research/bins/solid-checker-rust",["--format","json","--project",r.root+"/"+r.project,"--runtime-target","browser","--runtime-build","development","--rendering","csr"],{cwd:r.root,env:{...process.env,SOLID_CHECKER_DAEMON:"0",SOLID_TYPEFACTS_BIN:"/tmp/sc-unc-research/bins/solid-typefacts"}});const so=[];ch.stdout.on("data",d=>so.push(d));ch.on("close",()=>{try{const p=JSON.parse(Buffer.concat(so).toString());out[r.app+"|"+r.project]={premises:p.premises,n:p.findings.length}}catch(e){out[r.app+"|"+r.project]={err:String(e)}}done()})})}}
await Promise.all([w(),w(),w(),w()]);fs.writeFileSync("premises.json",JSON.stringify(out));console.log("ok",Object.keys(out).length);
