// usage: node show.mjs RULE [ctx-substring] [msg-substring] [N] [ctxLines]
import fs from "node:fs";
const [rule,ctx="",msg="",n="12",cl="4",seed="0"]=process.argv.slice(2);
const all=JSON.parse(fs.readFileSync("/tmp/sc-unc-research/flat.json","utf8")).filter(f=>f.id===rule&&(ctx===""||ctx==="-"||f.ctx.includes(ctx))&&f.msg.includes(msg==="-"?"":msg));
// stratify across apps
const byApp={};for(const f of all)(byApp[f.app]??=[]).push(f);
const apps=Object.keys(byApp);let picked=[];let i=+seed;
while(picked.length<+n&&apps.some(a=>byApp[a].length)){for(const a of apps){if(byApp[a].length&&picked.length<+n){picked.push(byApp[a].splice(i%byApp[a].length,1)[0]);}}}
console.log("total matching",all.length,"apps",apps.length, JSON.stringify(Object.fromEntries(apps.map(a=>[a,all.filter(f=>f.app===a).length]))));
for(const f of picked){console.log("\n=== "+f.app+"/"+f.file+":"+f.line+":"+f.col+"  ["+f.ctx+"] "+f.msg.slice(0,160));
 if(f.ev.length>1)console.log("   ev:",f.ev.slice(0,3).join(" | ").slice(0,400));
 try{const L=fs.readFileSync(f.path,"utf8");const lines=L.split("\n");const a=Math.max(0,f.line-1-(+cl)),b=Math.min(lines.length,f.line+(+cl));
  for(let k=a;k<b;k++)console.log((k+1===f.line?">":" ")+String(k+1).padStart(4)+" "+lines[k].slice(0,170));
  console.log("   TOKEN:",JSON.stringify(Buffer.from(L).subarray(f.s,f.e).toString().slice(0,80)));}catch(e){console.log("   (unreadable)",e.message)}}
