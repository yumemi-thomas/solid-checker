# Uncertifiable-result research: root causes and sound fixes (rc.17 sweep 9)

Scope: `/tmp/sc-sweep/rc17-sweep-rebuilt-9.json` (34 projects, 6,052 uncertifiable, 372 violations).
Read-only: no repo file edited, no cargo/make run. Probes ran the **copied** release binary
(`rust/target/release/solid-checker-rust`, built 2026-10-25 20:38, copied to `/tmp/sc-unc-research/bins/`) on a scratch project
in `/tmp/sc-unc-research/probe/` (its `node_modules` is a symlink to the ai-memory-ui corpus install, signals/web rc.17).
All numbers below are **estimates** from classifying every finding in each bucket with the TypeScript checker
(exact symbol resolution of the function holding the site, every reference to it, the callee/consumer kind) and reading 10-20 samples per bucket. They were not obtained by running a fixed checker. Where a count says "reachable" it is an upper bound on what the slice can clear; the other gating reasons on the same finding are not subtracted unless stated.

Tooling (reusable, all in `/tmp/sc-unc-research/`): `flat.json` (all 6,052 findings with locations), `show.mjs` (stratified sampler with source), `place.mjs`/`agg2.mjs` (function-placement census for a rule), `factory.mjs` (factory-result consumer census), `cls.mjs`/`paramuse.mjs` (callee/parameter classification), `compcensus.mjs`, `spreadcal.mjs` (component caller census), `tryhead.mjs`, `premises.json` (dispatch-veto premises of all 31 projects with uncertifiable findings).

## 0. Headline

* The distribution is very skewed. `app-game` holds 2,838 of 6,052 (47%); `kui` 942 (11 sub-projects), `inferay` 582, `probus-hk` 343, `donegeon-client` 291, `ai-memory-ui` 257. Fixes that unlock one of those projects dominate the totals. All 34 projects run with the *closed* program boundary (`default_program_boundary`, `diagnostics.rs:1292-1325`: `private: true` or no publish field).
* Eight causes explain most of the four named buckets. Ranked (reduction x confidence / effort), details in section 2:

| # | slice | rule(s) | est. reachable | conf. | effort | seam |
|---|---|---|---|---|---|---|
| 0 | **Soundness: SC2001 false positives** (dead JSX-returning function, module-level IIFE / `.map` callback) | SC2001 | 0 (removes violations) | high, probe-verified | S | solid-reactive-ir |
| 1 | After-await / catch / finally write role = join(entry role, ownerless continuation) | SC2001 | 245 sites (164 outside veto projects) | med-high | S-M | solid-reactive-ir `execution_role/write_roles.rs` |
| 2 | Closed-program caller enumeration for exported components (props reactivity) | SC1001 | 100-150 (342 findings carry the clause) | med | S-M | solid-reactive-ir `source_discovery/props_reactivity.rs` |
| 3 | Member access on an exact factory/object result, cross-file (`r.add()`, `export const store = {...}`) | SC2001, SC1001, SC9012 | 450 of 825 | med | M-L | solid-reactive-ir `execution_role/invocation_flow.rs`, `object_members` |
| 4 | Dispatch veto (ADR 0356/0393/0395): 16 sites in 5 projects hold 570+ findings | SC2001, SC1001 (+SC4001 owner proofs) | 570 lower bound; 160 for inferay alone | high per site | S per site, all-or-nothing per project | solid-reactive-ir `indexes/event_delivery.rs` |
| 5 | Caller-literal discharge of handler sites (`onClick={props.x}`, `{...rest}`) | SC4001 | 170 of 431 | med | M | solid-reactive-ir `object_members/handlers.rs` + prop census of slice 2 |
| 6 | Reads: extend ADR 0400's invocation flow to SC1001 callbacks (project component props, project function args) | SC1001 | 150 of ~330 | med-low | L | solid-reactive-ir `execution_role/callee_roles.rs` |
| 7 | SC9012 leaf callbacks (createTrackedEffect/onSettled): accessor/setter transport through parameter objects and destructuring; member calls of factory results (rides on 3) | SC9012 | 250 of 561 | low-med | L, scattered | solid-reactive-ir `accessor_provenance`, `cleanup.rs` |
| 8 | SC9012 `parameter-*` (1,103): lib.dom/Array receivers and typed-primitive arguments | SC9012 | 150-350 | low; **design decision** | M | needs owner decision (ADR 0320 says "never from its declared type") |

If slices 1-6 land, the reachable total is roughly 1,400-1,700 of 6,052 (23-28%) after removing overlaps (a finding often has two gaps). The remainder is package behavior (three/pixi/typegpu/maplibre classes, @tanstack hooks, createHotkey), workspace-package isolation (kui), and the typed-value tension of slice 8.

Proposed order: **0, 1, 2, 3, 4 (inferay first, then app-game's EventTarget sites after 3), 5, 6, 7**; 8 only after the owner decides on the premise. Rationale at the end.

## 1. Bucket map

SC2001 (1,917) causes, priority-assigned (each finding counted once, `causes2001.mjs`):

| cause | count |
|---|---|
| dispatch-veto: inline/named intrinsic `on*` handler in a veto project | 285 |
| after-await / catch / finally write (non-veto projects 164, veto projects 81) | 245 |
| closure returned in an object by a factory/hook (`r.method()`, shorthand member), consumed elsewhere | 425 |
| callback prop passed to a project component (`<C onX={fn}>`) | 353 |
| helper called from other functions (call chain; mostly factory internals) | 337 |
| callback argument of a package/lib function (`add/removeEventListener` 64 findings, `createEventListener`, `onCleanup`, timers) | 153 |
| argument of a project function | 27 |
| other (object property, returned, assigned) | ~90 |

SC1001 (1,423): "component prop X is read ... call sites cannot be enumerated" appears on 577 findings (props backing unprovable); callbacks stored in objects 296; dispatch veto 157-284; callbacks to project components 82-226; arguments of project functions 106; arguments of package functions 67 (`causes1001.mjs`; by message class: callback-to-unproven-consumer 571, no-placement-fact 610, while-evaluating-condition 43, direct body read 198).

SC9012 (2,170): `createTrackedEffect`/`onSettled` 561 (reported *at the unresolved call inside the callback*), `parameter-member-target-unresolved` 563, `parameter-use-unmodeled` 540, `exported-parameter-member-dispatch` 134, `withheld-object-member` 104, others ~270 (`parameter-member-path-unresolved` 100, `parameter-member-targets-diverge` 40, `returned-callable-outside-source-universe` 40, `computed-call-target-unresolved` 17, `parameter-default-unresolved` 35, router getter 8, ...).

SC4001 (497): handler-spread 241, handler-member 190 (146 are `props.<name>`), "(none)" 66.

## 2. Root causes, fixes, soundness

### Slice 0 (soundness first): SC2001 false positives — confirmed by probe

`docs/open-work.md:137` says "unverified by probe". Probe results (this binary; `src/a.tsx` in `/tmp/sc-unc-research/probe`, all with `const [n, setN] = createSignal(0)`):

| code | result | verdict |
|---|---|---|
| `export const rows = [1,2,3].map((x) => { setN(x); return <li>{x}</li>; })` (module-level) | **violation**, "inside owned scope" | false positive: module-evaluation code has no owner |
| `export const once = (() => { setN(5); return <b>{n()}</b>; })();` | **violation** | false positive, same reason (the write is outside the JSX expression) |
| `function dead(x){ setN(x); return <li>{x}</li>; }` (unreferenced, not exported) | **violation** | false positive: never runs, treated as a component |
| `export const makeRow = (x) => { setN(x); return <li>{x}</li>; }` (exported, zero references) | **violation** | same |
| `export function renderRow(x){ setN(x); return <li/> }` + `export function onPick(){ return renderRow(1) }` | uncertifiable | fine |
| `export const ys = [..].map((x) => { setN(x); return x; })` (non-JSX) | uncertifiable | fine |

Cause (from ADR 0331/ADR 0334 text and the behavior): a lowercase JSX-returning function is "a proven component only where every reference is one ADR 0331's census accepts" — with **zero** references the census is vacuously true, so dead or exported-but-unreferenced code becomes a component and its body an owned region. Separately the module-level region (outside any function/class) is given an owned lexical role when it contains JSX. Fix: require at least one accepted reference (and in an open program none), and never give a module-top-level region, or an IIFE/`.map` callback evaluated there, the component role. Add the six rows above as fixtures (positive/negative/shadowed per AGENTS.md). Risk: low; it can only turn violations into uncertifiable.

### Slice 1: write after a possible suspension — SC2001, 245 sites

Where: `execution_role/write_roles.rs:223` (`may_follow_suspension` -> keep `Unknown`), `:402` and `suspended_write_role` `:766-777` (`follows_dominating_await || follows_try_head_await` -> `Unreported`, else `Unknown`), `body_roles.rs:174-262` (`follows_try_head_await`, `operand_cannot_throw`).

What the code proves today: a write is legal after a *dominating* await, or in a `catch`/`finally` whose `try` starts with `await f(args)` where `f` is a plain-identifier async **function declaration** and every argument is a literal or a parameter of the enclosing function. Everything else after an await is `Unknown`.

Probes (same binary): all four have the handler `onClick={() => load()}` as the only caller of `load`.

| `load` body | result |
|---|---|
| `try { await fetch("/x"); } catch { setN(1); }` | uncertifiable |
| `try { await get(id) } catch { setN(1) }`, `get` async declaration, `id` a parameter | **certified** |
| same, `id` is a `const` local declared before the `try` | uncertifiable |
| `if (props.go) await get(); setN(1);` (await in a branch) | uncertifiable |

Missing proof: the join. A write that follows a possible suspension runs either (a) before the first suspension, on the caller's stack, where its role is the *function's entry role* (the thing `write_flow_role` already computes for a write at the top of the function), or (b) in the ownerless continuation (ADR 0333: a resumption has no owner and no window). Its role is legal when the entry role is a placed non-reporting role (event handler, ownerless, `Unreported`); it is a violation only on the owned path. The code instead returns `Unknown` whenever the path is not provably suspended. Fix sketch: in `semantic_write_role` after `may_follow_suspension`, compute the entry role through the existing walk (without the suspension short-circuit) and return `Unreported` if it is a placed non-reporting role, else keep `Unknown`. Keep the ADR 0400 `write_flow_role` rule unchanged for *flow through other functions* (a layer past a suspension is still not placed by the callers); only the answer for the function's own entry changes. No new Type Facts demand; the proof digest already binds `write_flow_answers`.
A smaller secondary extension of `operand_cannot_throw`: callee any `async` function (declaration, `const` arrow, exact method) and arguments that are literals, parameters, or `const`/`let` bindings declared before the `try` in the same function's straight-line flow (no TDZ possible). WebIDL promise-returning operations (`fetch`, `navigator.clipboard.writeText`) never throw synchronously, but that is a spec premise, not bytes; keep it separate and documented.

Samples: `ai-memory-ui/src/routes/login.tsx:98` (catch after `await signIn(u, p)`, `u`,`p` const), `donegeon-client/web/apps/client/src/components/task/HomeSectionManager.tsx:49` (catch after `await organizationApi.sections.list(projectId)`), `ai-memory-ui/src/lib/auth.ts:349` (write after try/catch over `await fetch(..., {headers: {...csrfHeaders()}})`), `solid-groove/src/library/useLibraryBrowser.ts:238`.
Reachable: 245 (donegeon 80, ai-memory-ui 56, app-game 41, kui 20, inferay 16, ...). 81 of them sit in veto projects and stay held by slice 4. Estimate of what clears: 60-70% of the 164 outside veto projects (functions whose callers are all event/placed), so 100-115 now. Confidence medium-high (clear repro, one function to change); soundness argument above.
False-positive risk: none (silence only). Runtime fact it rests on: owner is the module variable `context` returned by `getOwner()` (`@solidjs/signals@2.0.0-rc.17` `dist/dev-shared.js:1405-1407`), set/restored only by `runWithOwner` and computation runs (`dev-shared.js:5758-5783`), so a microtask resumption sees `context` as left by the finished synchronous run — the ADR 0333 premise, which I did not re-audit.

### Slice 2: closed-program enumeration of exported components — SC1001, 342 findings carry "call sites cannot be enumerated"

Where: `source_discovery/props_reactivity.rs:7-60` (`PropUse`, `PropsReactivity::{Enumerated, Escaping}`), wording `rust/dialects/solid-v2/rules/src/lib.rs:85-88`. A component that is "exported, referenced outside JSX, or spread into" is `Escaping` even in a closed program, so no prop can be proven static and every untracked prop read is an obligation. ADR 0203/0214 already discharge the SC9012 analogue in a closed program.

Census over the 577 findings carrying the clause (`compcensus.mjs`): 232 findings are in exported components whose *only* references are JSX tags, imports and export specifiers and whose callers pass no spread (enumerable in a closed program); 52 more in non-exported ones (so another reason makes `Enumerated` unresolved: values the engine cannot classify, i.e. `unresolved` props); 159 have callers that spread into the component (stay); 80 are exported with no JSX caller at all (route/lazy/dead, stay); 48 have non-JSX references (`routes = { Home }`, calls; stay). Of the 280-340 findings eligible by the census (232 + 52 by component census, 342 by the priority classifier), about 100 are direct body reads (`does not track` wording) whose *only* gap is this one; the rest also carry the placement gap (veto, callbacks), so they clear only together with slices 3-6.
Fix sketch: in a closed program, treat an exported component whose every reference is a JSX tag, an import binding, an export specifier or a `typeof` type query as `Enumerated`; keep `Escaping` for `export *` barrels the census cannot see through, aliases, namespace reads, `createComponent`, `<Dynamic component>` and anything ADR 0203's list refuses.
Premise risk (important): `private: true` makes `default_program_boundary` answer `Closed`, but in a workspace a `private` package's exports are used by sibling packages that are not in the analyzed program (kui's `kernel` is imported by every `feature-*`). ADR 0203/0214/0400 and this slice then certify "no other caller". Recommend at least not defaulting to closed when the manifest sits under a workspace root (`workspaces`, `pnpm-workspace.yaml`) and the package is depended on by a sibling, or require `--program-boundary closed` explicitly for monorepo packages. This is an existing exposure, not new.
Confidence medium (the census is exact; the unresolved-values fraction is unmeasured). Effort S-M. False positives: none (silence); false *certification* only under a wrong closure premise.

### Slice 3: member access on an exact factory result or module object, across files — SC2001 425, SC1001 ~296, SC9012 104

This is the largest single lever and the clearest minimal repro. Probes (writes through the setter of a `createSignal` inside the object's methods):

| layout | result |
|---|---|
| same-file `const d = { has: id => rows().includes(id), add: id => setRows(...) }`, used in `onClick` and tracked JSX | certified |
| same-file factory `function createDismissed(){...return {has, add}}`, `const d = createDismissed()`, `d.add()` | certified |
| **cross-file** `export function createDismissed(){...}`, `const d = createDismissed(); d.add(...)` in a handler | **SC2001 uncertifiable** at the setter in the factory |
| cross-file factory consumed as `const { add, has } = createDismissed()` | **certified** (ADR 0400's object-pattern arm) |
| cross-file `export const dismissed = { has, add }` imported and used as `dismissed.add()` | **SC1001 + SC2001 uncertifiable** inside the object, and **SC9012 `withheld-object-member`** at `dismissed.has(props.id)` (the probus Alert.tsx:35 pattern) |
| cross-file factory used at module level in the consuming file, `d.add()` in a handler | SC2001 uncertifiable |

So the gap is exact: the invocation flow binds a member of a factory result only through `const { k } = call()` (ADR 0400, `execution_role/invocation_flow.rs`), and the same-file holder logic does not carry across modules for `binding.member(...)` or `export const obj = {...}`.
Corpus incidence: 378 SC2001 findings are in closures a factory returns in an object literal (193 in app-game: `createWorkspace`, `createEditorSelection`, `createViewportCamera`...; kui `createSession` 30, `createCurrentCluster` 10, `createRootPreference` 10; compass `createAppStore` 23; solid-groove `useLibraryBrowser` 15; every-deck `createExplorerPosition` 14), 288 of them from factories imported elsewhere. SC1001: reads inside object-stored closures `gutter: () => props.gutter ?? 0`, getters and methods in context values (class A, 231 + 36 + 15 + more; `ai-memory-ui/src/components/popover.tsx:107`, `workspace-cascader.tsx:120`). SC9012 `withheld-object-member`: probus `~/stores/*` (67), app-game (32), inferay (3), dashiboard (2).
Missing proof / fix sketch (solid-reactive-ir only, no protocol bump):
1. Extend the holder walk to a `member(...)`/`member` reference of a `const` binding whose initializer is a call of an exact project function (or an import of an exported `const` object literal), where the function's one unconditional return is an object literal with static keys and no getter/`__proto__`/`this` use (the same conditions ADR 0366/0400 state for object holders) and the member is not written (`member_name_may_be_reassigned`, `reflective_prototype_write`, already used by ADR 0203/0338).
2. Each call of the factory (cross-file calls through `exported_call_sites`) gives one binding; each reference of `binding.member` is an invocation to place (call in handler, tracked JSX, body, passed on). The answer is joined as for a plain function (ADR 0378); an escape of the binding (stored, passed as a whole, spread, returned, put in context) keeps the obligation.
3. For SC9012 `withheld-object-member`: `object_members::call_withheld` returns true for a literal receiver whose member is not in `object_member_targets()`; resolve the imported `const` object literal the same way (`value_origin` already handles `const` chains in the file).
Risk: false positives none (resolves obligations toward clean or toward the existing violation roles; an owned invocation then makes the write a violation, which is correct under ADR 0378). Digest: the per-build answer table is already bound into the proof digest (ADR 0400); add member holders to the cross-file digest inputs.
Estimate: SC2001 425 x 0.6 = 250, SC1001 296 x 0.5 = 150, SC9012 104 x 0.5 = 50, total about 450; confidence medium (factory consumers with escapes — `merge(...)`, spread into context providers, `Object.assign` — will stay). The eventDispatcher dispatch sites of slice 4 also need this slice.

### Slice 4: the dispatch veto — 285 SC2001 + 284 SC1001 (lower bound) from 16 sites in 5 projects

Mechanism: ADR 0356 withholds every event-owner and strict-read-window proof while any synchronous dispatch site remains unexcluded (`indexes/event_delivery.rs`). Probes confirm the severity: in a project whose only inline-handler component is clean, adding **one** `events.dispatchEvent(new Event("change"))` on a fresh `new EventTarget()` inside a *never-called* exported function turns SC2001 and SC1001 on the handler uncertifiable ("premise: B.ts:2 withholds event handler owner and read proofs: receiver unknown"); the same dispatch on `window` is excluded (ADR 0393) and the project stays certified; `window.addEventListener("keydown", () => el.click())` is withheld ("receiver element").
Veto sites (from the `premises` array of the release binary; `premises.json`):

| project | sites | what they are | what would exclude them soundly |
|---|---|---|---|
| inferay | 1: `src/modules/repository/hooks/useRepositoryWorkbench.tsx:781` `diffRailElement?.querySelector(..)?.dispatchEvent(new CustomEvent(..))` inside `handleDiffKeyboardNavigation`, registered through the project helper `listenWindowEvent(type, fn)` = `window.addEventListener(type, fn)` (`src/shared/lib/dom.tsx:280`) | a function registered with lib.dom `addEventListener` is invoked only by event delivery, the same fact that makes a JSX handler event-only (ADR 0395's induction applies unchanged); follow the parameter through the project wrapper with ADR 0400's walk |
| app-game | 7: `curves/pageTileCache.ts:291`, `prepareRasterImages.ts:393,430`, `prepareCurveDocument.ts:163,189` dispatch on `const events = new EventTarget()` or its member `tileCache.events`; `packages/ui-components-examples/cursor-emulation/eventDispatcher.ts:168,189` dispatch synthetic pointer events on real elements (`createEventDispatcher` called from `index.tsx:55`) | receiver is a fresh `new EventTarget()` (not a `Node`): a dispatch on it reaches only listeners added with `addEventListener` on that object, never a JSX handler (JSX handlers live on element nodes, `web.dev.js:806-830` `addEvent`; delivery walks `composedPath()` of the event target, `web.dev.js:1969,2013`). The member form needs slice 3. The two cursor-emulation sites are real and need the caller chain (`dispatcher.dispatchActions(...)`, a member call of a factory result, slice 3) placed in a timer/rAF/event callback |
| kui | 2: `kernel/src/components/VirtualizedTable.stories.tsx:316,320` `scroller.dispatchEvent(new Event("scroll"))` in a Storybook `play` function | no reviewed runner; the dispatch is real. Leave (33 findings), or add Storybook `play` as a reviewed test callback only with bytes of its runner |
| probus-hk | 2: `src/components/TabBar.tsx:271-272` `createHotkey(KEY, () => searchLink.click())` | callback handed to a package function: needs dependency source of `createHotkey` (ADR 0266) to show it runs from a keydown listener |
| skyjtx-website | 4: `tests/presentations/about.test.tsx:68,82,95,135` `el.dispatchEvent(..)` on `document.createElement("div")` inside `createRoot(...)` inside `it(...)` | fresh element never handed to JSX/`render` (receiver identity proof); 10 findings, low value |

All-or-nothing per project is the structural problem: one remaining site keeps all of a project's handler proofs withheld. Order within the slice: (a) addEventListener-registered functions are event-only, incl. through one project wrapper, and dormant (zero-reference, closed program) functions leave the veto — frees inferay (SC1001 118 + SC2001 43 + 1 SC4001-adjacent, about 160+) and also gives a **listener role**: 64 SC2001 findings sit in functions referenced as `window/element.addEventListener(type, fn)`/`removeEventListener` (`removeEventListener`'s argument is `ValueOnly` for the reference census); (b) non-Node `EventTarget` receivers (exact `new EventTarget()`, or a class extending it); (c) slice 3 for the member form and the emulator chain.
Soundness for (a): same induction as ADR 0395 (while any non-excluded site remains every proof is withheld; with none, every delivery comes from a host event). `removeEventListener(type, fn)` neither invokes nor registers. A function that is *also* called directly elsewhere keeps the mixed-entry rule. Soundness for (b): receiver exactness must follow ADR 0393 (resolve through the `lib.dom` `EventTarget` declaration and the exact `new` of a `const`, never by spelling; a parameter named `events` keeps the veto); registered listeners on that object are non-JSX listeners the census never seeds as ownerless (ADR 0327 only seeds compiler event handlers), so the exclusion does not affect them. Note: removing the veto also strengthens SC4001 ownerless claims; the 49 SC4001 "(none)" findings in veto projects (app-game 42, kui 7) may become violations, not clean — review each before updating snapshots (AGENTS.md invariant 6).
Confidence high per site; value depends on freeing whole projects (inferay yes; app-game only after slice 3).

### Slice 5: SC4001 handler sites — 431 findings, discharge from callers

Probes (cross-file `Parent` passes `onDone={() => setN(n()+1)}` and `label`):

| `Child` | result |
|---|---|
| `onClick={() => props.onDone()}` | certified |
| `const { onDone } = props; onClick={() => onDone()}` | certified |
| `onClick={props.onDone}` | **SC4001 `handler-member-unresolved`** at Child |
| `const rest = omit(props, "label"); <button {...rest}>` | **SC4001 `handler-spread-unresolved`** at Child |

The child-side obligation is redundant when every caller passes an exact function literal: the literal is analysed at its own site (ADR 0327 census; an owner primitive created inside would be SC4001 there). Emission: `object_members/handlers.rs:187-250` (`unresolved_handler_defects`).
Census: of 241 spread sites (`spreadcal.mjs`), **94** are in components whose every JSX caller passes no listener-named attribute and no spread, in a closed program (shadcn-style `Badge`, `Card`: `ai-memory-ui/src/components/badge.tsx:37`, `expenses-app/src/components/ui/badge.tsx:33`, `pekochan-blog`, `probus-hk`); 51 callers pass `on*` (resolvable only by the literal-discharge), 11 spread, 13 non-JSX use, 50 have no caller (20 are exported, vacuous in a closed program), 22 not in a component. Of 190 member sites, 146 are `props.<name>` (2 deeper), 42 are members of factory results (`workspace.undo`, `sensor.onPointerDown`: slice 3).
Fix: reuse slice 2's component census. Discharge the spread obligation when no caller can supply a listener key (callers' attribute names exhaust the keys and none is event-named, no spread caller, no `merge`/`ref` forwarding — this is ADR 0394's idea applied to the callers' key set instead of the declared type, so it needs no Type Facts change); discharge `props.<name>` when every caller passes a function literal or exact named function for that name (ADR 0400's `props.<name>` walk, `jsx` attribute -> value). Estimate 94 + about 80 = 170, confidence medium. Soundness: needs the exact-resolution of the component and closure of its callers (same premise as slice 2).

### Slice 6: strict-read callbacks (SC1001 class A, 571; class B 610) — reads analogue of ADR 0400

`callee_callback_timing` (`execution_role/callee_roles.rs:1089-1200`) withholds a read written in a function literal handed to a project function or a JSX prop (message "passed to a consumer that is not proven to invoke it"). ADR 0400's write flow places the same literals; ADR 0400 lists "reads for a forwarded or aliased owned call" as not built.
Census: 138 (class A) + 80 (B) callbacks passed as props to **project** components (almost all consumers resolve to project declarations: 130+80 of 226 where the tag symbol resolves; the rest are 16 unresolved symbols and 2 `@solidjs/web`), 106+35 arguments of project functions, 36 getters and 15 methods in context/option objects, 67 arguments of package functions (`useQuery`, `createMutation`, `onSettled` callbacks of @tanstack/solid-query, `createResizeObserver`; needs dependency source: leave).
Fix sketch: for a read in a literal handed to `props.<name>` of an exactly resolved project component, take the join of the places the child invokes `props.<name>` (call in a tracked JSX region or computation = tracked, in an event handler = event, in the body = untracked => the read is the SC1001 violation, forwarded to another component recurses), exactly as `write_function_role`/`write_site_role` do for writes (`execution_role/event_literals.rs`, `invocation_flow.rs`). Not-followed list the same as ADR 0400 (destructured props, spread, `merge`/`omit` views, `let`). Estimated reduction 150 (many of these also need slices 3/4); effort L because the read roles (strict-read window, `reports_untracked_read`) are richer than the write roles. Confidence medium-low.

### Slice 7: SC9012 leaf callbacks (createTrackedEffect/onSettled, 561)

Emission: `cleanup.rs:56-360` — one `UnresolvedCallback` per call in the callback's synchronous extent that `helper_forbidden_operations` (`cleanup.rs:717-905`) cannot follow to a body or a resolved std-lib member. The finding is at the **call** (the rule page says "at the call written in it"), so the unit is one call, and the callee decides. Census by callee kind (`cls-cte.json` + `cls-os.json`, 561):

| callee | count | proof available / missing |
|---|---|---|
| member call of a project-typed object (`tree.applyExpansion`, `selectedBackend().sources.tree`, `ancestor.setExpanded`) | ~145 (93 + 47 + 5) | exact factory-result member, slice 3 |
| accessor/setter that comes from a context/param **object** (`const { activeBoardID, setError } = context` where `context: BoardControllerDeckContext`) | 53 (donegeon), 26 (project hook destructured result, app-game) | accessor provenance transport across a parameter object whose single call site passes a spread of hook results (`Value::Object`/`context` in `accessor_provenance.rs`); safe_call_symbols/setter_symbols are not populated for them |
| project `FunctionDeclaration` reported at the outer call (51) | 51 | the incompleteness comes from a deeper call (`complete == false` pushes the obligation at the outer callee, `cleanup.rs:268-293`): a diagnostic improvement (report the deepest unresolved call) would show which of the other rows is the real gap |
| member of a package class instance (three/pixi/typegpu/rapier/maplibre) | ~100 (pixi 11+18, three 10, typegpu 13+13+11, rapier 8, dockview, rxjs) | needs dependency source or a "package has no path to Solid/the project's callbacks" proof; leave |
| lib/Array/DOM member through binding or parameter receiver | 53 (32 + 21) | ADR 0397's std-lib trust requires `resolved_callee_call(..).declaration.standard_library`; these are receivers typed from destructured bindings (`GPUCanvasContext` ...). Check why the declaration is not resolved (missing call fact?) before building anything |
| `access()` of `@solid-primitives/utils` | 16 | ADR 0338 knows `access(getter)`; remaining: `access(props.x)` shapes whose argument is not a proven getter |
| immediately invoked literal `(async () => {...})()` | 18 | reported at the IIFE call; the IIFE body then holds the unresolved call: report there instead |
| other (class construction, bitecs, signals function) | ~30 | leave |

Soundness is untouched by any of these (they discharge obligations toward "no cleanup/flush/primitive in the leaf scope" only when the callee body is read). Estimated 250 (43%) with the factory slice already counted in slice 3 (don't double count: slice 3's 50 SC9012 includes none of these). Confidence low-medium: scattered, each row a separate sub-slice. The `access()` and IIFE rows are small and cheap.

### Slice 8: SC9012 `parameter-*` families — a decision, not a bug

`parameter-member-target-unresolved` 563 and `parameter-use-unmodeled` 540 fire when a call in a component body (or other render position) passes a non-primitive, non-function argument to a project function that invokes a member of, or otherwise uses, that parameter (`interproc/result_reads.rs:957-1070`, `parameter_use.rs`). Whether the value is a reactive proxy is decided **by value origin, deliberately not by declared type** (`argument_is_proven_primitive`: "never from its declared type: an assertion, a type predicate or `any` changes the type and not the value"). With that rule, the following are open (counts from `paramuse.mjs`/`cls-pmt.json`):

* `parameter-member-target`: the invoked member's declaration is in a lib file for 205 (DOM `addEventListener` 48, `getBoundingClientRect` 19, `preventDefault`, WebGL/2D context methods, `Array.map/filter/find/some/reduce`), a project interface/property for 276 (kui `KuiApiClient.get/post/put/delete` 108: a context-provided object whose provider is in another workspace package, see below), other packages 37, unknown 45.
* `parameter-use-unmodeled`: 154 of 540 arguments have a primitive declared type (`string` 116, `number` 16, literal unions) but no value-origin proof (`sinceDays()` of a `createSignal<7|30>`, `props.projectId`, a callback parameter `timestamp: number`); 13 arguments are function-typed.

Two sound routes exist; the first is cheap but needs the owner's sign-off:
1. **Receiver-class proof (DOM/Event/Window only).** A store never wraps a DOM `Node` or an object whose `Object.prototype.toString` tag is not `[object Object]`: `@solidjs/signals@2.0.0-rc.17 dist/dev.js:2272-2283` `isWrappable` returns false for both, so a store/props proxy can never *be* an element, event or window. The obligation is "a caller-supplied value might be a reactive proxy whose members read tracked state"; for a parameter whose declared member resolves to a `lib.dom` `Node`/`Event`/`Window` interface the only way to violate is a hand-written look-alike object. This is a **declared-type premise** and conflicts with the wording of ADR 0320; it would have to be recorded as a reviewed premise like ADR 0397's std-lib trust (which already trusts `lib.dom` member declarations for local calls). Estimated 150-200 (DOM and event receivers; **not** `Array` methods, since arrays can be store proxies: `isWrappable` is true for `Array.isArray`).
2. **Value-origin for primitives**: make `proven_primitive` follow a `createSignal` accessor call (every write to the setter, found by the setter census, is a proven primitive), an enum/const, and a parameter whose every call-site argument is proven (ADR 0213's closed-program caller proof, now extended to signal accessors). This stays within the invariant. Estimated 60-100 of the 154 typed-primitive arguments. Effort M-L.
Not recommended: trusting `string`/`number` declared types directly (any `any`/assertion upstream falsifies it; the existing `runtime_type_escape` bit only covers the argument expression itself).

`exported-parameter-member-dispatch` (134): ADR 0203 discharges it in a closed program only when every reference is a call; these are exported **components** (`export function DataGrid(props)`; `props.workspace.root`, `props.state.visible`) whose props reach member calls. ADR 0214 covers `props.name` with a built-in value; the remaining ones pass objects from factories (slice 3) or deeper paths (`props.a.b()`); 70 are app-game, 24 sensor-sim (Convex handlers `handler: async (ctx, args) => ...`, a package callback contract, SC9005-like).

## 3. Cross-cutting findings the owner should know

1. **Shared infrastructure**: slices 2, 5 and 6 all need one thing: an exact per-component census (callers' attribute names and values, spread/escape flags), keyed by the props parameter declaration, closed-program-aware. Build it once (extending `PropsReactivity`) and expose it to `object_members/handlers.rs` and `execution_role/callee_roles.rs`. Slices 3 and 4 share the member-holder walk.
2. **Workspace packages are analysed in isolation.** kui's 11 sub-projects give 942 uncertifiable; `kui.api` (`useKui()` in `kernel/src/feature/context.tsx:169`) is provided in `shell`, outside the project being analysed, so the 108 `KuiApiClient.*` SC9012 and many SC4001/SC2001 flows end at a package boundary. Resolving workspace-linked packages to their TS source as analysed program files (not dependency bytes) would turn them into project facts. Separate decision; not sized.
3. **`default_program_boundary` and workspaces**: see slice 2 premise risk.
4. The SC9012 leaf-callback finding is reported at the outer call when an inner call is the gap (`cleanup.rs:268-293`), which inflates the "project function declaration" row (51) and hides the real missing fact. Reporting the deepest unresolved call would make the bucket self-diagnosing.
5. Possible real defects among the samples: none found. `app-game/apps/night-defense/src/StartMenuScene.tsx:89` looked like an effect after a `return` but the file does `const scene = (...)`; `return scene` at line 121. The SC4001 "(none)" 60 are hooks/components whose caller placement is unknown (`useAppState`, `useContext` in jandibat/kui hooks; effects in solid-groove hooks): obligations are correct, the fix would be the hook-caller census of slice 3.

## 4. Why this order

* **0** removes unsound violations first (cheap, no obligation counts depend on it).
* **1** is one function and the repro is four lines; it removes a documented 12.8% of SC2001 in 12 of 21 affected projects without a premise change.
* **2** is the existing ADR 0203/0214 idea applied to the props-backing proof; small code, but fix the workspace closure premise at the same time.
* **3** is the largest absolute lever and unlocks parts of 4, 5 and 7.
* **4** needs 3 for app-game; do inferay's listener-registration step as soon as the wrapper-parameter walk exists. It is the only slice that can turn uncertifiable into *violations* (SC4001), so review snapshots carefully.
* **5, 6** share the prop census; 6 is the expensive one.
* **7, 8** are scattered or need decisions.

## 5. What I did not verify

* No fixed checker was run; every "reachable" figure is a census upper bound times a judgment of the success rate. Overlaps between slices are only partly removed (the 3, 4, 6 families overlap on the same findings).
* The probes used the repo's release binary as of Oct 25 20:38; the working tree is being edited concurrently (`git status` showed uncommitted changes in `diagnostics.rs` and the compiler), so a rebuilt binary may differ.
* Sample reading covered 10-20 findings per bucket across apps; sub-bucket labels in tables 7-8 come from symbol resolution, not from reading each site.
* `dispatchAsInteraction` (`@solidjs/web` `dist/web.dev.js:653-660`) wraps handlers in an attribution call; I read it as non-owner-creating but did not audit the observe bundle. ADR 0327's premise is taken as given.
* The WebIDL "promise-returning operations never throw synchronously" statement in slice 1 is a spec premise, not bytes.

## Appendix: probe sources

`/tmp/sc-unc-research/probe/` (private package, `solid-js`/`@solidjs/web` rc.17 via symlinked `node_modules`, `tsconfig` with `jsxImportSource: "@solidjs/web"`). Run:
`SOLID_CHECKER_DAEMON=0 SOLID_TYPEFACTS_BIN=/tmp/sc-unc-research/bins/solid-typefacts /tmp/sc-unc-research/bins/solid-checker-rust --format json --project /tmp/sc-unc-research/probe/tsconfig.json --runtime-target browser --runtime-build development --rendering csr`

Member-flow minimal repro (slice 3), cross-file:
```ts
// store.ts
import { createSignal } from "solid-js";
export function createDismissed() {
  const [rows, setRows] = createSignal<string[]>([]);
  return { has: (id: string) => rows().includes(id), add: (id: string) => setRows((r) => [...r, id]) };
}
// A.tsx
import { createDismissed } from "./store";
export function Alert(props: { id: string }) {
  const dismissed = createDismissed();
  return <button onClick={() => dismissed.add(props.id)}>{String(dismissed.has(props.id))}</button>;
}
```
Result: `SC2001 uncertifiable store.ts:6` ("setter setRows is called in code the analysis cannot place"). Replacing the body of `Alert` with `const { add, has } = createDismissed();` certifies.

Veto repro (slice 4): the single component `A.tsx` (`onClick={() => setN(n() + 1)}`) is `certified`; adding `B.ts` with `const events = new EventTarget(); export function ping(){ events.dispatchEvent(new Event("change")); }` makes it `SC2001`+`SC1001` uncertifiable with premise `B.ts:2 withholds event handler owner and read proofs: receiver unknown`; `window.dispatchEvent` instead is `excluded: receiver window` and `certified`.

False-positive repro (slice 0): `src/a.tsx` above (section 2, slice 0).
