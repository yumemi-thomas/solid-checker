import fs from "node:fs"; import path from "node:path"; import {createRequire} from "node:module";
const ts=createRequire(import.meta.url)("/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps/ai-memory-ui/node_modules/typescript/lib/typescript.js");
const sweep=JSON.parse(fs.readFileSync("/tmp/sc-sweep/rc17-sweep-rebuilt-9.json","utf8"));
const rootOf={};for(const r of sweep.results)rootOf[r.app+"|"+r.project]=r.root;
const flat=JSON.parse(fs.readFileSync("flat.json","utf8")).filter(f=>f.id==="SC1001"&&/cannot be enumerated/.test(f.msg)).sort((a,b)=>a.app<b.app?-1:1);
const programs={};let last=null;
function prog(root,project){const k=root+"|"+project;if(programs[k])return programs[k];const cfgPath=path.join(root,project);const cfg=ts.readConfigFile(cfgPath,ts.sys.readFile);const parsed=ts.parseJsonConfigFileContent(cfg.config,ts.sys,path.dirname(cfgPath));const p=ts.createProgram({rootNames:parsed.fileNames,options:{...parsed.options,noEmit:true,skipLibCheck:true}});return programs[k]={p,c:p.getTypeChecker()};}
function nodeAt(sf,start,end){let best;(function v(n){if(n.getStart(sf)<=start&&n.end>=end){best=n;ts.forEachChild(n,v);}})(sf);return best;}
function sym(c,n){let s=c.getSymbolAtLocation(n);if(s&&(s.flags&ts.SymbolFlags.Alias)){try{s=c.getAliasedSymbol(s)}catch{}}return s;}
const isFn=n=>ts.isArrowFunction(n)||ts.isFunctionExpression(n)||ts.isFunctionDeclaration(n);
const out=[];
for(const f of flat){ if(f.app!==last){for(const k of Object.keys(programs))delete programs[k];last=f.app;if(global.gc)global.gc();}
 const cands=Object.keys(rootOf).filter(k=>k.startsWith(f.app+"|"));let P,sf;for(const k of cands){const PP=prog(rootOf[k],k.split("|")[1]);const s=PP.p.getSourceFile(f.path);if(s){P=PP;sf=s;break;}}
 if(!sf)continue;const c=P.c;const start=Buffer.from(sf.text).subarray(0,f.s).toString().length,end=Buffer.from(sf.text).subarray(0,f.e).toString().length;
 let n=nodeAt(sf,start,end);let comp=null;let q=n;while(q){if(isFn(q)){let nm=q.name?q.name.text:(ts.isVariableDeclaration(q.parent)&&ts.isIdentifier(q.parent.name)?q.parent.name.text:null);if(nm&&/^[A-Z]/.test(nm))comp={fn:q,name:nm,decl:ts.isFunctionDeclaration(q)?q:q.parent};}q=q.parent;}
 const info={app:f.app,file:f.file,line:f.line};if(!comp){info.cls="no-comp";out.push(info);continue;}
 const nameNode=ts.isFunctionDeclaration(comp.fn)?comp.fn.name:comp.decl.name;const s=sym(c,nameNode);const kinds={};let jsx=0,spreadCallers=0;
 for(const sf2 of P.p.getSourceFiles()){if(sf2.isDeclarationFile||sf2.fileName.includes("/node_modules/"))continue;if(!sf2.text.includes(comp.name))continue;(function v(x){if(ts.isIdentifier(x)&&x.text===comp.name){const t=sym(c,x);if(t===s&&!(x.parent===comp.decl||x.parent===comp.fn)){const p=x.parent;if((ts.isJsxOpeningElement(p)||ts.isJsxSelfClosingElement(p))&&p.tagName===x){jsx++;if(p.attributes.properties.some(a=>ts.isJsxSpreadAttribute(a)))spreadCallers++}else if(ts.isJsxClosingElement(p)){}else if(ts.isImportSpecifier(p)||ts.isImportClause(p)||ts.isExportSpecifier(p)){kinds[ts.SyntaxKind[p.kind]]=1}else{let pp=p;kinds[ts.SyntaxKind[pp.kind]+(ts.isTypeQueryNode(pp)?"":"")]=(kinds[ts.SyntaxKind[pp.kind]]||0)+1}}}ts.forEachChild(x,v)})(sf2)}
 const exp=(ts.isFunctionDeclaration(comp.fn)&&comp.fn.modifiers&&comp.fn.modifiers.some(m=>m.kind===ts.SyntaxKind.ExportKeyword))||(ts.isVariableDeclaration(comp.decl)&&comp.decl.parent.parent.modifiers&&comp.decl.parent.parent.modifiers.some(m=>m.kind===ts.SyntaxKind.ExportKeyword));
 info.exported=!!exp;info.jsx=jsx;info.spreadCallers=spreadCallers;info.other=Object.keys(kinds).filter(k=>!/ImportSpecifier|ImportClause|ExportSpecifier/.test(k));info.exportSpec=!!(kinds.ExportSpecifier);
 // which props: first path segment
 const reasons=[];if(info.exported&&info.jsx===0)reasons.push("exported-no-jsx-callers");if(spreadCallers)reasons.push("spread-callers");if(info.other.length)reasons.push("other-refs:"+info.other.join("+"));if(!reasons.length)reasons.push("none-found(exported="+info.exported+")");info.cls=reasons.join(",");out.push(info);}
fs.writeFileSync("compcensus.json",JSON.stringify(out));
const g={};for(const o of out){g[o.cls]=(g[o.cls]||0)+1}console.log(out.length,JSON.stringify(Object.entries(g).sort((a,b)=>b[1]-a[1]).slice(0,20),null,0));
