import fs from "node:fs";
const pl=JSON.parse(fs.readFileSync("pl-sc2001.json","utf8"));
const fac=JSON.parse(fs.readFileSync("fac-sc2001.json","utf8"));
const fk=new Map(fac.map(x=>[x.app+"|"+x.file+"|"+x.line+"|"+x.ctx,x]));
const veto=new Set(["app-game","inferay","kui","probus-hk","skyjtx-website"]);
const t={};const ex={};
function add(k,x){t[k]=(t[k]||0)+1;(ex[k]??=[]).push(x)}
for(const x of pl){const l=x.chain&&x.chain[0];const f=fk.get(x.app+"|"+x.file+"|"+x.line+"|"+x.ctx);
 const u=l?l.uses:[];const isFac=f&&(f.G&&!/Statement|Expression|Kind|none/.test(f.G)||(f.uses||[]).includes("objlit"));
 let c;
 if(!l){c="module-level / no function";}
 else if(l.comp){c="in component body (unplaced context)";}
 else if(veto.has(x.app)&&u.length&&u.every(s=>s.startsWith("jsx:intrinsic"))) c="1 dispatch-veto: inline/named intrinsic on* handler in veto app";
 else if(x.awaitBefore) c=veto.has(x.app)?"2b after-await catch/finally (veto app)":"2 after-await/catch/finally write (ADR 0333/0400)";
 else if(isFac) c="3 factory-returned closure (object member / hook result)";
 else if(u.some(s=>s.startsWith("jsx:component"))) c="4 callback prop to project component (props.<name>)";
 else if(u.some(s=>/^arg\d+-of:(project)/.test(s))) c="5 argument of project function (param flow)";
 else if(u.some(s=>/^arg\d+-of:(pkg|nosym)/.test(s)||/^arg-of/.test(s))) c="6 callback argument of package function";
 else if(u.some(s=>s.startsWith("jsx:intrinsic"))) c="7 intrinsic attr (non-veto app, other reason)";
 else if(u.some(s=>s.startsWith("called@"))) c="8 helper called from other function(s) (call-chain)";
 else c="9 other ("+(u[0]||"none")+")";
 add(c,x)}
let tot=0;for(const [k,v] of Object.entries(t).sort()){tot+=v;console.log(String(v).padStart(5),k)}console.log("total",tot);
for(const k of ["7 intrinsic attr (non-veto app, other reason)","9 other (none)","8 helper called from other function(s) (call-chain)","in component body (unplaced context)","module-level / no function"]){const a=Object.keys(ex).find(z=>z.startsWith(k.slice(0,8)));if(a)console.log(a,(ex[a]||[]).slice(0,4).map(x=>x.app+"/"+x.file.split("/").pop()+":"+x.line).join(" "))}
