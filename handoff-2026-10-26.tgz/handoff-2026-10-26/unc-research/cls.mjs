// Classify uncertifiable findings by exact TS symbol resolution (read-only).
// usage: node cls.mjs RULE ctxSub msgSub [out.json]
import fs from "node:fs"; import path from "node:path"; import {createRequire} from "node:module";
const TSP="/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps/ai-memory-ui/node_modules/typescript/lib/typescript.js";
const ts=createRequire(import.meta.url)(TSP);
const sweep=JSON.parse(fs.readFileSync("/tmp/sc-sweep/rc17-sweep-rebuilt-9.json","utf8"));
const projOf={};for(const r of sweep.results)projOf[r.app+"|"+r.project]=r;
const [rule,ctxSub="",msgSub="",out]=process.argv.slice(2);
const flat=JSON.parse(fs.readFileSync("/tmp/sc-unc-research/flat.json","utf8")).filter(f=>f.id===rule&&(ctxSub===""||f.ctx.includes(ctxSub))&&f.msg.includes(msgSub));
const programs={};
function prog(root,project){const k=root+"|"+project;if(programs[k])return programs[k];
 const cfgPath=path.join(root,project);const cfg=ts.readConfigFile(cfgPath,ts.sys.readFile);
 const parsed=ts.parseJsonConfigFileContent(cfg.config,ts.sys,path.dirname(cfgPath));
 const p=ts.createProgram({rootNames:parsed.fileNames,options:{...parsed.options,noEmit:true,skipLibCheck:true}});
 return programs[k]={p,c:p.getTypeChecker()};}
const rootOf={};for(const r of sweep.results)rootOf[r.app+"|"+r.project]=r.root;
function where(fileName,root){ if(fileName.includes("/node_modules/")){const m=fileName.match(/node_modules\/((?:@[^/]+\/)?[^/]+)/g);return "pkg:"+m[m.length-1].replace("node_modules/","");} if(/typescript\/lib\/lib\./.test(fileName))return "lib"; return "project";}
function nodeAt(sf,start,end){let best;function visit(n){if(n.getStart(sf)<=start&&n.end>=end){best=n;ts.forEachChild(n,visit);}}visit(sf);return best;}
function declKind(sym,c){ if(!sym)return "nosym"; let s=sym; if(s.flags&ts.SymbolFlags.Alias){try{s=c.getAliasedSymbol(s)}catch{}} const d=(s.declarations||[])[0]; if(!d)return "nodecl:"+ts.SymbolFlags[s.flags]; return ts.SyntaxKind[d.kind]+"@"+where(d.getSourceFile().fileName);}

function wh(n){return where(n.getSourceFile().fileName)}
function prov(expr,c,sf,depth=0){ if(depth>4)return "deep"; 
 while(ts.isParenthesizedExpression(expr)||ts.isNonNullExpression(expr)||ts.isAsExpression(expr))expr=expr.expression;
 if(ts.isCallExpression(expr)){const e=expr.expression;const nm=e.getText().slice(0,40);let sym=ts.isIdentifier(e)?c.getSymbolAtLocation(e):(ts.isPropertyAccessExpression(e)?c.getSymbolAtLocation(e.name):undefined);return "call("+nm+"→"+declKind(sym,c)+")";}
 if(ts.isArrowFunction(expr)||ts.isFunctionExpression(expr))return "fnliteral";
 if(ts.isIdentifier(expr)){const sym=c.getSymbolAtLocation(expr);return "id("+declKind(sym,c)+")"+provDecl(sym,c,depth);}
 if(ts.isPropertyAccessExpression(expr))return "member("+prov(expr.expression,c,sf,depth+1)+")."+expr.name.text;
 return ts.SyntaxKind[expr.kind];}
function provDecl(sym,c,depth){ if(!sym)return ""; let s=sym; if(s.flags&ts.SymbolFlags.Alias){try{s=c.getAliasedSymbol(s)}catch{}} const d=(s.declarations||[])[0]; if(!d)return "";
 if(ts.isBindingElement(d)){let p=d.parent;while(p&&!ts.isVariableDeclaration(p)&&!ts.isParameter(p))p=p.parent; if(!p)return ""; if(ts.isParameter(p))return "<-paramPattern"; if(p.initializer)return "<-destr["+d.name.getText().slice(0,20)+"]of "+prov(p.initializer,c,null,depth+1); return "<-destr-noinit"}
 if(ts.isVariableDeclaration(d)){ if(d.initializer)return "<-"+prov(d.initializer,c,null,depth+1); return "<-noinit"}
 if(ts.isParameter(d)){return "<-param:"+(d.type?d.type.getText().slice(0,40):"untyped")}
 if(ts.isFunctionDeclaration(d))return "<-fndecl"; return ""}
const res=[];
let lastApp=null;
function paramInfo(call,argNode,c,sf,f){ const out={}; const m=f.msg.match(/invokes (\.[\w$.]+|\._|\.\w+) on/); out.member=m?m[1]:'';
 try{ const e=call.expression; const sym=ts.isIdentifier(e)?c.getSymbolAtLocation(e):(ts.isPropertyAccessExpression(e)?c.getSymbolAtLocation(e.name):undefined); let s2=sym; if(s2&&(s2.flags&ts.SymbolFlags.Alias))s2=c.getAliasedSymbol(s2); const d=s2&&s2.declarations&&s2.declarations[0]; out.calleeDecl=declKind(sym,c); if(d){ let fn=d; if(ts.isVariableDeclaration(d)&&d.initializer)fn=d.initializer; const idx=call.arguments.findIndex(a=>a.pos<=argNode.pos&&a.end>=argNode.end); const p=fn.parameters&&fn.parameters[idx]; if(p){ out.paramType=p.type?p.type.getText().slice(0,60):'untyped'; const t=c.getTypeAtLocation(p); out.paramTypeStr=c.typeToString(t).slice(0,70); const mem=out.member.replace(/^\./,'').split('.')[0]; const ps=mem&&c.getPropertyOfType(c.getNonNullableType(t),mem); if(ps&&ps.declarations&&ps.declarations[0])out.memberDecl=declKind(ps,c); out.paramPattern=ts.isObjectBindingPattern(p.name)?'objpat':'id'; } } }catch(err){out.err=String(err).slice(0,60)} return out;}
flat.sort((a,b)=>a.app<b.app?-1:a.app>b.app?1:a.file<b.file?-1:1);
for(const f of flat){ if(f.app!==lastApp){for(const k of Object.keys(programs))delete programs[k];lastApp=f.app;if(global.gc)global.gc();} const key=[...Object.keys(rootOf)].find(k=>k.startsWith(f.app+"|")&&f.path.startsWith(rootOf[k].replace(/\/$/,"")+"/")); 
 // choose project whose program contains the file
 const cands=Object.keys(rootOf).filter(k=>k.startsWith(f.app+"|"));let pr,sf;
 for(const k of cands){const P=prog(rootOf[k],k.split("|")[1]);const s=P.p.getSourceFile(f.path);if(s){pr=P;sf=s;break;}}
 if(!sf){res.push({...f,cls:"nofile"});continue;}
 const buf=Buffer.from(sf.text);const start=Buffer.from(sf.text).subarray(0,f.s).toString().length,end=Buffer.from(sf.text).subarray(0,f.e).toString().length;
 let n=nodeAt(sf,start,end);const c=pr.c;let info={};
 // climb to nearest call expression whose expression contains/equals n (callee)
 let call=n;while(call&&!ts.isCallExpression(call)&&!ts.isNewExpression(call)&&!ts.isJsxOpeningLikeElement(call)&&!ts.isJsxSpreadAttribute(call))call=call.parent;
 info.node=n?ts.SyntaxKind[n.kind]:"none"; info.text=n?n.getText(sf).slice(0,70).replace(/\s+/g," "):"";
 if(call&&(ts.isCallExpression(call)||ts.isNewExpression(call))){const e=call.expression;info.callee=e.getText(sf).slice(0,80).replace(/\s+/g," ");
   let target=e; if(ts.isPropertyAccessExpression(e)||ts.isElementAccessExpression(e)){info.member=true;const memSym=c.getSymbolAtLocation(ts.isPropertyAccessExpression(e)?e.name:e.argumentExpression);info.memberDecl=declKind(memSym,c);
     let root=e.expression;while(ts.isPropertyAccessExpression(root)||ts.isCallExpression(root)||ts.isNonNullExpression(root)||ts.isElementAccessExpression(root)||ts.isParenthesizedExpression(root))root=root.expression;info.rootDecl=declKind(ts.isIdentifier(root)?c.getSymbolAtLocation(root):undefined,c);info.rootText=root.getText(sf).slice(0,30);
     info.recvType=c.typeToString(c.getTypeAtLocation(e.expression)).slice(0,80);}
   else {const sym=ts.isIdentifier(e)?c.getSymbolAtLocation(e):undefined;info.calleeDecl=declKind(sym,c);info.prov=prov(e,c,sf);info.ctype=c.typeToString(c.getTypeAtLocation(e)).slice(0,70);}
 }
 if(process.env.PARAM){let cc=n;while(cc&&!ts.isCallExpression(cc)&&!ts.isNewExpression(cc))cc=cc.parent; if(cc)info={...info,...paramInfo(cc,n,c,sf,f)}; }
 res.push({app:f.app,file:f.file,line:f.line,ctx:f.ctx,msg:f.msg.slice(0,100),...info});}
if(out)fs.writeFileSync(out,JSON.stringify(res));
const tally={};for(const r of res){const k=r.member?`member recv=${r.rootDecl} mem=${r.memberDecl}`:`call ${r.calleeDecl??r.cls??r.node}`;tally[k]=(tally[k]||0)+1;}
console.log(JSON.stringify(Object.entries(tally).sort((a,b)=>b[1]-a[1]).slice(0,40),null,0).replace(/\],\[/g,"],\n["));
