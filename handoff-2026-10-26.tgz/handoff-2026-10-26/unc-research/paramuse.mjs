import fs from "node:fs"; import path from "node:path"; import {createRequire} from "node:module";
const ts=createRequire(import.meta.url)("/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps/ai-memory-ui/node_modules/typescript/lib/typescript.js");
const sweep=JSON.parse(fs.readFileSync("/tmp/sc-sweep/rc17-sweep-rebuilt-9.json","utf8"));
const rootOf={};for(const r of sweep.results)rootOf[r.app+"|"+r.project]=r.root;
const [ctxSub,out]=process.argv.slice(2);
const flat=JSON.parse(fs.readFileSync("flat.json","utf8")).filter(f=>f.id==="SC9012"&&f.ctx===ctxSub).sort((a,b)=>a.app<b.app?-1:1);
const programs={};let last=null;
function prog(root,project){const k=root+"|"+project;if(programs[k])return programs[k];const cfgPath=path.join(root,project);const cfg=ts.readConfigFile(cfgPath,ts.sys.readFile);const parsed=ts.parseJsonConfigFileContent(cfg.config,ts.sys,path.dirname(cfgPath));const p=ts.createProgram({rootNames:parsed.fileNames,options:{...parsed.options,noEmit:true,skipLibCheck:true}});return programs[k]={p,c:p.getTypeChecker()};}
function nodeAt(sf,start,end){let best;(function v(n){if(n.getStart(sf)<=start&&n.end>=end){best=n;ts.forEachChild(n,v);}})(sf);return best;}
function sym(c,n){let s=c.getSymbolAtLocation(n);if(s&&(s.flags&ts.SymbolFlags.Alias)){try{s=c.getAliasedSymbol(s)}catch{}}return s;}
function whereOf(d){const f=d.getSourceFile().fileName;if(f.includes("/node_modules/")){if(/typescript\/lib\/lib\./.test(f))return"lib";const m=f.match(/node_modules\/((?:@[^/]+\/)?[^/]+)/g);return"pkg"}return"project"}
const isFn=n=>ts.isArrowFunction(n)||ts.isFunctionExpression(n)||ts.isFunctionDeclaration(n)||ts.isMethodDeclaration(n);
function peel(n){let p=n.parent;while(p&&(ts.isParenthesizedExpression(p)||ts.isAsExpression(p)||ts.isNonNullExpression(p)))p=p.parent;return p}
const res=[];
for(const f of flat){ if(f.app!==last){for(const k of Object.keys(programs))delete programs[k];last=f.app;if(global.gc)global.gc();}
 const cands=Object.keys(rootOf).filter(k=>k.startsWith(f.app+"|"));let P,sf;for(const k of cands){const PP=prog(rootOf[k],k.split("|")[1]);const s=PP.p.getSourceFile(f.path);if(s){P=PP;sf=s;break;}}
 if(!sf)continue;const c=P.c;const start=Buffer.from(sf.text).subarray(0,f.s).toString().length,end=Buffer.from(sf.text).subarray(0,f.e).toString().length;
 let n=nodeAt(sf,start,end);let call=n;while(call&&!(ts.isCallExpression(call)&&call.arguments.some(a=>a.pos<=n.pos&&a.end>=n.end)))call=call.parent;const info={app:f.app,file:f.file,line:f.line};
 if(!call){info.cls="nocall";res.push(info);continue;}
 // argument node: n or ancestor that is direct arg
 let argIdx=call.arguments.findIndex(a=>a.pos<=n.pos&&a.end>=n.end);const arg=call.arguments[argIdx];
 let z=arg;while(z&&(ts.isParenthesizedExpression(z)||ts.isAsExpression(z)||ts.isNonNullExpression(z)))z=z.expression;
 info.argKind=!z?"?":ts.isIdentifier(z)?(()=>{const s=sym(c,z);const d=s&&s.declarations&&s.declarations[0];return d?"id:"+ts.SyntaxKind[d.kind]:"id"})():ts.isPropertyAccessExpression(z)?"member":ts.isCallExpression(z)?"call":ts.isObjectLiteralExpression(z)?"objlit":ts.isArrayLiteralExpression(z)?"arrlit":ts.isTemplateExpression(z)?"template":ts.isArrowFunction(z)||ts.isFunctionExpression(z)?"fn":ts.SyntaxKind[z.kind];
 info.argType=z?c.typeToString(c.getTypeAtLocation(z)).slice(0,50):"";
 const e=call.expression;info.callee=e.getText().slice(0,40).replace(/\s+/g," ");
 let s2=ts.isIdentifier(e)?sym(c,e):ts.isPropertyAccessExpression(e)?sym(c,e.name):undefined;const d=s2&&s2.declarations&&s2.declarations[0];
 info.calleeWhere=d?whereOf(d):"nosym";
 if(d){let fnode=d;if(ts.isVariableDeclaration(d)&&d.initializer)fnode=d.initializer;if(ts.isPropertyAssignment(d)&&d.initializer)fnode=d.initializer;
  const p=fnode.parameters&&fnode.parameters[argIdx];info.calleeKind=ts.SyntaxKind[fnode.kind];
  if(p&&info.calleeWhere==="project"){ const uses=[];
   if(ts.isIdentifier(p.name)){const ps=c.getSymbolAtLocation(p.name);(function v(x){if(ts.isIdentifier(x)&&x.text===p.name.text&&x!==p.name&&c.getSymbolAtLocation(x)===ps){const q=peel(x);let u;
      if(ts.isPropertyAccessExpression(q)&&q.expression===x||ts.isPropertyAccessExpression(x.parent)&&x.parent.expression===x){const pa=x.parent;const pp=peel(pa);u=(ts.isCallExpression(pp)&&pp.expression===pa)?"member-call":"member-read";}
      else if(ts.isCallExpression(q)){const ci=q.arguments.indexOf(x.parent&&q.arguments.includes(x)?x:x);let cs=ts.isIdentifier(q.expression)?sym(c,q.expression):ts.isPropertyAccessExpression(q.expression)?sym(c,q.expression.name):undefined;const cd=cs&&cs.declarations&&cs.declarations[0];u="arg-to-"+(cd?whereOf(cd):"nosym")+"-call"}
      else if(ts.isSpreadAssignment(q)||ts.isSpreadElement(q))u="spread";
      else if(ts.isVariableDeclaration(q))u="alias";
      else if(ts.isReturnStatement(q)||ts.isArrowFunction(q))u="return";
      else if(ts.isPropertyAssignment(q)||ts.isShorthandPropertyAssignment(q)||ts.isArrayLiteralExpression(q))u="stored-in-literal";
      else if(ts.isBinaryExpression(q)||ts.isConditionalExpression(q)||ts.isPrefixUnaryExpression(q)||ts.isTypeOfExpression(q)||ts.isIfStatement(q)||ts.isTemplateSpan(q))u="test/operator";
      else u=ts.SyntaxKind[q.kind];uses.push(u)}ts.forEachChild(x,v)})(fnode.body||fnode)}
   else uses.push("destructured-param");
   info.uses=[...new Set(uses)].sort();}
 }
 res.push(info);}
fs.writeFileSync(out,JSON.stringify(res));
const g={};for(const o of res){const k="callee="+o.calleeWhere+" arg="+(o.argKind||"").replace(/id:.*/,"id")+" uses=["+(o.uses||[]).join(",")+"]";(g[k]??=[]).push(o)}
console.log(res.length);for(const [k,v] of Object.entries(g).sort((a,b)=>b[1].length-a[1].length).slice(0,30))console.log(String(v.length).padStart(4),k.slice(0,150),"|",v[0].app+"/"+v[0].file.split("/").pop()+":"+v[0].line)
