import { createSignal } from "solid-js";
async function get(): Promise<void> { await fetch("/x"); }
export function A(props: { go: boolean }) {
  const [n, setN] = createSignal(0);
  async function load() {
    if (props.go) await get();
    setN(1);
  }
  return <button onClick={() => load()}>{n()}</button>;
}
