import fs from "node:fs"; import path from "node:path"; import {createRequire} from "node:module";
const ts=createRequire(import.meta.url)("/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps/ai-memory-ui/node_modules/typescript/lib/typescript.js");
const sweep=JSON.parse(fs.readFileSync("/tmp/sc-sweep/rc17-sweep-rebuilt-9.json","utf8"));
const rootOf={};for(const r of sweep.results)rootOf[r.app+"|"+r.project]=r.root;
const pl=JSON.parse(fs.readFileSync("pl-sc2001.json","utf8")).filter(x=>x.awaitBefore);
const flat=JSON.parse(fs.readFileSync("flat.json","utf8")).filter(f=>f.id==="SC2001");
const key=f=>f.app+"|"+f.file+"|"+f.line;const fm=new Map(flat.map(f=>[key(f),f]));
pl.sort((a,b)=>a.app<b.app?-1:1);
const programs={};let last=null;
function prog(root,project){const k=root+"|"+project;if(programs[k])return programs[k];const cfgPath=path.join(root,project);const cfg=ts.readConfigFile(cfgPath,ts.sys.readFile);const parsed=ts.parseJsonConfigFileContent(cfg.config,ts.sys,path.dirname(cfgPath));const p=ts.createProgram({rootNames:parsed.fileNames,options:{...parsed.options,noEmit:true,skipLibCheck:true}});return programs[k]={p,c:p.getTypeChecker()};}
const isFn=n=>ts.isArrowFunction(n)||ts.isFunctionExpression(n)||ts.isFunctionDeclaration(n)||ts.isMethodDeclaration(n);
function nodeAt(sf,start,end){let best;function v(n){if(n.getStart(sf)<=start&&n.end>=end){best=n;ts.forEachChild(n,v);}}v(sf);return best;}
function sym(c,n){let s=c.getSymbolAtLocation(n);if(s&&(s.flags&ts.SymbolFlags.Alias)){try{s=c.getAliasedSymbol(s)}catch{}}return s;}
function whereOf(d){const f=d.getSourceFile().fileName;if(f.includes("/node_modules/")){if(/typescript\/lib\/lib\./.test(f))return"lib";const m=f.match(/node_modules\/((?:@[^/]+\/)?[^/]+)/g);return"pkg:"+m[m.length-1].replace("node_modules/","")}return"project"}
const out=[];
for(const x of pl){ if(x.app!==last){for(const k of Object.keys(programs))delete programs[k];last=x.app;if(global.gc)global.gc();}
 const f=fm.get(key(x)); if(!f){continue;}
 const cands=Object.keys(rootOf).filter(k=>k.startsWith(f.app+"|"));let P,sf;for(const k of cands){const PP=prog(rootOf[k],k.split("|")[1]);const s=PP.p.getSourceFile(f.path);if(s){P=PP;sf=s;break;}}
 if(!sf)continue;const c=P.c;const start=Buffer.from(sf.text).subarray(0,f.s).toString().length,end=Buffer.from(sf.text).subarray(0,f.e).toString().length;
 let n=nodeAt(sf,start,end);const info={app:x.app,file:x.file,line:x.line};
 // enclosing function
 let fn=n;while(fn&&!isFn(fn))fn=fn.parent;
 // find try whose catch/finally contains n, within fn
 let t=n,where=null;while(t&&t!==fn){const p=t.parent;if(p&&ts.isTryStatement(p)){if(p.catchClause===t||p.catchClause&&p.catchClause.pos<=n.pos&&p.catchClause.end>=n.end)where="catch";else if(p.finallyBlock&&p.finallyBlock.pos<=n.pos&&p.finallyBlock.end>=n.end)where="finally";else if(p.tryBlock&&p.tryBlock.pos<=n.pos&&p.tryBlock.end>=n.end)where="try-block";info.try=p;break;}t=p;}
 info.where=where||"after-or-elsewhere";
 if(info.try){const tb=info.try.tryBlock;const first=tb.statements[0];let aw=null;if(first){(function f2(z){if(aw)return;if(ts.isAwaitExpression(z)){aw=z;return;}if(isFn(z))return;ts.forEachChild(z,f2)})(first);}
   info.firstStmt=first?ts.SyntaxKind[first.kind]:"none";
   if(aw){const op=aw.expression;let o=op;while(ts.isParenthesizedExpression(o)||ts.isAsExpression(o)||ts.isNonNullExpression(o))o=o.expression;info.opKind=ts.SyntaxKind[o.kind];
    if(ts.isCallExpression(o)){const e=o.expression;info.callee=e.getText().slice(0,50).replace(/\s+/g," ");let s2=ts.isIdentifier(e)?sym(c,e):ts.isPropertyAccessExpression(e)?sym(c,e.name):undefined;const d=s2&&s2.declarations&&s2.declarations[0];
      if(d){info.calleeWhere=whereOf(d);info.calleeDecl=ts.SyntaxKind[d.kind];let fnode=d;if(ts.isVariableDeclaration(d)&&d.initializer)fnode=d.initializer;if(ts.isPropertyAssignment(d)&&d.initializer)fnode=d.initializer;info.calleeAsync=!!(fnode.modifiers&&fnode.modifiers.some(m=>m.kind===ts.SyntaxKind.AsyncKeyword));info.calleeFnKind=ts.SyntaxKind[fnode.kind];if(!info.calleeAsync){try{const ty=c.getTypeAtLocation(e);const sg=ty.getCallSignatures()[0];if(sg){const rt=c.typeToString(sg.getReturnType());info.retType=rt.slice(0,40)}}catch{}}}
      else info.calleeWhere="nosym";
      info.args=o.arguments.map(a=>{let z=a;while(ts.isParenthesizedExpression(z)||ts.isAsExpression(z)||ts.isNonNullExpression(z))z=z.expression;if(ts.isLiteralExpression(z)||z.kind===ts.SyntaxKind.TrueKeyword||z.kind===ts.SyntaxKind.FalseKeyword||z.kind===ts.SyntaxKind.NullKeyword)return"lit";if(ts.isIdentifier(z)){const s3=c.getSymbolAtLocation(z);const dd=s3&&s3.declarations&&s3.declarations[0];if(!dd)return"id?";if(ts.isParameter(dd))return"id:param";if(ts.isVariableDeclaration(dd))return"id:"+(dd.parent.flags&ts.NodeFlags.Const?"const":"let");return"id:"+ts.SyntaxKind[dd.kind]}if(ts.isPropertyAccessExpression(z))return"member";if(ts.isCallExpression(z))return"call";if(ts.isObjectLiteralExpression(z))return"objlit";if(ts.isTemplateExpression(z)||ts.isNoSubstitutionTemplateLiteral(z))return"template";return ts.SyntaxKind[z.kind]});}
   } else info.opKind="noawait-first";}
 out.push(info);}
fs.writeFileSync("tryhead.json",JSON.stringify(out.map(o=>({...o,try:undefined}))));
const g={};for(const o of out){const k=o.where+" | first="+o.firstStmt+" | "+(o.callee?"call "+(o.calleeWhere||"")+"/"+(o.calleeDecl||"")+"/async="+o.calleeAsync:o.opKind);g[k]=(g[k]||0)+1}
console.log(out.length);console.log(JSON.stringify(Object.entries(g).sort((a,b)=>b[1]-a[1]).slice(0,30),null,0).replace(/\],\[/g,"],\n["));
