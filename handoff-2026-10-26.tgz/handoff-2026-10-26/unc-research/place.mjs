// usage: node place.mjs RULE ctxSub msgSub out.json
import fs from "node:fs"; import path from "node:path"; import {createRequire} from "node:module";
const ts=createRequire(import.meta.url)("/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps/ai-memory-ui/node_modules/typescript/lib/typescript.js");
const sweep=JSON.parse(fs.readFileSync("/tmp/sc-sweep/rc17-sweep-rebuilt-9.json","utf8"));
const rootOf={};for(const r of sweep.results)rootOf[r.app+"|"+r.project]=r.root;
const [rule,ctxSub="",msgSub="",out]=process.argv.slice(2);
let flat=JSON.parse(fs.readFileSync("/tmp/sc-unc-research/flat.json","utf8")).filter(f=>f.id===rule&&(ctxSub===""||f.ctx.includes(ctxSub))&&f.msg.includes(msgSub));
flat.sort((a,b)=>a.app<b.app?-1:a.app>b.app?1:a.file<b.file?-1:1);
const programs={};
function prog(root,project){const k=root+"|"+project;if(programs[k])return programs[k];const cfgPath=path.join(root,project);const cfg=ts.readConfigFile(cfgPath,ts.sys.readFile);const parsed=ts.parseJsonConfigFileContent(cfg.config,ts.sys,path.dirname(cfgPath));const p=ts.createProgram({rootNames:parsed.fileNames,options:{...parsed.options,noEmit:true,skipLibCheck:true}});return programs[k]={p,c:p.getTypeChecker(),refs:new Map()};}
function where(fileName){ if(fileName.includes("/node_modules/")){const m=fileName.match(/node_modules\/((?:@[^/]+\/)?[^/]+)/g);return "pkg:"+m[m.length-1].replace("node_modules/","");} return "project";}
function nodeAt(sf,start,end){let best;function visit(n){if(n.getStart(sf)<=start&&n.end>=end){best=n;ts.forEachChild(n,visit);}}visit(sf);return best;}
const isFn=n=>ts.isArrowFunction(n)||ts.isFunctionExpression(n)||ts.isFunctionDeclaration(n)||ts.isMethodDeclaration(n)||ts.isGetAccessor(n)||ts.isSetAccessor(n)||ts.isConstructorDeclaration(n);
function enclosingFn(n){let p=n.parent;while(p&&!isFn(p))p=p.parent;return p;}
function sym(c,n){let s=c.getSymbolAtLocation(n);if(s&&(s.flags&ts.SymbolFlags.Alias)){try{s=c.getAliasedSymbol(s)}catch{}}return s;}
function calleeDesc(c,call){const e=call.expression;let nm=e.getText().slice(0,40).replace(/\s+/g," ");let s=ts.isIdentifier(e)?sym(c,e):ts.isPropertyAccessExpression(e)?sym(c,e.name):undefined;const d=s&&s.declarations&&s.declarations[0];const w=d?where(d.getSourceFile().fileName):"nosym";return {nm,w,call};}
function isComponentFn(f,sf){ // capitalized name or returns JSX
 let name; if(f.name)name=f.name.getText(sf); else if(ts.isVariableDeclaration(f.parent))name=f.parent.name.getText(sf);else if(ts.isExportAssignment(f.parent))name="default";
 if(name&&/^[A-Z]/.test(name))return name; return null;}
// describe how a function-ish value expression is *used* at node n (a reference or literal position)
function useOf(c,n,depth=0){ // n: expression node (fn literal or identifier ref)
 let p=n.parent; while(p&&(ts.isParenthesizedExpression(p)||ts.isAsExpression(p)||ts.isNonNullExpression(p)||ts.isSatisfiesExpression(p)))p=p.parent;
 if(!p)return "none";
 if(ts.isCallExpression(p)){ if(p.expression===n||p.expression.pos<=n.pos&&p.expression.end>=n.end&&ts.isParenthesizedExpression(p.expression)){ return "called@"+ctxOf(p,c,depth);} const d=calleeDesc(c,p); const i=p.arguments.indexOf(n); return "arg"+i+"-of:"+d.w+":"+d.nm; }
 if(ts.isNewExpression(p)){return "arg-of-new:"+p.expression.getText().slice(0,30)}
 if(ts.isJsxExpression(p)&&p.parent&&ts.isJsxAttribute(p.parent)){const attr=p.parent;const tag=attr.parent.parent.tagName;const tn=tag.getText();const intr=/^[a-z]/.test(tn)&&!tn.includes(".");let w2="";if(!intr){try{let ts2=sym(c,tag.kind===ts.SyntaxKind.PropertyAccessExpression?tag.expression:tag);const d=ts2&&ts2.declarations&&ts2.declarations[0];w2=d?(where(d.getSourceFile().fileName)):"nosym";}catch{} }return "jsx:"+(intr?"intrinsic":"component["+w2+"]:"+tn)+":"+attr.name.getText();}
 if(ts.isJsxExpression(p)){return "jsx-child"}
 if(ts.isVariableDeclaration(p)&&p.initializer&&(p.initializer===n||true)){ if(ts.isIdentifier(p.name))return "bound:"+p.name.text; return "bound-pattern";}
 if(ts.isPropertyAssignment(p)){return "objprop:"+p.name.getText().slice(0,24)}
 if(ts.isShorthandPropertyAssignment(p))return "objprop-shorthand";
 if(ts.isReturnStatement(p)||ts.isArrowFunction(p))return "returned";
 if(ts.isBinaryExpression(p)&&p.operatorToken.kind===ts.SyntaxKind.EqualsToken)return "assigned";
 if(ts.isArrayLiteralExpression(p))return "array-elem";
 if(ts.isExportAssignment(p)||ts.isExportSpecifier(p))return "exported";
 if(ts.isConditionalExpression(p)||ts.isBinaryExpression(p))return "cond:"+useOf(c,p,depth+1);
 if(ts.isSpreadAssignment(p)||ts.isSpreadElement(p))return "spread";
 return ts.SyntaxKind[p.kind];
}
function ctxOf(call,c,depth){ // role of the position where a call sits: nearest function and its kind
 const f=enclosingFn(call); if(!f)return "module"; const sf=f.getSourceFile(); const comp=isComponentFn(f,sf); if(comp&&!(f.parent&&ts.isCallExpression(f.parent)))return "component-body"; if(f.parent&&ts.isCallExpression(f.parent)&&isFn(f)){const d=calleeDesc(c,f.parent);return "inline-in:"+d.w+":"+d.nm.slice(0,20);} if(f.parent&&ts.isJsxExpression(f.parent)){return "inline-jsx"} return "fn:"+(f.name?f.name.getText(sf):(ts.isVariableDeclaration(f.parent)?f.parent.name.getText(sf):"anon"));}
function refsOf(P,decl,c){ // identifier references of a binding via findReferences-lite: scan source files for identifiers resolving to same symbol
 return null;}
const res=[];let lastApp=null;
function binderRefs(P,s,declFile){ // collect reference nodes of symbol s within program (project files only)
 const key=s; const out=[]; for(const sf of P.p.getSourceFiles()){ if(sf.fileName.includes("/node_modules/")||sf.isDeclarationFile)continue; if(!sf.text.includes(s.name))continue; (function v(n){ if(ts.isIdentifier(n)&&n.text===s.name){ const t=P.c.getSymbolAtLocation(n); let ts2=t; if(ts2&&(ts2.flags&ts.SymbolFlags.Alias)){try{ts2=P.c.getAliasedSymbol(ts2)}catch{}} if(ts2===s&&!(n.parent&&((ts.isVariableDeclaration(n.parent)&&n.parent.name===n)||(ts.isFunctionDeclaration(n.parent)&&n.parent.name===n))))out.push(n); } ts.forEachChild(n,v);})(sf);} return out;}
for(const f of flat){ if(f.app!==lastApp){for(const k of Object.keys(programs))delete programs[k];lastApp=f.app;if(global.gc)global.gc();}
 const cands=Object.keys(rootOf).filter(k=>k.startsWith(f.app+"|"));let P,sf;for(const k of cands){const PP=prog(rootOf[k],k.split("|")[1]);const s=PP.p.getSourceFile(f.path);if(s){P=PP;sf=s;break;}}
 if(!sf){res.push({...f,pl:"nofile"});continue;}
 const start=Buffer.from(sf.text).subarray(0,f.s).toString().length,end=Buffer.from(sf.text).subarray(0,f.e).toString().length;
 let n=nodeAt(sf,start,end); const c=P.c; const info={app:f.app,file:f.file,line:f.line,ctx:f.ctx,msg:f.msg.slice(0,90)};
 if(!n){res.push({...info,pl:"nonode"});continue;}
 // find enclosing fn chain
 let fn=enclosingFn(n); info.chain=[];
 let awaitBefore=false; let cur=n; // detect await between function start and site (same fn)
 if(fn){ (function chk(x){ if(x.pos>=n.pos)return; if(ts.isAwaitExpression(x)&&x.end<=n.pos)awaitBefore=true; if(x!==fn&&isFn(x))return; ts.forEachChild(x,chk);})(fn.body||fn); info.awaitBefore=awaitBefore&&!!(fn.modifiers&&fn.modifiers.some(m=>m.kind===ts.SyntaxKind.AsyncKeyword)); }
 let depth=0; while(fn&&depth<4){ const comp=isComponentFn(fn,fn.getSourceFile()); const lvl={kind:ts.SyntaxKind[fn.kind],comp:comp||undefined,async:!!(fn.modifiers&&fn.modifiers.some(m=>m.kind===ts.SyntaxKind.AsyncKeyword))};
  // uses of the function value
  let uses=[]; 
  if(ts.isFunctionDeclaration(fn)&&fn.name){ const s=sym(c,fn.name); lvl.name=fn.name.text; if(s){const rs=binderRefs(P,s,sf); uses=rs.map(r=>useOf(c,r)); if(ts.isSourceFile(fn.parent)&&fn.modifiers&&fn.modifiers.some(m=>m.kind===ts.SyntaxKind.ExportKeyword))uses.push("EXPORTED");}}
  else { const u=useOf(c,fn); if(u.startsWith("bound:")&&ts.isVariableDeclaration(fn.parent)){ lvl.name=fn.parent.name.getText(); const s=sym(c,fn.parent.name); if(s){const rs=binderRefs(P,s,sf); uses=rs.map(r=>useOf(c,r)); } const vs=fn.parent.parent&&fn.parent.parent.parent; if(vs&&ts.isVariableStatement(vs)&&vs.modifiers&&vs.modifiers.some(m=>m.kind===ts.SyntaxKind.ExportKeyword))uses.push("EXPORTED"); } else uses=[u]; }
  lvl.uses=uses.slice(0,12); info.chain.push(lvl);
  // stop at component function or module-level function
  if(comp&&!(fn.parent&&ts.isCallExpression(fn.parent)))break; fn=enclosingFn(fn); depth++; }
 if(!info.chain.length)info.top="module-level";
 res.push(info);}
fs.writeFileSync(out,JSON.stringify(res));
console.log("done",res.length);
