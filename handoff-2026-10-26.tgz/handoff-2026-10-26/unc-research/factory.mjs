// For findings whose enclosing function escapes via an object literal (shorthand/prop/method), trace the factory and its consumers.
import fs from "node:fs"; import path from "node:path"; import {createRequire} from "node:module";
const ts=createRequire(import.meta.url)("/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps/ai-memory-ui/node_modules/typescript/lib/typescript.js");
const sweep=JSON.parse(fs.readFileSync("/tmp/sc-sweep/rc17-sweep-rebuilt-9.json","utf8"));
const rootOf={};for(const r of sweep.results)rootOf[r.app+"|"+r.project]=r.root;
const [rule,out]=process.argv.slice(2);
const flat=JSON.parse(fs.readFileSync("flat.json","utf8")).filter(f=>f.id===rule).sort((a,b)=>a.app<b.app?-1:a.app>b.app?1:0);
const programs={};let last=null;
function prog(root,project){const k=root+"|"+project;if(programs[k])return programs[k];const cfgPath=path.join(root,project);const cfg=ts.readConfigFile(cfgPath,ts.sys.readFile);const parsed=ts.parseJsonConfigFileContent(cfg.config,ts.sys,path.dirname(cfgPath));const p=ts.createProgram({rootNames:parsed.fileNames,options:{...parsed.options,noEmit:true,skipLibCheck:true}});return programs[k]={p,c:p.getTypeChecker(),idx:new Map()};}
const isFn=n=>ts.isArrowFunction(n)||ts.isFunctionExpression(n)||ts.isFunctionDeclaration(n)||ts.isMethodDeclaration(n)||ts.isGetAccessor(n)||ts.isSetAccessor(n);
function nodeAt(sf,start,end){let best;(function v(n){if(n.getStart(sf)<=start&&n.end>=end){best=n;ts.forEachChild(n,v);}})(sf);return best;}
function sym(c,n){let s=c.getSymbolAtLocation(n);if(s&&(s.flags&ts.SymbolFlags.Alias)){try{s=c.getAliasedSymbol(s)}catch{}}return s;}
function refs(P,s){ // all reference identifier nodes to symbol s in project files (index by name)
 const out=[];const name=s.name;for(const sf of P.p.getSourceFiles()){if(sf.isDeclarationFile||sf.fileName.includes("/node_modules/"))continue;if(!sf.text.includes(name))continue;(function v(n){if(ts.isIdentifier(n)&&n.text===name){let t;if(n.parent&&ts.isShorthandPropertyAssignment(n.parent)&&n.parent.name===n){t=P.c.getShorthandAssignmentValueSymbol(n.parent);}else t=P.c.getSymbolAtLocation(n);if(t&&(t.flags&ts.SymbolFlags.Alias)){try{t=P.c.getAliasedSymbol(t)}catch{}}if(t===s&&!(n.parent&&(ts.isVariableDeclaration(n.parent)&&n.parent.name===n||ts.isFunctionDeclaration(n.parent)&&n.parent.name===n||ts.isBindingElement(n.parent)&&n.parent.name===n)))out.push(n);}ts.forEachChild(n,v);})(sf);}return out;}
function peel(n){let p=n.parent;while(p&&(ts.isParenthesizedExpression(p)||ts.isAsExpression(p)||ts.isNonNullExpression(p)||ts.isSatisfiesExpression(p)))p=p.parent;return p;}
function usage(c,n){ // how is reference/expression n used
 const p=peel(n);if(!p)return"none";
 if(ts.isCallExpression(p)&&p.expression===n)return"call";
 if(ts.isPropertyAccessExpression(p)&&p.expression===n){const pp=peel(p);if(pp&&ts.isCallExpression(pp)&&pp.expression===p)return"member-call:"+p.name.text;return"member-read:"+p.name.text;}
 if(ts.isJsxExpression(p)&&p.parent&&ts.isJsxAttribute(p.parent)){const tn=p.parent.parent.parent.tagName.getText();return"jsx:"+(/^[a-z]/.test(tn)&&!tn.includes(".")?"intr:":"comp:")+p.parent.name.getText();}
 if(ts.isVariableDeclaration(p)){return ts.isIdentifier(p.name)?"bound":"destructured";}
 if(ts.isReturnStatement(p)||ts.isArrowFunction(p))return"returned";
 if(ts.isCallExpression(p)){return"arg-of:"+p.expression.getText().slice(0,24)}
 if(ts.isObjectLiteralExpression(p)||ts.isPropertyAssignment(p)||ts.isShorthandPropertyAssignment(p))return"objlit";
 if(ts.isSpreadAssignment(p)||ts.isSpreadElement(p))return"spread";
 return ts.SyntaxKind[p.kind];}
const res=[];
for(const f of flat){ if(f.app!==last){for(const k of Object.keys(programs))delete programs[k];last=f.app;if(global.gc)global.gc();}
 const cands=Object.keys(rootOf).filter(k=>k.startsWith(f.app+"|"));let P,sf;for(const k of cands){const PP=prog(rootOf[k],k.split("|")[1]);const s=PP.p.getSourceFile(f.path);if(s){P=PP;sf=s;break;}}
 if(!sf)continue;const c=P.c;const start=Buffer.from(sf.text).subarray(0,f.s).toString().length,end=Buffer.from(sf.text).subarray(0,f.e).toString().length;
 let n=nodeAt(sf,start,end);let fn=n;while(fn&&!isFn(fn))fn=fn.parent;if(!fn)continue;
 // climb function nesting until function that is not inline-arg: record F as nearest named/escaping fn
 const info={app:f.app,file:f.file,line:f.line,id:f.id,ctx:f.ctx};
 // determine F's own uses
 let uses=[];let fname=null;let objlitMember=false;let OL=null;
 if(ts.isMethodDeclaration(fn)&&fn.parent&&ts.isObjectLiteralExpression(fn.parent)){objlitMember=true;OL=fn.parent;fname=fn.name.getText();}
 else if(ts.isPropertyAssignment(fn.parent)&&ts.isObjectLiteralExpression(fn.parent.parent)){objlitMember=true;OL=fn.parent.parent;fname=fn.parent.name.getText();}
 else{let s=null;if(ts.isFunctionDeclaration(fn)&&fn.name){s=sym(c,fn.name);fname=fn.name.text}else if(ts.isVariableDeclaration(fn.parent)&&ts.isIdentifier(fn.parent.name)){s=sym(c,fn.parent.name);fname=fn.parent.name.text}
  if(s){const rs=refs(P,s);uses=rs.map(r=>({u:usage(c,r),n:r}));const sh=uses.find(u=>u.u==="objlit");if(sh){let o=sh.n;while(o&&!ts.isObjectLiteralExpression(o))o=o.parent;OL=o;objlitMember=true}}}
 info.fname=fname;info.uses=[...new Set(uses.map(u=>u.u))];
 if(OL){ // is OL returned (directly or via const) from function G
  let G=null,viaConst=null;let p=peel(OL);if(p&&ts.isReturnStatement(p)||p&&ts.isArrowFunction(p)){G=p;while(G&&!isFn(G))G=G.parent;}
  else if(p&&ts.isVariableDeclaration(p)&&ts.isIdentifier(p.name)){const s=sym(c,p.name);if(s){const rs=refs(P,s);for(const r of rs){const u=usage(c,r);if(u==="returned"){G=r;while(G&&!isFn(G))G=G.parent;viaConst=true}}}}
  else if(p&&ts.isAsExpression(p)){}
  if(G&&isFn(G)){let gname=null,gs=null;if(ts.isFunctionDeclaration(G)&&G.name){gname=G.name.text;gs=sym(c,G.name)}else if(ts.isVariableDeclaration(G.parent)&&ts.isIdentifier(G.parent.name)){gname=G.parent.name.text;gs=sym(c,G.parent.name)}
   info.G=gname;if(gs){const gr=refs(P,gs);info.gcalls=gr.length;const cons={};for(const r of gr){const u=usage(c,r);let key=u;
     if(u==="call"){const cp=peel(r.parent&&ts.isCallExpression(r.parent)?r.parent:r);// result use
       const callNode=r.parent;const ru=usage(c,callNode);key="call→"+ru;
       if(ru==="bound"||ru==="destructured"){ if(ru==="bound"&&ts.isVariableDeclaration(peel(callNode))){const vd=peel(callNode);const vs=sym(c,vd.name);if(vs){const rr=refs(P,vs);const sub={};for(const q of rr){const qu=usage(c,q);sub[qu.startsWith("member-call")?"member-call":qu.startsWith("member-read")?"member-read":qu]=1}key="call→bound→["+Object.keys(sub).sort().join(",")+"]"}}}}
     cons[key]=(cons[key]||0)+1}info.consumers=cons;}}
  else info.G=p?ts.SyntaxKind[p.kind]:"none";}
 res.push(info);}
fs.writeFileSync(out,JSON.stringify(res));
const g={};for(const x of res){if(!x.G&&!x.uses.includes("objlit"))continue;const k="G="+(x.G?"factory":"?")+" "+Object.keys(x.consumers||{}).sort().join("|");g[k]=(g[k]||0)+1}
console.log(res.length);console.log(JSON.stringify(Object.entries(g).sort((a,b)=>b[1]-a[1]).slice(0,25),null,0).replace(/\],\[/g,"],\n["));
