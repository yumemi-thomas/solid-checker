# E2 research notes: ADR 0386 (`reactivity` group key) and ADR 0387 (inline directives)

Read-only pass, 2026-10-25, branch `claude/catalog-review-adr-0381-0400`. Nothing was built, run or modified. **Read** marks behaviour derived from code and not executed. ESLint facts come from `packages/cli/node_modules/eslint` (10.8.0, `packages/cli/package.json:51`).

**Concurrency.** The worktree changed during this pass. The ADR 0385 slice (`valid-use-server`) is uncommitted in `rule_options.rs` (+99/-10), in the solid-facts AST files (`ast/mod.rs:50` now `AST_FACTS_SCHEMA = 75`), and in `rules.rs` (comments). Line numbers below are from the second read. Re-check them before editing, and sequence this work after that slice commits or rebase onto it.

## 0. Key findings for the implementer
1. **Map order trap.** `parse_with_aliases` iterates a `BTreeMap` by configured key (`rule_options.rs:101`). A naive group expansion overwrites `reactive-handler-frozen` and `reactive-read-after-await` silently (section 1.2).
2. **ESLint errors on unknown rule ids in disable comments** (`linter.js:243-278`). `solid-checker/reactivity` in a directive is an ESLint error unless a rule of that name exists, and `solid/<name>` is an error unless the user loaded a `solid` plugin.
3. **Double handling is not harmless.** A native suppression that ESLint also applies leaves ESLint's directive unused, which the default config reports as a warning (section 2.3, E4).
4. **Foreign-plugin names in `eslint-disable` must be ignored.** Three fixtures use `eslint-disable-next-line prefer-rest-params`. ADR 0387 does not say so (section 2.2).
5. **`DirectiveFact` is taken** (`ast/types.rs:714`, prologue directives). The schema is already 75, so a new table takes 76 (section 2.1).
6. **A project-level notice fails `--certify`** (`snapshot_emission.rs:35-41`). A typo in a directive would fail it (section 2.4).
7. **Pre-existing:** a member set to `off` in ESLint is still reported under `recommended` (section 1.3). `DEPRECATED_RULE_KEYS` drifts from `RULE_ALIASES` by seven names.

## 1. ADR 0386: `reactivity` group

### 1.1 Native path
- Members (`rust/dialects/solid-v2/rules/src/rules.rs`): SC1001 `strict-read-untracked` :119, SC1002 `reactive-read-after-await` :120, SC1005 `uncalled-accessor` :121, SC1007 `reactive-handler-frozen` :122-124. All `default_enabled: true` (:273). Non-members: SC1003 `no-destructure` :137, SC4001 `missing-owner` :196, SC9011 and SC9012 :132, :135 (uncertifiable).
- Parse (`rust/crates/solid-reactive-ir/src/upstream_compat/rule_options.rs`): `Document` :69-72 (`deny_unknown_fields`); `parse_with_aliases` :87; configured key then alias canonicalisation :101-102; catalog check :103-107; `overrides.insert(canonical)` :116-123; non-`enabled` keys refused :155. The ADR 0385 arm at :124-137 hard-codes `valid-use-server`, so the file already names a rule.
- State: `RuleOptions` :39-56 (`overrides: BTreeMap<String, RuleOverride>` :40; `client_wrappers` :54, added by ADR 0385); `RuleOverride` :58-64; `request_rules` (`--enable-rule`) :177; `is_enabled` :183-199. The module doc :33 still says "Dialect-neutral".
- Discovery (`rust/crates/solid-facts-backend/src/diagnostics.rs`): `discover_rule_options` :1292-1303 accepts a name only if a catalog declares it or `retired_rule` knows it (:1298-1301). A group key is refused there today ("the rule catalog has no rule named ..."). `discover_rule_options_with` :1324-1347 walks the ancestors and fails closed. `discovered_rule_options_path` :1356-1364 feeds the daemon fingerprint.
- Application: `analyze_accepted_inner` (:249) reads options :332-334; identity :371-380 (`rule_options` field :135); `retain_enabled` :396. `retain_enabled` :591-626 keys on `finding.rule` (:599-605), so findings name the member without any change. An unknown finding name is `UnknownRuleIdentity` (:614, :622).
- `suppress_findings_owned_by_enabled_rules` is called at :410 and defined at `rust/crates/solid-reactive-ir/src/projection.rs:717`. It runs after enablement (doc :709-716): SC1001 is dropped when SC5001, SC1004 or SC1007 survives on its span. SC1007 owns only where `CatalogCapabilities::SOLID_2` says so (:502).
- Aliases (`rust/crates/solid-facts-backend/src/dialect.rs`): `RULE_ALIASES` :231-300 (25 rows, count pinned at `dialect/tests.rs:195-199`); `rule_alias` :314-319; `expected-function-got-expression` to `reactive-handler-frozen` :267-270.

### 1.2 Trap: map order
`parse_with_aliases` iterates `document.rules` (`rule_options.rs:101`), a `BTreeMap` sorted by configured key. The group and the members sort as `reactive-handler-frozen` < `reactive-read-after-await` < `reactivity` < `strict-read-untracked` < `uncalled-accessor`. A group expanded when its own key is reached overwrites the two `reactive-*` members set before it, so their explicit settings lose silently. Expansion has to be two-phase: group defaults first, then explicit members (**Read**). Two configured spellings that canonicalise to one rule also collide silently; the later key wins.

### 1.3 ESLint adapter (`packages/cli/eslint.cjs`)
- One ESLint rule per catalog entry: `reportingRule` :708-747; registration :816-823, with a collision throw :818-820. `reactivity` is not a key of `plugin.rules`.
- Routing by name: each per-rule `Program` keeps `finding.rule === entry.name && userFacing` (:734-736). A group rule that reported under its own id would name the group in ESLint output, which ADR 0386 forbids.
- Manifest: `packages/cli/lib/rules-solid-v2.json` (members :8-11), generated by the Rust test `the_shipped_manifest_is_the_catalog` (`rules.rs:308-324`; `manifest_json` :292-301). `scripts/dialect-manifests.mjs` does not generate it. It validates dialect assembly manifests (:19-35).
- Config builder: `plugin.configs[catalog.config]` :849-874, severities :867-871. `recommended` enables only `certification` and `contract-note` (:842-848).
- Enablement channel: ESLint severity reaches native only as `--enable-rule`, and only for `defaultEnabled === false` rules active in the file (:383-386, :431). No v2 rule has that flag (grep finds none). So an ESLint `off` on a member is a view filter; native still computes the finding.
- `certification` :624-653 reports every finding that no active per-rule rule owns (:642-645). **Read, not executed:** with `recommended` alone, or `[v2, recommended]`, `"solid-checker/strict-read-untracked": "off"` still reports SC1001 through `certification`. No test sets a member to `"off"`; the `"off"` assertions are at `adapter.test.mjs` :369, :567, :663, :909, :914, none on a member.
- Precedence: ESLint's later config object wins per key (`adapter.test.mjs:561-562`). A rule cannot read other rules' severities. `configuration()` (`eslint.cjs:103-107`) sees only its own options and `settings.solidChecker`. `rule_options.rs:13-20` records a deliberate "no per-ESLint-config channel".
- Hand copy: `DEPRECATED_RULE_KEYS` :799-814 is a subset of `RULE_ALIASES`, though ADR 0391 names `RULE_ALIASES` the authority. Seven non-`v1` aliases are missing: `no-owner-effect`, `no-owner-cleanup`, `no-owner-boundary`, `no-owner-settled-cleanup`, `package-contract-export-missing`, `package-contract-missing`, `package-contract-callback-missing`. **Read:** ESLint rejects `solid-checker/no-owner-cleanup` today, though native accepts it.

What a group needs in ESLint (options, undecided):
- G1: a registered rule named `reactivity`. ESLint reports unknown rule ids in config and in disable comments as errors (E3). It cannot report member findings under member ids, so it can only be a no-op key.
- G2: a preset object setting the four member keys to `off`. Member precedence then depends on array order, which ESLint decides, not the adapter.
- G3: expand the group in `rule-options.json` only, leave ESLint severities per member, and accept the key through G1.
- Recommendation: pass the member list into `parse_with_aliases` as a parameter, as `alias` already is (:87). The ADR 0385 arm already hard-codes a name at :124, so a literal `reactivity` arm would match the file's precedent, but the parameter keeps the module dialect-neutral.

### 1.4 Tests that pin current behaviour (extend these)
- `rule_options.rs` test module :199-: `known_rule` :202-213 (no group; now lists `valid-use-server`); tests at :216, :224 (refusal text "takes only `enabled`"), :239, :260, :286 (aliases), :302 (precedence), :324 and :366 (ADR 0385 options).
- `diagnostics/tests.rs`: `unknown_finding_identities_fail_closed` :41; `a_disabled_coverage_rule_returns_its_withheld_obligations` :73; `diagnostic_session_keys_retention_on_requested_enablement` :170; `compatibility_rule_identities_are_tolerated_and_typos_are_not` :266 (alias loop; `v1/no-such-rule` must fail).
- `projection/tests.rs`: `enabled_specific_defects_own_their_strict_reads` :164; `solid_one_keeps_the_handler_rule_split` :192.
- `dialect/tests.rs`: counts 25 and 57 at :194-206; `every_catalog_identity_resolves_to_its_metadata` :209; notice identity :1050-1075.
- `rules.rs` test module from :305: manifest :308, identities :329, codes sharing a name :346, docs page :376.
- `packages/cli/test/adapter.test.mjs`: per-rule surface and key-count assert :343-371 (a group key changes the count); deprecated keys :534-545; recommended and certification :560-606; `lintPass` and `enabledRules` :654-666; real `Linter` :152-165.

## 2. ADR 0387: inline directives

### 2.1 Comments in solid-facts
- Not captured. `rg -i comment rust/crates/solid-facts/src` matches only doc and test text (`ast/tests.rs:667,1733,1762`, `ast/types.rs:408`). Nothing reads `.comments`, and the visitor does not visit them.
- One parse: `extract()` `rust/crates/solid-facts/src/ast/extract.rs:21-57` (JSON early return :24-30; `Parser::new` :37; `visit_program` :56). `Collector::finish` :407 builds `AstFacts` (`schema: AST_FACTS_SCHEMA` :484). `AST_FACTS_SCHEMA = 75` now (`ast/mod.rs:50`). `AstFacts::empty` is at `ast/types.rs:1802`.
- Oxc 0.118.0 (`rust/Cargo.lock`): `Program.comments: Vec<Comment>` (`oxc_ast-0.118.0/src/ast/js.rs:61`). `Comment { span, kind }`: the span includes the delimiters; `kind` is `Line`, `SingleLineBlock` or `MultiLineBlock` (`ast/comment.rs:13-24`, `:130-157`). The parser collects all trivia (`oxc_parser-0.118.0/src/lib.rs:583`). **To verify:** whether comments inside JSX children `{/* */}` are included.
- Proposal (narrowest): `AstFacts.inline_directives: Vec<CommentDirectiveFact>` with `#[serde(default)]`, where `CommentDirectiveFact { span: Span, origin: {SolidChecker, Eslint}, action: {Disable, DisableNextLine, DisableLine, Enable}, block: bool, rules: Vec<String> }`, kept only for comments whose label is a directive label. The name must differ from `DirectiveFact` (`types.rs:714`), which is taken by prologue directives (`module_directives` :382, `stray_directives` :391 from ADR 0385). Convention: a new table bumps the schema with a "(facts schema N)" note (`types.rs:154, 346, 354, 384`), so the directive table is 76. The grammar split belongs in solid-facts (syntax). Name resolution stays in solid-facts-backend, because `ast/mod.rs:1-4` makes the crate checker-independent. `Span` is a plain `u32` pair (`core.rs:13-16`); no Oxc node crosses the seam.

### 2.2 Where a finding's location is known, and where to suppress
- Findings carry byte spans from creation (`Finding`, `rust/crates/solid-reactive-ir/src/findings.rs:132-158`). Line and column are added at snapshot time (`diagnostics.rs:1137-1162`: line is the count of `\n` plus one; column counts UTF-16).
- Order in `analyze_accepted_inner`: `retain_enabled` :396, owned-suppression :410, release notice :413, router notice :418, reclassification :438-481, refused-file notice :487-520, `snapshot_of` :523, coverage status override :526-528, premises :529-547.
- Recommendation: insert the directive pass between :410 and :413. Project notices are pushed after it, so they are never directive-suppressed. Use `facts.files[..].ast.inline_directives` and `FileFacts.source` (`rust/crates/solid-facts/src/project.rs:16-21`); the file lookup pattern is at :438-443.
- `snapshot_of` computes `status` from the findings (:1025-1034). Suppressing after :523 must recompute `status` and keep the coverage override (:526-528) consistent.
- Open: project-scoped findings (`subject_kind == "project"`). ESLint reports them at `[0,0]` in every linted file (`eslint.cjs:565-566`, `:580-593`), so a block directive at the top of a file would hide them in ESLint. Coverage findings: `retain_enabled` keeps the status uncertifiable when a coverage rule is disabled (:524-528; `diagnostics/tests.rs:73`). Decide the same for directives.
- Foreign-plugin names. ADR 0387 says a directive "naming no known rule" is a notice, but not which names count. Three fixtures carry `// eslint-disable-next-line prefer-rest-params` (`fixtures/reactive-ir/parameter-use-forms/App.tsx:53`, `fixtures/runtime-oracle/r6-b3-flagarguments/App.tsx:12`, `fixtures/runtime-oracle/r6-b3-fwdarguments/App.tsx:12`). Recommendation: an `eslint-disable*` name without a `solid-checker/` or `solid/` prefix belongs to another plugin and is ignored silently. Only prefixed names, and bare names in the `solid-checker-*` family, are checked. Otherwise these fixtures would produce notices.

### 2.3 Same result in WASM and in ESLint
- WASM: `rust/crates/solid-checker-wasm/src/lib.rs:196-226` builds facts from the request sources and calls `analyze_project_inputs_measured_with_enablement` (:216). Backend suppression therefore reaches WASM with no adapter change. Other native callers: `check.rs:304`, `daemon.rs:749, 1436`.
- ESLint byte mapping: `byteOffsetToIndex` :485-496, `findingRange` :498-503, `projectFindings` :552-595.
- Line breaks differ: ESLint uses `\r\n|[\r\n  ]` (`eslint/lib/shared/ast-utils.js:13`); native counts `\n` only (`diagnostics.rs:1137-1162`). A line-based match disagrees on a lone CR or U+2028/2029. Open.
- Parity: ADR 0379 says analysis-only diffs skip the WASM parity gate in `make verify`, and CI's `wasm-parity` job runs it on every PR. AGENTS.md's "`make verify` runs both" is ambiguous on this.
- ESLint 10.8.0 facts (**Read**):
  - E1. `eslint/lib/shared/directives.js:11`: only labels starting with `eslint` are directives. `solid-checker-*` comments are invisible to ESLint core.
  - E2. `source-code.js:855-857`, `:888-891`: a `//` comment may carry only `eslint-disable-line` or `eslint-disable-next-line`. `// eslint-disable X` is ignored.
  - E3. `linter.js:243-278`: an unknown rule id in a disable directive gets `report.addError` (:278), message "Definition for rule '<id>' was not found." (`file-report.js:96`, `:107-111`), severity 2 (`:571-575`). The same error applies to unknown ids in config (`linter.js:557-572`).
  - E4. Default `reportUnusedDisableDirectives: 1` (warn) at `default-config.js:62`. It is the `FlatConfigArray` base (`flat-config-array.js:89`), and `Linter.verify` with a config array builds one (`linter.js:854`), so the warning applies to the adapter tests too. The message is at `apply-disable-directives.js:408-413`.
  - E5. The `-- text` justification is split by `parseDirective` (`source-code.js:880-886`).
  - E6. An `eslint-disable-line` spanning lines is a problem (`source-code.js:899-900`).
- Double handling is NOT harmless. If native suppresses `// eslint-disable-next-line solid-checker/strict-read-untracked`, the adapter never reports that finding, so ESLint's directive matches nothing and gets the E4 warning. It is harmless only with `reportUnusedDisableDirectives` set to `off`.
- Options:
  - O1 (recommended): the adapter passes a native flag, so native skips `eslint-disable*` naming `solid-checker/<member>`, which ESLint already applies per rule id. The flag joins the argument list (`eslint.cjs:421-443`) and the cache key (`:387-397`). Native keeps `solid-checker-*`.
  - O2: native applies everything, and the ESLint warnings are documented.
  - Under either option, `solid/<name>` in ESLint depends on the user's loaded plugins (E3). A group directive is an error without a rule of that name, and an unused-directive warning with one (G1). Under O1 native must still apply `solid-checker/reactivity` itself, because ESLint cannot.
  - Open: `eslint-disable` with no names. ESLint means "all rules"; native should match, or the two diverge.

### 2.4 The unknown-rule notice
- Existing notices: SC9013 `dialect.rs:522-524`; SC9014 `:531-533`, appended `diagnostics.rs:413-415`, built :637+; SC9015 `dialect.rs:538-540`, appended :518-520, built :864-900 with `subject_kind = "project"` at :894. Pattern: `RuleMetadata { uncertifiable: true, default_enabled: true }`, then `Finding::new` (`findings.rs:161-169`), a hint, evidence, and a project subject.
- Codes: SC9016 and above are unused (grep finds none).
- Requirements: a new `Rule` variant, its metadata, and the `Rule::ALL` length `[Self; 34]` (`rules.rs:79`); `docs/rules/<name>.md` (`rules.rs:376-384`); manifest regeneration (`rules.rs:308-324`); the README count (`docs/rules/README.md:3-4`); an identity test like `dialect/tests.rs:1050-1075`.
- Effects (**Read**): a project-level uncertifiable finding gives status "notice" and makes `--certify` fail (`snapshot_emission.rs:35-41`, call site :121 passes `has_notice`; the daemon does the same at `daemon.rs:1733`; `user_status` :52-60). ESLint shows it on every file (`userFacing`, `eslint.cjs:73-75`). A typo in a directive would therefore fail `--certify`. That fits the fail-closed intent, but it should be stated.
- Must NOT produce the notice: adapter-only ESLint ids `certification`, `package-note` and `contract-note` (`eslint.cjs:792`), which ESLint users do write. Also retired ids (`RETIRED_RULES`, `dialect.rs:39-224`), accepted silently as `diagnostics.rs:1295-1301` does for rule options. The `merged` retirees must not alias (`dialect.rs:171-179`: "existing disables intentionally do not transfer").

### 2.5 Upstream comment syntax
- Upstream has no comment syntax of its own. Its documented suppression is ESLint's: `// eslint-disable-next-line` (`/tmp/sc-upstream-spec/raw/docs_reactivity.md:83`).
- Upstream also documents `/* eslint solid/reactivity: ["error", {...}] */` (`docs_reactivity.md:877-887`). That is an options form, which ADR 0387 does not cover. ESLint applies it in ESLint only, and native never reads it, which is a divergence.
- Names a user writes: `solid/reactivity`, `solid/no-destructure`, and so on. ESLint core validates them under E3.

## 3. Upstream to checker name table
Source: `/tmp/sc-upstream-spec/raw/src_plugin.ts:51`, the complete `allRules` (35 names; `validate-jsx-nesting` is commented out). `/tmp/sc-upstream-spec/INDEX.md` covers only five rules, so this registry is the full list. Checker side: `rules.rs`, `dialect.rs`, `docs/rules/README.md:124-137`, ADRs 0381-0390.

| Upstream name | Checker | Status |
|---|---|---|
| components-return-once | SC1004 `components-return-once` | same name, shipped |
| no-destructure | SC1003 `no-destructure` | same name, shipped |
| jsx-no-duplicate-props | SC8003 `jsx-no-duplicate-props` | same name, shipped |
| prefer-for | SC8014 `prefer-for` | same name, shipped |
| prefer-show | SC8015 `prefer-show` | same name, shipped |
| no-write-in-pure-computation | SC2001 | shipped; alias `reactive-write-in-owned-scope` (ADR 0382) |
| no-store-mutation-outside-setter | SC2003 | shipped; alias `no-direct-mutation` (ADR 0383) |
| valid-use-server | SC7006 | shipped; alias `server-function-module-directive` (ADR 0385). Placement checks and `clientWrappers` are in the uncommitted ADR 0385 slice |
| reactivity | SC1001, SC1002, SC1005, SC1007 | group, ADR 0386, not shipped |
| no-single-arg-create-effect | SC7001 `missing-effect-function` | different claim, no alias (ADR 0390) |
| event-handlers, imports, jsx-no-script-url, jsx-uses-vars, jsx-no-undef, no-array-handlers, no-innerhtml, no-proxy-apis, no-react-deps, no-react-specific-props, no-unknown-namespaces, prefer-classlist, self-closing-comp, style-prop | nothing | retired with the 1.x catalog; only `v1/` rows exist (`dialect.rs:39-224`); the bare name is in no table |
| no-accessor-as-prop, no-boolean-enumerated-attribute, no-browser-globals-in-server-function, no-invalid-server-capture, no-module-scope-reactive-primitive, no-restated-default-options, no-unused-signal, prefer-onSettled-for-side-effects, prefer-structured-class, removed-api, require-async-server-function | undecided | no key in any table, no repo mention |

- Recommendation: a directive naming a pinned v0.18.1 name with no checker rule is accepted silently, with no notice. Pin the list as data with a test. Names outside it get the notice.
- The bare retired names (`prefer-classlist`, `jsx-no-undef`, `event-handlers`, and so on) are refused today by `rule-options.json` (`rule_options.rs:103-107`, `diagnostics.rs:1298-1301`). The directive path should not copy that.

## 4. Open design questions
1. ESLint group representation: G1, G2 or G3 (section 1.3).
2. ESLint double handling: O1 (recommended) or O2 (section 2.3).
3. `solid/<name>` directives under ESLint: an error without a `solid` plugin (E3).
4. Directives on project and coverage findings, and their effect on status (section 2.2).
5. `solid-checker-enable`, and `solid-checker-disable` with no rule: ADR 0387 is silent on both forms.
6. Notice code and name, and whether the notice is project-scoped (every-file display, `--certify` failure).
7. `no-single-arg-create-effect`: silent, or alias to SC7001 (ADR 0390 says the claims differ).
8. The 11 undecided upstream names (section 3).
9. Where the v0.18.1 list lives: `dialect.rs` next to `RULE_ALIASES`, or the solid-v2 rules crate. New aliases change the pinned 25.
10. `DEPRECATED_RULE_KEYS` drift (seven names): fix, or document as the ESLint-only alias set.
11. Line-break definition for native directive matching.
12. Foreign-plugin names in `eslint-disable` (section 2.2): ignore is recommended, not yet decided.
13. Sequencing against the ADR 0385 slice, which is uncommitted in the same files (`rule_options.rs`, `ast/mod.rs` schema, `ast/types.rs`, `ast/extract.rs`, `ast/visitor.rs`).

## 5. Pre-existing gaps, not caused by ADRs 0386 or 0387
- A member set to `off` in ESLint is still reported under `recommended`, or whenever `certification` is on (section 1.3). **Read; not executed.**
- `DEPRECATED_RULE_KEYS` drift (seven aliases) (section 1.3).
- Bare upstream names are refused by `rule-options.json` (section 3).

## 6. Budgets and docs
- `docs/decisions.md` is 142,443 bytes against a 145,000 budget (2,557 headroom). `docs/open-work.md` is 31,092 against 32,000 (908 headroom). Budgets: `scripts/doc-budget.mjs:21-40`. A design entry has to fit.
- `DOCS_ALLOWED` (`doc-budget.mjs:71-87`) allows no new top-level doc.
- `docs/rules/README.md:134-137` says the group and directives are "not yet shipped"; update it when they ship. `docs/open-work.md` has no 0386 or 0387 entry (grep).

## 7. Test surfaces (not run)
- Rust: section 1.4; plus `solid-facts/src/ast/tests.rs:919, 1750` (schema asserts), `solid-checker-wasm/src/lib.rs:237` (shared-input test) and `snapshot_emission/tests.rs:58` (certify semantics).
- JS: `adapter.test.mjs` as in section 1.4. For directive behaviour, use `ESLint` or `Linter` with `reportUnusedDisableDirectives` set explicitly, so the warning is observable and asserted.
- Fixtures: the `add-fixture` skill (`.claude/skills/add-fixture/SKILL.md`), then `make coverage` and `make ownership-gate` (AGENTS invariant 6).

## Owner decisions (2026-10-25)
1. Group in ESLint: G3. `reactivity` expands in rule-options.json and native directives (two-phase expansion, member settings win); ESLint registers a no-op `solid-checker/reactivity` rule so the key and disable comments are valid; severities stay per member.
2. Double handling: O1. The adapter passes a flag; native ignores `eslint-disable*` comments naming `solid-checker/<member>` (ESLint applies them) but still applies `solid-checker-*` comments and group names.
3. Directive scope: site violations only. Uncertifiable obligations and project notices are never suppressed by a comment.
4. Unknown names: new project notice SC9016 for unknown `solid-checker/*` names only (fails --certify like other notices). Upstream `solid/*` names in the pinned v0.18.1 list (`allRules`, 35 names), adapter ids (certification, package-note, contract-note) and RETIRED_RULES ids are accepted silently; other plugins' names are ignored.
Orchestrator decisions: `no-single-arg-create-effect` gets no alias (ADR 0390); bare `solid-checker-disable` / `eslint-disable` with no names means all checker rules (matches ESLint); `-enable` supported; add the seven missing DEPRECATED_RULE_KEYS so ESLint matches RULE_ALIASES; the pinned upstream name list lives next to RULE_ALIASES in solid-facts-backend/src/dialect.rs.
