# solid/reactivity invalid cases → solid-checker catalog

Research output (read-only). No file in the repo or `../solid-checker-rc17-corpus` was modified, and no cargo, make or bun ran there.

**Inputs:** `/tmp/sc-upstream-spec/reactivity.md` §2c (verbatim case blocks, upstream order kept) and `raw/test_rules_reactivity.test.ts`. Code below is copied from those blocks, indentation trimmed, lines joined with ` ⏎ `, irrelevant lines dropped (marked `…`).

**Our side:** `docs/rules/` pages SC1001, SC1002, SC1003, SC1005, SC1007, SC2003, SC9011, SC9012 (and SC7001 and SC4002 where the tsc arm is decided); `docs/rules/README.md`; `fixtures/tsc-oracle/README.md` (redundancy ledger) and `fixtures/tsc-oracle/rule-cases.json`. The task named `cases.json`; the oracle's file is `rule-cases.json` (`cases.json` in that directory does not exist). `docs/decisions.md` ADR 0386 and `docs/release-audits/2026-10-22-solid-2-rc17/signals.md` were read for the group key and the mapArray audit row.

**Classes.** The six classes requested, plus one I added:
- `covered`: the page describes this shape as a violation.
- `uncertifiable`: the page says the shape is an obligation (a reason is given).
- `tsc`: TypeScript reports it on the published typings. Ledger row or rule-cases entry cited; "unverified" marks where I could not confirm the diagnostic.
- `not-2.0`: the API or premise does not exist in Solid 2.0.
- `miss`: a plausible real 2.0 defect no page claims.
- `unclear`: the page does not clearly describe the shape, or two pages disagree.
- `not-a-defect` (added): the page or the runtime says the shape is legal, or the upstream message is an analysability lint with no runtime defect. The six-class list had no home for these, so I did not force them into `miss` or `unclear`.

**Props caveat used throughout.** The props rules (SC1001, SC1002, SC1003, SC1007) decide by caller classification: reported when a visible call site passes a reactive value, uncertifiable when call sites cannot be enumerated (`strict-read-untracked.md` "Props follow their callers"; `no-destructure.md`; `reactive-handler-frozen.md`). No page says what happens when there are zero visible call sites. Upstream's fixtures are standalone components with no caller, so every props row below is `unclear` on that single gap, not on its own merits.

## Invalid-case table (63 rows, upstream order)

| # | upstream messageId | case code (verbatim, trimmed) | our rule | class | justification (page section) |
|---|---|---|---|---|---|
| 1 | untrackedReactive | `const Component = () => { ⏎ const [signal] = createSignal(5); ⏎ console.log(signal()); ⏎ return null; }` | SC1001 | covered | "What it does": a signal accessor read at top level of a component body. Caveat: the body has no JSX and the page does not define component identity. |
| 2 | untrackedReactive | `const Component = () => { ⏎ const [signal] = createSignal(5); ⏎ console.log(signal()); ⏎ return <div>{signal()}</div> }` | SC1001 | covered | Same as 1. The JSX read at line 5 is tracked; line 4 (`console.log`) is the violation. |
| 3 | untrackedReactive | `const Component = props => { ⏎ const value = props.value; ⏎ return <div>{value()}</div>; }` | SC1001 (props) | unclear | Props branch needs caller classification; zero visible call sites is undefined (see caveat). |
| 4 | untrackedReactive | `import { createSignal } from "my-solid-renderer"; ⏎ const Component = () => { ⏎ const [count] = createSignal(0); ⏎ const doubled = count() * 2; ⏎ return <div>{doubled}</div>; };` + `settings: { solid: { moduleSources: ["my-solid-renderer"] } }` | none | miss | Config-dependent. Upstream's `moduleSources` makes a package a Solid primitive source. Our catalog resolves exact symbols and does not infer from a package name (AGENTS invariant 3); no config equivalent exists. A defect only if that package re-exports Solid's primitive. |
| 5 | untrackedReactive | `const Component = props => { ⏎ const { value: valueProp } = props; ⏎ const value = createMemo(() => valueProp \|\| "default"); ⏎ return <div>{value()}</div>; };` | SC1003 (outside the `reactivity` key) | unclear | `no-destructure.md` "What it does" covers setup-time destructuring of props, but its verdict depends on call sites; zero-caller undefined. Upstream files this under untrackedReactive, which contradicts ADR 0386 (see Task E). |
| 6 | untrackedReactive | `const Component = props => { ⏎ const valueProp = props.value; ⏎ const value = createMemo(() => valueProp \|\| "default"); ⏎ return <div>{value()}</div>; };` | SC1001 (props) | unclear | Props-caller gap. |
| 7 | untrackedReactive | `const Component = props => { ⏎ const [value] = createSignal(props.value); ⏎ }` | SC1001 (props) | unclear | Props-caller gap. Read of `props.value` as an argument in the body. |
| 8 | untrackedReactive | `const Component = props => { ⏎ const derived = () => props.value; ⏎ const oops = derived(); ⏎ return <div>{oops}</div>; }` | SC1001 (props, helper) | unclear | Helper called from the body is described ("What it does"), but the props read needs caller classification. |
| 9 | untrackedReactive | `function Component(something) { ⏎ console.log(something.a); ⏎ return <div />; }` | SC1001 (props) | unclear | No page says how a first parameter not named `props` is classified as props (upstream: uppercase name plus JSX). Plus the props-caller gap. |
| 10 | untrackedReactive | `const Component = () => { ⏎ const [signal] = createSignal(); ⏎ const d = () => { ⏎ signal(); ⏎ } ⏎ d(); }` | SC1001 | covered | "What it does": a read reached through a plain helper called from an untracked position (one hop). |
| 11 | untrackedReactive | `const Component = () => { ⏎ const [signal] = createSignal(); ⏎ function d() { ⏎ signal(); ⏎ } ⏎ d(); }` | SC1001 | covered | Same as 10, with a function declaration. |
| 12 | untrackedReactive | `const Component = () => { ⏎ const [signal] = createSignal(); ⏎ const d = () => { ⏎ const e = () => { ⏎ signal(); ⏎ } ⏎ e(); ⏎ } ⏎ d(); }` | SC1001 | unclear | "What it does" reports call chains, but "How it is proven → Not decided" says "a read through another helper hop" is not decided. The two sections conflict. |
| 13 | untrackedReactive | `const Component = () => { ⏎ const [signal1] = createSignal(); ⏎ const d = () => { ⏎ const [signal2] = createSignal(); ⏎ const e = () => { ⏎ signal1(); ⏎ signal2(); ⏎ } ⏎ e(); ⏎ } ⏎ }` | SC1001 | uncertifiable | `d` is never called, so `e` sits in a helper chain with no resolved caller: "A read no fact places is uncertifiable" (`strict-read-untracked.md`, "What it does"). |
| 14 | untrackedReactive | `const Component = () => { ⏎ const [signal] = createSignal(); ⏎ const foo = () => { signal(); } ⏎ const bar = () => { foo(); } ⏎ bar(); }` | SC1001 | unclear | Two helper hops (`bar` → `foo` → read): same "Not decided" conflict as 12. |
| 15 | shouldDestructure | `const Component = () => { ⏎ createSignal(); ⏎ }` | none | not-a-defect | Discarded primitive result. No runtime defect and no page claims it. Upstream's message is about analysability ("For proper analysis"). |
| 16 | shouldDestructure | `const Component = () => { ⏎ const [, setSignal] = createSignal(); ⏎ }` | none | not-a-defect | Getter discarded. A write-only signal is not a runtime defect. |
| 17 | shouldDestructure | `const Component = () => { ⏎ const {2: signal, 3: setSignal} = createSignal(); ⏎ }` | none | tsc (unverified) | Numeric keys 2 and 3 on a two-element tuple. TypeScript should reject this (TS2339 or TS2493, not run by me; no ledger row). The runtime defect (both bindings `undefined`) is TypeScript's to report. |
| 18 | shouldAssign | `const Component = () => { ⏎ createMemo(() => 5); ⏎ }` | none | not-a-defect | Discarded memo. No runtime defect and no page claims it. |
| 19 | badSignal (JSX) | `const Component = () => { ⏎ const [signal] = createSignal(); ⏎ return <div>{signal}</div> ⏎ }` | none | not-a-defect | `uncalled-accessor.md` "Examples": `return <span>{count}</span>` is correct, because JSX children are called reactively. |
| 20 | badSignal (JSX) | `const Component = () => { ⏎ const memo = createMemo(() => 5); ⏎ return <div>{memo}</div> ⏎ }` | none | not-a-defect | Same as 19 (memo accessor as a JSX child). |
| 21 | badSignal (JSX) | `const Component = () => { ⏎ const [signal] = createSignal(); ⏎ return <button type={signal}>Button</button> ⏎ }` | none | tsc | Native JSX attribute: TS2322. Ledger row `uncalled-accessor (SC1005)`, typed positions (`fixtures/tsc-oracle/README.md`); `rule-cases.json` uncalled-accessor entry, `allow` [2322, 2538]. `uncalled-accessor.md` "Scope" table. |
| 22 | badSignal (arithmetic or comparisons) | `const Component = () => { ⏎ const [signal] = createSignal("world"); ⏎ const memo = createMemo(() => "hello " + signal) ⏎ }` | SC1005 | covered | "Scope" section: a string-concatenation binary operand is kept. Upstream's `where` text differs from ours; cosmetic. |
| 23 | badSignal (template literals) | ``const Component = () => { ⏎ const [signal] = createSignal("world"); ⏎ const memo = createMemo(() => `hello ${signal}`) ⏎ }`` | SC1005 | covered | "What it does" and "Scope": untagged template interpolation is kept. |
| 24 | badSignal (unary expressions) | `const Component = () => { ⏎ const [signal] = createSignal(5); ⏎ const memo = createMemo(() => -signal) ⏎ }` | SC1005 | covered | "Scope" section: unary `-count`, `+count`, `~count` are kept (TypeScript accepts a function operand there). |
| 25 | badSignal (property accesses) | `const Component = (props) => { ⏎ const [signal] = createSignal(5); ⏎ const memo = createMemo(() => props.array[signal]) ⏎ }` | none | tsc | Computed property key: TS2538. Ledger row `uncalled-accessor`, typed positions; rule-cases entry `allow` [2322, 2538]. |
| 26 | expectedFunctionGotExpression | `const Component = props => { ⏎ return <div onClick={props.onClick} />; ⏎ }` | SC1007 | unclear | `reactive-handler-frozen.md` "What it does": a handler prop is a violation only when a call site passes it reactively. Zero-caller undefined. |
| 27 | expectedFunctionGotExpression | `const Component = props => { ⏎ createEffect(props.theEffect); ⏎ }` | none (SC7001 arity) | tsc | One-argument `createEffect`: TS2554. `missing-effect-function.md` "What it does" says SC7001 is silent there because TypeScript reports it. Ledger row `missing-effect-function (SC7001)`, absent-apply arm; rule-cases `allow` [2554]. |
| 28 | providerValue | `const Component = props => { ⏎ return <SomeContext.Provider value={props.value}>{props.children}</SomeContext.Provider>; ⏎ }` | none | not-2.0 | `Context.Provider` is on the solidjs-2 skill's 1.x list (renamed or removed in 2.0). |
| 29 | providerValue | `const Component = props => { ⏎ return <SomeProvider value={props.value}>{props.children}</SomeProvider>; ⏎ }` | none | unclear | Identified by name only (`…Provider`), which invariant 3 forbids. No page says whether a user component is a provider. Passing `props.value` to a component is legal in 2.0 (props are getters), so the claim is not established. |
| 30 | providerValue | `const Component = props => { ⏎ const [signal] = createSignal(); ⏎ return <SomeContext.Provider value={signal()} someOtherProp={props.foo}>{props.children}</SomeContext.Provider>; ⏎ }` | none | not-2.0 | `Context.Provider` (1.x form), as 28. |
| 31 | providerValue | `const MyContext = createContext(); ⏎ const Component = props => { ⏎ return <MyContext value={props.value}>{props.children}</MyContext>; ⏎ }` | none | miss | 2.0 provider form (`<Ctx value>`). The claim that the provider reads `value` once is on no page. `missing-context-provider.md` covers absent providers (SC4002). `decisions.md` ADR 0153 says only that a provider stores its `value` prop. Needs a runtime or dependency-source check before a rule. |
| 32 | badUnnamedDerivedSignal | `const owner = getOwner(); ⏎ const [signal] = createSignal(); ⏎ createEffect(() => runWithOwner(owner, () => console.log(signal()))); ` | none | unclear | `reactive-read-after-await.md` "Owners": "A callback of `untrack` or `runWithOwner` runs with tracking off", which would make the read a defect. `strict-read-untracked.md` says nothing about `runWithOwner(owner)` in a tracked scope, and no page claims this message. Also one-argument `createEffect` (TS2554). Candidate miss. |
| 33 | badUnnamedDerivedSignal | `function Component() { ⏎ const owner = getOwner(); ⏎ const [signal] = createSignal(); ⏎ createEffect(() => runWithOwner(owner, () => console.log(signal()))); ⏎ }` | none | unclear | Same as 32. |
| 34 | untrackedReactive + badUnnamedDerivedSignal | `function Component(props) { ⏎ const style = props.big ? () => ({ fontSize: props.size }) : undefined; ⏎ return <div style={style && style()} />; ⏎ }` | SC1001 (props) | unclear | untrackedReactive: props-caller gap. badUnnamedDerivedSignal: no page describes an unnamed derived closure under a conditional. |
| 35 | badUnnamedDerivedSignal | `import { createSignal } from "solid-js"; ⏎ import { dynamic } from "some-lib"; ⏎ function Component() { ⏎ const [count, setCount] = createSignal(0); ⏎ const Test = dynamic(() => test(count())); ⏎ return <Test />; ⏎ }` | none | unclear | A read in an arrow handed to an unresolved package call. SC9011 covers an accessor passed as an argument, not a read inside a callback. `strict-read-untracked.md` covers only named host-retained callbacks. Candidate miss or obligation; no page says which. |
| 36 | noAsyncTrackedScope | `const [count, setCount] = createSignal(0); ⏎ createEffect(async () => { ⏎ await Promise.resolve(); ⏎ console.log(count()); ⏎ });` | SC1002 | covered | "What it does": an accessor call after an `await` in an async `createEffect` compute. Covered for the read only. The messageId's claim (the async scope itself) is not made by any page: the SC1002 correct example keeps async computations. Also TS2554 (one-argument `createEffect`). Invariant 1 is not breached: the SC1002 claim is timing, not the arity. |
| 37 | noAsyncTrackedScope | `const [photos, setPhotos] = createSignal([]); ⏎ createEffect(async () => { ⏎ const res = await fetch("https://jsonplaceholder.typicode.com/photos?_limit=20"); ⏎ setPhotos(await res.json()); ⏎ });` | none | not-2.0 | Async computations are legal in 2.0 (`reactive-read-after-await.md` correct example). No accessor is read after the `await`. The one-argument `createEffect` is TS2554. |
| 38 | badSignal | ``const [signal] = createSignal("red"); ⏎ css`color: ${signal}`;`` | none | unclear | `uncalled-accessor.md` positions are "an untagged template interpolation". The tagged `css` is an unresolved callee. The page neither claims nor marks the shape as an obligation. |
| 39 | badSignal | ``const [signal] = createSignal("red"); ⏎ const f = () => signal(); ⏎ css`color: ${f}`;`` | none | unclear | Same as 38. `f` is a plain function, not an accessor, so SC1005 does not claim it either. |
| 40 | untrackedReactive | `function createCustomStore() { ⏎ const [store, updateStore] = createStore({}); ⏎ return mapArray( ⏎ [], ⏎ (item) => store.path.to.field ⏎ ); ⏎ }` | none | miss | `release-audits/…/signals.md` row "`mapArray` / `repeat` `setStrictRead(options.name)`" (dev.js:8889, 9332) says the mapper is a strict-read window, so the read is untracked. No SC1001 page names mapper callbacks as a scope. |
| 41 | untrackedReactive | `const [array] = createSignal([]); ⏎ const result = mapArray(array, (item, i) => { ⏎ i() ⏎ });` | none | miss | Same audit row. The index accessor `i` is read inside the mapper. |
| 42 | untrackedReactive | `const [array] = createSignal([]); ⏎ const result = indexArray(array, (item) => { ⏎ item() ⏎ });` | none | unclear | The audit row names `mapArray`/`repeat`, not `indexArray`. Check `indexArray`'s strict-read window before calling it a miss. |
| 43 | untrackedReactive | `const [signal] = createSignal(); ⏎ let el = <Component staticProp={signal()} />;` | none | not-a-defect | Module-scope read. `strict-read-untracked.md` "Module scope is not reported": "a deliberate module-scope snapshot is legal, undiagnosed Solid". |
| 44 | untrackedReactive | `const [signal] = createSignal(0); ⏎ useExample(signal())` | none | not-a-defect | Module-scope read (as 43). |
| 45 | untrackedReactive | `const [signal] = createSignal(0); ⏎ useExample([signal()])` | none | not-a-defect | Module-scope read (as 43). |
| 46 | untrackedReactive | `const [signal] = createSignal(0); ⏎ useExample({ value: signal() })` | none | not-a-defect | Module-scope read (as 43). |
| 47 | expectedFunctionGotExpression | `const [signal] = createSignal(0); ⏎ useExample((() => signal())())` | none | not-a-defect | Module-scope read (as 43). The "expected function" premise (custom hooks take accessors) is an upstream heuristic that no page states. |
| 48 | untrackedReactive | `const Component = _props => { ⏎ const props = merge({ value: "default" }, _props); ⏎ const value = props.value; ⏎ return <div>{value}</div>; };` | SC1001 (view) | uncertifiable | `strict-read-untracked.md` "How it is proven → Props views" and "What it does": a read through a `merge` alias that may return its only source "stays uncertifiable". |
| 49 | untrackedReactive | `const Component = props => { ⏎ const rest = omit(props, "value"); ⏎ console.log(rest.other); ⏎ return null; ⏎ };` | SC1001 (view) | uncertifiable | `omit(props, …)` always builds a view (`strict-read-untracked.md` "Props views"); "A read through the view or alias (`rest.x`…) … stay uncertifiable". |
| 50 | untrackedReactive | `const Component = () => { ⏎ const projected = createProjection(draft => {}); ⏎ console.log(projected.value); ⏎ return null; ⏎ };` | SC1001 (store path) | unclear | SC1001 claims "store path" reads, but the page does not name `createProjection` as a store source. Candidate covered once the source list is confirmed. |
| 51 | untrackedReactive | `const Component = () => { ⏎ const [value, setValue] = createOptimistic(0); ⏎ console.log(value()); ⏎ return null; ⏎ };` | SC1001 | covered | Accessor read at top level of a component body. `strict-read-untracked.md` "How it is proven → Getter arity" names the `createOptimistic` getter. |
| 52 | untrackedReactive | `const Component = () => { ⏎ const [state, setState] = createOptimisticStore({}); ⏎ console.log(state.value); ⏎ return null; ⏎ };` | SC1001 (store path) | unclear | As 50, for `createOptimisticStore`. |
| 53 | readAfterAwait | `const [id, setId] = createSignal(1); ⏎ const user = createMemo(async () => { ⏎ const response = await fetch("/api/users"); ⏎ return response.json() + id(); ⏎ });` | SC1002 | covered | `reactive-read-after-await.md` "What it does": an accessor call after an `await` in an async memo. |
| 54 | readAfterAwait | `function Component(props) { ⏎ const data = createMemo(async () => { ⏎ const response = await fetch("/api"); ⏎ return response.json() + props.suffix; ⏎ }); ⏎ return <div>{data()}</div>; ⏎ }` | SC1002 (props) | unclear | "Props member reads follow the component's caller classification" (`reactive-read-after-await.md`). Props-caller gap. |
| 55 | readAfterAwait | `import { dynamic } from "@solidjs/web"; ⏎ const [count, setCount] = createSignal(1); ⏎ const Test = dynamic(async () => { ⏎ await tick(); ⏎ return test(count()); ⏎ });` | SC1002 | unclear | SC1002 names `createMemo`, `createEffect`, `createProjection` "and friends". `dynamic`'s async source is not named; `static-dynamic-async-source.md` covers only the `static` flag. |
| 56 | readAfterAwait | `const [count, setCount] = createSignal(1); ⏎ const [derived, setDerived] = createSignal(async () => { ⏎ await tick(); ⏎ return count() * 2; ⏎ });` | SC1002 | unclear | The function form of `createSignal` is not named as a computation on the SC1002 page. |
| 57 | readAfterAwait | `const [urls, setUrls] = createSignal([]); ⏎ const [weight, setWeight] = createSignal(1); ⏎ const total = createMemo(async () => { ⏎ let sum = 0; ⏎ for (const url of urls()) { ⏎ sum += (await fetch(url)).size * weight(); ⏎ } ⏎ return sum; ⏎ });` | SC1002 | unclear | "Dominance" says "a conditional or looped await does not [dominate]". `weight()` sits after the await in the same loop body. The page does not say whether that read is silent, uncertifiable, or reported. |
| 58 | staleCapture | `const [items, setItems] = createSignal([]); ⏎ function useCartTotal() { ⏎ const list = items(); ⏎ return () => list.reduce((sum, item) => sum + item.price, 0); ⏎ }` | SC1001 | uncertifiable | The read is in a helper with no resolved caller ("A read no fact places is uncertifiable", `strict-read-untracked.md`). If a component calls the helper, SC1001 covers the read (row 60). The stale-closure claim adds no separate rule. |
| 59 | staleCapture | `const [items, setItems] = createSignal([]); ⏎ function useCount() { ⏎ const total = items().length; ⏎ return () => total; ⏎ }` | SC1001 | uncertifiable | Same as 58. |
| 60 | staleCapture | `const [theme, setTheme] = createSignal("dark"); ⏎ function Component() { ⏎ const current = theme(); ⏎ return <button onClick={() => console.log(current)}>theme</button>; ⏎ }` | SC1001 | covered | `theme()` at line 3 is a read at top level of a component body (SC1001 "What it does"). Upstream reports line 4 (the stale capture); we report line 3. Same defect. |
| 61 | staleCapture | `const [count, setCount] = createSignal(0); ⏎ function useStale() { ⏎ const value = count(); ⏎ return () => value + 1; ⏎ }` | SC1001 | uncertifiable | Same as 58. |
| 62 | noAsyncTrackedScope | `const [id, setId] = createSignal(1); ⏎ const [data] = createResource(async () => id(), async (v) => fetch("/api/" + v));` | none | not-2.0 | `createResource` is on the solidjs-2 skill's 1.x list (renamed or removed in 2.0). |
| 63 | untrackedReactive | `function Component(props) { ⏎ const { item } = props; ⏎ return <div>{item}</div>; ⏎ }` | SC1003 (outside the `reactivity` key) | unclear | `no-destructure.md` "What it does": the verdict depends on call sites. Zero-caller undefined. |

## Counts

| class | rows | count |
|---|---|---|
| covered | 1, 2, 10, 11, 22, 23, 24, 36, 51, 53, 60 | 11 |
| uncertifiable | 13, 48, 49, 58, 59, 61 | 6 |
| tsc | 17 (unverified), 21, 25, 27 | 4 |
| not-2.0 | 28, 30, 37, 62 | 4 |
| miss | 4, 31, 40, 41 | 4 |
| unclear | 3, 5, 6, 7, 8, 9, 12, 14, 26, 29, 32, 33, 34, 35, 38, 39, 42, 50, 52, 54, 55, 56, 57, 63 | 24 |
| not-a-defect (added class) | 15, 16, 18, 19, 20, 43, 44, 45, 46, 47 | 10 |
| **total** | | **63** |

Notes:
- Row 36 is `covered` for the read. Its one-argument `createEffect` is TypeScript's (TS2554), a separate claim, so no invariant-1 breach.
- No covered row is a TypeScript error. Rows 21, 25 and 27 are the only TypeScript-owned shapes that our rules would also touch, and they are excluded from our claims.

## Rows that decide Task E

### `miss` (4 rows)

- **4 (config).** A package that re-exports Solid primitives under a custom name. Needs a declared-source mechanism (an equivalent of `settings.solid.moduleSources`). The name alone must not be used (invariant 3).
- **31 (provider value).** The 2.0 `<Ctx value>` provider reads `value` once. No page; needs a runtime or dependency-source check before a rule.
- **40, 41 (mapArray mapper).** The rc.17 audit row shows the mapper is a strict-read window. SC1001 names components, effects and helpers only. Add mapper callbacks as a scope, after confirming against the runtime.

### `unclear` (24 rows), grouped by what decides them

1. **Props with zero visible call sites** (3, 5, 6, 7, 8, 9, 26, 54, 63). Nine rows hinge on one undefined behaviour. Upstream's fixtures are standalone, so this decides most of the surface. The props rules need a stated zero-caller verdict.
2. **Parameter identity** (9). Which first parameter counts as props when not named `props`.
3. **Helper hop depth** (12, 14). `strict-read-untracked.md` "What it does" reports call chains; "How it is proven → Not decided" leaves "a read through another helper hop" open. Pick one.
4. **runWithOwner tracking** (32, 33, plus the badUnnamedDerivedSignal arm of 34). `reactive-read-after-await.md` says `runWithOwner` callbacks run with tracking off; `strict-read-untracked.md` is silent. If the first is right these are a `miss`.
5. **Store and reactive source enumeration** (50, 52, 55, 56). SC1001 and SC1002 do not list `createProjection`, `createOptimisticStore`, `dynamic`'s async source or `createSignal`'s function form.
6. **Callbacks handed to unresolved package calls** (35, 38, 39). Whether they are uncertifiable obligations or out of scope. No page says.
7. **Loop-carried await** (57). `dominance` says a looped await does not dominate; the same-body read is unaddressed.
8. **indexArray** (42). Check whether `indexArray` has the same strict-read window as `mapArray`.
9. **Provider identity by name** (29). Invariant 3 forbids naming it.

## Task E: what the `reactivity` key must cover

ADR 0386 defines `reactivity` as SC1001, SC1002, SC1005 and SC1007, and states that SC1003 is excluded "(upstream keeps no-destructure apart)". The upstream test file contradicts that premise: rows 5 and 63 are `untrackedReactive` on destructured props. Two options for Task E: add SC1003 to the group, or change ADR 0386's rationale. Either way the choice is open, and SC1003's rows are `unclear` on the props gap anyway.

Minimum surface for the `reactivity` key to match upstream's invalid-case surface:

- **Keep in the group** (SC1001, SC1002, SC1005, SC1007): rows 1, 2, 10, 11, 22, 23, 24, 36, 51, 53, 60 (covered); 13, 48, 49, 58, 59, 61 (uncertifiable); the props rows and the candidate-covered rows once they are resolved.
- **Add to the group or accept as misses:** 4 (config), 31 (provider value), 40, 41 (mapArray mapper). Also 42 pending its check.
- **Do not add.** These are not-a-defect or not-2.0 and need no rule: 15, 16, 18 (discarded results); 19, 20 (JSX child, legal per `uncalled-accessor.md`); 43 to 47 (module-scope reads, silent per `strict-read-untracked.md`); 28, 30, 37, 62 (1.x APIs and premises); 17 and 21, 25, 27 (TypeScript-owned).
- **SC2003 `noWrite`.** Upstream's `reactivity` source emits `noWrite` (the message text is in the spec, §2a), but there are no upstream test cases for it. ADR 0386 excludes SC2003 from the key. Task E must decide whether `noWrite` belongs to the surface.
- **`providerValue` and `staleCapture` messageIds.** Neither has a group member. Rows 58, 59, 61 and 60 are covered by SC1001 as reads, so the stale-closure message adds no rule; row 31 is the only provider rule candidate.
- **`badUnnamedDerivedSignal`.** No page describes this shape (rows 32, 33, 34's arm, 35). Task E needs a decision here, or an explicit "not in the surface" note.

## What I did not verify

- I did not run `make tsc-oracle`, the checker, or `scripts/tsc-oracle.mjs`. The `tsc` classifications rest on ledger rows and `rule-cases.json` entries, which the README says are re-checked on the pinned rc.17 by the gate. Row 17 is unverified.
- I did not run upstream's tests. Classifications rest on page text and cited ledger rows.
- Row 36's classification does not depend on whether a one-argument `createEffect` counts as an apply-phase read. I did not resolve that question.
