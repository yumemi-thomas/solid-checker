# solid/reactivity — upstream spec (eslint-plugin-solid v0.18.1)

Upstream files: `docs/reactivity.md` (1545 lines; its Tests section is generated from the test file and is not repeated here), `src/rules/reactivity.ts` (1764 lines), `test/rules/reactivity.test.ts` (1411 lines); helpers in `../raw/src_utils.ts`, `../raw/src_compat.ts`, harness in `../raw/test_ruleTester.ts`. Rule key: `solid/reactivity`.

## 1. What it reports

A single-pass, stack-based analysis of one file. It tracks *reactive variables*: signals and memos (from `createSignal`, `createMemo`, `createSelector`, `createOptimistic`, `useTransition`, the `mapArray`/`indexArray` callback parameters, and `<For>`/`<Index>` callback parameters), props and stores (a function's first parameter is props when its name matches `/[pP]rops/`, or, at function exit, when the function contains JSX and its name is not lowercase; `createStore`/`createOptimisticStore`, `createProjection`, `createMutable`, `mergeProps`/`merge`, `splitProps`, `omit`, `createResource`). It then checks every use of those variables against *tracked scopes* (JSX expressions, arguments of `createEffect`, `createMemo`, `on`, event handlers, `onMount`/`onSettled`, timers, etc.). Eleven message ids cover the shapes: reading a signal or prop outside a tracked scope (`untrackedReactive`, `expectedFunctionGotExpression`, `providerValue`), using an uncalled signal (`badSignal`), missing calls on derived functions (`badUnnamedDerivedSignal`), discarded primitive results (`shouldDestructure`, `shouldAssign`), reassignment of reactive variables (`noWrite`), async tracked scopes (`noAsyncTrackedScope`), reads after an `await` (`readAfterAwait`), and stale captures in returned functions (`staleCapture`). Docs: "Enforce that reactivity (props, signals, memos, etc.) is properly used, so changes in those values will be tracked and update the view as expected." This rule is **a warning** by default.


## 2. Reported shapes (invalid cases, verbatim)

Source: `test/rules/reactivity.test.ts`, `invalid:` array, raw lines 714–1409. 63 cases. Every block below is a raw slice of that file.

### 2a. Message texts (verbatim literals from `src/rules/reactivity.ts`)

| messageId | literal | upstream invalid cases |
|---|---|---|
| `noWrite` | `"The reactive variable '{{name}}' should not be reassigned or altered directly."` | **none (no upstream test)** |
| `untrackedReactive` | `"The reactive variable '{{name}}' should be used within JSX, a tracked scope (like createEffect), or inside an event handler function, or else changes will be ignored."` | 28 |
| `expectedFunctionGotExpression` | `"The reactive variable '{{name}}' should be wrapped in a function for reactivity. This includes event handler bindings on native elements, which are not reactive like other JSX props."` | 3 |
| `badSignal` | `"The reactive variable '{{name}}' should be called as a function when used in {{where}}."` | 9 |
| `badUnnamedDerivedSignal` | `"This function should be passed to a tracked scope (like createEffect) or an event handler because it contains reactivity, or else changes will be ignored."` | 4 |
| `shouldDestructure` | `"For proper analysis, array destructuring should be used to capture the {{nth}}result of this function call."` | 3 |
| `shouldAssign` | `"For proper analysis, a variable should be used to capture the result of this function call."` | 1 |
| `noAsyncTrackedScope` | `"This tracked scope should not be async. Solid's reactivity only tracks synchronously."` | 3 |
| `readAfterAwait` | `"The reactive variable '{{name}}' is read after this computation suspends (at an 'await' or 'yield'), so changes to it won't be tracked. Read it before the first 'await' and store the result in a variable."` | 5 |
| `staleCapture` | `"'{{captured}}' captures the value of the reactive variable '{{name}}' at setup, but a returned function reads the capture later — it will never update. Call '{{name}}' inside the returned function instead, or prefix '{{captured}}' with 'initial'/'default'/'static' if a one-time snapshot is intended."` | 4 |
| `providerValue` | `"A context provider reads its 'value' prop only once, when it is created, so the reactive variable '{{name}}' will not stay up to date here. Pass the signal, memo, or store itself (or an object containing them) instead of reading it in JSX."` | 4 |

### 2b. Summary table

| # | messageId(s) | data / options | test lines | leading comment (verbatim) |
|---|---|---|---|---|
| 1 | `untrackedReactive` |  | 715–723 | // Untracked signals |
| 2 | `untrackedReactive` |  | 724–732 |  |
| 3 | `untrackedReactive` |  | 734–741 | // Untracked property access |
| 4 | `untrackedReactive` | settings: { solid: { moduleSources: ["my-solid-renderer"] } } | 744–754 | // settings.solid.moduleSources registers custom renderers/re-export // wrappers as Solid primitive sources (#183) |
| 5 | `untrackedReactive` |  | 755–763 |  |
| 6 | `untrackedReactive` | { name: "props.value" } | 764–777 |  |
| 7 | `untrackedReactive` |  | 778–784 |  |
| 8 | `untrackedReactive` | { name: "derived" } | 786–799 | // mark `props` as props by name before we've determined if Component is a component in :exit |
| 9 | `untrackedReactive` |  | 801–808 | // treat first parameter of uppercase function with JSX as a props |
| 10 | `untrackedReactive` | { name: "d" } | 810–825 | // Derived signals |
| 11 | `untrackedReactive` | { name: "d" } | 826–841 |  |
| 12 | `untrackedReactive` | { name: "d" } | 842–860 |  |
| 13 | `untrackedReactive` | { name: "e" } | 861–880 |  |
| 14 | `untrackedReactive` | { name: "bar" } | 881–899 |  |
| 15 | `shouldDestructure` | { nth: "first " } | 901–912 | // Unused reactives |
| 16 | `shouldDestructure` | { nth: "first " } | 913–924 |  |
| 17 | `shouldDestructure` | { nth: "first " } | 925–936 |  |
| 18 | `shouldAssign` |  | 937–947 |  |
| 19 | `badSignal` | { name: "signal", where: "JSX" } | 949–962 | // Uncalled signals |
| 20 | `badSignal` | { name: "memo", where: "JSX" } | 963–976 |  |
| 21 | `badSignal` | { name: "signal", where: "JSX" } | 977–990 |  |
| 22 | `badSignal` | { name: "signal", where: "arithmetic or comparisons" } | 991–1004 |  |
| 23 | `badSignal` | { name: "signal", where: "template literals" } | 1005–1018 |  |
| 24 | `badSignal` | { name: "signal", where: "unary expressions" } | 1019–1032 |  |
| 25 | `badSignal` | { name: "signal", where: "property accesses" } | 1033–1046 |  |
| 26 | `expectedFunctionGotExpression` | { name: "props.onClick" } | 1048–1060 | // event listeners are not rebound on native elements |
| 27 | `expectedFunctionGotExpression` | { name: "props.theEffect" } | 1061–1073 |  |
| 28 | `providerValue` | { name: "props.value" } | 1075–1081 | // provider value passed as-is |
| 29 | `providerValue` | { name: "props.value" } | 1082–1088 |  |
| 30 | `providerValue` | { name: "signal" } | 1089–1096 |  |
| 31 | `providerValue` | { name: "props.value" } | 1098–1105 | // Solid 2.0: the context object itself is the provider |
| 32 | `badUnnamedDerivedSignal` |  | 1107–1113 | // getOwner/runWithOwner |
| 33 | `badUnnamedDerivedSignal` |  | 1114–1122 |  |
| 34 | `untrackedReactive`, `badUnnamedDerivedSignal` |  | 1126–1136 | // the conditional look-through (#235) only applies to object property // values; a conditionally-assigned variable is still an unnamed derived // signal, and the condition itself is still an untracked read |
| 35 | `badUnnamedDerivedSignal` |  | 1138–1148 | // a `dynamic` not imported from Solid is not a tracked scope |
| 36 | `noAsyncTrackedScope` |  | 1150–1158 | // Async tracking scopes |
| 37 | `noAsyncTrackedScope` |  | 1159–1167 |  |
| 38 | `badSignal` |  | 1169–1174 | // non-function expression inside tagged template literal expression is not tracked scope |
| 39 | `badSignal` |  | 1175–1181 |  |
| 40 | `untrackedReactive` |  | 1183–1193 | // mapArray |
| 41 | `untrackedReactive` |  | 1194–1201 |  |
| 42 | `untrackedReactive` |  | 1202–1209 |  |
| 43 | `untrackedReactive` |  | 1211–1216 | // static* prefix for props |
| 44 | `untrackedReactive` |  | 1218–1223 | // custom hooks |
| 45 | `untrackedReactive` |  | 1224–1229 |  |
| 46 | `untrackedReactive` |  | 1230–1235 |  |
| 47 | `expectedFunctionGotExpression` |  | 1236–1241 |  |
| 48 | `untrackedReactive` |  | 1244–1252 | // === Solid 2.0 APIs === // merge/omit results are reactive like mergeProps/splitProps |
| 49 | `untrackedReactive` |  | 1253–1261 |  |
| 50 | `untrackedReactive` |  | 1263–1271 | // createProjection returns a reactive store |
| 51 | `untrackedReactive` |  | 1273–1281 | // createOptimistic returns a signal pair |
| 52 | `untrackedReactive` |  | 1283–1291 | // createOptimisticStore returns a store pair |
| 53 | `readAfterAwait` |  | 1294–1302 | // === reads after suspension in async computations === // signal read after await in an async memo is not tracked |
| 54 | `readAfterAwait` |  | 1304–1314 | // props read after await is not tracked |
| 55 | `readAfterAwait` |  | 1316–1326 | // dynamic's async source does not track reads after await |
| 56 | `readAfterAwait` |  | 1328–1336 | // function-form createSignal with a read after await |
| 57 | `readAfterAwait` |  | 1340–1352 | // a loop containing an await taints the whole loop body (later iterations // read after the previous iteration's suspension), but not the iterated // expression, which is evaluated once up front |
| 58 | `staleCapture` |  | 1355–1363 | // Stale captures: signal read at setup, value captured by a variable a // returned function reads — the capture never updates (#213) |
| 59 | `staleCapture` |  | 1365–1373 | // Derived-through-expression capture is just as stale |
| 60 | `staleCapture` |  | 1375–1383 | // Functions embedded in returned JSX escape the same way |
| 61 | `staleCapture` |  | 1385–1393 | // Implicit arrow return escapes too |
| 62 | `noAsyncTrackedScope` |  | 1395–1400 | // createResource(source, fetcher): the source is still a sync tracked scope |
| 63 | `untrackedReactive` |  | 1402–1409 | // destructuring props outside a tracked scope still snapshots values |

### 2c. Cases grouped by messageId (code verbatim)

#### `untrackedReactive`

**Case 1** — lines 715–723

<!-- // Untracked signals -->
```js
    {
      code: `
      const Component = () => {
        const [signal] = createSignal(5);
        console.log(signal());
        return null;
      }`,
      errors: [{ messageId: "untrackedReactive", line: 4 }],
    },
```

**Case 2** — lines 724–732

```js
    {
      code: `
      const Component = () => {
        const [signal] = createSignal(5);
        console.log(signal());
        return <div>{signal()}</div>
      }`,
      errors: [{ messageId: "untrackedReactive", line: 4 }],
    },
```

**Case 3** — lines 734–741

<!-- // Untracked property access -->
```js
    {
      code: `
      const Component = props => {
        const value = props.value;
        return <div>{value()}</div>;
      }`,
      errors: [{ messageId: "untrackedReactive" }],
    },
```

**Case 4** — lines 744–754

<!-- // settings.solid.moduleSources registers custom renderers/re-export -->
<!-- // wrappers as Solid primitive sources (#183) -->
```js
    {
      code: `
      import { createSignal } from "my-solid-renderer";
      const Component = () => {
        const [count] = createSignal(0);
        const doubled = count() * 2;
        return <div>{doubled}</div>;
      };`,
      settings: { solid: { moduleSources: ["my-solid-renderer"] } },
      errors: [{ messageId: "untrackedReactive" }],
    },
```

**Case 5** — lines 755–763

```js
    {
      code: `
      const Component = props => {
        const { value: valueProp } = props;
        const value = createMemo(() => valueProp || "default");
        return <div>{value()}</div>;
      };`,
      errors: [{ messageId: "untrackedReactive", line: 3, column: 38, endColumn: 43 }],
    },
```

**Case 6** — lines 764–777

```js
    {
      code: `
      const Component = props => {
        const valueProp = props.value;
        const value = createMemo(() => valueProp || "default");
        return <div>{value()}</div>;
      };`,
      errors: [
        {
          messageId: "untrackedReactive",
          data: { name: "props.value" },
        },
      ],
    },
```

**Case 7** — lines 778–784

```js
    {
      code: `
      const Component = props => {
        const [value] = createSignal(props.value);
      }`,
      errors: [{ messageId: "untrackedReactive" }],
    },
```

**Case 8** — lines 786–799

<!-- // mark `props` as props by name before we've determined if Component is a component in :exit -->
```js
    {
      code: `
      const Component = props => {
        const derived = () => props.value;
        const oops = derived();
        return <div>{oops}</div>;
      }`,
      errors: [
        {
          messageId: "untrackedReactive",
          data: { name: "derived" },
        },
      ],
    },
```

**Case 9** — lines 801–808

<!-- // treat first parameter of uppercase function with JSX as a props -->
```js
    {
      code: `
      function Component(something) {
        console.log(something.a);
        return <div />;
      }`,
      errors: [{ messageId: "untrackedReactive" }],
    },
```

**Case 10** — lines 810–825

<!-- // Derived signals -->
```js
    {
      code: `
      const Component = () => {
        const [signal] = createSignal();
        const d = () => { // <-- d becomes a derived signal
          signal();
        }
        d(); // not ok
      }`,
      errors: [
        {
          messageId: "untrackedReactive",
          data: { name: "d" },
        },
      ],
    },
```

**Case 11** — lines 826–841

```js
    {
      code: `
      const Component = () => {
        const [signal] = createSignal();
        function d() { // <-- d becomes a derived signal
          signal();
        }
        d(); // not ok
      }`,
      errors: [
        {
          messageId: "untrackedReactive",
          data: { name: "d" },
        },
      ],
    },
```

**Case 12** — lines 842–860

```js
    {
      code: `
      const Component = () => {
        const [signal] = createSignal();
        const d = () => { // <-- d becomes a derived signal
          const e = () => { // <-- e becomes a derived signal
            signal();
          }
          e();
        }
        d(); // not ok
      }`,
      errors: [
        {
          messageId: "untrackedReactive",
          data: { name: "d" },
        },
      ],
    },
```

**Case 13** — lines 861–880

```js
    {
      code: `
      const Component = () => {
        const [signal1] = createSignal();
        const d = () => { // <-- d becomes a derived signal
          const [signal2] = createSignal();
          const e = () => { // <-- e becomes a derived signal
            signal1();
            signal2();
          }
          e(); // not ok, signal2 is in scope
        }
      }`,
      errors: [
        {
          messageId: "untrackedReactive",
          data: { name: "e" },
        },
      ],
    },
```

**Case 14** — lines 881–899

```js
    {
      code: `
      const Component = () => {
        const [signal] = createSignal();
        const foo = () => { // foo becomes a derived signal
          signal();
        }
        const bar = () => { // bar becomes a derived signal
          foo();
        }
        bar(); // not ok
      }`,
      errors: [
        {
          messageId: "untrackedReactive",
          data: { name: "bar" },
        },
      ],
    },
```

**Case 34** — lines 1126–1136 (also errors: badUnnamedDerivedSignal)

<!-- // the conditional look-through (#235) only applies to object property -->
<!-- // values; a conditionally-assigned variable is still an unnamed derived -->
<!-- // signal, and the condition itself is still an untracked read -->
```js
    {
      code: `
      function Component(props) {
        const style = props.big ? () => ({ fontSize: props.size }) : undefined;
        return <div style={style && style()} />;
      }`,
      errors: [
        { messageId: "untrackedReactive", line: 3 },
        { messageId: "badUnnamedDerivedSignal", line: 3 },
      ],
    },
```

**Case 40** — lines 1183–1193

<!-- // mapArray -->
```js
    {
      code: `
      function createCustomStore() {
        const [store, updateStore] = createStore({});
        return mapArray(
          [],
          (item) => store.path.to.field
        );
      }`,
      errors: [{ messageId: "untrackedReactive" }],
    },
```

**Case 41** — lines 1194–1201

```js
    {
      code: `
      const [array] = createSignal([]);
      const result = mapArray(array, (item, i) => {
        i()
      });`,
      errors: [{ messageId: "untrackedReactive", line: 4 }],
    },
```

**Case 42** — lines 1202–1209

```js
    {
      code: `
      const [array] = createSignal([]);
      const result = indexArray(array, (item) => {
        item()
      });`,
      errors: [{ messageId: "untrackedReactive", line: 4 }],
    },
```

**Case 43** — lines 1211–1216

<!-- // static* prefix for props -->
```js
    {
      code: `
      const [signal] = createSignal();
      let el = <Component staticProp={signal()} />;`,
      errors: [{ messageId: "untrackedReactive" }],
    },
```

**Case 44** — lines 1218–1223

<!-- // custom hooks -->
```js
    {
      code: `
      const [signal] = createSignal(0);
      useExample(signal())`,
      errors: [{ messageId: "untrackedReactive" }],
    },
```

**Case 45** — lines 1224–1229

```js
    {
      code: `
      const [signal] = createSignal(0);
      useExample([signal()])`,
      errors: [{ messageId: "untrackedReactive" }],
    },
```

**Case 46** — lines 1230–1235

```js
    {
      code: `
      const [signal] = createSignal(0);
      useExample({ value: signal() })`,
      errors: [{ messageId: "untrackedReactive" }],
    },
```

**Case 48** — lines 1244–1252

<!-- // === Solid 2.0 APIs === -->
<!-- // merge/omit results are reactive like mergeProps/splitProps -->
```js
    {
      code: `
      const Component = _props => {
        const props = merge({ value: "default" }, _props);
        const value = props.value;
        return <div>{value}</div>;
      };`,
      errors: [{ messageId: "untrackedReactive", line: 4 }],
    },
```

**Case 49** — lines 1253–1261

```js
    {
      code: `
      const Component = props => {
        const rest = omit(props, "value");
        console.log(rest.other);
        return null;
      };`,
      errors: [{ messageId: "untrackedReactive", line: 4 }],
    },
```

**Case 50** — lines 1263–1271

<!-- // createProjection returns a reactive store -->
```js
    {
      code: `
      const Component = () => {
        const projected = createProjection(draft => {});
        console.log(projected.value);
        return null;
      };`,
      errors: [{ messageId: "untrackedReactive", line: 4 }],
    },
```

**Case 51** — lines 1273–1281

<!-- // createOptimistic returns a signal pair -->
```js
    {
      code: `
      const Component = () => {
        const [value, setValue] = createOptimistic(0);
        console.log(value());
        return null;
      };`,
      errors: [{ messageId: "untrackedReactive", line: 4 }],
    },
```

**Case 52** — lines 1283–1291

<!-- // createOptimisticStore returns a store pair -->
```js
    {
      code: `
      const Component = () => {
        const [state, setState] = createOptimisticStore({});
        console.log(state.value);
        return null;
      };`,
      errors: [{ messageId: "untrackedReactive", line: 4 }],
    },
```

**Case 63** — lines 1402–1409

<!-- // destructuring props outside a tracked scope still snapshots values -->
```js
    {
      code: `
      function Component(props) {
        const { item } = props;
        return <div>{item}</div>;
      }`,
      errors: [{ messageId: "untrackedReactive", line: 3 }],
    },
```

#### `shouldDestructure`

**Case 15** — lines 901–912

<!-- // Unused reactives -->
```js
    {
      code: `
      const Component = () => {
        createSignal();
      }`,
      errors: [
        {
          messageId: "shouldDestructure",
          data: { nth: "first " },
        },
      ],
    },
```

**Case 16** — lines 913–924

```js
    {
      code: `
      const Component = () => {
        const [, setSignal] = createSignal();
      }`,
      errors: [
        {
          messageId: "shouldDestructure",
          data: { nth: "first " },
        },
      ],
    },
```

**Case 17** — lines 925–936

```js
    {
      code: `
      const Component = () => {
        const {2: signal, 3: setSignal} = createSignal();
      }`,
      errors: [
        {
          messageId: "shouldDestructure",
          data: { nth: "first " },
        },
      ],
    },
```

#### `shouldAssign`

**Case 18** — lines 937–947

```js
    {
      code: `
      const Component = () => {
        createMemo(() => 5);
      }`,
      errors: [
        {
          messageId: "shouldAssign",
        },
      ],
    },
```

#### `badSignal`

**Case 19** — lines 949–962

<!-- // Uncalled signals -->
```js
    {
      code: `
      const Component = () => {
        const [signal] = createSignal();
        return <div>{signal}</div>
      }`,
      errors: [
        {
          messageId: "badSignal",
          line: 4,
          data: { name: "signal", where: "JSX" },
        },
      ],
    },
```

**Case 20** — lines 963–976

```js
    {
      code: `
      const Component = () => {
        const memo = createMemo(() => 5);
        return <div>{memo}</div>
      }`,
      errors: [
        {
          messageId: "badSignal",
          line: 4,
          data: { name: "memo", where: "JSX" },
        },
      ],
    },
```

**Case 21** — lines 977–990

```js
    {
      code: `
      const Component = () => {
        const [signal] = createSignal();
        return <button type={signal}>Button</button>
      }`,
      errors: [
        {
          messageId: "badSignal",
          line: 4,
          data: { name: "signal", where: "JSX" },
        },
      ],
    },
```

**Case 22** — lines 991–1004

```js
    {
      code: `
      const Component = () => {
        const [signal] = createSignal("world");
        const memo = createMemo(() => "hello " + signal)
      }`,
      errors: [
        {
          messageId: "badSignal",
          line: 4,
          data: { name: "signal", where: "arithmetic or comparisons" },
        },
      ],
    },
```

**Case 23** — lines 1005–1018

```js
    {
      code: `
      const Component = () => {
        const [signal] = createSignal("world");
        const memo = createMemo(() => \`hello \${signal}\`)
      }`,
      errors: [
        {
          messageId: "badSignal",
          line: 4,
          data: { name: "signal", where: "template literals" },
        },
      ],
    },
```

**Case 24** — lines 1019–1032

```js
    {
      code: `
      const Component = () => {
        const [signal] = createSignal(5);
        const memo = createMemo(() => -signal)
      }`,
      errors: [
        {
          messageId: "badSignal",
          line: 4,
          data: { name: "signal", where: "unary expressions" },
        },
      ],
    },
```

**Case 25** — lines 1033–1046

```js
    {
      code: `
      const Component = (props) => {
        const [signal] = createSignal(5);
        const memo = createMemo(() => props.array[signal])
      }`,
      errors: [
        {
          messageId: "badSignal",
          line: 4,
          data: { name: "signal", where: "property accesses" },
        },
      ],
    },
```

**Case 38** — lines 1169–1174

<!-- // non-function expression inside tagged template literal expression is not tracked scope -->
```js
    {
      code: `
      const [signal] = createSignal("red");
      css\`color: \${signal}\`;`,
      errors: [{ messageId: "badSignal", line: 3 }],
    },
```

**Case 39** — lines 1175–1181

```js
    {
      code: `
      const [signal] = createSignal("red");
      const f = () => signal();
      css\`color: \${f}\`;`,
      errors: [{ messageId: "badSignal", line: 4 }],
    },
```

#### `expectedFunctionGotExpression`

**Case 26** — lines 1048–1060

<!-- // event listeners are not rebound on native elements -->
```js
    {
      code: `
      const Component = props => {
        return <div onClick={props.onClick} />;
      }`,
      errors: [
        {
          messageId: "expectedFunctionGotExpression",
          line: 3,
          data: { name: "props.onClick" },
        },
      ],
    },
```

**Case 27** — lines 1061–1073

```js
    {
      code: `
      const Component = props => {
        createEffect(props.theEffect);
      }`,
      errors: [
        {
          messageId: "expectedFunctionGotExpression",
          line: 3,
          data: { name: "props.theEffect" },
        },
      ],
    },
```

**Case 47** — lines 1236–1241

```js
    {
      code: `
      const [signal] = createSignal(0);
      useExample((() => signal())())`,
      errors: [{ messageId: "expectedFunctionGotExpression" }],
    },
```

#### `providerValue`

**Case 28** — lines 1075–1081

<!-- // provider value passed as-is -->
```js
    {
      code: `
      const Component = props => {
        return <SomeContext.Provider value={props.value}>{props.children}</SomeContext.Provider>;
      }`,
      errors: [{ messageId: "providerValue", data: { name: "props.value" } }],
    },
```

**Case 29** — lines 1082–1088

```js
    {
      code: `
      const Component = props => {
        return <SomeProvider value={props.value}>{props.children}</SomeProvider>;
      }`,
      errors: [{ messageId: "providerValue", data: { name: "props.value" } }],
    },
```

**Case 30** — lines 1089–1096

```js
    {
      code: `
      const Component = props => {
        const [signal] = createSignal();
        return <SomeContext.Provider value={signal()} someOtherProp={props.foo}>{props.children}</SomeContext.Provider>;
      }`,
      errors: [{ messageId: "providerValue", data: { name: "signal" } }],
    },
```

**Case 31** — lines 1098–1105

<!-- // Solid 2.0: the context object itself is the provider -->
```js
    {
      code: `
      const MyContext = createContext();
      const Component = props => {
        return <MyContext value={props.value}>{props.children}</MyContext>;
      }`,
      errors: [{ messageId: "providerValue", data: { name: "props.value" } }],
    },
```

#### `badUnnamedDerivedSignal`

**Case 32** — lines 1107–1113

<!-- // getOwner/runWithOwner -->
```js
    {
      code: `
      const owner = getOwner();
      const [signal] = createSignal();
      createEffect(() => runWithOwner(owner, () => console.log(signal())));`,
      errors: [{ messageId: "badUnnamedDerivedSignal", line: 4 }],
    },
```

**Case 33** — lines 1114–1122

```js
    {
      code: `
      function Component() {
        const owner = getOwner();
        const [signal] = createSignal();
        createEffect(() => runWithOwner(owner, () => console.log(signal())));
      }`,
      errors: [{ messageId: "badUnnamedDerivedSignal", line: 5 }],
    },
```

**Case 35** — lines 1138–1148

<!-- // a `dynamic` not imported from Solid is not a tracked scope -->
```js
    {
      code: `
      import { createSignal } from "solid-js";
      import { dynamic } from "some-lib";
      function Component() {
        const [count, setCount] = createSignal(0);
        const Test = dynamic(() => test(count()));
        return <Test />;
      }`,
      errors: [{ messageId: "badUnnamedDerivedSignal", line: 6 }],
    },
```

#### `noAsyncTrackedScope`

**Case 36** — lines 1150–1158

<!-- // Async tracking scopes -->
```js
    {
      code: `
      const [count, setCount] = createSignal(0);
      createEffect(async () => {
        await Promise.resolve();
        console.log(count());
      });`,
      errors: [{ messageId: "noAsyncTrackedScope", line: 3 }],
    },
```

**Case 37** — lines 1159–1167

```js
    {
      code: `
      const [photos, setPhotos] = createSignal([]);
      createEffect(async () => {
        const res = await fetch("https://jsonplaceholder.typicode.com/photos?_limit=20");
        setPhotos(await res.json());
      });`,
      errors: [{ messageId: "noAsyncTrackedScope", line: 3 }],
    },
```

**Case 62** — lines 1395–1400

<!-- // createResource(source, fetcher): the source is still a sync tracked scope -->
```js
    {
      code: `
      const [id, setId] = createSignal(1);
      const [data] = createResource(async () => id(), async (v) => fetch("/api/" + v));`,
      errors: [{ messageId: "noAsyncTrackedScope", line: 3 }],
    },
```

#### `readAfterAwait`

**Case 53** — lines 1294–1302

<!-- // === reads after suspension in async computations === -->
<!-- // signal read after await in an async memo is not tracked -->
```js
    {
      code: `
      const [id, setId] = createSignal(1);
      const user = createMemo(async () => {
        const response = await fetch("/api/users");
        return response.json() + id();
      });`,
      errors: [{ messageId: "readAfterAwait", line: 5 }],
    },
```

**Case 54** — lines 1304–1314

<!-- // props read after await is not tracked -->
```js
    {
      code: `
      function Component(props) {
        const data = createMemo(async () => {
          const response = await fetch("/api");
          return response.json() + props.suffix;
        });
        return <div>{data()}</div>;
      }`,
      errors: [{ messageId: "readAfterAwait", line: 5 }],
    },
```

**Case 55** — lines 1316–1326

<!-- // dynamic's async source does not track reads after await -->
```js
    {
      code: `
      import { createSignal } from "solid-js";
      import { dynamic } from "@solidjs/web";
      const [count, setCount] = createSignal(1);
      const Test = dynamic(async () => {
        await tick();
        return test(count());
      });`,
      errors: [{ messageId: "readAfterAwait", line: 7 }],
    },
```

**Case 56** — lines 1328–1336

<!-- // function-form createSignal with a read after await -->
```js
    {
      code: `
      const [count, setCount] = createSignal(1);
      const [derived, setDerived] = createSignal(async () => {
        await tick();
        return count() * 2;
      });`,
      errors: [{ messageId: "readAfterAwait", line: 5 }],
    },
```

**Case 57** — lines 1340–1352

<!-- // a loop containing an await taints the whole loop body (later iterations -->
<!-- // read after the previous iteration's suspension), but not the iterated -->
<!-- // expression, which is evaluated once up front -->
```js
    {
      code: `
      const [urls, setUrls] = createSignal([]);
      const [weight, setWeight] = createSignal(1);
      const total = createMemo(async () => {
        let sum = 0;
        for (const url of urls()) {
          sum += (await fetch(url)).size * weight();
        }
        return sum;
      });`,
      errors: [{ messageId: "readAfterAwait", line: 7 }],
    },
```

#### `staleCapture`

**Case 58** — lines 1355–1363

<!-- // Stale captures: signal read at setup, value captured by a variable a -->
<!-- // returned function reads — the capture never updates (#213) -->
```js
    {
      code: `
      const [items, setItems] = createSignal([]);
      function useCartTotal() {
        const list = items();
        return () => list.reduce((sum, item) => sum + item.price, 0);
      }`,
      errors: [{ messageId: "staleCapture", line: 4 }],
    },
```

**Case 59** — lines 1365–1373

<!-- // Derived-through-expression capture is just as stale -->
```js
    {
      code: `
      const [items, setItems] = createSignal([]);
      function useCount() {
        const total = items().length;
        return () => total;
      }`,
      errors: [{ messageId: "staleCapture", line: 4 }],
    },
```

**Case 60** — lines 1375–1383

<!-- // Functions embedded in returned JSX escape the same way -->
```js
    {
      code: `
      const [theme, setTheme] = createSignal("dark");
      function Component() {
        const current = theme();
        return <button onClick={() => console.log(current)}>theme</button>;
      }`,
      errors: [{ messageId: "staleCapture", line: 4 }],
    },
```

**Case 61** — lines 1385–1393

<!-- // Implicit arrow return escapes too -->
```js
    {
      code: `
      const [count, setCount] = createSignal(0);
      function useStale() {
        const value = count();
        return () => value + 1;
      }`,
      errors: [{ messageId: "staleCapture", line: 4 }],
    },
```

## 3. Non-reports (valid cases, verbatim)

Source: `test/rules/reactivity.test.ts`, `valid:` array, raw lines 6–711. Grouped by the source comment that precedes each run of cases (the comment is the upstream reason).

### 3.1 no source comment

```js
    `function MyComponent(props) {
      return <div>Hello {props.name}</div>;
    }
    let el = <MyComponent name="Solid" />;`,

    `const [first, setFirst] = createSignal("JSON");
    const [last, setLast] = createSignal("Bourne");
    createEffect(() => console.log(\`\${first()} \${last()}\`));`,
    `let Component = props => {
      return <div>{props.value || "default"}</div>;
    };`,
    `let Component = props => {
      const value = () => props.value || "default";
      return <div>{value()}</div>;
    };`,
    `let Component = props => {
      const value = createMemo(() => props.value || "default");
      return <div>{value()}</div>;
    };`,
    `let Component = _props => {
      const props = mergeProps({ value: "default" }, _props);
      return <div>{props.value}</div>;
    };`,
    `let Component = _props => {
      const [foo, bar, baz] = splitProps(_props, ["foo"], ["bar"]);
      return <div>{foo.foo} {bar.bar} {baz.baz}</div>;
    }`,
    `let Component = () => {
      const [a, setA] = createSignal(1);
      const [b, setB] = createSignal(1);
      createEffect(() => {
        console.log(a(), untrack(b));
      });
    }`,
    `function Component(props) {
      const [value, setValue] = createSignal();
      return <div class={props.class}>{value()}</div>;
    }`,
    `function Component(props) {
      const [value, setValue] = createSignal();
      createEffect(() => console.log(value()));
      return <div class={props.class}>{value()}</div>;
    }`,
    `const [value, setValue] = createSignal();
    on(value, () => console.log('hello'));`,
    `const [value, setValue] = createSignal();
    on([value], () => console.log('hello'));`,
```

### 3.2 spreading props

```js
    // spreading props
    `function Component(props) {
      return <div {...props} />;
    }`,
    `function Component(props) {
      return <div {...props.nestedProps} />;
    }`,
    `function Component() {
      const [signal, setSignal] = createSignal({});
      return <div {...signal()} />;
    }`,
```

### 3.3 Derived signals

```js
    // Derived signals
    `let c = () => {
      const [signal] = createSignal();
      const d = () => {
        function e() { // <-- e becomes a derived signal
          signal();
        }
      } // <-- d never uses it
      d(); // <-- this is fine
    };`,
    `const [signal] = createSignal();
    createEffect(() => console.log(signal()));`,
    `const [signal] = createSignal();
    const memo = createMemo(() => signal());`,
    `const el = <button onClick={() => toggleShow(!show())}>
      {show() ? "Hide" : "Show"}
    </button>`,
    `const [count] = createSignal();
    createEffect(() => {
      (() => count())()
    })`,
    `const [count] = createSignal();
    const el = <div>{(() => count())()}</div>`,
    `const [count, setCount] = createSignal();
    const el = <button type="button" onClick={() => setCount(count() + 1)}>Increment</button>;`,
```

### 3.4 Parse top level JSX

```js
    // Parse top level JSX
    `const el = <div />`,
```

### 3.5 getOwner/runWithOwner

```js
    // getOwner/runWithOwner
    `const [signal] = createSignal();
    createEffect(() => {
      const owner = getOwner();
      runWithOwner(owner, () => console.log(signal()));
    });`,
    `const [signal] = createSignal();
    createEffect(() => {
      runWithOwner(undefined, () => console.log(signal()));
    });`,
```

### 3.6 Sync callbacks

```js
    // Sync callbacks
    `const [signal] = createSignal();
    createEffect(() => {
      [1, 2].forEach(() => console.log(signal()));
    });`,
    `function Component(props) {
      createEffect(() => {
        [1, 2].forEach(() => console.log(props.foo));
      });
      return <div />;
    }`,
    `function Component(bleargh /* doesn't match props regex */) {
      createEffect(() => {
        [1, 2].forEach(() => console.log(bleargh.foo));
      });
      return <div />;
    }`,
```

### 3.7 Timers

```js
    // Timers
    `const [signal] = createSignal(5);
    setTimeout(() => console.log(signal()), 500);
    setInterval(() => console.log(signal()), 600);
    setImmediate(() => console.log(signal()));
    requestAnimationFrame(() => console.log(signal()));
    requestIdleCallback(() => console.log(signal()));`,
```

### 3.8 Observers from Standard Web APIs

```js
    // Observers from Standard Web APIs
    `const [signal] = createSignal(5);
    new IntersectionObserver(() => console.log(signal()));
    new MutationObserver(() => console.log(signal()));
    new PerformanceObserver(() => console.log(signal()));
    new ReportingObserver(() => console.log(signal()));
    new ResizeObserver(() => console.log(signal()));`,
```

### 3.9 Async tracking scope exceptions

```js
    // Async tracking scope exceptions
    `const [photos, setPhotos] = createSignal([]);
    onMount(async () => {
      const res = await fetch("https://jsonplaceholder.typicode.com/photos?_limit=20");
      setPhotos(await res.json());
    });`,
    `const [a, setA] = createSignal(1);
    const [b] = createSignal(2);
    on(b, async () => { await delay(1000); setA(a() + 1) });`,
```

### 3.10 Custom hooks

```js
    // Custom hooks
    `const Component = (props) => {
      const localRef = () => props.ref;
      const composedRef1 = useComposedRefs(localRef);
      const composedRef2 = useComposedRefs(() => props.ref);
      const composedRef3 = createComposedRefs(localRef);
    }`,
    `function createFoo(v) {}
    const [bar, setBar] = createSignal();
    createFoo({ onBar: () => bar() });`,
    `function createFoo(v) {}
    const [bar, setBar] = createSignal();
    createFoo({ onBar() { bar() } });`,
    `function createFoo(v) {}
    const [bar, setBar] = createSignal();
    createFoo(bar);`,
    `function createFoo(v) {}
    const [bar, setBar] = createSignal();
    createFoo([bar]);`,
    {
      code: `function createFoo(v) {}
      const [bar, setBar] = createSignal();
      createFoo({ onBar: () => bar() } as object);`,
      [tsOnly]: true,
    },
    `const [bar, setBar] = createSignal();
    X.createFoo(() => bar());`,
    `const [bar, setBar] = createSignal();
    X . Y\n. createFoo(() => bar());`,
    {
      code: `function customQuery(v) {}
      const [signal, setSignal] = createSignal();
      customQuery(() => signal());`,
      options: [{ customReactiveFunctions: ["customQuery"] }], // only needed when not create*/use*
    },
```

### 3.11 customReactiveFunctions supports '*' wildcards and '/regex/' strings (#176)

```js
    // customReactiveFunctions supports '*' wildcards and '/regex/' strings (#176)
    {
      code: `function watchQuery(v) {}
      const [signal, setSignal] = createSignal();
      watchQuery(() => signal());`,
      options: [{ customReactiveFunctions: ["watch*"] }],
    },
    {
      code: `function watchQuery(v) {}
      const [signal, setSignal] = createSignal();
      watchQuery(() => signal());`,
      options: [{ customReactiveFunctions: ["/^watch[A-Z]/"] }],
    },
```

### 3.12 destructuring props inside a tracked scope re-runs on updates (#191)

```js
    // destructuring props inside a tracked scope re-runs on updates (#191)
    `function Component(props) {
      const value = createMemo(() => {
        const { item } = props;
        return item;
      });
      return <div>{value()}</div>;
    }`,
    `function Component(props) {
      createEffect(() => {
        const { onChange } = props;
        onChange();
      });
      return <div />;
    }`,
```

### 3.13 createResource(fetcher) and createResource(fetcher, options) have no source; the fetcher is not a tracked scope and may be async (#199)

```js
    // createResource(fetcher) and createResource(fetcher, options) have no source;
    // the fetcher is not a tracked scope and may be async (#199)
    `const [data] = createResource(async () => {
      const res = await fetch("/api");
      return res.json();
    });`,
    `const [data] = createResource(async () => {
      const res = await fetch("/api");
      return res.json();
    }, { initialValue: [] });`,
```

### 3.14 createResource(source, fetcher): the fetcher receives the source's value, is not tracked, and may be async (#195)

```js
    // createResource(source, fetcher): the fetcher receives the source's value,
    // is not tracked, and may be async (#195)
    `function Component(props) {
      const [data] = createResource(() => props.id, async (id) => {
        const res = await fetch("/api/" + id);
        return res.json();
      });
      return <div>{data()}</div>;
    }`,
```

### 3.15 window/globalThis-prefixed timers behave like the bare globals (#194)

```js
    // window/globalThis-prefixed timers behave like the bare globals (#194)
    `function Component() {
      const [count, setCount] = createSignal(0);
      window.setTimeout(() => console.log(count()), 500);
      globalThis.setInterval(() => console.log(count()), 500);
      return <div />;
    }`,
```

### 3.16 promise callbacks run later and poll current values, like timer callbacks or code after an await (#235)

```js
    // promise callbacks run later and poll current values, like timer
    // callbacks or code after an await (#235)
    `function Saver(props) {
      const commit = () => props.onSaved && props.onSaved();
      const saveThen = () => {
        save().then(() => commit());
      };
      const saveCatch = () => {
        save().catch(() => commit());
      };
      const saveFinally = () => {
        save().finally(() => commit());
      };
      return <>
        <button onClick={saveThen}>then</button>
        <button onClick={saveCatch}>catch</button>
        <button onClick={saveFinally}>finally</button>
      </>;
    }`,
```

### 3.17 named callbacks and two-argument then get the same treatment (#235)

```js
    // named callbacks and two-argument then get the same treatment (#235)
    `function Component(props) {
      const commit = () => props.onDone && props.onDone();
      const start = () => {
        load().then(commit, commit);
      };
      return <button onClick={start} />;
    }`,
```

### 3.18 optional callback properties wrapped in a conditional or logical expression classify like the unconditional property form (#235)

```js
    // optional callback properties wrapped in a conditional or logical
    // expression classify like the unconditional property form (#235)
    `function Draggable(props) {
      const options = createMemo(() => ({
        onDrag: props.onDrag ? (e) => props.onDrag(e) : undefined,
        onDragEnd: props.onDragEnd && ((e) => props.onDragEnd(e)),
        onDragStart: (e) => props.onDragStart(e),
      }));
      return <div data-draggable={!!options().onDrag} />;
    }`,
```

### 3.19 mergeProps wraps function sources in createMemo, so they are tracked (#179)

```js
    // mergeProps wraps function sources in createMemo, so they are tracked (#179)
    `function Component(props) {
      const [dynamic, setDynamic] = createSignal({});
      const merged = mergeProps({ start: 0 }, () => ({ end: props.end, ...dynamic() }));
      return <div>{merged.end}</div>;
    }`,
```

### 3.20 a memo passed to a function is as safe as passing a signal (#182)

```js
    // a memo passed to a function is as safe as passing a signal (#182)
    `const [count, setCount] = createSignal(0);
    const double = createMemo(() => count() * 2);
    createCounter(double);`,
```

### 3.21 directly-returned create* calls hand their result to the caller (#52)

```js
    // directly-returned create* calls hand their result to the caller (#52)
    `function createDouble(count) {
      return createMemo(() => count() * 2);
    }`,
    `const wrap = (fn) => createMemo(fn);`,
```

### 3.22 functions passed to unknown calls inside a tracked scope either run synchronously (still tracked) or poll current values later (#197)

```js
    // functions passed to unknown calls inside a tracked scope either run
    // synchronously (still tracked) or poll current values later (#197)
    `function Component(props) {
      createEffect(() => {
        doSomething(() => props.toggle);
      });
      return <div />;
    }`,
```

### 3.23 Event listeners

```js
    // Event listeners
    `const [signal, setSignal] = createSignal(1);
    const element = document.getElementById("id");
    element.addEventListener("click", () => {
      console.log(signal());
    }, { once: true });`,
    `const {0: signal, 1: setSignal} = createSignal(1);
    const element = document.getElementById("id");
    element.onclick = () => {
      console.log(signal());
    };`,
    `const {'0': signal, '1': setSignal} = createSignal(1);
    const element = document.getElementById("id");
    element.onclick = () => {
      console.log(signal());
    };`,
    `const [signal, setSignal] = createSignal(1);
    const element = document.getElementById("id");
    element.onclick = () => {
      console.log(signal());
    };`,
    `function Component() {
      const [signal, setSignal] = createSignal(1);
      return <div onClick={() => console.log(signal())} />;
    }`,
    `function Component() {
      const [signal, setSignal] = createSignal(1);
      const handler = () => console.log(signal());
      return <div onClick={handler} />;
    }`,
    `function Component() {
      const [signal, setSignal] = createSignal(1);
      return <div onClick={signal} />;
    }`,
    `function Component() {
      const [signal, setSignal] = createSignal(1);
      return <div on:click={() => console.log(signal())} />;
    }`,
    `function Component(props) {
      return <div onClick={e => props.onClick(e)} />;
    }`,
```

### 3.24 event listeners are reactive on components

```js
    // event listeners are reactive on components
    `const Parent = props => {
      return <Child onClick={props.onClick} />;
    }`,
    `const Parent = props => {
      return <Child onClick={e => props.onClick(e)} />;
    }`,
```

### 3.25 Pass reactive variables as-is into provider value prop

```js
    // Pass reactive variables as-is into provider value prop
    `const Component = props => {
      const [signal] = createSignal();
      return <SomeContext.Provider value={signal}>{props.children}</SomeContext.Provider>;
    }`,
```

### 3.26 Don't warn on using props.initial* or props.default* for initialization

```js
    // Don't warn on using props.initial* or props.default* for initialization
    `function Component(props) {
      const [count, setCount] = useSignal(props.initialCount);
      return <div>{count()}</div>;
    }`,
    `function Component(props) {
      const {0: count, 1: setCount} = useSignal(props.initialCount);
      return <div>{count()}</div>;
    }`,
    `function Component(props) {
      const [count, setCount] = useSignal(props.defaultCount);
      return <div>{count()}</div>;
    }`,
```

### 3.27 Store getters

```js
    // Store getters
    `const [state, setState] = createStore({
      firstName: 'Will',
      lastName: 'Smith',
      get fullName() {
        return state.firstName + " " + state.lastName;
      }
    });`,
    `const {0: state, 1: setState} = createStore({
      firstName: 'Will',
      lastName: 'Smith',
      get fullName() {
        return state.firstName + " " + state.lastName;
      }
    });`,
```

### 3.28 untrack()

```js
    // untrack()
    `const [signal] = createSignal(5);
    untrack(() => {
      console.log(signal());
    });`,
```

### 3.29 untrack's callback is explicitly NOT tracked, so async is harmless and reads after await lose nothing (#188)

```js
    // untrack's callback is explicitly NOT tracked, so async is harmless and
    // reads after await lose nothing (#188)
    `const [value, setValue] = createSignal();
    untrack(async () => {
      const result = await loadData();
      setValue(result);
      console.log(value());
    });`,
```

### 3.30 stashing a store proxy on an object stores a reference, not a snapshot; reads through it are reactive at read time (#184)

```js
    // stashing a store proxy on an object stores a reference, not a snapshot;
    // reads through it are reactive at read time (#184)
    `class UIStore {
      constructor() {
        const [state, setState] = createStore({ init: false });
        this.state = state;
        this.setState = setState;
      }
    }`,
```

### 3.31 wrappers pass the tuple through: analyze the primitive as if assigned to the wrapper's result (#190)

```js
    // wrappers pass the tuple through: analyze the primitive as if assigned to
    // the wrapper's result (#190)
    `const Component = () => {
      const [state, setState] = makePersisted(createSignal(false));
      return <div onClick={() => setState(!state())}>{String(state())}</div>;
    };`,
```

### 3.32 when the wrapper's result escapes uncaptured, nothing is conclusive

```js
    // when the wrapper's result escapes uncaptured, nothing is conclusive
    `registerSignal(makePersisted(createSignal(false)));`,
```

### 3.33 has JSX, but lowercase function and not named props => don't treat first parameter as props

```js
    // has JSX, but lowercase function and not named props => don't treat first parameter as props
    `function notAComponent(something) {
      console.log(something.a);
      return <div />;
    }`,
```

### 3.34 function expression inside tagged template literal expression is tracked scope

```js
    // function expression inside tagged template literal expression is tracked scope
    "css`color: ${props => props.color}`;",
    "html`<div>${props => props.name}</div>`;",
    "styled.css`color: ${props => props.color};`",
```

### 3.35 refs

```js
    // refs
    `function Component() {
      let canvas;
      return <canvas ref={canvas} />;
    }`,
    `function Component() {
      let canvas;
      return (
        <canvas ref={c => {
          canvas = c;
        }} />
      );
    }`,
    `function Component() {
      const [index] = createSignal(0);
      let canvas;
      return (
        <canvas ref={c => {
          index();
          canvas = c;
        }} />
      );
    }`,
    `function Component() {
      const [canvas, setCanvas] = createSignal();
      return <canvas ref={c => setCanvas(c)} />;
    }`,
```

### 3.36 mapArray()

```js
    // mapArray()
    `function createCustomStore() {
      const [store, updateStore] = createStore({});

      return mapArray(
        // the first argument to mapArray is a tracked scope
        () => store.path.to.field,
        (item) => ({})
      );
    }`,
    `function createCustomStore() {
      const [store, updateStore] = createStore({});

      return indexArray(
        // the first argument to mapArray is a tracked scope
        () => store.path.to.field,
        (item) => ({})
      );
    }`,
```

### 3.37 type casting

```js
    // type casting
    {
      code: `const m = createMemo(() => 5) as Accessor<number>;`,
      [tsOnly]: true,
    },
    {
      code: `const m = createMemo(() => 5)!;`,
      [tsOnly]: true,
    },
    {
      code: `const m = createMemo(() => 5)! as Accessor<number>;`,
      [tsOnly]: true,
    },
    {
      code: `const m = createMemo(() => 5) satisfies Accessor<number>;`,
      [tsOnly]: true,
    },
    {
      code: `const [s] = createSignal('a' as string)`,
      [tsOnly]: true,
    },
    {
      code: `createFoo('a' as string)`,
      [tsOnly]: true,
    },
```

### 3.38 functions in JSXExpressionContainers

```js
    // functions in JSXExpressionContainers
    `function Component(props) {
      return (
        <div>{() => {
          console.log('hello');
          return props.greeting;
        }}</div>
      );
    }`,
```

### 3.39 passing function instead of signal

```js
    // passing function instead of signal
    `const [signal, setSignal] = createSignal();
    let el = <Child foo={() => signal()}></Child>`,
```

### 3.40 static* prefix for props

```js
    // static* prefix for props
    `function Component(props) {
      const value = props.staticValue;
    }`,
    `function Component() {
      const staticValue = () => props.value;
      const value = staticValue();
    }`,
```

### 3.41 observable

```js
    // observable
    `function Component(props) {
      const count$ = observable(() => props.count);
      return <div />;
    }`,
    `const [signal, setSignal] = createSignal(0);
    const value$ = observable(signal);`,
```

### 3.42 use: functions

```js
    // use: functions
    `let someHook;
    function Component(props) {
      return <div use:someHook={() => props.count} />;
    }`,
```

### 3.43 f*cking insane edge case with multiple functions taking props as sync callbacks (#110)

```js
    // f*cking insane edge case with multiple functions taking props as sync callbacks (#110)
    `function formObjectDispatch(formObject, action) {
      const { field } = action.payload;
      formObject.findIndex((props) => props.field === field);
      formObject.findIndex((props) => props.field === field);
    }`,
```

### 3.44 === Solid 2.0 APIs === createProjection returns a readonly derived store

```js
    // === Solid 2.0 APIs ===
    // createProjection returns a readonly derived store
    `function Component() {
      const [todos, setTodos] = createStore([]);
      const selected = createProjection(draft => {
        draft.count = todos.length;
      });
      createEffect(() => console.log(selected.count));
    }`,
```

### 3.45 createOptimistic acts like createSignal

```js
    // createOptimistic acts like createSignal
    `function Component(props) {
      const [name, setName] = createOptimistic(() => props.name);
      return <div>{name()}</div>;
    }`,
```

### 3.46 createOptimisticStore acts like createStore

```js
    // createOptimisticStore acts like createStore
    `function Component() {
      const [state, setState] = createOptimisticStore({ items: [] });
      return <div>{state.items.length}</div>;
    }`,
```

### 3.47 merge replaces mergeProps

```js
    // merge replaces mergeProps
    `let Component = _props => {
      const props = merge({ value: "default" }, _props);
      return <div>{props.value}</div>;
    };`,
```

### 3.48 omit replaces splitProps, returning a single props object

```js
    // omit replaces splitProps, returning a single props object
    `let Component = props => {
      const rest = omit(props, "value");
      return <div>{rest.other}</div>;
    };`,
```

### 3.49 function-form createSignal/createStore (derived, writable)

```js
    // function-form createSignal/createStore (derived, writable)
    `const [count, setCount] = createSignal(0);
    const [double, setDouble] = createSignal(() => count() * 2);
    createEffect(() => console.log(double()));`,
    `function Component(props) {
      const [derived, setDerived] = createStore(draft => {
        draft.name = props.name;
      });
      return <div>{derived.name}</div>;
    }`,
```

### 3.50 async computations are first-class in 2.0

```js
    // async computations are first-class in 2.0
    `const [id, setId] = createSignal(1);
    const user = createMemo(async () => {
      const response = await fetch(\`/api/users/\${id()}\`);
      return response.json();
    });`,
```

### 3.51 reads before the first await are tracked

```js
    // reads before the first await are tracked
    `const [id, setId] = createSignal(1);
    const [format, setFormat] = createSignal("json");
    const user = createMemo(async () => {
      const fmt = format();
      const response = await fetch("/api/users/" + id());
      return fmt === "json" ? response.json() : response.text();
    });`,
```

### 3.52 async event handlers may read reactive values after await (polling is fine)

```js
    // async event handlers may read reactive values after await (polling is fine)
    `const [count, setCount] = createSignal(0);
    const el = <button onClick={async () => {
      await save();
      console.log(count());
    }} />;`,
```

### 3.53 action callbacks are not tracked scopes; post-yield reads poll current values

```js
    // action callbacks are not tracked scopes; post-yield reads poll current values
    `function Component(props) {
      const save = action(function* () {
        yield api.save();
        console.log(props.value);
      });
      return <button onClick={save}>Save</button>;
    }`,
```

### 3.54 split effects: createEffect(compute, effect)

```js
    // split effects: createEffect(compute, effect)
    `const [count, setCount] = createSignal(0);
    createEffect(() => count(), (value) => {
      console.log(value);
    });`,
```

### 3.55 isPending/latest/resolve take reactive functions

```js
    // isPending/latest/resolve take reactive functions
    `function Component(props) {
      const pending = isPending(() => props.user);
      return <div>{latest(() => props.user.name)}</div>;
    }`,
```

### 3.56 onSettled replaces onMount

```js
    // onSettled replaces onMount
    `function Component() {
      const [count, setCount] = createSignal(0);
      onSettled(() => {
        console.log(count());
      });
    }`,
```

### 3.57 flush callback runs in the current scope, like batch

```js
    // flush callback runs in the current scope, like batch
    `function Component() {
      const [count, setCount] = createSignal(0);
      createEffect(() => {
        flush(() => console.log(count()));
      });
    }`,
```

### 3.58 dynamic tracks its source function

```js
    // dynamic tracks its source function
    `import { createSignal } from "solid-js";
    import { dynamic } from "@solidjs/web";
    function Component() {
      const [count, setCount] = createSignal(0);
      const Test = dynamic(() => test(count()));
      return <Test />;
    }`,
```

### 3.59 dynamic accepts an async source; reads before the first await are tracked

```js
    // dynamic accepts an async source; reads before the first await are tracked
    `import { createSignal } from "solid-js";
    import { dynamic } from "@solidjs/web";
    function Component() {
      const [count, setCount] = createSignal(0);
      const Test = dynamic(async () => test(count()));
      return <Test />;
    }`,
```

### 3.60 repeat takes a count accessor and a map function

```js
    // repeat takes a count accessor and a map function
    `const [count, setCount] = createSignal(5);
    const items = repeat(() => count(), (index) => index * 2);`,
```

### 3.61 action callbacks may read reactive values and be async/generators

```js
    // action callbacks may read reactive values and be async/generators
    `function Component(props) {
      const save = action(async () => {
        await postData(props.data);
      });
      return <button onClick={save}>Save</button>;
    }`,
```

### 3.62 <For keyed={false}> passes the item as an accessor (old <Index> shape)

```js
    // <For keyed={false}> passes the item as an accessor (old <Index> shape)
    `function Component(props) {
      return (
        <For each={props.items} keyed={false}>
          {(item, index) => <div data-index={index}>{item()}</div>}
        </For>
      );
    }`,
```

### 3.63 <For keyed={fn}> passes accessors for both params

```js
    // <For keyed={fn}> passes accessors for both params
    `function Component(props) {
      return (
        <For each={props.items} keyed={item => item.id}>
          {(item, index) => <div data-index={index()}>{item().name}</div>}
        </For>
      );
    }`,
```

### 3.64 <For keyed> and <For keyed={true}> behave like 1.x <For>

```js
    // <For keyed> and <For keyed={true}> behave like 1.x <For>
    `function Component(props) {
      return (
        <For each={props.items} keyed>
          {(item, index) => <div data-index={index()}>{item.name}</div>}
        </For>
      );
    }`,
```

### 3.65 Returned accessors are the custom-primitive contract: the caller decides whether they land in a tracked scope. (#213)

```js
    // Returned accessors are the custom-primitive contract: the caller
    // decides whether they land in a tracked scope. (#213)
    `const [items, setItems] = createSignal([]);
    function useCartTotal() {
      return () => items().reduce((sum, item) => sum + item.price, 0);
    }`,
    `const [count, setCount] = createSignal(0);
    const useDouble = () => () => count() * 2;`,
    `const [count, setCount] = createSignal(0);
    function useCounter() {
      return function current() { return count(); };
    }`,
```

### 3.66 Snapshot capture opted into by naming convention (#213)

```js
    // Snapshot capture opted into by naming convention (#213)
    `const [items, setItems] = createSignal([]);
    function useTotal() {
      const initialItems = items();
      return () => initialItems.length;
    }`,
```

### 3.67 Captured value only used at setup, not by a returned function

```js
    // Captured value only used at setup, not by a returned function
    `const [items, setItems] = createSignal([]);
    function useTotal() {
      const list = items();
      console.log(list);
      return () => items().length;
    }`,
```

### 3.68 A capture read by a synchronous array-method callback runs during the computation, where it is fresh — the callback doesn't escape through the return; only the call's result does (#223)

```js
    // A capture read by a synchronous array-method callback runs during the
    // computation, where it is fresh — the callback doesn't escape through
    // the return; only the call's result does (#223)
    `const ITEMS = ["alpha", "beta", "gamma"];
    function Filtered() {
      const [query, setQuery] = createSignal("");
      const matches = createMemo(() => {
        const q = query().toUpperCase();
        return ITEMS.filter((item) => item.toUpperCase().includes(q));
      });
      return <div>{matches().length}</div>;
    }`,
    `const ITEMS = ["alpha", "beta"];
    function Component() {
      const [query, setQuery] = createSignal("");
      createEffect(() => {
        const q = query();
        console.log(ITEMS.some((item) => item === q));
      });
      return <div />;
    }`,
```

### 3.69 IIFEs run during the computation too

```js
    // IIFEs run during the computation too
    `const [count, setCount] = createSignal(0);
    function useLabel() {
      const value = count();
      return (() => "count: " + value)();
    }`,
```

## 4. Options, version handling, and the mechanisms behind each message

### Options

- **Schema** (verbatim): one property `customReactiveFunctions` — `type: "array"`, `items: { type: "string" }`, `default: []`; `additionalProperties: false`. Description: "List of function names to consider as reactive functions (allow signals to be safely passed as arguments). Supports exact names, '*' wildcards ('use*Store'), and regexes given as '/pattern/' strings. In addition, any create* or use* functions are automatically included."
- **Default:** `defaultOptions: [{ customReactiveFunctions: [] }]`. Docs: "Manually configuring an array will *replace* the defaults."
- **Matching:** `createNameMatcher(options.customReactiveFunctions)`, same grammar as `valid-use-server`'s `clientWrappers` (exact; `*` → `[a-zA-Z0-9_$]*` anchored; `/…/` → unanchored regex; invalid regex → exact). Always-on: any callee or member property matching `/^(?:use|create)[A-Z]/`.
- **Where the matcher applies:** a call with an `Identifier` callee, or a member callee whose property name matches (e.g. `X.createFoo(() => bar())`). Its arguments go through `permissivelyTrackNode`, which marks every function or identifier argument (not member-object identifiers, not callee identifiers) as `called-function` and skips into their children.

### Solid 2.0 mode

- `v2 = isSolidV2(context)`: true when `settings.solid.version` is a number or numeric string ≥ 2 (`getSolidVersion` in `src/utils.ts`). **The rule's own test file never sets `settings.solid.version`**, so every upstream case runs in the v1 branch (only the `moduleSources` test sets settings).
- The only behavioural switch in the rule body: a bare signal used as a DOM attribute value (`<button type={signal}>`) reports `badSignal` with `where: "JSX"` only when `!v2`. In v2 it is left to `solid/no-accessor-as-prop` (same node is never reported twice).
- Solid 2.0 names are recognised unconditionally (not gated on `v2`): `merge`, `omit`, `createProjection`, `createOptimistic`, `createOptimisticStore`, `createTrackedEffect`, `isPending`, `latest`, `resolve`, `deep`, `repeat`, `createErrorBoundary`, `createLoadingBoundary`, `createRevealOrder`, `dynamic`, `onSettled`, `flush`, `action`, `keyed` on `<For>`.
- Module sources: `getSolidSourceRegex(context)`, so `@solidjs/signals` and `@solidjs/web` imports count, and `settings.solid.moduleSources` adds exact names.

### Reactive-value producers (`checkForReactiveAssignment`): matcher lines verbatim, bodies summarised

```ts
        if (matchImport(["createSignal", "useTransition", "createOptimistic"], callee.name)) {
          // first element is the signal; no destructure → shouldDestructure "first"
        } else if (matchImport(["createMemo", "createSelector"], callee.name)) {
          // whole variable is the signal; no capture → shouldAssign
        } else if (matchImport(["createStore", "createOptimisticStore"], callee.name)) {
          // first element is a props-kind store; no destructure → shouldDestructure "first"
        } else if (matchImport(["mergeProps", "merge", "omit"], callee.name)) {
          // whole variable is a props object; no capture → shouldAssign
        } else if (matchImport("splitProps", callee.name)) {
          // array pattern: every element is props; empty → shouldDestructure (no nth)
        } else if (matchImport("createResource", callee.name)) {
          // first element is a props-kind value; no warning if absent
        } else if (matchImport(["createMutable", "createProjection"], callee.name)) {
          // whole variable is a props-kind value
        } else if (matchImport("mapArray", callee.name)) {
          // second callback parameter is a signal (index)
        } else if (matchImport("indexArray", callee.name)) {
          // first callback parameter is a signal (value)
        }
```

(Only the `matchImport(...)` lines are verbatim; the bodies are in `checkForReactiveAssignment` in `src/rules/reactivity.ts`, and the comments above are summaries, not quotes.)

Other producers:
- `<For each={…}>{(item, index) => …}</For>` (`"JSXElement > JSXExpressionContainer > :function"` selector): `item` is a signal when `keyed={false}` or `keyed={fn}`; `index` is a signal unless `keyed={false}`. Bare `keyed` and `keyed={true}` behave like 1.x (`item` is a plain value).
- `<Index>{(item, index) => …}</Index>`: `item` is a signal.

### Tracked-scope producers (`checkForTrackedScopes`), by call shape

| Call / node | Tracked scope kind | Note |
|---|---|---|
| `createMemo`, `children`, `createEffect`, `createRenderEffect`, `createDeferred`, `createComputed`, `createSelector`, `mapArray`, `indexArray`, `observable`, `createTrackedEffect`, `isPending`, `latest`, `resolve`, `deep`, `repeat`, `createErrorBoundary`, `createLoadingBoundary`, `createRevealOrder`, `dynamic` — arg 0 | `function` | `createMemo` and `dynamic` allow async (reads before first `await` tracked). Other async callbacks → `noAsyncTrackedScope`. |
| `createEffect` arg 1 (if function); `createErrorBoundary`/`createLoadingBoundary` arg 1 | `called-function` | the effect half and fallbacks are untracked |
| `createSignal`, `createStore`, `createProjection`, `createOptimistic`, `createOptimisticStore` — arg 0 when a function | `function` (async allowed) | function-form derived primitives |
| `createStore({ get x() {…} })` | `function` | getters in the store literal |
| `mergeProps`, `merge` — any function-traced argument | `function` | |
| `createResource(src, fetcher)` / `createResource(fetcher)` | `function` for `src`; fetcher is `called-function` | the fetcher itself is not tracked; `createResource(fetcher)` makes arg 0 `called-function` |
| `on(deps, fn)` | deps: `function`; fn: `called-function` | array deps supported |
| `onMount`, `onCleanup`, `onError`, `onSettled`, `action`, `setInterval`, `setTimeout`, `setImmediate`, `requestAnimationFrame`, `requestIdleCallback`, and `window./globalThis./self.` prefixed timers | `called-function` (arg 0) | |
| `untrack(fn)` | `called-function` | allows async without read-after-await |
| `runWithOwner(owner, fn)` | `function` unless `owner = getOwner()` is in a non-tracked function | |
| `IntersectionObserver`, `MutationObserver`, `PerformanceObserver`, `ReportingObserver`, `ResizeObserver` (`new`) — arg 0 | `called-function` | |
| `addEventListener(type, fn)` — arg 1 | `called-function` | |
| `.then/.catch/.finally(...)` — every argument | `called-function` | |
| `createReactive(fn)` / `createReaction(fn)` | arg 0 → `called-function`; each call of the returned `track(fn)` → arg 0 `function` | |
| `obj.onxxx = () => …` (assignment to lowercase `on*` member) | `called-function` | |
| Tagged template `css\`${fn}\`` function expressions | `called-function` | |
| JSX `on*` attribute on DOM element (`onClick={…}`, `on:click`, `on-click`) | `called-function` | |
| JSX `use:dir={fn}` | `called-function` | |
| JSX `ref={fn}` | `called-function` | |
| JSX function child `{() => …}` directly in an element | `function` | |
| `<Comp staticX={…}>` (component, `static[A-Z]` prop) | none — passing reactive values here is itself reported as untracked | |
| Provider `value={…}` (`X.Provider`, `…Provider` name, or a `createContext()` binding) | none; container recorded for `providerValue` | |
| Any other JSX container / spread | `expression` | |
| Matching `/^(?:use|create)[A-Z]/` or custom name, any argument | permissive: each traced function/identifier → `called-function` | |
| Unknown call inside a tracked scope | function arguments → `called-function` | |
| `mapArray` / `indexArray` / `repeat` — arg 1 (callback) | sync callback (same scope, `syncCallbacks`) | |
| `batch`, `produce`, `flush` — exactly one argument, non-async function | sync callback (same scope) | |
| `.forEach/map/flatMap/reduce/reduceRight/find/findIndex/filter/every/some(fn)` — callee object is not an object literal, exactly one argument, non-async function | sync callback (same scope) | |
| Setter of `createSignal`/`createStore`/`createOptimistic`/`createOptimisticStore` — callbacks passed to the setter call (non-async) | sync callback | |
| IIFE callee | sync callback | |

### Mechanisms by message id (from the source; the cases in §2 are the authority)

| messageId | Triggered when (source) |
|---|---|
| `noWrite` | A signal/memo reference that `isWrite()` (`sig = …`), or a props/store reference that is the object of a direct member assignment (`props.a = …`; one level only, `props.a.b = …` is not caught here). **No upstream test case pins `noWrite`.** |
| `untrackedReactive` | A signal call or props read whose declaration scope is the current function and that is not inside any tracked scope, and not inside a provider `value`, and no expression-kind tracked scope encloses it. `data.name` = `sourceCode.getText(parentMemberExpression)` for member reads, else identifier name. Report node = the member chain or call. |
| `expectedFunctionGotExpression` | Same as `untrackedReactive`, except some tracked-scope node *contains* the read without being the read itself (`findInScope`). Examples: `<div onClick={props.onClick} />` (the container's expression, a `MemberExpression`, is registered as `called-function`) and `createEffect(props.theEffect)`. |
| `providerValue` | Same as untracked, but inside a `value={…}` container of a provider element. |
| `badSignal` | An uncalled signal/memo identifier whose parent is: `TemplateLiteral` ("template literals"); `BinaryExpression` with one of `< <= > >= << >> >>> + - * / % ** \| ^ & in` ("arithmetic or comparisons"); `UnaryExpression` `- + ~` ("unary expressions"); computed `MemberExpression` property ("property accesses"); `JSXExpressionContainer` as a child or, when `!v2`, a DOM attribute ("JSX"). `data.where` carries the label. |
| `badUnnamedDerivedSignal` | An anonymous (or unassigned) function that contains reactive reads and is not matched by a tracked scope in its own scope. `loc` = the function head (`getFunctionHeadLocation`), no `data`. |
| `shouldDestructure` | `createSignal` / `useTransition` / `createOptimistic` / `createStore` / `createOptimisticStore` whose result is not an array pattern with a capturable element 0 (bare call, identifier, object pattern, hole) — `data.nth` = `"first "`; `splitProps` with no identifier element (no `data`, so the message text keeps the literal `{{nth}}`; derived, not test-pinned). `createResource` never reports this (verified: no `warnShouldDestructure` in its branch). |
| `shouldAssign` | `createMemo` / `createSelector` / `mergeProps` / `merge` / `omit` result not captured in a plain identifier (bare call, destructured result, etc.). |
| `noAsyncTrackedScope` | An `async` or generator function registered as a `function` tracked scope where async is not allowed (e.g. `createEffect(async () => …)`, `createResource`'s source). |
| `readAfterAwait` | A signal or props read positioned after the first `await`/`yield` of an async tracked scope: `createMemo`, `dynamic`, or the function-form `createSignal`/`createStore`/`createProjection`/`createOptimistic`/`createOptimisticStore`. A loop containing the first suspension taints the whole loop. Reads in the operands of that first suspension are still tracked. |
| `staleCapture` | A signal call at the setup level of a function, whose result is captured by a variable declared in a `VariableDeclarator` (`const` or `let`), where a nested function reads that variable and escapes the enclosing function via `return` (including wrapping in JSX or an object literal). A function passed as an argument to a call does not escape this way. Captured names starting `initial`, `default`, or `static[A-Z]` are exempt. |

### Documented exemptions that suppress reports (derived from the source)

- A props member read whose property name matches `/^(?:initial|default|static[A-Z])/` (e.g. `props.initialCount`) is not reported.
- Returned functions (`return () => sig()`, arrow body) are accessors handed to the caller and are not required to match a tracked scope.
- Captures whose name starts with `initial`/`default`/`static[A-Z]` are not stale captures.
- `obj.x = props` (storing the whole reactive object into a member, e.g. `this.state = state`) is exempt; `obj.x = props.y` is an ordinary member read and is analysed as one.
- A function passed to an unknown call *outside* any tracked scope is not marked as tracked. The unknown-call fallback only applies inside a `function`/`called-function` scope.

## 5. Severity

- `recommended` (`src/configs/recommended.ts`): `"solid/reactivity": 1` (warn). Comment group: `// reactivity`.
- `v2` (`src/configs/v2.ts`): spreads `...recommended.rules`, so `"solid/reactivity": 1` (warn). The `v2` config also sets `settings.solid.version: 2`, which switches the `!v2` `badSignal` branch off (see above).
- `v2-strict` (`src/configs/v2-strict.ts`): spreads `v2.rules`; no override → warn.
- Docs header: "This rule is **a warning** by default."
