#!/usr/bin/env python3
"""Assemble <rule>.md: hand-written head/tail fragments around verbatim slices of upstream files.

usage: gen.py <rule> <raw_src.ts> <raw_test.ts> <head.md> <tail.md> <out.md>
Invalid cases are the `    {` ... `    },` blocks of the `invalid:` array; valid items are
grouped under the nearest preceding `    //` comment. Every code block is a raw line slice.
"""
import pathlib
import re
import sys


def load(path):
    return pathlib.Path(path).read_text(encoding="utf-8").split("\n")


def section(lines, marker):
    start = next(i for i, l in enumerate(lines) if l == f"  {marker}: [")
    end = next(i for i in range(start + 1, len(lines)) if lines[i] == "  ],")
    return start + 1, end


def invalid_cases(lines, s, e):
    out, i = [], s
    while i < e:
        if lines[i] == "    {":
            j = i + 1
            while lines[j] != "    },":
                j += 1
            comments, k = [], i - 1
            while k >= s and lines[k].startswith("    //"):
                comments.insert(0, lines[k].strip())
                k -= 1
            out.append({"start": i, "end": j, "block": lines[i : j + 1], "comments": comments})
            i = j + 1
        else:
            i += 1
    return out


def valid_groups(lines, s, e):
    groups = [{"heading": "no source comment", "lines": []}]
    prev_comment = False
    for i in range(s, e):
        l = lines[i]
        if l.startswith("    //"):
            cur = groups[-1]
            has_code = any(x.strip() and not x.strip().startswith("//") for x in cur["lines"])
            if prev_comment and not has_code:
                cur["heading"] += " " + l.strip()[2:].strip()
                cur["lines"].append(l)
            else:
                groups.append({"heading": l.strip()[2:].strip(), "lines": [l]})
            prev_comment = True
        else:
            groups[-1]["lines"].append(l)
            prev_comment = False
    return [g for g in groups if any(x.strip() for x in g["lines"])]


def message_texts(src):
    block = src[src.index("messages: {") :]
    block = block[: block.index("\n    },") + 1]
    found = {}
    for mid in re.findall(r"\n\s{6}(\w+):", block):
        m = re.search(r"\n\s{6}" + mid + r":", block)
        rest = block[m.end() :]
        end = re.search(r"[\"'`],?\n", rest)
        found[mid] = " ".join(rest[: end.start() + 1].split())
    return found


def main():
    rule, src_p, test_p, head_p, tail_p, out_p = sys.argv[1:7]
    src_text = pathlib.Path(src_p).read_text(encoding="utf-8")
    lines = load(test_p)
    vs, ve = section(lines, "valid")
    is_, ie = section(lines, "invalid")
    cases = invalid_cases(lines, is_, ie)
    n_errors = sum(1 for l in lines[is_:ie] if "errors:" in l)
    if n_errors != len(cases):
        raise SystemExit(f"{rule}: {len(cases)} case blocks but {n_errors} errors: lines")
    msgs = message_texts(src_text)

    info = []
    for n, c in enumerate(cases, 1):
        text = " ".join(c["block"])
        ids = re.findall(r'messageId: "(\w+)"', text)
        datas = re.findall(r"data: (\{[^}]*\})", text)
        opts = re.findall(r"(settings: \{ solid: \{.*?\} \})", text) + re.findall(r"(options: \[\{.*?\}\])", text)
        c.update(n=n, ids=ids, data="; ".join(datas + opts), first=ids[0] if ids else "?")
        info.append(c)

    out = [pathlib.Path(head_p).read_text(encoding="utf-8").rstrip() + "\n"]
    out.append(f"\n## 2. Reported shapes (invalid cases, verbatim)\n")
    out.append(
        f"Source: `test/rules/{rule}.test.ts`, `invalid:` array, raw lines {is_ + 1}–{ie}. "
        f"{len(cases)} cases. Every block below is a raw slice of that file.\n"
    )
    out.append("### 2a. Message texts (verbatim literals from `src/rules/" + rule + ".ts`)\n")
    out.append("| messageId | literal | upstream invalid cases |\n|---|---|---|")
    for mid, txt in msgs.items():
        cnt = sum(1 for c in info if mid in c["ids"])
        out.append(f"| `{mid}` | `{txt}` | {cnt or '**none (no upstream test)**'} |")
    out.append("\n### 2b. Summary table\n")
    out.append("| # | messageId(s) | data / options | test lines | leading comment (verbatim) |\n|---|---|---|---|---|")
    for c in info:
        com = " ".join(c["comments"]).replace("|", "\\|") or ""
        d = c["data"].replace("|", "\\|")
        out.append(
            f"| {c['n']} | {', '.join('`'+x+'`' for x in c['ids'])} | {d} | {c['start']+1}–{c['end']+1} | {com} |"
        )
    out.append("\n### 2c. Cases grouped by messageId (code verbatim)\n")
    seen = []
    for c in info:
        if c["first"] not in seen:
            seen.append(c["first"])
    for mid in seen:
        out.append(f"#### `{mid}`\n")
        for c in info:
            if c["first"] != mid:
                continue
            also = [x for x in c["ids"][1:]]
            note = f" (also errors: {', '.join(also)})" if also else ""
            out.append(f"**Case {c['n']}** — lines {c['start']+1}–{c['end']+1}{note}\n")
            for com in c["comments"]:
                out.append(f"<!-- {com} -->")
            out.append("```js\n" + "\n".join(c["block"]) + "\n```\n")

    out.append("## 3. Non-reports (valid cases, verbatim)\n")
    out.append(
        f"Source: `test/rules/{rule}.test.ts`, `valid:` array, raw lines {vs + 1}–{ve}. "
        "Grouped by the source comment that precedes each run of cases (the comment is the upstream reason).\n"
    )
    for k, g in enumerate(valid_groups(lines, vs, ve), 1):
        body = "\n".join(g["lines"]).strip("\n")
        out.append(f"### 3.{k} {g['heading']}\n")
        out.append("```js\n" + body + "\n```\n")

    out.append(pathlib.Path(tail_p).read_text(encoding="utf-8").rstrip() + "\n")
    pathlib.Path(out_p).write_text("\n".join(out), encoding="utf-8")
    print(f"{rule}: {len(info)} invalid cases, {len(msgs)} message ids, {sum(len(g['lines']) for g in valid_groups(lines, vs, ve))} valid lines -> {out_p}")


if __name__ == "__main__":
    main()
