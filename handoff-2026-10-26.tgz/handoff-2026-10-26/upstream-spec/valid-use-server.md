# solid/valid-use-server — upstream spec (eslint-plugin-solid v0.18.1)

Upstream files: `docs/valid-use-server.md`, `src/rules/valid-use-server.ts`, `test/rules/valid-use-server.test.ts` (snapshots in `../raw/`, flattened names; helpers from `src/utils.ts` also in `../raw/src_utils.ts`). Rule key: `solid/valid-use-server`.

## 1. What it reports

Five shapes, all about where the `"use server"` directive is honoured and what a module-level directive file exports or calls:

1. `templateDirective` — a template literal with no substitutions whose cooked text is `use server` at statement position. Reported anywhere, even inside a module-level file.
2. `misplacedDirective` — a string statement `"use server"` that is not in the directive prologue of its Program or function body, unless the whole module or an enclosing extracted function already has the directive (those are silently skipped).
3. `ineligiblePosition` — a valid prologue directive inside an object-literal method, getter/setter, or class method (the compiler never extracts those). Message names the position.
4. `nonFunctionExport` — in a module-level `"use server"` file, an export whose value is a literal, template literal, array or object (`export const X = 1`, `export default {…}`).
5. `clientWrapper` — in a module-level `"use server"` file, a module-scope call to a client-side declaration wrapper (built-in list or `clientWrappers` option), e.g. `query(...)`, `GET(...)`.

Docs: "Enforce that \"use server\" directives are placed where the compiler honors them, and that module-level directive files export working server functions."


## 2. Reported shapes (invalid cases, verbatim)

Source: `test/rules/valid-use-server.test.ts`, `invalid:` array, raw lines 67–164. 13 cases. Every block below is a raw slice of that file.

### 2a. Message texts (verbatim literals from `src/rules/valid-use-server.ts`)

| messageId | literal | upstream invalid cases |
|---|---|---|
| `misplacedDirective` | `'The "use server" directive only takes effect as the first statement of a function body or module; here it is an ordinary expression statement and the code stays on the client.'` | 2 |
| `templateDirective` | `'A template literal is never a directive; this code stays on the client. Use a plain string: "use server".'` | 2 |
| `ineligiblePosition` | `'The "use server" directive in {{position}} is silently ignored — the function is never extracted to the server. Use a standalone function, a function-valued property, or a block-bodied arrow instead.'` | 3 |
| `nonFunctionExport` | `"Every export of a module-level \"use server\" file is registered as a server function; '{{name}}' is not a function and will fail the server at boot. Move non-function exports to another module."` | 2 |
| `clientWrapper` | `"In a module-level \"use server\" file the client receives bare server references, so '{{name}}' never runs on the client and its behavior is silently lost. Wrap the imported server function in a shared module instead, or move the directive inside the wrapped function."` | 4 |

### 2b. Summary table

| # | messageId(s) | data / options | test lines | leading comment (verbatim) |
|---|---|---|---|---|
| 1 | `misplacedDirective` |  | 68–75 | // directive after other statements is an ordinary expression statement |
| 2 | `misplacedDirective` |  | 77–85 | // a directive inside a plain block is never a directive |
| 3 | `templateDirective` |  | 87–90 | // template literals are never directives |
| 4 | `templateDirective` |  | 91–94 |  |
| 5 | `ineligiblePosition` | { position: "an object method" } | 96–104 | // object methods are silently skipped by the compiler |
| 6 | `ineligiblePosition` | { position: "a getter or setter" } | 106–114 | // getters and setters too |
| 7 | `ineligiblePosition` | { position: "a class method" } | 116–124 | // and class methods |
| 8 | `nonFunctionExport` | { name: "LIMIT" } | 126–133 | // every export of a module-level directive file must be a function |
| 9 | `nonFunctionExport` | { name: "default" } | 134–138 |  |
| 10 | `clientWrapper` | { name: "query" } | 140–145 | // client wrappers are compiled out of the client in module-level files |
| 11 | `clientWrapper` | { name: "GET" } | 146–151 |  |
| 12 | `clientWrapper` | { name: "action" } | 152–157 |  |
| 13 | `clientWrapper` | { name: "defineLoader" }; options: [{ clientWrappers: ["define*"] }] | 159–164 | // custom wrappers via the clientWrappers option, incl. wildcards |

### 2c. Cases grouped by messageId (code verbatim)

#### `misplacedDirective`

**Case 1** — lines 68–75

<!-- // directive after other statements is an ordinary expression statement -->
```js
    {
      code: `async function getUser(id) {
  const table = "users";
  "use server";
  return db.get(table, id);
}`,
      errors: [{ messageId: "misplacedDirective" }],
    },
```

**Case 2** — lines 77–85

<!-- // a directive inside a plain block is never a directive -->
```js
    {
      code: `async function getUser(id) {
  if (id) {
    "use server";
    return db.get(id);
  }
}`,
      errors: [{ messageId: "misplacedDirective" }],
    },
```

#### `templateDirective`

**Case 3** — lines 87–90

<!-- // template literals are never directives -->
```js
    {
      code: "async function getUser(id) {\n  `use server`;\n  return db.get(id);\n}",
      errors: [{ messageId: "templateDirective" }],
    },
```

**Case 4** — lines 91–94

```js
    {
      code: "`use server`;\nexport async function getUser(id) {\n  return db.get(id);\n}",
      errors: [{ messageId: "templateDirective" }],
    },
```

#### `ineligiblePosition`

**Case 5** — lines 96–104

<!-- // object methods are silently skipped by the compiler -->
```js
    {
      code: `const api = {
  async getUser(id) {
    "use server";
    return db.get(id);
  },
};`,
      errors: [{ messageId: "ineligiblePosition", data: { position: "an object method" } }],
    },
```

**Case 6** — lines 106–114

<!-- // getters and setters too -->
```js
    {
      code: `const api = {
  get user() {
    "use server";
    return db.get(1);
  },
};`,
      errors: [{ messageId: "ineligiblePosition", data: { position: "a getter or setter" } }],
    },
```

**Case 7** — lines 116–124

<!-- // and class methods -->
```js
    {
      code: `class Api {
  async getUser(id) {
    "use server";
    return db.get(id);
  }
}`,
      errors: [{ messageId: "ineligiblePosition", data: { position: "a class method" } }],
    },
```

#### `nonFunctionExport`

**Case 8** — lines 126–133

<!-- // every export of a module-level directive file must be a function -->
```js
    {
      code: `"use server";
export const LIMIT = 10;
export async function getUsers() {
  return db.all();
}`,
      errors: [{ messageId: "nonFunctionExport", data: { name: "LIMIT" } }],
    },
```

**Case 9** — lines 134–138

```js
    {
      code: `"use server";
export default { version: 1 };`,
      errors: [{ messageId: "nonFunctionExport", data: { name: "default" } }],
    },
```

#### `clientWrapper`

**Case 10** — lines 140–145

<!-- // client wrappers are compiled out of the client in module-level files -->
```js
    {
      code: `"use server";
import { query } from "@solidjs/router";
export const getUser = query(async (id) => db.get(id), "user");`,
      errors: [{ messageId: "clientWrapper", data: { name: "query" } }],
    },
```

**Case 11** — lines 146–151

```js
    {
      code: `"use server";
import { GET } from "@solidjs/web";
export const listUsers = GET(async () => db.all());`,
      errors: [{ messageId: "clientWrapper", data: { name: "GET" } }],
    },
```

**Case 12** — lines 152–157

```js
    {
      code: `"use server";
import { action } from "@solidjs/router";
export const save = action(async (data) => db.save(data));`,
      errors: [{ messageId: "clientWrapper", data: { name: "action" } }],
    },
```

**Case 13** — lines 159–164

<!-- // custom wrappers via the clientWrappers option, incl. wildcards -->
```js
    {
      code: `"use server";
export const getUser = defineLoader(async (id) => db.get(id));`,
      options: [{ clientWrappers: ["define*"] }],
      errors: [{ messageId: "clientWrapper", data: { name: "defineLoader" } }],
    },
```

## 3. Non-reports (valid cases, verbatim)

Source: `test/rules/valid-use-server.test.ts`, `valid:` array, raw lines 6–64. Grouped by the source comment that precedes each run of cases (the comment is the upstream reason).

### 3.1 function-level directive in the prologue of an eligible function

```js
    // function-level directive in the prologue of an eligible function
    `export const getUser = async (id) => {
  "use server";
  return db.get(id);
};`,
    `export async function getUser(id) {
  "use server";
  return db.get(id);
}`,
```

### 3.2 other directives may precede it in the prologue

```js
    // other directives may precede it in the prologue
    `async function getUser(id) {
  "use strict";
  "use server";
  return db.get(id);
}`,
```

### 3.3 function-valued properties are eligible (unlike object methods)

```js
    // function-valued properties are eligible (unlike object methods)
    `const api = {
  getUser: async function (id) {
    "use server";
    return db.get(id);
  },
};`,
```

### 3.4 a "use server" string in expression (non-statement) position is just a string

```js
    // a "use server" string in expression (non-statement) position is just a string
    `const mode = "use server";
function describe() {
  return "use server";
}`,
```

### 3.5 module-level directive with async function exports

```js
    // module-level directive with async function exports
    `"use server";
export async function getUser(id) {
  return db.get(id);
}
export const listUsers = async () => db.all();`,
```

### 3.6 wrappers around function-level server functions are the supported pattern

```js
    // wrappers around function-level server functions are the supported pattern
    `import { query } from "@solidjs/router";
export const getUser = query(async (id) => {
  "use server";
  return db.get(id);
}, "user");`,
```

### 3.7 wrapper calls inside functions of a module-level file are server-side code

```js
    // wrapper calls inside functions of a module-level file are server-side code
    `"use server";
import { query } from "@solidjs/router";
export async function setup() {
  return query(async (id) => db.get(id), "user");
}`,
```

### 3.8 re-exports are not statically analyzable; give them the benefit of the doubt

```js
    // re-exports are not statically analyzable; give them the benefit of the doubt
    `"use server";
export { helper } from "./helpers";`,
```

### 3.9 directives nested inside a server function are ignored but harmless

```js
    // directives nested inside a server function are ignored but harmless
    `export async function outer() {
  "use server";
  const helpers = {
    inner() {
      "use server";
      return 1;
    },
  };
  return helpers.inner();
}`,
```

## 4. Options and implementation notes

### Options

- **Schema** (verbatim `meta.schema`): an object with one property `clientWrappers` — `type: "array"`, `items: { type: "string" }`, `default: []`, `additionalProperties: false`. The description reads: "Additional function names treated as client-side declaration wrappers that must not be called inside a module-level \"use server\" file. Supports exact names, '*' wildcards, and regexes given as '/pattern/' strings. GET, live, withMeta, query, action, and liveQuery are always included."
- **Default:** `defaultOptions: [{ clientWrappers: [] }]`. Docs: "Options shown here are the defaults. Manually configuring an array will *replace* the defaults."
- **Grammar** (`createNameMatcher`, `src/utils.ts`), applied per entry, first match wins:
  1. length > 2 and starts and ends with `/` → `new RegExp(entry.slice(1, -1))`. **Not anchored**, so `"/define/"` also matches `redefine`. An invalid regex falls back to exact string comparison.
  2. contains `*` → split on `*`, escape regex metacharacters in each part, join with `[a-zA-Z0-9_$]*`, wrap in `^…$`. So `define*` matches `define`, `defineLoader`, not `redefine` and not `define-x`.
  3. otherwise exact string equality.
- **Name source:** the matcher is applied to the *local* callee identifier name (`node.callee.name`) and needs no import. It applies to any module-scope call, including locally defined functions.

### Built-in client wrappers

`CLIENT_WRAPPERS` (verbatim, `src/rules/valid-use-server.ts`):

```ts
const CLIENT_WRAPPERS = ["GET", "live", "withMeta", "query", "action", "liveQuery"];
const WRAPPER_SOURCES = /^(?:solid-js|@solidjs\/(?:web|router|start))(?:\/|$)/;
```

- Built-in names are matched by `matchImport(CLIENT_WRAPPERS, name)`: the callee must be a local binding created by an `ImportSpecifier` from `WRAPPER_SOURCES` whose imported name is in the list (aliases are reported under the local name). Source matching is by the regex above, **not** by per-name source: `GET` from `solid-js` or from `@solidjs/start` also matches, and `live`/`withMeta`/`GET` are not restricted to `@solidjs/web`. `handleImportDeclaration` uses `WRAPPER_SOURCES` directly, so `settings.solid.moduleSources` is **not** honoured by this rule.
- Only `Identifier` callees are checked. `router.query(...)` or `api.GET(...)` are ignored.

### Directive placement (how it is judged)

Applied to every `ExpressionStatement` whose expression is a `TemplateLiteral` (with no substitutions and cooked text `use server`) or a `Literal` with value `"use server"`. In order:

1. Template form → `templateDirective`, always (returns before any other check).
2. If the module (`Program` prologue) has `"use server"` (`moduleLevel`) → no further report for any string statement, including misplaced ones.
3. If the nearest enclosing function is itself inside an extracted function (`isInsideUseServerFunction`: some strict *ancestor* function has `"use server"` in its prologue) → no report.
4. Parent is a `Program`, or a `BlockStatement` that is a function body. Otherwise (if/for/bare block, or any other parent) → `misplacedDirective`.
5. Statement must be in the prologue (`getDirectivePrologue(body)`: the maximal leading run of string-literal expression statements). Otherwise → `misplacedDirective`. Consequence (derived from the code; no upstream test pins it): `import x from "y"; "use server";` at module top is `misplacedDirective`, because the prologue ends at the first non-string statement and `moduleLevel` is then false.
6. If the function body is a function and is not inside another extracted function: `getUseServerEligibility(fn)`:
   - `Property` value with `kind !== "init"` (getter/setter) → `accessor`;
   - `Property` value with `method: true` → `objectMethod`;
   - `MethodDefinition` with `kind` `get`/`set` → `accessor`; any other class member → `classMethod`;
   - otherwise `eligible` (standalone functions, arrows, function-valued properties).
   Non-eligible → `ineligiblePosition` with `POSITION_LABELS`: `objectMethod` → "an object method", `accessor` → "a getter or setter", `classMethod` → "a class method".

### Module-level checks

Only when `moduleLevel` is true:

- `ExportNamedDeclaration` with a `VariableDeclaration`: each declarator with an `Identifier` id and an init is checked (`checkExportedValue`).
- `ExportDefaultDeclaration`: the declaration is checked with name `"default"`.
- `checkExportedValue` reports `nonFunctionExport` only when the node is `Literal`, `TemplateLiteral`, `ArrayExpression` or `ObjectExpression`. Identifiers, calls, binary expressions, functions and classes are not reported. `export { x } from "…"` (no declaration) is never reported.
- `CallExpression` whose callee is an `Identifier` and whose nearest enclosing function is none (module scope): matched by built-in import or custom name → `clientWrapper` with `data.name` = local callee name.

`messageId` `nonFunctionExport`'s data key is `name` (`"default"` for default exports).

## 5. Severity

- `recommended`: **not listed** → off (docs: "This rule is **off** by default.").
- `v2`: `"solid/valid-use-server": 2` (error). Comment: `// server functions are core in 2.0; misplaced/ignored "use server" directives and broken module-level directive files are silent failures`.
- `v2-strict`: inherits error via `...v2.rules`.
- Companion rules in v2 (not part of this spec): `solid/require-async-server-function`, `solid/no-invalid-server-capture`, `solid/no-browser-globals-in-server-function`, all error.
