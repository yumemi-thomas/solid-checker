# solid/no-write-in-pure-computation — upstream spec (eslint-plugin-solid v0.18.1)

Upstream files: `docs/no-write-in-pure-computation.md`, `src/rules/no-write-in-pure-computation.ts`, `test/rules/no-write-in-pure-computation.test.ts` (snapshots in `../raw/`, flattened names). Rule key: `solid/no-write-in-pure-computation`.

## 1. What it reports

A call to a *setter* (the second element of a `createSignal`, `createStore` or `createOptimistic` destructure, resolved by import) whose nearest enclosing function is a pure owned scope:

- the callback of `createMemo(fn)` → `writeInMemo`;
- the first (compute) argument of `createEffect(compute, effect)` or `createRenderEffect(compute, effect)` when called with two or more arguments → `writeInCompute` (the message names the API);
- a component body: a function that contains JSX directly, whose name is not lowercase, that is not a render prop, and that is not a plain call argument → `writeInComponent`. Component status is decided at the function's exit.

Setter calls inside a nested function (event handler, `onSettled`, `createTrackedEffect`, the effect half, any other callback) are not reported. Setter calls at module scope (no enclosing function) are not reported. A signal created with `ownedWrite: true` is exempt, but only for signal and optimistic setters, never for `createStore`. Docs: "Disallow writing signals or stores inside `createMemo`, the compute half of `createEffect`, or a component body, which are pure owned scopes."


## 2. Reported shapes (invalid cases, verbatim)

Source: `test/rules/no-write-in-pure-computation.test.ts`, `invalid:` array, raw lines 117–223. 11 cases. Every block below is a raw slice of that file.

### 2a. Message texts (verbatim literals from `src/rules/no-write-in-pure-computation.ts`)

| messageId | literal | upstream invalid cases |
|---|---|---|
| `writeInMemo` | `"Calling the setter '{{name}}' inside createMemo makes the computation impure and creates an update cycle. Derive the value instead of storing it, or move the write to an effect."` | 6 |
| `writeInCompute` | `"Calling the setter '{{name}}' in the compute half of {{api}} — the compute function is tracked and must be pure. Move the write into the effect half (the second argument)."` | 2 |
| `writeInComponent` | `"Calling the setter '{{name}}' during component setup — the body runs once as a pure owned scope, and Solid 2.0 throws on setup writes in dev. Initialize the state with the right value instead, or move the write into an effect half or event handler."` | 3 |

### 2b. Summary table

| # | messageId(s) | data / options | test lines | leading comment (verbatim) |
|---|---|---|---|---|
| 1 | `writeInMemo` |  | 117–125 |  |
| 2 | `writeInCompute` |  | 126–134 |  |
| 3 | `writeInCompute` |  | 135–143 |  |
| 4 | `writeInMemo` |  | 145–153 | // store setters are writes too |
| 5 | `writeInMemo` |  | 155–163 | // an options literal without the opt-in doesn't exempt anything |
| 6 | `writeInMemo` |  | 165–174 | // ...including through const indirection |
| 7 | `writeInMemo` |  | 175–183 |  |
| 8 | `writeInMemo` |  | 185–193 | // ownedWrite is a SignalOptions flag; core has no such exemption for store setters |
| 9 | `writeInComponent` |  | 195–203 | // setup-scope writes in component bodies throw in 2.0 dev |
| 10 | `writeInComponent` |  | 205–213 | // arrow components and module-level signals are the same hazard |
| 11 | `writeInComponent` |  | 215–223 | // conditional writes still run during setup |

### 2c. Cases grouped by messageId (code verbatim)

#### `writeInMemo`

**Case 1** — lines 117–125

```js
    {
      code: `import { createSignal, createMemo } from "solid-js";
const [count, setCount] = createSignal(0);
const bad = createMemo(() => {
  setCount(count() + 1);
  return count();
});`,
      errors: [{ messageId: "writeInMemo" }],
    },
```

**Case 4** — lines 145–153

<!-- // store setters are writes too -->
```js
    {
      code: `import { createStore, createMemo } from "solid-js";
const [store, setStore] = createStore({ count: 0 });
const bad = createMemo(() => {
  setStore((draft) => draft.count++);
  return store.count;
});`,
      errors: [{ messageId: "writeInMemo" }],
    },
```

**Case 5** — lines 155–163

<!-- // an options literal without the opt-in doesn't exempt anything -->
```js
    {
      code: `import { createSignal, createMemo } from "solid-js";
const [count, setCount] = createSignal(0, { name: "count" });
const bad = createMemo(() => {
  setCount(count() + 1);
  return count();
});`,
      errors: [{ messageId: "writeInMemo" }],
    },
```

**Case 6** — lines 165–174

<!-- // ...including through const indirection -->
```js
    {
      code: `import { createSignal, createMemo } from "solid-js";
const opts = { name: "count" };
const [count, setCount] = createSignal(0, opts);
const bad = createMemo(() => {
  setCount(count() + 1);
  return count();
});`,
      errors: [{ messageId: "writeInMemo" }],
    },
```

**Case 7** — lines 175–183

```js
    {
      code: `import { createSignal, createMemo } from "solid-js";
const [count, setCount] = createSignal(0, { ownedWrite: false });
const bad = createMemo(() => {
  setCount(count() + 1);
  return count();
});`,
      errors: [{ messageId: "writeInMemo" }],
    },
```

**Case 8** — lines 185–193

<!-- // ownedWrite is a SignalOptions flag; core has no such exemption for store setters -->
```js
    {
      code: `import { createStore, createMemo } from "solid-js";
const [store, setStore] = createStore({ count: 0 }, { ownedWrite: true });
const bad = createMemo(() => {
  setStore((draft) => draft.count++);
  return store.count;
});`,
      errors: [{ messageId: "writeInMemo" }],
    },
```

#### `writeInCompute`

**Case 2** — lines 126–134

```js
    {
      code: `import { createSignal, createEffect } from "solid-js";
const [log, setLog] = createSignal("");
createEffect(() => {
  setLog(query());
  return query();
}, (value) => console.log(value));`,
      errors: [{ messageId: "writeInCompute" }],
    },
```

**Case 3** — lines 135–143

```js
    {
      code: `import { createSignal, createRenderEffect } from "solid-js";
const [size, setSize] = createSignal(0);
createRenderEffect(() => {
  setSize(width());
  return width();
}, (value) => update(value));`,
      errors: [{ messageId: "writeInCompute" }],
    },
```

#### `writeInComponent`

**Case 9** — lines 195–203

<!-- // setup-scope writes in component bodies throw in 2.0 dev -->
```js
    {
      code: `import { createSignal } from "solid-js";
function Counter() {
  const [count, setCount] = createSignal(0);
  setCount(1);
  return <div>{count()}</div>;
}`,
      errors: [{ messageId: "writeInComponent" }],
    },
```

**Case 10** — lines 205–213

<!-- // arrow components and module-level signals are the same hazard -->
```js
    {
      code: `import { createSignal } from "solid-js";
const [theme, setTheme] = createSignal("dark");
const Header = () => {
  setTheme("light");
  return <header>{theme()}</header>;
};`,
      errors: [{ messageId: "writeInComponent" }],
    },
```

**Case 11** — lines 215–223

<!-- // conditional writes still run during setup -->
```js
    {
      code: `import { createSignal, createStore } from "solid-js";
function App(props) {
  const [store, setStore] = createStore({ ready: false });
  if (props.eager) setStore((draft) => { draft.ready = true; });
  return <div>{String(store.ready)}</div>;
}`,
      errors: [{ messageId: "writeInComponent" }],
    },
```

## 3. Non-reports (valid cases, verbatim)

Source: `test/rules/no-write-in-pure-computation.test.ts`, `valid:` array, raw lines 6–114. Grouped by the source comment that precedes each run of cases (the comment is the upstream reason).

### 3.1 the effect half is the sanctioned place for writes

```js
    // the effect half is the sanctioned place for writes
    `import { createSignal, createEffect } from "solid-js";
const [count, setCount] = createSignal(0);
const [double, setDouble] = createSignal(0);
createEffect(() => count(), (value) => setDouble(value * 2));`,
```

### 3.2 event handlers and other deferred functions write outside the computation

```js
    // event handlers and other deferred functions write outside the computation
    `import { createSignal, createMemo } from "solid-js";
const [count, setCount] = createSignal(0);
const handler = createMemo(() => () => setCount(count() + 1));`,
    `import { createSignal } from "solid-js";
const [count, setCount] = createSignal(0);
setCount(5);`,
```

### 3.3 reads inside a memo are what memos are for

```js
    // reads inside a memo are what memos are for
    `import { createSignal, createMemo } from "solid-js";
const [count, setCount] = createSignal(0);
const double = createMemo(() => count() * 2);`,
```

### 3.4 functions that aren't tuple setters are not writes

```js
    // functions that aren't tuple setters are not writes
    `import { createMemo } from "solid-js";
const result = createMemo(() => transform(input()));`,
```

### 3.5 `ownedWrite: true` opts a signal into owned-scope writes; core skips its dev guard for these, and its error message steers users to the option

```js
    // `ownedWrite: true` opts a signal into owned-scope writes; core skips its
    // dev guard for these, and its error message steers users to the option
    `import { createSignal, createMemo } from "solid-js";
const [cache, setCache] = createSignal(0, { ownedWrite: true });
const value = createMemo(() => {
  setCache(compute());
  return cache();
});`,
    `import { createSignal, createEffect } from "solid-js";
const [last, setLast] = createSignal("", { name: "last", ownedWrite: true });
createEffect(() => {
  setLast(query());
  return query();
}, (value) => console.log(value));`,
```

### 3.6 the opt-in resolves through one level of const indirection

```js
    // the opt-in resolves through one level of const indirection
    `import { createSignal, createMemo } from "solid-js";
const opts = { ownedWrite: true };
const [cache, setCache] = createSignal(0, opts);
const value = createMemo(() => {
  setCache(compute());
  return cache();
});`,
```

### 3.7 options we can't read statically may contain the opt-in; stay quiet

```js
    // options we can't read statically may contain the opt-in; stay quiet
    `import { createSignal, createMemo } from "solid-js";
const [cache, setCache] = createSignal(0, signalOptions);
const value = createMemo(() => {
  setCache(compute());
  return cache();
});`,
```

### 3.8 a later property write makes the literal read inconclusive; stay quiet

```js
    // a later property write makes the literal read inconclusive; stay quiet
    `import { createSignal, createMemo } from "solid-js";
const opts = { name: "cache" };
opts.ownedWrite = true;
const [cache, setCache] = createSignal(0, opts);
const value = createMemo(() => {
  setCache(compute());
  return cache();
});`,
    `import { createSignal, createMemo } from "solid-js";
const [cache, setCache] = createSignal(0, { ...baseOptions });
const value = createMemo(() => {
  setCache(compute());
  return cache();
});`,
```

### 3.9 writes in a component belong in callbacks — all exempt via the nearest-enclosing-function discipline, no name-listing needed

```js
    // writes in a component belong in callbacks — all exempt via the
    // nearest-enclosing-function discipline, no name-listing needed
    `import { createSignal, onSettled, createTrackedEffect } from "solid-js";
function Counter() {
  const [count, setCount] = createSignal(0);
  onSettled(() => setCount(1));
  createTrackedEffect(() => setCount(count() + 1));
  const onClick = () => setCount(count() + 1);
  return <button onClick={onClick}>{count()}</button>;
}`,
```

### 3.10 effect halves inside components are imperative scopes

```js
    // effect halves inside components are imperative scopes
    `import { createSignal, createEffect } from "solid-js";
function Tracker() {
  const [pos, setPos] = createSignal(0);
  const [log, setLog] = createSignal("");
  createEffect(() => pos(), (value) => setLog(String(value)));
  return <div>{log()}</div>;
}`,
```

### 3.11 lowercase helpers and data callbacks that contain JSX aren't components

```js
    // lowercase helpers and data callbacks that contain JSX aren't components
    `import { createSignal } from "solid-js";
const [flag, setFlag] = createSignal(false);
function renderReset() {
  setFlag(false);
  return <div />;
}`,
    `import { createSignal } from "solid-js";
const [n, setN] = createSignal(0);
const rows = items.map((item) => {
  setN(item.id);
  return <li>{item.name}</li>;
});`,
```

### 3.12 ownedWrite signals may be written during setup too

```js
    // ownedWrite signals may be written during setup too
    `import { createSignal } from "solid-js";
function Widget() {
  const [cache, setCache] = createSignal(0, { ownedWrite: true });
  setCache(1);
  return <div>{cache()}</div>;
}`,
```

### 3.13 functions without JSX are not components; a custom primitive's writes are its own business (and un-provable here anyway)

```js
    // functions without JSX are not components; a custom primitive's writes
    // are its own business (and un-provable here anyway)
    `import { createSignal } from "solid-js";
function useCounter() {
  const [count, setCount] = createSignal(0);
  setCount(1);
  return count;
}`,
```

## 4. Options and implementation notes

- **Options:** none. `schema: []`, `defaultOptions: []`. The `ownedWrite` exemption is read from the signal's own options argument, not from rule options.
- **Setter recognition** (`isSetter`): `id` must be `declId.elements[1]` of an `ArrayPattern` declarator whose init is a call to an identifier callee matched by `matchImport(["createSignal", "createStore", "createOptimistic"], …)`. **`createOptimisticStore` is not in this list**, so `const [s, setS] = createOptimisticStore(...)` setter calls are never reported (the reactivity rule *does* treat that pair as a store). Setter callee must be a plain `Identifier` (`obj.setX(...)` is ignored).
- **Computation registration** (on `CallExpression`, before descendants are visited):
  - `createMemo` (import-matched): if `arguments[0]` is a function node, register it as `{ messageId: "writeInMemo", api: "createMemo" }`.
  - `createEffect` / `createRenderEffect` (import-matched) with `arguments.length >= 2`: if `arguments[0]` is a function, register it as `{ messageId: "writeInCompute", api: <imported name> }`. The effect half (`arguments[1]`) is not registered.
- **Enclosing function:** `findParent(node, isFunctionNode)` — the *nearest* function only. A setter call in `createMemo(() => items.map((x) => { setN(x) }))` belongs to the inner arrow, not the memo.
- **Component detection** (`isComponent`, mirrors `no-destructure`): the function's name (`FunctionDeclaration`/`FunctionExpression` id, or `VariableDeclarator` id) must not start with a lowercase letter (anonymous functions pass); the function must not be a `JSXExpressionContainer` child; and it must not be a `CallExpression` argument unless the callee `Identifier` name starts with an uppercase letter (member callees like `items.map(...)` make it a non-component). `hasJSX` is set only by `JSXElement`/`JSXFragment` whose nearest function is this function.
- **Deferred report:** unregistered, non-computation setter calls are queued per enclosing function and reported at `:function:exit` only if `hasJSX && !computations.has(node) && isComponent(node)`. Diagnostic `node` is the setter call expression.
- **`ownedWrite` (`allowsOwnedWrite`), verbatim:**

```ts
    const allowsOwnedWrite = (init: T.CallExpression): boolean => {
      let options: T.Node | undefined = init.arguments[1];
      if (!options) return false;
      if (options.type === "Identifier") {
        const variable = findVariable(context, options);
        const def = variable?.defs[0];
        if (
          variable?.defs.length !== 1 ||
          def?.type !== "Variable" ||
          def.node.parent?.kind !== "const" ||
          !def.node.init ||
          // A const holding an object can still be given properties later
          // (`opts.ownedWrite = true`); any reference that mutates the object
          // or escapes it (passed elsewhere, aliased) makes the literal read
          // inconclusive. Only references that ARE the options argument of a
          // signal creation keep it conclusive.
          variable.references.some(
            (ref) =>
              ref.identifier !== def.node.id &&
              !(
                ref.identifier.parent?.type === "CallExpression" &&
                ref.identifier.parent.arguments[1] === ref.identifier
              )
          )
        ) {
          return true;
        }
        options = def.node.init;
      }
      if (options.type !== "ObjectExpression") return true;
      return options.properties.some(
        (property) =>
          property.type === "SpreadElement" ||
          ((property.key.type === "Identifier"
            ? property.key.name === "ownedWrite"
            : property.key.type === "Literal" && property.key.value === "ownedWrite") &&
            !(property.value.type === "Literal" && property.value.value === false))
      );
    };
```

  Reading it: no options argument → not exempt (reported). Identifier options that cannot be proven → exempt (silent). Object literal → exempt if it has a spread, or an `ownedWrite` key whose value is not the literal `false` (so `ownedWrite: someVar` is exempt). Non-object, non-identifier options (e.g. a call) → exempt. The check is called only for `createSignal`, `createOptimistic`; `createStore` skips it (`primitive !== "createStore" && allowsOwnedWrite(init)`).
- **Messages (`{{name}}` = setter identifier name; `{{api}}` only in `writeInCompute`):** see §2a.
- **Not checked:** setters from custom primitives, `createOptimisticStore` setters, member-callee setter calls, and writes that happen through an alias of the setter.

## 5. Severity

- `recommended`: **not listed** → off (docs: "This rule is **off** by default.").
- `v2`: `"solid/no-write-in-pure-computation": 2` (error). Comment: `// writes inside memos/compute halves create cycles and throw in 2.0 dev`.
- `v2-strict`: inherits error via `...v2.rules`.
