# solid/no-single-arg-create-effect — upstream spec (eslint-plugin-solid v0.18.1)

Upstream files: `docs/no-single-arg-create-effect.md`, `src/rules/no-single-arg-create-effect.ts`, `test/rules/no-single-arg-create-effect.test.ts` (snapshots in `../raw/`, flattened names). Rule key: `solid/no-single-arg-create-effect`. Source import-tracking via `trackImports(getSolidSourceRegex(context))`.

## 1. What it reports

Any call to `createEffect` or `createRenderEffect` (identifier callee, resolved through an import from a Solid source) with exactly one argument. The message ids differ by callee: `singleArgEffect` for `createEffect`, `singleArgRenderEffect` for `createRenderEffect`. The report node is the whole `CallExpression`. The rule does not inspect the argument, so a single-argument call with any expression (including a spread, `createEffect(...fns)`, or a named function `createEffect(myEffect)`) is reported. Zero-argument calls and two- or three-argument calls are not reported. Docs: "Require the two-argument `createEffect(compute, effect)` form used by Solid 2.0."


## 2. Reported shapes (invalid cases, verbatim)

Source: `test/rules/no-single-arg-create-effect.test.ts`, `invalid:` array, raw lines 14–23. 2 cases. Every block below is a raw slice of that file.

### 2a. Message texts (verbatim literals from `src/rules/no-single-arg-create-effect.ts`)

| messageId | literal | upstream invalid cases |
|---|---|---|
| `singleArgEffect` | `"In Solid 2.0, createEffect takes separate compute and effect functions: `createEffect(() => signal(), (value) => doWork(value))`. For a derived value use `createMemo`; for a one-shot side effect, just call the function directly."` | 1 |
| `singleArgRenderEffect` | `"In Solid 2.0, createRenderEffect takes separate compute and effect functions: `createRenderEffect(() => signal(), (value) => doWork(value))`."` | 1 |

### 2b. Summary table

| # | messageId(s) | data / options | test lines | leading comment (verbatim) |
|---|---|---|---|---|
| 1 | `singleArgEffect` |  | 14–18 |  |
| 2 | `singleArgRenderEffect` |  | 19–23 |  |

### 2c. Cases grouped by messageId (code verbatim)

#### `singleArgEffect`

**Case 1** — lines 14–18

```js
    {
      code: `import { createEffect } from "solid-js";
createEffect(() => console.log(count()));`,
      errors: [{ messageId: "singleArgEffect" }],
    },
```

#### `singleArgRenderEffect`

**Case 2** — lines 19–23

```js
    {
      code: `import { createRenderEffect } from "solid-js";
createRenderEffect(() => update(count()));`,
      errors: [{ messageId: "singleArgRenderEffect" }],
    },
```

## 3. Non-reports (valid cases, verbatim)

Source: `test/rules/no-single-arg-create-effect.test.ts`, `valid:` array, raw lines 6–11. Grouped by the source comment that precedes each run of cases (the comment is the upstream reason).

### 3.1 no source comment

```js
    `import { createEffect } from "solid-js";
createEffect(() => count(), (value) => console.log(value));`,
    `import { createEffect } from "solid-js";
createEffect(count, (value) => console.log(value), { name: "logger" });`,
    `import { createRenderEffect } from "solid-js";
createRenderEffect(() => count(), (value) => update(value));`,
```

## 4. Options and implementation notes

- **Options:** none. `meta.schema: []`, `defaultOptions: []`, `Options = []`.
- **Import gating:** `matchImport("createEffect", node.callee.name)` / `matchImport("createRenderEffect", node.callee.name)`. Aliases are honored (`import { createEffect as ce }` → `ce(x)` is checked); a same-named function that is not imported from a Solid source is not.
- **Source regex:** `getSolidSourceRegex(context)`, i.e. `solid-js` (and subpaths), `@solidjs/signals`, `@solidjs/web`, plus any exact names in `settings.solid.moduleSources`.
- **Version:** the rule does not read `settings.solid.version`. It is identical under v1 and v2 settings; it is only *enabled* by the `v2` config (see §5).
- **Not checked:** `createTrackedEffect`, member callees (`solid.createEffect(x)`), and the argument's shape.

Core logic, verbatim from `src/rules/no-single-arg-create-effect.ts`:

```ts
  create(context) {
    const { matchImport, handleImportDeclaration } = trackImports(getSolidSourceRegex(context));

    return {
      ImportDeclaration: handleImportDeclaration,
      CallExpression(node) {
        if (node.callee.type !== "Identifier" || node.arguments.length !== 1) return;
        if (matchImport("createEffect", node.callee.name)) {
          context.report({ node, messageId: "singleArgEffect" });
        } else if (matchImport("createRenderEffect", node.callee.name)) {
          context.report({ node, messageId: "singleArgRenderEffect" });
        }
      },
    };
  },
```

## 5. Severity

- `recommended` (`src/configs/recommended.ts`): **not listed** → off.
- `v2` (`src/configs/v2.ts`): `"solid/no-single-arg-create-effect": 2` (error). Comment there: `// 2.0 requires the split createEffect(compute, effect) form`.
- `v2-strict` (`src/configs/v2-strict.ts`): inherits `v2` via `...v2.rules` → error.
- Rule docs header: "This rule is **off** by default."

Default-off outside v2 configs; `settings.solid.version` is not consulted, so enabling the rule under a v1 project would still flag single-argument calls.
