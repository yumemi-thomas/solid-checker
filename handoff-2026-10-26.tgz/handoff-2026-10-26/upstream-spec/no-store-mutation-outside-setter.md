# solid/no-store-mutation-outside-setter — upstream spec (eslint-plugin-solid v0.18.1)

Upstream files: `docs/no-store-mutation-outside-setter.md`, `src/rules/no-store-mutation-outside-setter.ts`, `test/rules/no-store-mutation-outside-setter.test.ts` (snapshots in `../raw/`, flattened names). Rule key: `solid/no-store-mutation-outside-setter`.

## 1. What it reports

A mutation whose base identifier resolves, through its `const` declaration, to a `createStore` read proxy (`const [store, setStore] = createStore(...)`) or to a `createProjection` result (`const p = createProjection(...)`). Mutations are: an assignment to a member (`store.a.b = x`, including compound operators), an update (`store.n++`), a `delete` of a member, or a call to one of nine in-place array methods on a member (`store.items.push(x)`). Store mutations report `mutateStore` ("silently ignored"); projection mutations report `mutateProjection`. Mutations inside the setter callback are also reported when they target the read proxy (`setStore(() => { store.count = 5; })`). Writes through the setter's draft parameter are never reported because the draft is a different binding. Docs: "Disallow mutating a store's read proxy; store state changes only through the setter's mutable draft."


## 2. Reported shapes (invalid cases, verbatim)

Source: `test/rules/no-store-mutation-outside-setter.test.ts`, `invalid:` array, raw lines 34–80. 7 cases. Every block below is a raw slice of that file.

### 2a. Message texts (verbatim literals from `src/rules/no-store-mutation-outside-setter.ts`)

| messageId | literal | upstream invalid cases |
|---|---|---|
| `mutateStore` | `"'{{name}}' is a store's read proxy, which is read-only; this mutation is silently ignored — no error, no update, the write just vanishes. Mutate the draft inside the setter instead: `{{setter}}(draft => { ... })`."` | 6 |
| `mutateProjection` | `"'{{name}}' is a projection, a read-only derived store. Derive this value inside the projection function instead of mutating the result."` | 1 |

### 2b. Summary table

| # | messageId(s) | data / options | test lines | leading comment (verbatim) |
|---|---|---|---|---|
| 1 | `mutateStore` |  | 34–39 |  |
| 2 | `mutateStore` |  | 40–45 |  |
| 3 | `mutateStore` |  | 46–51 |  |
| 4 | `mutateStore` |  | 52–57 |  |
| 5 | `mutateStore` |  | 58–63 |  |
| 6 | `mutateStore` |  | 65–72 | // mutating the read proxy is wrong even inside the setter — use the draft |
| 7 | `mutateProjection` |  | 73–80 |  |

### 2c. Cases grouped by messageId (code verbatim)

#### `mutateStore`

**Case 1** — lines 34–39

```js
    {
      code: `import { createStore } from "solid-js";
const [store, setStore] = createStore({ count: 0 });
store.count = 5;`,
      errors: [{ messageId: "mutateStore" }],
    },
```

**Case 2** — lines 40–45

```js
    {
      code: `import { createStore } from "solid-js";
const [store, setStore] = createStore({ count: 0 });
store.count++;`,
      errors: [{ messageId: "mutateStore" }],
    },
```

**Case 3** — lines 46–51

```js
    {
      code: `import { createStore } from "solid-js";
const [store, setStore] = createStore({ items: [] });
store.items.push(item);`,
      errors: [{ messageId: "mutateStore" }],
    },
```

**Case 4** — lines 52–57

```js
    {
      code: `import { createStore } from "solid-js";
const [store, setStore] = createStore({ user: { name: "a" } });
delete store.user.name;`,
      errors: [{ messageId: "mutateStore" }],
    },
```

**Case 5** — lines 58–63

```js
    {
      code: `import { createStore } from "solid-js";
const [store, setStore] = createStore({ nested: { deep: { value: 0 } } });
store.nested.deep.value = 1;`,
      errors: [{ messageId: "mutateStore" }],
    },
```

**Case 6** — lines 65–72

<!-- // mutating the read proxy is wrong even inside the setter — use the draft -->
```js
    {
      code: `import { createStore } from "solid-js";
const [store, setStore] = createStore({ count: 0 });
setStore(() => {
  store.count = 5;
});`,
      errors: [{ messageId: "mutateStore" }],
    },
```

#### `mutateProjection`

**Case 7** — lines 73–80

```js
    {
      code: `import { createProjection } from "solid-js";
const selected = createProjection((draft) => {
  draft[selectedId()] = true;
});
selected.other = true;`,
      errors: [{ messageId: "mutateProjection" }],
    },
```

## 3. Non-reports (valid cases, verbatim)

Source: `test/rules/no-store-mutation-outside-setter.test.ts`, `valid:` array, raw lines 6–31. Grouped by the source comment that precedes each run of cases (the comment is the upstream reason).

### 3.1 no source comment

```js
    `import { createStore } from "solid-js";
const [store, setStore] = createStore({ count: 0 });
setStore((draft) => {
  draft.count++;
});
console.log(store.count);`,
```

### 3.2 a shadowing parameter is the draft, not the read proxy

```js
    // a shadowing parameter is the draft, not the read proxy
    `import { createStore } from "solid-js";
const [store, setStore] = createStore({ count: 0 });
setStore((store) => {
  store.count = 5;
});`,
```

### 3.3 snapshots are plain data and free to mutate

```js
    // snapshots are plain data and free to mutate
    `import { createStore, snapshot } from "solid-js";
const [store, setStore] = createStore({ items: [] });
const copy = snapshot(store);
copy.items.push(1);`,
```

### 3.4 non-mutating methods read through the proxy

```js
    // non-mutating methods read through the proxy
    `import { createStore } from "solid-js";
const [store, setStore] = createStore({ items: [] });
const doubled = store.items.map((n) => n * 2);
setStore((draft) => (draft.items = doubled));`,
```

### 3.5 plain objects are not stores

```js
    // plain objects are not stores
    `const obj = { count: 0 };
obj.count++;
delete obj.count;`,
```

## 4. Options and implementation notes

- **Options:** none. `schema: []`, `defaultOptions: []`.
- **Store detection** (`resolveTarget`): `findVariable(context, id)?.defs[0]` must be a `Variable` def with an `init`. For a store: `declId` is an `ArrayPattern`, `declId.elements[0]` is an `Identifier` with the *same name* as the base identifier, and `init` is a call whose callee is an identifier matching `matchImport("createStore", …)`. Only `createStore` is recognised — `createOptimisticStore` is **not** in this list. The setter name reported in the message is `declId.elements[1]` if it is an identifier, otherwise the fallback `"setStore"`.
- **Projection detection:** `declId.type === "Identifier"` and the init callee matches `matchImport("createProjection", …)`.
- **Base identifier:** `baseIdentifier` walks `MemberExpression.object` links only (so `store.a[0].b` → `store`). Calls, computed keys and other wrappers stop the walk and return `null` (not reported). Parameters, plain objects, `snapshot(store)` results and `store.items.map(...)` are all non-matches because their defs are not a `createStore`/`createProjection` `Variable`.
- **Shadowing:** resolution is by scope (`findVariable`), so a setter parameter named `store` is a `Parameter` def and is never a target. This is what makes `setStore((store) => { store.count = 5; })` valid.
- **Mutation sites** (`checkMutation(member, reportNode)`):
  - `AssignmentExpression` where `left` is a `MemberExpression` → report node = the whole assignment (any operator; plain `store = x` is not a member and is not reported).
  - `UpdateExpression` with a `MemberExpression` argument → report node = the update.
  - `UnaryExpression` with `operator === "delete"` and a `MemberExpression` argument → report node = the unary.
  - `CallExpression` whose callee is a `MemberExpression` whose `property` node is an `Identifier` with a name in the list below → report node = the call. This is name-based and does not check `computed`: `store.items.push(x)` matches, and so does `store[push](x)` where `push` is any identifier. The string form `store["push"](x)` does not match (its property is a `Literal`).
- **Mutating methods (`MUTATING_METHODS`), verbatim:**

```ts
// Array methods that mutate their receiver in place.
const MUTATING_METHODS = new Set([
  "push",
  "pop",
  "shift",
  "unshift",
  "splice",
  "sort",
  "reverse",
  "fill",
  "copyWithin",
]);
```

- **Messages used:** `mutateStore` → `{{name}}` = base identifier text; `{{setter}}` = setter name (or `setStore`). `mutateProjection` → `{{name}}` only.
- **Not checked:** `Object.assign(store, …)`, `Reflect` calls, `store.items.length = 0` is an assignment and *is* checked (member on the left), `splice`-like helpers from libraries, and any mutation through an alias (`const s = store; s.x = 1`) — `s` is a `Variable` whose init is an identifier, not a `createStore` call.

Core `resolveTarget` and `checkMutation` logic, verbatim from `src/rules/no-store-mutation-outside-setter.ts`:

```ts
    /** Resolves an identifier to the store or projection it names, if any. */
    const resolveTarget = (id: T.Identifier): Target | null => {
      const def = findVariable(context, id)?.defs[0];
      if (!def || def.type !== "Variable" || !def.node.init) return null;
      const { id: declId, init } = def.node;
      if (init.type !== "CallExpression" || init.callee.type !== "Identifier") return null;

      // const [store, setStore] = createStore(...)
      if (
        declId.type === "ArrayPattern" &&
        declId.elements[0]?.type === "Identifier" &&
        declId.elements[0].name === id.name &&
        matchImport("createStore", init.callee.name)
      ) {
        const setter = declId.elements[1]?.type === "Identifier" ? declId.elements[1].name : null;
        return { kind: "store", setter };
      }
      // const projected = createProjection(...)
      if (declId.type === "Identifier" && matchImport("createProjection", init.callee.name)) {
        return { kind: "projection" };
      }
      return null;
    };
```

## 5. Severity

- `recommended`: **not listed** → off (docs header: "This rule is **off** by default.").
- `v2`: `"solid/no-store-mutation-outside-setter": 2` (error). Comment: `// the store read proxy is read-only; mutations go through the setter's draft`.
- `v2-strict`: inherits error via `...v2.rules`.
- Docs also state the v2 config enables it as an error.
