# solid/no-single-arg-create-effect — upstream spec (eslint-plugin-solid v0.18.1)

Upstream files: `docs/no-single-arg-create-effect.md`, `src/rules/no-single-arg-create-effect.ts`, `test/rules/no-single-arg-create-effect.test.ts` (snapshots in `../raw/`, flattened names). Rule key: `solid/no-single-arg-create-effect`. Source import-tracking via `trackImports(getSolidSourceRegex(context))`.

## 1. What it reports

Any call to `createEffect` or `createRenderEffect` (identifier callee, resolved through an import from a Solid source) with exactly one argument. The message ids differ by callee: `singleArgEffect` for `createEffect`, `singleArgRenderEffect` for `createRenderEffect`. The report node is the whole `CallExpression`. The rule does not inspect the argument, so a single-argument call with any expression (including a spread, `createEffect(...fns)`, or a named function `createEffect(myEffect)`) is reported. Zero-argument calls and two- or three-argument calls are not reported. Docs: "Require the two-argument `createEffect(compute, effect)` form used by Solid 2.0."

