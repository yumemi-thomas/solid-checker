## 4. Options and implementation notes

- **Options:** none. `schema: []`, `defaultOptions: []`. The `ownedWrite` exemption is read from the signal's own options argument, not from rule options.
- **Setter recognition** (`isSetter`): `id` must be `declId.elements[1]` of an `ArrayPattern` declarator whose init is a call to an identifier callee matched by `matchImport(["createSignal", "createStore", "createOptimistic"], …)`. **`createOptimisticStore` is not in this list**, so `const [s, setS] = createOptimisticStore(...)` setter calls are never reported (the reactivity rule *does* treat that pair as a store). Setter callee must be a plain `Identifier` (`obj.setX(...)` is ignored).
- **Computation registration** (on `CallExpression`, before descendants are visited):
  - `createMemo` (import-matched): if `arguments[0]` is a function node, register it as `{ messageId: "writeInMemo", api: "createMemo" }`.
  - `createEffect` / `createRenderEffect` (import-matched) with `arguments.length >= 2`: if `arguments[0]` is a function, register it as `{ messageId: "writeInCompute", api: <imported name> }`. The effect half (`arguments[1]`) is not registered.
- **Enclosing function:** `findParent(node, isFunctionNode)` — the *nearest* function only. A setter call in `createMemo(() => items.map((x) => { setN(x) }))` belongs to the inner arrow, not the memo.
- **Component detection** (`isComponent`, mirrors `no-destructure`): the function's name (`FunctionDeclaration`/`FunctionExpression` id, or `VariableDeclarator` id) must not start with a lowercase letter (anonymous functions pass); the function must not be a `JSXExpressionContainer` child; and it must not be a `CallExpression` argument unless the callee `Identifier` name starts with an uppercase letter (member callees like `items.map(...)` make it a non-component). `hasJSX` is set only by `JSXElement`/`JSXFragment` whose nearest function is this function.
- **Deferred report:** unregistered, non-computation setter calls are queued per enclosing function and reported at `:function:exit` only if `hasJSX && !computations.has(node) && isComponent(node)`. Diagnostic `node` is the setter call expression.
- **`ownedWrite` (`allowsOwnedWrite`), verbatim:**

```ts
    const allowsOwnedWrite = (init: T.CallExpression): boolean => {
      let options: T.Node | undefined = init.arguments[1];
      if (!options) return false;
      if (options.type === "Identifier") {
        const variable = findVariable(context, options);
        const def = variable?.defs[0];
        if (
          variable?.defs.length !== 1 ||
          def?.type !== "Variable" ||
          def.node.parent?.kind !== "const" ||
          !def.node.init ||
          // A const holding an object can still be given properties later
          // (`opts.ownedWrite = true`); any reference that mutates the object
          // or escapes it (passed elsewhere, aliased) makes the literal read
          // inconclusive. Only references that ARE the options argument of a
          // signal creation keep it conclusive.
          variable.references.some(
            (ref) =>
              ref.identifier !== def.node.id &&
              !(
                ref.identifier.parent?.type === "CallExpression" &&
                ref.identifier.parent.arguments[1] === ref.identifier
              )
          )
        ) {
          return true;
        }
        options = def.node.init;
      }
      if (options.type !== "ObjectExpression") return true;
      return options.properties.some(
        (property) =>
          property.type === "SpreadElement" ||
          ((property.key.type === "Identifier"
            ? property.key.name === "ownedWrite"
            : property.key.type === "Literal" && property.key.value === "ownedWrite") &&
            !(property.value.type === "Literal" && property.value.value === false))
      );
    };
```

  Reading it: no options argument → not exempt (reported). Identifier options that cannot be proven → exempt (silent). Object literal → exempt if it has a spread, or an `ownedWrite` key whose value is not the literal `false` (so `ownedWrite: someVar` is exempt). Non-object, non-identifier options (e.g. a call) → exempt. The check is called only for `createSignal`, `createOptimistic`; `createStore` skips it (`primitive !== "createStore" && allowsOwnedWrite(init)`).
- **Messages (`{{name}}` = setter identifier name; `{{api}}` only in `writeInCompute`):** see §2a.
- **Not checked:** setters from custom primitives, `createOptimisticStore` setters, member-callee setter calls, and writes that happen through an alias of the setter.

## 5. Severity

- `recommended`: **not listed** → off (docs: "This rule is **off** by default.").
- `v2`: `"solid/no-write-in-pure-computation": 2` (error). Comment: `// writes inside memos/compute halves create cycles and throw in 2.0 dev`.
- `v2-strict`: inherits error via `...v2.rules`.
