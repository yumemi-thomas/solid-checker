# solid/no-write-in-pure-computation — upstream spec (eslint-plugin-solid v0.18.1)

Upstream files: `docs/no-write-in-pure-computation.md`, `src/rules/no-write-in-pure-computation.ts`, `test/rules/no-write-in-pure-computation.test.ts` (snapshots in `../raw/`, flattened names). Rule key: `solid/no-write-in-pure-computation`.

## 1. What it reports

A call to a *setter* (the second element of a `createSignal`, `createStore` or `createOptimistic` destructure, resolved by import) whose nearest enclosing function is a pure owned scope:

- the callback of `createMemo(fn)` → `writeInMemo`;
- the first (compute) argument of `createEffect(compute, effect)` or `createRenderEffect(compute, effect)` when called with two or more arguments → `writeInCompute` (the message names the API);
- a component body: a function that contains JSX directly, whose name is not lowercase, that is not a render prop, and that is not a plain call argument → `writeInComponent`. Component status is decided at the function's exit.

Setter calls inside a nested function (event handler, `onSettled`, `createTrackedEffect`, the effect half, any other callback) are not reported. Setter calls at module scope (no enclosing function) are not reported. A signal created with `ownedWrite: true` is exempt, but only for signal and optimistic setters, never for `createStore`. Docs: "Disallow writing signals or stores inside `createMemo`, the compute half of `createEffect`, or a component body, which are pure owned scopes."

