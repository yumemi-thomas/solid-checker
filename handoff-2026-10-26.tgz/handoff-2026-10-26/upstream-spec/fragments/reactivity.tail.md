## 4. Options, version handling, and the mechanisms behind each message

### Options

- **Schema** (verbatim): one property `customReactiveFunctions` — `type: "array"`, `items: { type: "string" }`, `default: []`; `additionalProperties: false`. Description: "List of function names to consider as reactive functions (allow signals to be safely passed as arguments). Supports exact names, '*' wildcards ('use*Store'), and regexes given as '/pattern/' strings. In addition, any create* or use* functions are automatically included."
- **Default:** `defaultOptions: [{ customReactiveFunctions: [] }]`. Docs: "Manually configuring an array will *replace* the defaults."
- **Matching:** `createNameMatcher(options.customReactiveFunctions)`, same grammar as `valid-use-server`'s `clientWrappers` (exact; `*` → `[a-zA-Z0-9_$]*` anchored; `/…/` → unanchored regex; invalid regex → exact). Always-on: any callee or member property matching `/^(?:use|create)[A-Z]/`.
- **Where the matcher applies:** a call with an `Identifier` callee, or a member callee whose property name matches (e.g. `X.createFoo(() => bar())`). Its arguments go through `permissivelyTrackNode`, which marks every function or identifier argument (not member-object identifiers, not callee identifiers) as `called-function` and skips into their children.

### Solid 2.0 mode

- `v2 = isSolidV2(context)`: true when `settings.solid.version` is a number or numeric string ≥ 2 (`getSolidVersion` in `src/utils.ts`). **The rule's own test file never sets `settings.solid.version`**, so every upstream case runs in the v1 branch (only the `moduleSources` test sets settings).
- The only behavioural switch in the rule body: a bare signal used as a DOM attribute value (`<button type={signal}>`) reports `badSignal` with `where: "JSX"` only when `!v2`. In v2 it is left to `solid/no-accessor-as-prop` (same node is never reported twice).
- Solid 2.0 names are recognised unconditionally (not gated on `v2`): `merge`, `omit`, `createProjection`, `createOptimistic`, `createOptimisticStore`, `createTrackedEffect`, `isPending`, `latest`, `resolve`, `deep`, `repeat`, `createErrorBoundary`, `createLoadingBoundary`, `createRevealOrder`, `dynamic`, `onSettled`, `flush`, `action`, `keyed` on `<For>`.
- Module sources: `getSolidSourceRegex(context)`, so `@solidjs/signals` and `@solidjs/web` imports count, and `settings.solid.moduleSources` adds exact names.

### Reactive-value producers (`checkForReactiveAssignment`): matcher lines verbatim, bodies summarised

```ts
        if (matchImport(["createSignal", "useTransition", "createOptimistic"], callee.name)) {
          // first element is the signal; no destructure → shouldDestructure "first"
        } else if (matchImport(["createMemo", "createSelector"], callee.name)) {
          // whole variable is the signal; no capture → shouldAssign
        } else if (matchImport(["createStore", "createOptimisticStore"], callee.name)) {
          // first element is a props-kind store; no destructure → shouldDestructure "first"
        } else if (matchImport(["mergeProps", "merge", "omit"], callee.name)) {
          // whole variable is a props object; no capture → shouldAssign
        } else if (matchImport("splitProps", callee.name)) {
          // array pattern: every element is props; empty → shouldDestructure (no nth)
        } else if (matchImport("createResource", callee.name)) {
          // first element is a props-kind value; no warning if absent
        } else if (matchImport(["createMutable", "createProjection"], callee.name)) {
          // whole variable is a props-kind value
        } else if (matchImport("mapArray", callee.name)) {
          // second callback parameter is a signal (index)
        } else if (matchImport("indexArray", callee.name)) {
          // first callback parameter is a signal (value)
        }
```

(Only the `matchImport(...)` lines are verbatim; the bodies are in `checkForReactiveAssignment` in `src/rules/reactivity.ts`, and the comments above are summaries, not quotes.)

Other producers:
- `<For each={…}>{(item, index) => …}</For>` (`"JSXElement > JSXExpressionContainer > :function"` selector): `item` is a signal when `keyed={false}` or `keyed={fn}`; `index` is a signal unless `keyed={false}`. Bare `keyed` and `keyed={true}` behave like 1.x (`item` is a plain value).
- `<Index>{(item, index) => …}</Index>`: `item` is a signal.

### Tracked-scope producers (`checkForTrackedScopes`), by call shape

| Call / node | Tracked scope kind | Note |
|---|---|---|
| `createMemo`, `children`, `createEffect`, `createRenderEffect`, `createDeferred`, `createComputed`, `createSelector`, `mapArray`, `indexArray`, `observable`, `createTrackedEffect`, `isPending`, `latest`, `resolve`, `deep`, `repeat`, `createErrorBoundary`, `createLoadingBoundary`, `createRevealOrder`, `dynamic` — arg 0 | `function` | `createMemo` and `dynamic` allow async (reads before first `await` tracked). Other async callbacks → `noAsyncTrackedScope`. |
| `createEffect` arg 1 (if function); `createErrorBoundary`/`createLoadingBoundary` arg 1 | `called-function` | the effect half and fallbacks are untracked |
| `createSignal`, `createStore`, `createProjection`, `createOptimistic`, `createOptimisticStore` — arg 0 when a function | `function` (async allowed) | function-form derived primitives |
| `createStore({ get x() {…} })` | `function` | getters in the store literal |
| `mergeProps`, `merge` — any function-traced argument | `function` | |
| `createResource(src, fetcher)` / `createResource(fetcher)` | `function` for `src`; fetcher is `called-function` | the fetcher itself is not tracked; `createResource(fetcher)` makes arg 0 `called-function` |
| `on(deps, fn)` | deps: `function`; fn: `called-function` | array deps supported |
| `onMount`, `onCleanup`, `onError`, `onSettled`, `action`, `setInterval`, `setTimeout`, `setImmediate`, `requestAnimationFrame`, `requestIdleCallback`, and `window./globalThis./self.` prefixed timers | `called-function` (arg 0) | |
| `untrack(fn)` | `called-function` | allows async without read-after-await |
| `runWithOwner(owner, fn)` | `function` unless `owner = getOwner()` is in a non-tracked function | |
| `IntersectionObserver`, `MutationObserver`, `PerformanceObserver`, `ReportingObserver`, `ResizeObserver` (`new`) — arg 0 | `called-function` | |
| `addEventListener(type, fn)` — arg 1 | `called-function` | |
| `.then/.catch/.finally(...)` — every argument | `called-function` | |
| `createReactive(fn)` / `createReaction(fn)` | arg 0 → `called-function`; each call of the returned `track(fn)` → arg 0 `function` | |
| `obj.onxxx = () => …` (assignment to lowercase `on*` member) | `called-function` | |
| Tagged template `css\`${fn}\`` function expressions | `called-function` | |
| JSX `on*` attribute on DOM element (`onClick={…}`, `on:click`, `on-click`) | `called-function` | |
| JSX `use:dir={fn}` | `called-function` | |
| JSX `ref={fn}` | `called-function` | |
| JSX function child `{() => …}` directly in an element | `function` | |
| `<Comp staticX={…}>` (component, `static[A-Z]` prop) | none — passing reactive values here is itself reported as untracked | |
| Provider `value={…}` (`X.Provider`, `…Provider` name, or a `createContext()` binding) | none; container recorded for `providerValue` | |
| Any other JSX container / spread | `expression` | |
| Matching `/^(?:use|create)[A-Z]/` or custom name, any argument | permissive: each traced function/identifier → `called-function` | |
| Unknown call inside a tracked scope | function arguments → `called-function` | |
| `mapArray` / `indexArray` / `repeat` — arg 1 (callback) | sync callback (same scope, `syncCallbacks`) | |
| `batch`, `produce`, `flush` — exactly one argument, non-async function | sync callback (same scope) | |
| `.forEach/map/flatMap/reduce/reduceRight/find/findIndex/filter/every/some(fn)` — callee object is not an object literal, exactly one argument, non-async function | sync callback (same scope) | |
| Setter of `createSignal`/`createStore`/`createOptimistic`/`createOptimisticStore` — callbacks passed to the setter call (non-async) | sync callback | |
| IIFE callee | sync callback | |

### Mechanisms by message id (from the source; the cases in §2 are the authority)

| messageId | Triggered when (source) |
|---|---|
| `noWrite` | A signal/memo reference that `isWrite()` (`sig = …`), or a props/store reference that is the object of a direct member assignment (`props.a = …`; one level only, `props.a.b = …` is not caught here). **No upstream test case pins `noWrite`.** |
| `untrackedReactive` | A signal call or props read whose declaration scope is the current function and that is not inside any tracked scope, and not inside a provider `value`, and no expression-kind tracked scope encloses it. `data.name` = `sourceCode.getText(parentMemberExpression)` for member reads, else identifier name. Report node = the member chain or call. |
| `expectedFunctionGotExpression` | Same as `untrackedReactive`, except some tracked-scope node *contains* the read without being the read itself (`findInScope`). Examples: `<div onClick={props.onClick} />` (the container's expression, a `MemberExpression`, is registered as `called-function`) and `createEffect(props.theEffect)`. |
| `providerValue` | Same as untracked, but inside a `value={…}` container of a provider element. |
| `badSignal` | An uncalled signal/memo identifier whose parent is: `TemplateLiteral` ("template literals"); `BinaryExpression` with one of `< <= > >= << >> >>> + - * / % ** \| ^ & in` ("arithmetic or comparisons"); `UnaryExpression` `- + ~` ("unary expressions"); computed `MemberExpression` property ("property accesses"); `JSXExpressionContainer` as a child or, when `!v2`, a DOM attribute ("JSX"). `data.where` carries the label. |
| `badUnnamedDerivedSignal` | An anonymous (or unassigned) function that contains reactive reads and is not matched by a tracked scope in its own scope. `loc` = the function head (`getFunctionHeadLocation`), no `data`. |
| `shouldDestructure` | `createSignal` / `useTransition` / `createOptimistic` / `createStore` / `createOptimisticStore` whose result is not an array pattern with a capturable element 0 (bare call, identifier, object pattern, hole) — `data.nth` = `"first "`; `splitProps` with no identifier element (no `data`, so the message text keeps the literal `{{nth}}`; derived, not test-pinned). `createResource` never reports this (verified: no `warnShouldDestructure` in its branch). |
| `shouldAssign` | `createMemo` / `createSelector` / `mergeProps` / `merge` / `omit` result not captured in a plain identifier (bare call, destructured result, etc.). |
| `noAsyncTrackedScope` | An `async` or generator function registered as a `function` tracked scope where async is not allowed (e.g. `createEffect(async () => …)`, `createResource`'s source). |
| `readAfterAwait` | A signal or props read positioned after the first `await`/`yield` of an async tracked scope: `createMemo`, `dynamic`, or the function-form `createSignal`/`createStore`/`createProjection`/`createOptimistic`/`createOptimisticStore`. A loop containing the first suspension taints the whole loop. Reads in the operands of that first suspension are still tracked. |
| `staleCapture` | A signal call at the setup level of a function, whose result is captured by a variable declared in a `VariableDeclarator` (`const` or `let`), where a nested function reads that variable and escapes the enclosing function via `return` (including wrapping in JSX or an object literal). A function passed as an argument to a call does not escape this way. Captured names starting `initial`, `default`, or `static[A-Z]` are exempt. |

### Documented exemptions that suppress reports (derived from the source)

- A props member read whose property name matches `/^(?:initial|default|static[A-Z])/` (e.g. `props.initialCount`) is not reported.
- Returned functions (`return () => sig()`, arrow body) are accessors handed to the caller and are not required to match a tracked scope.
- Captures whose name starts with `initial`/`default`/`static[A-Z]` are not stale captures.
- `obj.x = props` (storing the whole reactive object into a member, e.g. `this.state = state`) is exempt; `obj.x = props.y` is an ordinary member read and is analysed as one.
- A function passed to an unknown call *outside* any tracked scope is not marked as tracked. The unknown-call fallback only applies inside a `function`/`called-function` scope.

## 5. Severity

- `recommended` (`src/configs/recommended.ts`): `"solid/reactivity": 1` (warn). Comment group: `// reactivity`.
- `v2` (`src/configs/v2.ts`): spreads `...recommended.rules`, so `"solid/reactivity": 1` (warn). The `v2` config also sets `settings.solid.version: 2`, which switches the `!v2` `badSignal` branch off (see above).
- `v2-strict` (`src/configs/v2-strict.ts`): spreads `v2.rules`; no override → warn.
- Docs header: "This rule is **a warning** by default."
