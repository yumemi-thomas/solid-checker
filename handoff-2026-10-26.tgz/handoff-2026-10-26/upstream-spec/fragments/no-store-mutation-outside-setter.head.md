# solid/no-store-mutation-outside-setter — upstream spec (eslint-plugin-solid v0.18.1)

Upstream files: `docs/no-store-mutation-outside-setter.md`, `src/rules/no-store-mutation-outside-setter.ts`, `test/rules/no-store-mutation-outside-setter.test.ts` (snapshots in `../raw/`, flattened names). Rule key: `solid/no-store-mutation-outside-setter`.

## 1. What it reports

A mutation whose base identifier resolves, through its `const` declaration, to a `createStore` read proxy (`const [store, setStore] = createStore(...)`) or to a `createProjection` result (`const p = createProjection(...)`). Mutations are: an assignment to a member (`store.a.b = x`, including compound operators), an update (`store.n++`), a `delete` of a member, or a call to one of nine in-place array methods on a member (`store.items.push(x)`). Store mutations report `mutateStore` ("silently ignored"); projection mutations report `mutateProjection`. Mutations inside the setter callback are also reported when they target the read proxy (`setStore(() => { store.count = 5; })`). Writes through the setter's draft parameter are never reported because the draft is a different binding. Docs: "Disallow mutating a store's read proxy; store state changes only through the setter's mutable draft."

