## 4. Options and implementation notes

### Options

- **Schema** (verbatim `meta.schema`): an object with one property `clientWrappers` — `type: "array"`, `items: { type: "string" }`, `default: []`, `additionalProperties: false`. The description reads: "Additional function names treated as client-side declaration wrappers that must not be called inside a module-level \"use server\" file. Supports exact names, '*' wildcards, and regexes given as '/pattern/' strings. GET, live, withMeta, query, action, and liveQuery are always included."
- **Default:** `defaultOptions: [{ clientWrappers: [] }]`. Docs: "Options shown here are the defaults. Manually configuring an array will *replace* the defaults."
- **Grammar** (`createNameMatcher`, `src/utils.ts`), applied per entry, first match wins:
  1. length > 2 and starts and ends with `/` → `new RegExp(entry.slice(1, -1))`. **Not anchored**, so `"/define/"` also matches `redefine`. An invalid regex falls back to exact string comparison.
  2. contains `*` → split on `*`, escape regex metacharacters in each part, join with `[a-zA-Z0-9_$]*`, wrap in `^…$`. So `define*` matches `define`, `defineLoader`, not `redefine` and not `define-x`.
  3. otherwise exact string equality.
- **Name source:** the matcher is applied to the *local* callee identifier name (`node.callee.name`) and needs no import. It applies to any module-scope call, including locally defined functions.

### Built-in client wrappers

`CLIENT_WRAPPERS` (verbatim, `src/rules/valid-use-server.ts`):

```ts
const CLIENT_WRAPPERS = ["GET", "live", "withMeta", "query", "action", "liveQuery"];
const WRAPPER_SOURCES = /^(?:solid-js|@solidjs\/(?:web|router|start))(?:\/|$)/;
```

- Built-in names are matched by `matchImport(CLIENT_WRAPPERS, name)`: the callee must be a local binding created by an `ImportSpecifier` from `WRAPPER_SOURCES` whose imported name is in the list (aliases are reported under the local name). Source matching is by the regex above, **not** by per-name source: `GET` from `solid-js` or from `@solidjs/start` also matches, and `live`/`withMeta`/`GET` are not restricted to `@solidjs/web`. `handleImportDeclaration` uses `WRAPPER_SOURCES` directly, so `settings.solid.moduleSources` is **not** honoured by this rule.
- Only `Identifier` callees are checked. `router.query(...)` or `api.GET(...)` are ignored.

### Directive placement (how it is judged)

Applied to every `ExpressionStatement` whose expression is a `TemplateLiteral` (with no substitutions and cooked text `use server`) or a `Literal` with value `"use server"`. In order:

1. Template form → `templateDirective`, always (returns before any other check).
2. If the module (`Program` prologue) has `"use server"` (`moduleLevel`) → no further report for any string statement, including misplaced ones.
3. If the nearest enclosing function is itself inside an extracted function (`isInsideUseServerFunction`: some strict *ancestor* function has `"use server"` in its prologue) → no report.
4. Parent is a `Program`, or a `BlockStatement` that is a function body. Otherwise (if/for/bare block, or any other parent) → `misplacedDirective`.
5. Statement must be in the prologue (`getDirectivePrologue(body)`: the maximal leading run of string-literal expression statements). Otherwise → `misplacedDirective`. Consequence (derived from the code; no upstream test pins it): `import x from "y"; "use server";` at module top is `misplacedDirective`, because the prologue ends at the first non-string statement and `moduleLevel` is then false.
6. If the function body is a function and is not inside another extracted function: `getUseServerEligibility(fn)`:
   - `Property` value with `kind !== "init"` (getter/setter) → `accessor`;
   - `Property` value with `method: true` → `objectMethod`;
   - `MethodDefinition` with `kind` `get`/`set` → `accessor`; any other class member → `classMethod`;
   - otherwise `eligible` (standalone functions, arrows, function-valued properties).
   Non-eligible → `ineligiblePosition` with `POSITION_LABELS`: `objectMethod` → "an object method", `accessor` → "a getter or setter", `classMethod` → "a class method".

### Module-level checks

Only when `moduleLevel` is true:

- `ExportNamedDeclaration` with a `VariableDeclaration`: each declarator with an `Identifier` id and an init is checked (`checkExportedValue`).
- `ExportDefaultDeclaration`: the declaration is checked with name `"default"`.
- `checkExportedValue` reports `nonFunctionExport` only when the node is `Literal`, `TemplateLiteral`, `ArrayExpression` or `ObjectExpression`. Identifiers, calls, binary expressions, functions and classes are not reported. `export { x } from "…"` (no declaration) is never reported.
- `CallExpression` whose callee is an `Identifier` and whose nearest enclosing function is none (module scope): matched by built-in import or custom name → `clientWrapper` with `data.name` = local callee name.

`messageId` `nonFunctionExport`'s data key is `name` (`"default"` for default exports).

## 5. Severity

- `recommended`: **not listed** → off (docs: "This rule is **off** by default.").
- `v2`: `"solid/valid-use-server": 2` (error). Comment: `// server functions are core in 2.0; misplaced/ignored "use server" directives and broken module-level directive files are silent failures`.
- `v2-strict`: inherits error via `...v2.rules`.
- Companion rules in v2 (not part of this spec): `solid/require-async-server-function`, `solid/no-invalid-server-capture`, `solid/no-browser-globals-in-server-function`, all error.
