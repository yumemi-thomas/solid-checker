# solid/valid-use-server — upstream spec (eslint-plugin-solid v0.18.1)

Upstream files: `docs/valid-use-server.md`, `src/rules/valid-use-server.ts`, `test/rules/valid-use-server.test.ts` (snapshots in `../raw/`, flattened names; helpers from `src/utils.ts` also in `../raw/src_utils.ts`). Rule key: `solid/valid-use-server`.

## 1. What it reports

Five shapes, all about where the `"use server"` directive is honoured and what a module-level directive file exports or calls:

1. `templateDirective` — a template literal with no substitutions whose cooked text is `use server` at statement position. Reported anywhere, even inside a module-level file.
2. `misplacedDirective` — a string statement `"use server"` that is not in the directive prologue of its Program or function body, unless the whole module or an enclosing extracted function already has the directive (those are silently skipped).
3. `ineligiblePosition` — a valid prologue directive inside an object-literal method, getter/setter, or class method (the compiler never extracts those). Message names the position.
4. `nonFunctionExport` — in a module-level `"use server"` file, an export whose value is a literal, template literal, array or object (`export const X = 1`, `export default {…}`).
5. `clientWrapper` — in a module-level `"use server"` file, a module-scope call to a client-side declaration wrapper (built-in list or `clientWrappers` option), e.g. `query(...)`, `GET(...)`.

Docs: "Enforce that \"use server\" directives are placed where the compiler honors them, and that module-level directive files export working server functions."

