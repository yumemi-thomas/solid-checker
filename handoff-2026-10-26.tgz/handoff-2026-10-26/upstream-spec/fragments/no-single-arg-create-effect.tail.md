## 4. Options and implementation notes

- **Options:** none. `meta.schema: []`, `defaultOptions: []`, `Options = []`.
- **Import gating:** `matchImport("createEffect", node.callee.name)` / `matchImport("createRenderEffect", node.callee.name)`. Aliases are honored (`import { createEffect as ce }` → `ce(x)` is checked); a same-named function that is not imported from a Solid source is not.
- **Source regex:** `getSolidSourceRegex(context)`, i.e. `solid-js` (and subpaths), `@solidjs/signals`, `@solidjs/web`, plus any exact names in `settings.solid.moduleSources`.
- **Version:** the rule does not read `settings.solid.version`. It is identical under v1 and v2 settings; it is only *enabled* by the `v2` config (see §5).
- **Not checked:** `createTrackedEffect`, member callees (`solid.createEffect(x)`), and the argument's shape.

Core logic, verbatim from `src/rules/no-single-arg-create-effect.ts`:

```ts
  create(context) {
    const { matchImport, handleImportDeclaration } = trackImports(getSolidSourceRegex(context));

    return {
      ImportDeclaration: handleImportDeclaration,
      CallExpression(node) {
        if (node.callee.type !== "Identifier" || node.arguments.length !== 1) return;
        if (matchImport("createEffect", node.callee.name)) {
          context.report({ node, messageId: "singleArgEffect" });
        } else if (matchImport("createRenderEffect", node.callee.name)) {
          context.report({ node, messageId: "singleArgRenderEffect" });
        }
      },
    };
  },
```

## 5. Severity

- `recommended` (`src/configs/recommended.ts`): **not listed** → off.
- `v2` (`src/configs/v2.ts`): `"solid/no-single-arg-create-effect": 2` (error). Comment there: `// 2.0 requires the split createEffect(compute, effect) form`.
- `v2-strict` (`src/configs/v2-strict.ts`): inherits `v2` via `...v2.rules` → error.
- Rule docs header: "This rule is **off** by default."

Default-off outside v2 configs; `settings.solid.version` is not consulted, so enabling the rule under a v1 project would still flag single-argument calls.
