## 4. Options and implementation notes

- **Options:** none. `schema: []`, `defaultOptions: []`.
- **Store detection** (`resolveTarget`): `findVariable(context, id)?.defs[0]` must be a `Variable` def with an `init`. For a store: `declId` is an `ArrayPattern`, `declId.elements[0]` is an `Identifier` with the *same name* as the base identifier, and `init` is a call whose callee is an identifier matching `matchImport("createStore", …)`. Only `createStore` is recognised — `createOptimisticStore` is **not** in this list. The setter name reported in the message is `declId.elements[1]` if it is an identifier, otherwise the fallback `"setStore"`.
- **Projection detection:** `declId.type === "Identifier"` and the init callee matches `matchImport("createProjection", …)`.
- **Base identifier:** `baseIdentifier` walks `MemberExpression.object` links only (so `store.a[0].b` → `store`). Calls, computed keys and other wrappers stop the walk and return `null` (not reported). Parameters, plain objects, `snapshot(store)` results and `store.items.map(...)` are all non-matches because their defs are not a `createStore`/`createProjection` `Variable`.
- **Shadowing:** resolution is by scope (`findVariable`), so a setter parameter named `store` is a `Parameter` def and is never a target. This is what makes `setStore((store) => { store.count = 5; })` valid.
- **Mutation sites** (`checkMutation(member, reportNode)`):
  - `AssignmentExpression` where `left` is a `MemberExpression` → report node = the whole assignment (any operator; plain `store = x` is not a member and is not reported).
  - `UpdateExpression` with a `MemberExpression` argument → report node = the update.
  - `UnaryExpression` with `operator === "delete"` and a `MemberExpression` argument → report node = the unary.
  - `CallExpression` whose callee is a `MemberExpression` whose `property` node is an `Identifier` with a name in the list below → report node = the call. This is name-based and does not check `computed`: `store.items.push(x)` matches, and so does `store[push](x)` where `push` is any identifier. The string form `store["push"](x)` does not match (its property is a `Literal`).
- **Mutating methods (`MUTATING_METHODS`), verbatim:**

```ts
// Array methods that mutate their receiver in place.
const MUTATING_METHODS = new Set([
  "push",
  "pop",
  "shift",
  "unshift",
  "splice",
  "sort",
  "reverse",
  "fill",
  "copyWithin",
]);
```

- **Messages used:** `mutateStore` → `{{name}}` = base identifier text; `{{setter}}` = setter name (or `setStore`). `mutateProjection` → `{{name}}` only.
- **Not checked:** `Object.assign(store, …)`, `Reflect` calls, `store.items.length = 0` is an assignment and *is* checked (member on the left), `splice`-like helpers from libraries, and any mutation through an alias (`const s = store; s.x = 1`) — `s` is a `Variable` whose init is an identifier, not a `createStore` call.

Core `resolveTarget` and `checkMutation` logic, verbatim from `src/rules/no-store-mutation-outside-setter.ts`:

```ts
    /** Resolves an identifier to the store or projection it names, if any. */
    const resolveTarget = (id: T.Identifier): Target | null => {
      const def = findVariable(context, id)?.defs[0];
      if (!def || def.type !== "Variable" || !def.node.init) return null;
      const { id: declId, init } = def.node;
      if (init.type !== "CallExpression" || init.callee.type !== "Identifier") return null;

      // const [store, setStore] = createStore(...)
      if (
        declId.type === "ArrayPattern" &&
        declId.elements[0]?.type === "Identifier" &&
        declId.elements[0].name === id.name &&
        matchImport("createStore", init.callee.name)
      ) {
        const setter = declId.elements[1]?.type === "Identifier" ? declId.elements[1].name : null;
        return { kind: "store", setter };
      }
      // const projected = createProjection(...)
      if (declId.type === "Identifier" && matchImport("createProjection", init.callee.name)) {
        return { kind: "projection" };
      }
      return null;
    };
```

## 5. Severity

- `recommended`: **not listed** → off (docs header: "This rule is **off** by default.").
- `v2`: `"solid/no-store-mutation-outside-setter": 2` (error). Comment: `// the store read proxy is read-only; mutations go through the setter's draft`.
- `v2-strict`: inherits error via `...v2.rules`.
- Docs also state the v2 config enables it as an error.
