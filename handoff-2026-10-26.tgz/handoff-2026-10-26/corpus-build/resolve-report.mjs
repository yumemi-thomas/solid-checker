import { createRequire } from "node:module";
import { readFileSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
const ROOT = "/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps";
const M = JSON.parse(readFileSync("/tmp/sc-sweep/rc17-manifest-rebuilt.json", "utf8"));
const PK = ["solid-js", "@solidjs/signals", "@solidjs/web", "@solidjs/router", "@solidjs/vite-plugin", "vite-plugin-solid"];
const rows = [];
for (const p of M.projects) {
  const dir = dirname(join(ROOT, p.root, p.project));
  const req = createRequire(join(dir, "package.json"));
  const v = {};
  for (const k of PK) { try { v[k] = JSON.parse(readFileSync(req.resolve(`${k}/package.json`), "utf8")).version; } catch { v[k] = "-"; } }
  rows.push({ app: p.root, project: p.project, ...v });
}
const w = (s, n) => String(s).padEnd(n);
console.log(w("app/project", 50), w("solid-js", 12), w("signals", 12), w("web", 12), w("router", 14), w("vite-plugin", 14), "vite-plugin-solid");
for (const r of rows) console.log(w(`${r.app}/${r.project}`, 50), w(r["solid-js"], 12), w(r["@solidjs/signals"], 12), w(r["@solidjs/web"], 12), w(r["@solidjs/router"], 14), w(r["@solidjs/vite-plugin"], 14), r["vite-plugin-solid"]);
const bad = [...new Set(rows.filter((r) => r["@solidjs/signals"] !== "2.0.0-rc.17").map((r) => r.app))];
console.log("\nsignals != rc.17 in apps:", bad.join(" "));
