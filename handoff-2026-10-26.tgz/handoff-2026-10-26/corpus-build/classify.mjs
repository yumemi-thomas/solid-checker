import { createRequire } from "node:module";
import { readFileSync } from "node:fs";
const tsPath = process.argv[2]; const ts = createRequire(tsPath)(tsPath.replace(/package\.json$/, ""));
const s = JSON.parse(readFileSync("/tmp/sc-sweep/rc17-sweep-rebuilt-1.json", "utf8"));
const all = s.results.flatMap((r) => r.findings.filter((f) => f.kind === "uncertifiable").map((f) => ({ ...f, app: r.app })));
const files = new Map();
function sf(path) { if (!files.has(path)) { try { files.set(path, ts.createSourceFile(path, readFileSync(path, "utf8"), ts.ScriptTarget.Latest, true, path.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS)); } catch { files.set(path, null); } } return files.get(path); }
function nodeAt(root, pos) { let best = root; (function walk(n) { if (n.getStart() <= pos && pos < n.getEnd()) { best = n; ts.forEachChild(n, walk); } })(root); return best; }
const isFn = (n) => ts.isArrowFunction(n) || ts.isFunctionExpression(n) || ts.isFunctionDeclaration(n) || ts.isMethodDeclaration(n) || ts.isGetAccessor(n) || ts.isSetAccessor(n) || ts.isConstructorDeclaration(n);
function tagName(el) { const t = ts.isJsxSelfClosingElement(el) || ts.isJsxOpeningElement(el) ? el.tagName : ts.isJsxElement(el) ? el.openingElement.tagName : null; return t ? t.getText() : "?"; }
function describe(fn) {
  // What the innermost enclosing function is handed to.
  let p = fn.parent;
  while (p && (ts.isParenthesizedExpression(p) || ts.isAsExpression(p) || ts.isSatisfiesExpression(p) || ts.isNonNullExpression(p))) p = p.parent;
  if (ts.isFunctionDeclaration(fn)) return `function declaration${fn.modifiers?.some((m) => m.kind === ts.SyntaxKind.ExportKeyword) ? " (exported)" : ""}`;
  if (ts.isMethodDeclaration(fn)) return ts.isObjectLiteralExpression(fn.parent) ? "object-literal method" : "class method";
  if (ts.isJsxExpression(p) && ts.isJsxAttribute(p.parent)) { const attr = p.parent; const el = attr.parent.parent; const tag = tagName(el); const kind = /^[a-z]/.test(tag) ? "intrinsic" : "component"; const name = attr.name.getText(); return `JSX attr ${kind} ${/^on[A-Z]/.test(name) ? "on*" : /^ref$/.test(name) ? "ref" : "other"}`; }
  if (ts.isJsxExpression(p) && (ts.isJsxElement(p.parent) || ts.isJsxFragment(p.parent))) { const tag = ts.isJsxElement(p.parent) ? tagName(p.parent) : "<>"; return `JSX child of ${/^[a-z]/.test(tag) ? "intrinsic" : "component"}`; }
  if (ts.isCallExpression(p)) { const callee = p.expression.getText().replace(/\s+/g, ""); const short = callee.length > 40 ? callee.slice(0, 40) + "…" : callee; const kind = ts.isPropertyAccessExpression(p.expression) ? "member call" : "call"; return `arg of ${kind} ${short}`; }
  if (ts.isNewExpression(p)) return `arg of new ${p.expression.getText()}`;
  if (ts.isVariableDeclaration(p)) { const decl = p.parent; const kw = decl.flags & ts.NodeFlags.Const ? "const" : decl.flags & ts.NodeFlags.Let ? "let" : "var"; const stmt = decl.parent; const exported = ts.isVariableStatement(stmt) && stmt.modifiers?.some((m) => m.kind === ts.SyntaxKind.ExportKeyword); const top = ts.isSourceFile(stmt.parent); return `${kw} binding${exported ? " (exported)" : ""}${top ? " (module)" : " (local)"}`; }
  if (ts.isPropertyAssignment(p) || ts.isShorthandPropertyAssignment(p)) return "object-literal property";
  if (ts.isReturnStatement(p)) return "returned";
  if (ts.isBinaryExpression(p) && p.operatorToken.kind === ts.SyntaxKind.EqualsToken) return "assigned";
  if (ts.isArrayLiteralExpression(p)) return "array element";
  if (ts.isExportAssignment(p)) return "export default";
  if (ts.isConditionalExpression(p) || ts.isBinaryExpression(p)) return "operand of expression";
  return ts.SyntaxKind[p.kind];
}
function classify(f) {
  const file = sf(f.primaryLocation.path); if (!file) return "(unparsed)";
  let n = nodeAt(file, f.primaryLocation.startByte);
  // byte offset vs UTF-16: re-anchor by line/column when the text has multibyte chars
  const lc = file.getLineAndCharacterOfPosition(n.getStart()); if (lc.line + 1 !== f.primaryLocation.line) { const pos = file.getPositionOfLineAndCharacter(f.primaryLocation.line - 1, Math.max(0, f.primaryLocation.column - 1)); n = nodeAt(file, pos); }
  let fn = n; while (fn && !isFn(fn)) fn = fn.parent;
  if (!fn) return "module scope";
  const inner = describe(fn);
  let outer = fn.parent; while (outer && !isFn(outer)) outer = outer.parent;
  return outer ? `${inner}  ⟵ in ${describe(outer).split(" (")[0]}` : `${inner}  ⟵ top-level`;
}
for (const id of ["SC2001", "SC1001"]) {
  const xs = all.filter((f) => f.id === id && (id !== "SC1001" || true));
  const c = {}; for (const f of xs) { const k = classify(f); c[k] = (c[k] || 0) + 1; }
  console.log(`\n=== ${id} (${xs.length}) innermost enclosing function → what it is handed to`);
  for (const [k, v] of Object.entries(c).sort((a, b) => b[1] - a[1]).slice(0, 18)) console.log(String(v).padStart(5), k);
}
// SC9012 leaf-callback: which callee is unresolved
const leaf = all.filter((f) => f.id === "SC9012" && /createTrackedEffect|onSettled/.test(f.message));
const lc = {}; for (const f of leaf) { const e = (f.evidence || []).map((x) => x.message).find((m) => /target|callee|resolve|standard/i.test(m)) || f.evidence?.at(-1)?.message || ""; const k = e.replace(/"[^"]*"/g, '"_"').slice(0, 140); lc[k] = (lc[k] || 0) + 1; }
console.log(`\n=== SC9012 leaf callbacks (${leaf.length}) evidence`); for (const [k, v] of Object.entries(lc).sort((a, b) => b[1] - a[1]).slice(0, 8)) console.log(String(v).padStart(5), k);
const leafCallee = {}; for (const f of leaf) { const file = sf(f.primaryLocation.path); if (!file) continue; const n = nodeAt(file, file.getPositionOfLineAndCharacter(f.primaryLocation.line - 1, Math.max(0, f.primaryLocation.column - 1))); let call = n; while (call && !ts.isCallExpression(call)) call = call.parent; const t = call ? call.expression.getText().replace(/\s+/g, "") : "?"; const k = ts.isPropertyAccessExpression(call?.expression ?? n) ? (call.expression.questionDotToken || call.expression.expression.kind === ts.SyntaxKind.ThisKeyword ? "member (optional/this)" : "member call") : /^[a-z]/.test(t) ? "plain call" : t; leafCallee[k] = (leafCallee[k] || 0) + 1; }
console.log(`--- call shape at the finding site`); for (const [k, v] of Object.entries(leafCallee).sort((a, b) => b[1] - a[1]).slice(0, 8)) console.log(String(v).padStart(5), k);
// SC4001 spreads
const sp = all.filter((f) => f.id === "SC4001" && f.analysisContext === "handler-spread-unresolved");
const sc = {}; for (const f of sp) { const file = sf(f.primaryLocation.path); if (!file) continue; const n = nodeAt(file, file.getPositionOfLineAndCharacter(f.primaryLocation.line - 1, Math.max(0, f.primaryLocation.column - 1))); let spread = n; while (spread && !ts.isJsxSpreadAttribute(spread)) spread = spread.parent; const e = spread?.expression; const k = !e ? "?" : ts.isCallExpression(e) ? `call ${e.expression.getText().replace(/\s+/g, "").slice(0, 30)}` : ts.isIdentifier(e) ? `identifier (${e.text === "props" ? "props" : "local"})` : ts.SyntaxKind[e.kind]; sc[k] = (sc[k] || 0) + 1; }
console.log(`\n=== SC4001 handler-spread-unresolved (${sp.length}) spread expression`); for (const [k, v] of Object.entries(sc).sort((a, b) => b[1] - a[1]).slice(0, 10)) console.log(String(v).padStart(5), k);
