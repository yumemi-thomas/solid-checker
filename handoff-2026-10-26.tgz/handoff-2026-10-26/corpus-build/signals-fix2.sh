set -u
C=/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps
PIN=2.0.0-rc.17
export PATH="/opt/homebrew/bin:$PATH"; eval "$(mise env -s zsh)"
# 1. remove the root pnpm-workspace.yaml files the first pass created (untracked)
for a in dashiboard-ui error-menu-web kui spookysoftware-www; do
  (cd "$C/$a" && git ls-files --error-unmatch pnpm-workspace.yaml >/dev/null 2>&1) || rm -f "$C/$a/pnpm-workspace.yaml"
done
# 2. pnpm: override at the install root
pin_pnpm() { # app installdir
  f="$C/$1/$2/pnpm-workspace.yaml"
  if [ -f "$f" ] && grep -q "^overrides:" "$f"; then
    grep -q "@solidjs/signals" "$f" || perl -0pi -e "s/^overrides:\s*\n/overrides:\n  '\@solidjs\/signals': '$PIN'\n/m" "$f"
  else
    printf "\noverrides:\n  '@solidjs/signals': '%s'\n" "$PIN" >> "$f"
  fi
  echo "--- $1: $f"; grep -n -A2 "^overrides:" "$f" | head -4
}
pin_pnpm dashiboard-ui dashiboard-ui
pin_pnpm error-menu-web web
pin_pnpm kui frontend
pin_pnpm spookysoftware-www domains/www
# 3. compass-ui (bun): move the pin into the existing overrides object
node -e '
const fs=require("fs");const f=process.argv[1];const j=JSON.parse(fs.readFileSync(f,"utf8"));
delete j.resolutions; j.overrides={...(j.overrides??{}),"@solidjs/signals":"2.0.0-rc.17"};
fs.writeFileSync(f,JSON.stringify(j,null,2)+"\n");console.log("compass-ui overrides:",JSON.stringify(j.overrides));' "$C/compass-ui/package.json"
# 4/5. reinstall
(cd "$C/compass-ui" && npx -y bun@1.4.0 install --ignore-scripts --minimum-release-age=0 2>&1 | tail -2)
(cd "$C/donegeon-client/web" && npm update @solidjs/signals --ignore-scripts --no-audit --no-fund 2>&1 | tail -2)
(cd "$C/dashiboard-ui/dashiboard-ui" && npx -y pnpm@10.33.2 install --no-frozen-lockfile --ignore-scripts 2>&1 | tail -2)
(cd "$C/error-menu-web/web" && npx -y pnpm@10.33.2 install --no-frozen-lockfile --ignore-scripts 2>&1 | tail -2)
(cd "$C/kui/frontend" && npx -y pnpm@11.25.0 install --no-frozen-lockfile --ignore-scripts 2>&1 | tail -2)
(cd "$C/spookysoftware-www/domains/www" && npx -y pnpm@10.33.2 install --no-frozen-lockfile --ignore-scripts 2>&1 | tail -2)
node /tmp/sc-corpus-build/signals-pin.mjs | tail -3
