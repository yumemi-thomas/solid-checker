// Pass 2: pin the version-table packages each app depends on with exact overrides
// (npm `overrides`, bun/yarn `resolutions`, pnpm-workspace.yaml `overrides`),
// reinstall with the per-manager fixes, and verify solid-js from every manifest project.
import { spawn } from "node:child_process";
import { existsSync, readFileSync, readdirSync, writeFileSync, createWriteStream } from "node:fs";
import { join, dirname, resolve } from "node:path";
const ROOT = resolve("/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps");
const LOGS = "/tmp/sc-corpus-build/logs";
const APPS = JSON.parse(readFileSync("/tmp/sc-corpus-build/apps.json", "utf8"));
const VERSIONS = JSON.parse(readFileSync("/tmp/sc-corpus-build/versions.json", "utf8"));
const MANIFEST = JSON.parse(readFileSync("/tmp/sc-sweep/rc17-manifest-rebuilt.json", "utf8"));
const only = process.argv.slice(2);
function sh(cmd, args, cwd, log, env = {}) {
  return new Promise((res, rej) => {
    log.write(`\n$ ${cmd} ${args.join(" ")}  (cwd ${cwd})\n`);
    const p = spawn(cmd, args, { cwd, env: { ...process.env, CI: "1", ...env }, stdio: ["ignore", "pipe", "pipe"] });
    let tail = ""; const keep = (d) => { const s = d.toString(); log.write(s); tail = (tail + s).slice(-4000); };
    p.stdout.on("data", keep); p.stderr.on("data", keep);
    p.on("close", (code) => code === 0 ? res(tail) : rej(new Error(`${cmd} ${args[0]} exited ${code}\n${tail}`)));
  });
}
function* packageJsons(dir) {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    if (e.name === "node_modules" || e.name === ".git") continue;
    const p = join(dir, e.name);
    if (e.isDirectory()) yield* packageJsons(p); else if (e.name === "package.json") yield p;
  }
}
function usedTablePackages(appDir) {
  const used = new Set();
  for (const file of packageJsons(appDir)) {
    let json; try { json = JSON.parse(readFileSync(file, "utf8")); } catch { continue; }
    for (const s of ["dependencies", "devDependencies", "peerDependencies", "optionalDependencies"]) for (const k of Object.keys(json[s] ?? {})) if (k in VERSIONS) used.add(k);
  }
  // solid-js is also pulled transitively by every @solidjs/* package; pin the core triple whenever any table package is used.
  if (used.size) for (const k of ["solid-js", "@solidjs/web", "@solidjs/signals"]) used.add(k);
  return [...used].sort();
}
function addOverrides(appDir, installDir, pm, used, log) {
  const tool = pm.split("@")[0];
  const pins = Object.fromEntries(used.map((k) => [k, VERSIONS[k]]));
  if (tool === "pnpm") {
    const ws = join(appDir, "pnpm-workspace.yaml");
    let y = existsSync(ws) ? readFileSync(ws, "utf8") : "";
    const lines = used.map((k) => `  '${k}': '${VERSIONS[k]}'`);
    // drop any existing override lines for these packages, then (re)insert under `overrides:`
    y = y.split("\n").filter((l) => !used.some((k) => new RegExp(`^\\s+['"]?${k.replace(/[/@.]/g, (c) => "\\" + c)}['"]?\\s*:`).test(l) && /^\s+/.test(l))).join("\n");
    if (/^overrides:\s*$/m.test(y)) y = y.replace(/^overrides:\s*$/m, `overrides:\n${lines.join("\n")}`);
    else y = y.replace(/\s*$/, "") + `\noverrides:\n${lines.join("\n")}\n`;
    if (!existsSync(ws) && installDir !== ".") { /* pnpm reads pnpm-workspace.yaml from the install root */ }
    const target = installDir === "." ? ws : join(appDir, installDir, "pnpm-workspace.yaml");
    if (target !== ws) { let t = existsSync(target) ? readFileSync(target, "utf8") : ""; t = t.split("\n").filter((l) => !used.some((k) => l.includes(`'${k}'`) || l.includes(`"${k}"`) || l.trim().startsWith(k + ":"))).join("\n"); if (/^overrides:\s*$/m.test(t)) t = t.replace(/^overrides:\s*$/m, `overrides:\n${lines.join("\n")}`); else t = t.replace(/\s*$/, "") + `\noverrides:\n${lines.join("\n")}\n`; writeFileSync(target, t); log.write(`\noverrides -> ${target}\n`); }
    else { writeFileSync(ws, y); log.write(`\noverrides -> ${ws}\n`); }
    return;
  }
  const file = join(appDir, installDir, "package.json");
  const text = readFileSync(file, "utf8"); const json = JSON.parse(text);
  const key = tool === "npm" ? "overrides" : "resolutions";
  json[key] = { ...(json[key] ?? {}), ...pins };
  writeFileSync(file, JSON.stringify(json, null, 2) + (text.endsWith("\n") ? "\n" : ""));
  log.write(`\n${key} -> ${file}: ${JSON.stringify(pins)}\n`);
}
async function install(pm, dir, log) {
  const [tool, ver] = pm.split("@");
  if (tool === "npm") return sh("npm", ["install", "--ignore-scripts", "--no-audit", "--no-fund"], dir, log);
  if (tool === "pnpm") return sh("npx", ["-y", `pnpm@${ver}`, "install", "--no-frozen-lockfile", "--ignore-scripts"], dir, log);
  if (tool === "bun") return sh("npx", ["-y", "bun@1.4.0", "install", "--ignore-scripts", "--minimum-release-age=0"], dir, log);
  if (tool === "yarn") return sh("npx", ["-y", "@yarnpkg/cli-dist@4.18.0", "install", "--no-immutable", "--mode=skip-build"], dir, log, { YARN_NPM_MINIMAL_AGE_GATE: "0", YARN_NODE_LINKER: "node-modules", YARN_ENABLE_IMMUTABLE_INSTALLS: "0", YARN_ENABLE_GLOBAL_CACHE: "0" });
}
function solidFrom(dir, stopAt) {
  let d = dir;
  while (d.startsWith(stopAt)) { const pj = join(d, "node_modules", "solid-js", "package.json"); if (existsSync(pj)) return JSON.parse(readFileSync(pj, "utf8")).version; const parent = dirname(d); if (parent === d) break; d = parent; }
  return null;
}
async function fixApp([name, , , installDir, pm]) {
  const appDir = join(ROOT, name); const log = createWriteStream(join(LOGS, `${name}.fix.log`), { flags: "w" });
  const r = { name, pm };
  try {
    if (!existsSync(join(appDir, ".git"))) throw new Error("not cloned");
    const used = usedTablePackages(appDir); r.pinned = used;
    addOverrides(appDir, installDir, pm, used, log);
    await install(pm, join(appDir, installDir), log);
    r.projects = MANIFEST.projects.filter((p) => p.root === name).map((p) => ({ project: p.project, exists: existsSync(join(appDir, p.project)), solid: solidFrom(dirname(join(appDir, p.project)), appDir) }));
    r.ok = r.projects.length > 0 && r.projects.every((p) => p.exists && p.solid === "2.0.0-rc.17");
  } catch (e) { r.ok = false; r.error = String(e.message).slice(-1200); }
  log.end(); return r;
}
const queue = APPS.filter((a) => only.length === 0 || only.includes(a[0]));
const results = []; let next = 0;
async function worker() { while (next < queue.length) { const r = await fixApp(queue[next++]); results.push(r); console.log(`${r.ok ? "OK  " : "FAIL"} ${r.name} ${JSON.stringify(r.projects?.map((p) => p.solid) ?? [])}${r.error ? "\n     " + r.error.split("\n").filter(Boolean).slice(-3).join(" | ") : ""}`); } }
await Promise.all(Array.from({ length: 5 }, worker));
writeFileSync("/tmp/sc-corpus-build/results-fix.json", JSON.stringify(results.sort((a, b) => a.name.localeCompare(b.name)), null, 1));
console.log(`\n${results.filter((r) => r.ok).length}/${results.length} apps: every manifest project resolves solid-js 2.0.0-rc.17`);
