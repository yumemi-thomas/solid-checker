// Resolve Solid packages the way the checker does (solid-js from the project dir;
// @solidjs/signals from the installed solid-js's real directory), then pin
// @solidjs/signals 2.0.0-rc.17 with an override wherever it resolves elsewhere,
// reinstall, and re-verify.
import { spawn } from "node:child_process";
import { existsSync, readFileSync, writeFileSync, realpathSync, createWriteStream } from "node:fs";
import { join, dirname } from "node:path";
const ROOT = "/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps";
const APPS = JSON.parse(readFileSync("/tmp/sc-corpus-build/apps.json", "utf8"));
const M = JSON.parse(readFileSync("/tmp/sc-sweep/rc17-manifest-rebuilt.json", "utf8"));
const PIN = "2.0.0-rc.17"; const apply = process.argv.includes("--apply");
function findPkg(fromDir, name) { let d = fromDir; while (true) { const pj = join(d, "node_modules", name, "package.json"); if (existsSync(pj)) return { version: JSON.parse(readFileSync(pj, "utf8")).version, dir: realpathSync(dirname(pj)) }; const p = dirname(d); if (p === d) return null; d = p; } }
function resolveAll(projectDir) {
  const solid = findPkg(projectDir, "solid-js");
  const signals = solid ? findPkg(solid.dir, "@solidjs/signals") : null;
  const web = findPkg(projectDir, "@solidjs/web"), router = findPkg(projectDir, "@solidjs/router"), vp = findPkg(projectDir, "@solidjs/vite-plugin"), vps = findPkg(projectDir, "vite-plugin-solid");
  return { solid: solid?.version ?? "-", signals: signals?.version ?? "-", web: web?.version ?? "-", router: router?.version ?? "-", vitePlugin: vp?.version ?? "-", vitePluginSolid: vps?.version ?? "-" };
}
function report() {
  const w = (s, n) => String(s).padEnd(n); const need = new Set();
  console.log(w("app/project", 52), w("solid-js", 12), w("signals", 12), w("web", 12), w("router", 14), w("vite-plugin", 14), "vite-plugin-solid");
  for (const p of M.projects) { const r = resolveAll(dirname(join(ROOT, p.root, p.project))); console.log(w(`${p.root}/${p.project}`, 52), w(r.solid, 12), w(r.signals, 12), w(r.web, 12), w(r.router, 14), w(r.vitePlugin, 14), r.vitePluginSolid); if (r.signals !== PIN) need.add(p.root); }
  return need;
}
function sh(cmd, args, cwd, log, env = {}) { return new Promise((res, rej) => { log.write(`\n$ ${cmd} ${args.join(" ")} (cwd ${cwd})\n`); const p = spawn(cmd, args, { cwd, env: { ...process.env, CI: "1", ...env }, stdio: ["ignore", "pipe", "pipe"] }); let tail = ""; const k = (d) => { const s = d.toString(); log.write(s); tail = (tail + s).slice(-3000); }; p.stdout.on("data", k); p.stderr.on("data", k); p.on("close", (c) => c === 0 ? res() : rej(new Error(`${cmd} exited ${c}\n${tail}`))); }); }
function addOverride(appDir, installDir, pm, log) {
  const tool = pm.split("@")[0];
  if (tool === "pnpm") {
    const ws = join(appDir, "pnpm-workspace.yaml"); let y = existsSync(ws) ? readFileSync(ws, "utf8") : "";
    if (/@solidjs\/signals['"]?\s*:/.test(y)) y = y.replace(/^(\s+['"]?@solidjs\/signals['"]?\s*:\s*).*$/m, `$1'${PIN}'`);
    else if (/^overrides:\s*$/m.test(y)) y = y.replace(/^overrides:\s*$/m, `overrides:\n  '@solidjs/signals': '${PIN}'`);
    else y = y.replace(/\s*$/, "") + `\noverrides:\n  '@solidjs/signals': '${PIN}'\n`;
    writeFileSync(ws, y); log.write(`override -> ${ws}\n`); return;
  }
  const file = join(appDir, installDir, "package.json"); const text = readFileSync(file, "utf8"); const json = JSON.parse(text);
  const key = tool === "npm" ? "overrides" : "resolutions"; json[key] = { ...(json[key] ?? {}), "@solidjs/signals": PIN };
  writeFileSync(file, JSON.stringify(json, null, 2) + (text.endsWith("\n") ? "\n" : "")); log.write(`${key} -> ${file}\n`);
}
async function install(pm, dir, log) {
  const [tool, ver] = pm.split("@");
  if (tool === "npm") return sh("npm", ["install", "--ignore-scripts", "--no-audit", "--no-fund"], dir, log);
  if (tool === "pnpm") return sh("npx", ["-y", `pnpm@${ver}`, "install", "--no-frozen-lockfile", "--ignore-scripts"], dir, log);
  if (tool === "bun") return sh("npx", ["-y", "bun@1.4.0", "install", "--ignore-scripts", "--minimum-release-age=0"], dir, log);
  if (tool === "yarn") return sh("npx", ["-y", "@yarnpkg/cli-dist@4.18.0", "install", "--no-immutable", "--mode=skip-build"], dir, log, { YARN_NPM_MINIMAL_AGE_GATE: "0", YARN_NODE_LINKER: "node-modules", YARN_ENABLE_IMMUTABLE_INSTALLS: "0", YARN_ENABLE_GLOBAL_CACHE: "0" });
}
const need = report();
console.log("\nsignals != rc.17:", [...need].join(" ") || "(none)");
if (apply && need.size) {
  const queue = APPS.filter((a) => need.has(a[0])); let next = 0; const out = [];
  async function worker() { while (next < queue.length) { const [name, , , installDir, pm] = queue[next++]; const log = createWriteStream(join("/tmp/sc-corpus-build/logs", `${name}.signals.log`)); try { addOverride(join(ROOT, name), installDir, pm, log); await install(pm, join(ROOT, name, installDir), log); out.push(`done ${name}`); } catch (e) { out.push(`FAIL ${name}: ${e.message.split("\n").slice(-2).join(" | ")}`); } log.end(); console.log(out.at(-1)); } }
  await Promise.all(Array.from({ length: 5 }, worker));
  console.log("\n--- after ---"); const still = report(); console.log("\nsignals != rc.17:", [...still].join(" ") || "(none)");
}
