// Pass 3: no version patching. Restore every file pass 1 changed from the pinned
// commit, install from the repo's own lockfile with lifecycle scripts disabled,
// and record which solid-js each manifest project resolves.
import { spawn, execFileSync } from "node:child_process";
import { existsSync, readFileSync, writeFileSync, createWriteStream, mkdirSync } from "node:fs";
import { join, dirname, resolve } from "node:path";
const ROOT = resolve("/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps");
const LOGS = "/tmp/sc-corpus-build/logs";
const APPS = JSON.parse(readFileSync("/tmp/sc-corpus-build/apps.json", "utf8"));
const MANIFEST = JSON.parse(readFileSync("/tmp/sc-sweep/rc17-manifest-rebuilt.json", "utf8"));
const only = process.argv.slice(2);
function sh(cmd, args, cwd, log, env = {}) {
  return new Promise((res, rej) => {
    log.write(`\n$ ${cmd} ${args.join(" ")}  (cwd ${cwd})\n`);
    const p = spawn(cmd, args, { cwd, env: { ...process.env, CI: "1", ...env }, stdio: ["ignore", "pipe", "pipe"] });
    let tail = ""; const keep = (d) => { const s = d.toString(); log.write(s); tail = (tail + s).slice(-4000); };
    p.stdout.on("data", keep); p.stderr.on("data", keep);
    p.on("close", (code) => code === 0 ? res(tail) : rej(new Error(`${cmd} ${args[0]} exited ${code}\n${tail}`)));
  });
}
function restore(appDir, log) {
  // Every tracked file pass 1 or an install changed is rewritten from the commit (no checkout/reset).
  const changed = execFileSync("git", ["diff", "--name-only", "HEAD"], { cwd: appDir, encoding: "utf8" }).split("\n").filter(Boolean);
  for (const f of changed) {
    const bytes = execFileSync("git", ["show", `HEAD:${f}`], { cwd: appDir, maxBuffer: 1 << 28 });
    writeFileSync(join(appDir, f), bytes);
  }
  log.write(`\nrestored ${changed.length} file(s): ${changed.join(", ")}\n`);
  return changed;
}
async function install(pm, dir, log) {
  const [tool, ver] = pm.split("@");
  if (tool === "npm") return sh("npm", ["install", "--ignore-scripts", "--no-audit", "--no-fund"], dir, log);
  if (tool === "pnpm") {
    try { return await sh("npx", ["-y", `pnpm@${ver}`, "install", "--frozen-lockfile", "--ignore-scripts"], dir, log); }
    catch (e) { log.write("\nfrozen lockfile refused; retrying without\n"); return sh("npx", ["-y", `pnpm@${ver}`, "install", "--no-frozen-lockfile", "--ignore-scripts"], dir, log); }
  }
  if (tool === "bun") return sh("npx", ["-y", "bun@1.4.0", "install", "--ignore-scripts", "--minimum-release-age=0"], dir, log);
  if (tool === "yarn") return sh("npx", ["-y", "@yarnpkg/cli-dist@4.18.0", "install", "--no-immutable", "--mode=skip-build"], dir, log, { YARN_NPM_MINIMAL_AGE_GATE: "0", YARN_NODE_LINKER: "node-modules", YARN_ENABLE_IMMUTABLE_INSTALLS: "0", YARN_ENABLE_GLOBAL_CACHE: "0" });
}
function solidFrom(dir, stopAt) {
  let d = dir;
  while (d.startsWith(stopAt)) { const pj = join(d, "node_modules", "solid-js", "package.json"); if (existsSync(pj)) return JSON.parse(readFileSync(pj, "utf8")).version; const parent = dirname(d); if (parent === d) break; d = parent; }
  return null;
}
async function run([name, repo, commit, installDir, pm]) {
  const appDir = join(ROOT, name); const log = createWriteStream(join(LOGS, `${name}.plain.log`), { flags: "w" });
  const r = { name, pm, installDir };
  try {
    if (!existsSync(join(appDir, ".git"))) {
      mkdirSync(appDir, { recursive: true });
      await sh("git", ["init", "-q"], appDir, log); await sh("git", ["fetch", "--depth", "1", "-q", repo, commit], appDir, log); await sh("git", ["checkout", "-q", "FETCH_HEAD"], appDir, log);
    }
    r.restored = restore(appDir, log);
    await install(pm, join(appDir, installDir), log);
    r.projects = MANIFEST.projects.filter((p) => p.root === name).map((p) => ({ project: p.project, exists: existsSync(join(appDir, p.project)), solid: solidFrom(dirname(join(appDir, p.project)), appDir) }));
    r.installOk = true;
    r.ok = r.projects.length > 0 && r.projects.every((p) => p.exists && p.solid === "2.0.0-rc.17");
  } catch (e) { r.installOk = false; r.ok = false; r.error = String(e.message).slice(-1200); }
  log.end(); return r;
}
const queue = APPS.filter((a) => only.length === 0 || only.includes(a[0]));
const results = []; let next = 0;
async function worker() { while (next < queue.length) { const r = await run(queue[next++]); results.push(r); console.log(`${r.ok ? "OK  " : "FAIL"} ${r.name} ${JSON.stringify(r.projects?.map((p) => p.solid) ?? [])}${r.error ? "\n     " + r.error.split("\n").filter(Boolean).slice(-3).join(" | ") : ""}`); } }
await Promise.all(Array.from({ length: 5 }, worker));
writeFileSync("/tmp/sc-corpus-build/results-plain.json", JSON.stringify(results.sort((a, b) => a.name.localeCompare(b.name)), null, 1));
console.log(`\n${results.filter((r) => r.ok).length}/${results.length} apps: every manifest project resolves solid-js 2.0.0-rc.17`);
