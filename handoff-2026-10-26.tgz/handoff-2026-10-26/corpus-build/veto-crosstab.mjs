import { createRequire } from "node:module"; import { readFileSync, existsSync } from "node:fs"; import { execFileSync } from "node:child_process"; import { join, dirname } from "node:path";
const tsPath = "/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps/ai-memory-ui/node_modules/typescript/package.json"; const ts = createRequire(tsPath)(tsPath.replace(/package\.json$/, ""));
const ROOT = "/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps";
const s = JSON.parse(readFileSync("/tmp/sc-sweep/rc17-sweep-rebuilt-3.json", "utf8"));
const files = new Map(); const sf = (p) => { if (!files.has(p)) files.set(p, ts.createSourceFile(p, readFileSync(p, "utf8"), ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX)); return files.get(p); };
function nodeAt(root, pos) { let best = root; (function w(n) { if (n.getStart() <= pos && pos < n.getEnd()) { best = n; ts.forEachChild(n, w); } })(root); return best; }
const isFn = (n) => ts.isArrowFunction(n) || ts.isFunctionExpression(n) || ts.isFunctionDeclaration(n) || ts.isMethodDeclaration(n);
function intrinsicHandler(f) { const file = sf(f.primaryLocation.path); let n = nodeAt(file, file.getPositionOfLineAndCharacter(f.primaryLocation.line - 1, Math.max(0, f.primaryLocation.column - 1))); while (n && !isFn(n)) n = n.parent; if (!n) return false; let p = n.parent; while (p && (ts.isParenthesizedExpression(p) || ts.isAsExpression(p))) p = p.parent; if (!(ts.isJsxExpression(p) && ts.isJsxAttribute(p.parent))) return false; const attr = p.parent; const el = attr.parent.parent; const tag = (ts.isJsxOpeningElement(el) || ts.isJsxSelfClosingElement(el)) ? el.tagName.getText() : "?"; return /^[a-z]/.test(tag) && /^on[A-Z]/.test(attr.name.getText()); }
// per project: dispatch/click sites in files the project program likely includes (same root dir of the tsconfig), vs SC2001/SC1001 obligations in intrinsic handlers
const rows = [];
for (const r of s.results) {
  const projDir = dirname(join(r.root, r.project));
  let dispatch = 0; try { dispatch = execFileSync("rg", ["-c", "--no-ignore", "-g", "!node_modules", "-g", "*.{ts,tsx}", "\\.dispatchEvent\\(|\\.click\\(\\)", projDir], { encoding: "utf8" }).split("\n").filter(Boolean).reduce((a, l) => a + Number(l.split(":").pop()), 0); } catch { dispatch = 0; }
  const unc = r.findings.filter((f) => f.kind === "uncertifiable" && (f.id === "SC2001" || f.id === "SC1001"));
  const inHandler = unc.filter((f) => { try { return intrinsicHandler(f); } catch { return false; } }).length;
  const viol = r.findings.filter((f) => f.kind === "violation" && (f.id === "SC2001" || f.id === "SC1001")).length;
  rows.push({ p: `${r.app}/${r.project}`, dispatch, inHandler, unc: unc.length, viol });
}
rows.sort((a, b) => b.inHandler - a.inHandler);
console.log("project".padEnd(52), "dispatch-sites", "unc-in-intrinsic-handler", "SC2001+SC1001 unc", "viol");
for (const r of rows) console.log(r.p.padEnd(52), String(r.dispatch).padStart(14), String(r.inHandler).padStart(24), String(r.unc).padStart(17), String(r.viol).padStart(5));
