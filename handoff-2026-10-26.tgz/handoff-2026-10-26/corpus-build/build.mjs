import { execFile, spawn } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync, statSync, createWriteStream } from "node:fs";
import { join, dirname, resolve } from "node:path";
const ROOT = resolve("/Users/thomas.guehenneux/EDF/Yumemi/GitHub/solid-checker-rc17-corpus/apps");
const LOGS = "/tmp/sc-corpus-build/logs";
const APPS = JSON.parse(readFileSync("/tmp/sc-corpus-build/apps.json", "utf8"));
const VERSIONS = JSON.parse(readFileSync("/tmp/sc-corpus-build/versions.json", "utf8"));
const MANIFEST = JSON.parse(readFileSync("/tmp/sc-sweep/rc17-manifest-rebuilt.json", "utf8"));
const only = process.argv.slice(2);
mkdirSync(ROOT, { recursive: true });

function sh(cmd, args, cwd, log, env = {}) {
  return new Promise((res, rej) => {
    log.write(`\n$ ${cmd} ${args.join(" ")}  (cwd ${cwd})\n`);
    const p = spawn(cmd, args, { cwd, env: { ...process.env, CI: "1", ...env }, stdio: ["ignore", "pipe", "pipe"] });
    let tail = "";
    const keep = (d) => { const s = d.toString(); log.write(s); tail = (tail + s).slice(-4000); };
    p.stdout.on("data", keep); p.stderr.on("data", keep);
    p.on("close", (code) => code === 0 ? res(tail) : rej(new Error(`${cmd} ${args[0]} exited ${code}\n${tail}`)));
  });
}
function* packageJsons(dir) {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    if (e.name === "node_modules" || e.name === ".git") continue;
    const p = join(dir, e.name);
    if (e.isDirectory()) yield* packageJsons(p);
    else if (e.name === "package.json") yield p;
  }
}
function styled(old, v) {
  if (typeof old !== "string") return null;
  if (/^(workspace:|catalog:|npm:|link:|file:|github:|git\+|https?:)/.test(old)) return null;
  // Exact pin: a caret on a prerelease floats to the next rc (rc.18 was published 2026-10-23).
  return v;
}
function patchObject(obj, changes, where) {
  if (!obj || typeof obj !== "object") return;
  for (const [k, old] of Object.entries(obj)) {
    if (!(k in VERSIONS)) continue;
    const nv = styled(old, VERSIONS[k]);
    if (nv && nv !== old) { obj[k] = nv; changes.push(`${where}: ${k} ${old} -> ${nv}`); }
  }
}
function patchPackageJsons(appDir, log) {
  const changes = [];
  for (const file of packageJsons(appDir)) {
    const text = readFileSync(file, "utf8");
    let json; try { json = JSON.parse(text); } catch { continue; }
    const rel = file.slice(appDir.length + 1);
    for (const section of ["dependencies", "devDependencies", "peerDependencies", "optionalDependencies", "overrides", "resolutions"]) patchObject(json[section], changes, `${rel} ${section}`);
    if (json.pnpm?.overrides) patchObject(json.pnpm.overrides, changes, `${rel} pnpm.overrides`);
    if (json.workspaces && !Array.isArray(json.workspaces) && json.workspaces.catalog) patchObject(json.workspaces.catalog, changes, `${rel} workspaces.catalog`);
    if (json.catalog) patchObject(json.catalog, changes, `${rel} catalog`);
    const before = changes.length;
    if (changes.some((c) => c.startsWith(rel + " "))) writeFileSync(file, JSON.stringify(json, null, 2) + (text.endsWith("\n") ? "\n" : ""));
  }
  // pnpm catalogs in pnpm-workspace.yaml: patch `name: version` lines for table packages.
  const ws = join(appDir, "pnpm-workspace.yaml");
  if (existsSync(ws)) {
    let y = readFileSync(ws, "utf8"); const orig = y;
    for (const [k, v] of Object.entries(VERSIONS)) {
      const re = new RegExp(`^(\\s*['"]?${k.replace(/[/@.]/g, (c) => "\\" + c)}['"]?\\s*:\\s*)(['"]?)([\\^~]?)([^'"\\s#]+)(['"]?)\\s*$`, "gm");
      y = y.replace(re, (m, pre, q1, caret, _old, q2) => { changes.push(`pnpm-workspace.yaml: ${k} ${_old} -> ${caret}${v}`); return `${pre}${q1}${caret}${v}${q2}`; });
    }
    if (y !== orig) writeFileSync(ws, y);
  }
  log.write(`\npatched ${changes.length} entries:\n${changes.map((c) => "  " + c).join("\n")}\n`);
  return changes;
}
async function install(pm, dir, log) {
  const [tool, ver] = pm.split("@");
  if (tool === "npm") return sh("npm", ["install", "--ignore-scripts", "--no-audit", "--no-fund"], dir, log);
  if (tool === "pnpm") return sh("npx", ["-y", `pnpm@${ver}`, "install", "--no-frozen-lockfile", "--ignore-scripts"], dir, log);
  if (tool === "bun") return sh("npx", ["-y", "bun@1.4.0", "install", "--ignore-scripts", "--minimum-release-age=0"], dir, log);
  if (tool === "yarn") return sh("npx", ["-y", "@yarnpkg/cli-dist@4.18.0", "install", "--no-immutable", "--mode=skip-build"], dir, log, { YARN_NPM_MINIMAL_AGE_GATE: "0", YARN_NODE_LINKER: "node-modules", YARN_ENABLE_IMMUTABLE_INSTALLS: "0", YARN_ENABLE_GLOBAL_CACHE: "0" });
  throw new Error("unknown pm " + pm);
}
function solidVersionFrom(dir) {
  let d = dir;
  while (true) {
    const pj = join(d, "node_modules", "solid-js", "package.json");
    if (existsSync(pj)) return { version: JSON.parse(readFileSync(pj, "utf8")).version, at: pj };
    const parent = dirname(d); if (parent === d || !d.startsWith(ROOT)) return null; d = parent;
  }
}
async function buildApp([name, repo, commit, installDir, pm]) {
  const appDir = join(ROOT, name);
  const log = createWriteStream(join(LOGS, `${name}.log`), { flags: "w" });
  const result = { name, pm, installDir };
  try {
    if (!existsSync(join(appDir, ".git"))) {
      mkdirSync(appDir, { recursive: true });
      await sh("git", ["init", "-q"], appDir, log);
      await sh("git", ["fetch", "--depth", "1", "-q", repo, commit], appDir, log);
      await sh("git", ["checkout", "-q", "FETCH_HEAD"], appDir, log);
    }
    result.patched = patchPackageJsons(appDir, log).length;
    const dir = join(appDir, installDir);
    await install(pm, dir, log);
    result.projects = MANIFEST.projects.filter((p) => p.root === name).map((p) => { const pd = dirname(join(appDir, p.project)); const v = existsSync(join(appDir, p.project)) ? solidVersionFrom(pd) : null; return { project: p.project, exists: existsSync(join(appDir, p.project)), solid: v?.version ?? null }; });
    result.solid = [...new Set(result.projects.map((p) => p.solid))].join(",");
    result.ok = result.projects.length > 0 && result.projects.every((p) => p.exists && p.solid === "2.0.0-rc.17");
  } catch (e) { result.ok = false; result.error = String(e.message).slice(-1500); }
  log.end();
  return result;
}
const queue = APPS.filter((a) => only.length === 0 || only.includes(a[0]));
const results = []; let next = 0;
async function worker() { while (next < queue.length) { const app = queue[next++]; const r = await buildApp(app); results.push(r); console.log(`${r.ok ? "OK  " : "FAIL"} ${r.name} solid-js=${r.solid} patched=${r.patched ?? "-"}${r.error ? "\n     " + r.error.split("\n").slice(-3).join(" | ") : ""}`); } }
await Promise.all(Array.from({ length: 5 }, worker));
writeFileSync(process.env.RESULTS ?? "/tmp/sc-corpus-build/results.json", JSON.stringify(results.sort((a, b) => a.name.localeCompare(b.name)), null, 1));
console.log(`\n${results.filter((r) => r.ok).length}/${results.length} apps resolve solid-js 2.0.0-rc.17`);
